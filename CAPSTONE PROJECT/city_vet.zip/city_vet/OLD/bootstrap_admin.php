<?php
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/config/db_connection.php';
require_once __DIR__ . '/api/system/audit_helper.php';

$isJson = (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false)
    || (isset($_GET['format']) && $_GET['format'] === 'json');

$existingAdmin = $conn->query("SELECT User_ID FROM users WHERE Role_ID = 1 LIMIT 1");
if ($existingAdmin && $existingAdmin->num_rows > 0) {
    http_response_code(403);
    if ($isJson) {
        header("Content-Type: application/json; charset=UTF-8");
        echo json_encode(["status" => "error", "message" => "Administrator setup is permanently locked. An administrator account already exists."]);
    } else {
        echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'><title>Setup Locked - City Vet</title><style>body{font-family:system-ui,-apple-system,sans-serif;background:#f8fafc;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:1rem;box-sizing:border-box}.card{background:#fff;padding:2.5rem;border-radius:12px;box-shadow:0 4px 6px -1px rgba(0,0,0,0.1);max-width:480px;width:100%;text-align:center}.card h1{color:#dc2626;font-size:1.5rem;margin:0 0 1rem}.card p{color:#475569;line-height:1.6;margin:0 0 1rem}.btn{display:inline-block;margin-top:1rem;padding:0.75rem 1.5rem;background:#0d9488;color:#fff;text-decoration:none;border-radius:6px;font-weight:600}</style></head><body><div class='card'><h1>Setup Locked</h1><p>An administrator account already exists in the system. The bootstrap utility has been permanently locked for security.</p><p><strong>Please delete <code>bootstrap_admin.php</code> from your server immediately.</strong></p><a href='index.html' class='btn'>Go to Login</a></div></body></html>";
    }
    exit();
}

$error = '';
$success = false;
$createdUsername = '';
$createdEmail = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $postData = [];
    if (!empty($raw)) {
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            $postData = $decoded;
        }
    }
    if (empty($postData)) {
        $postData = $_POST;
    }

    $token = $postData['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!validateCsrfToken($token)) {
        $error = "Invalid or expired security token. Please refresh and try again.";
    } else {
        $username = trim((string)($postData['username'] ?? ''));
        $email = strtolower(trim((string)($postData['email'] ?? '')));
        $phone = trim((string)($postData['phone_number'] ?? ''));
        $password = (string)($postData['password'] ?? '');
        $confirmPassword = (string)($postData['confirm_password'] ?? '');

        if (strlen($username) < 3 || strlen($username) > 50) {
            $error = "Username must be between 3 and 50 characters.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Please provide a valid email address.";
        } elseif (!validateStrongPassword($password)) {
            $error = "Password must be at least 8 characters long and include an uppercase letter, a lowercase letter, a number, and a special character.";
        } elseif ($password !== $confirmPassword) {
            $error = "Passwords do not match.";
        } else {
            $conn->begin_transaction();
            try {
                $checkLock = $conn->query("SELECT User_ID FROM users WHERE Role_ID = 1 LIMIT 1 FOR UPDATE");
                if ($checkLock && $checkLock->num_rows > 0) {
                    $conn->rollback();
                    $error = "Administrator already exists.";
                } else {
                    $checkDup = $conn->prepare("SELECT User_ID FROM users WHERE LOWER(Email) = ? OR LOWER(Username) = ? LIMIT 1");
                    $lowUser = strtolower($username);
                    $checkDup->bind_param("ss", $email, $lowUser);
                    $checkDup->execute();
                    if ($checkDup->get_result()->num_rows > 0) {
                        $checkDup->close();
                        $conn->rollback();
                        $error = "A user with this email or username already exists.";
                    } else {
                        $checkDup->close();
                        $hash = password_hash($password, PASSWORD_BCRYPT);
                        $ins = $conn->prepare("INSERT INTO users (Role_ID, Username, Password_Hash, Email, Phone_number, Status, Is_Online, Created_At) VALUES (1, ?, ?, ?, ?, 'active', 0, NOW())");
                        $ins->bind_param("ssss", $username, $hash, $email, $phone);
                        $ins->execute();
                        $adminId = $conn->insert_id;
                        $ins->close();

                        auditLog($conn, $adminId, "Bootstrap Admin Initialized", "users", $adminId, [
                            'event_type' => 'security',
                            'outcome' => 'success',
                            'metadata' => ['username' => $username, 'email' => $email]
                        ]);

                        $conn->commit();
                        $success = true;
                        $createdUsername = $username;
                        $createdEmail = $email;
                    }
                }
            } catch (Exception $e) {
                $conn->rollback();
                $error = "An error occurred while creating administrator: " . $e->getMessage();
            }
        }
    }

    if ($isJson) {
        header("Content-Type: application/json; charset=UTF-8");
        if ($success) {
            echo json_encode([
                "status" => "success",
                "message" => "Administrator account successfully created. Please remove bootstrap_admin.php immediately.",
                "username" => $createdUsername,
                "email" => $createdEmail
            ]);
        } else {
            http_response_code(400);
            echo json_encode(["status" => "error", "message" => $error]);
        }
        exit();
    }
}

$csrfToken = getCsrfToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Initial Administrator Setup - City Vet</title>
    <style>
        body {
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background-color: #f1f5f9;
            color: #1e293b;
            margin: 0;
            padding: 2rem 1rem;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            box-sizing: border-box;
        }
        .container {
            width: 100%;
            max-width: 520px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #0f766e 0%, #14b8a6 100%);
            color: #ffffff;
            padding: 2rem 2rem 1.5rem;
            text-align: center;
        }
        .header h1 {
            margin: 0 0 0.5rem;
            font-size: 1.5rem;
            font-weight: 700;
        }
        .header p {
            margin: 0;
            color: #ccfbf1;
            font-size: 0.9rem;
        }
        .body {
            padding: 2rem;
        }
        .alert-error {
            background: #fef2f2;
            border: 1px solid #fecaca;
            color: #991b1b;
            padding: 0.875rem 1rem;
            border-radius: 8px;
            font-size: 0.875rem;
            margin-bottom: 1.5rem;
        }
        .alert-success {
            background: #f0fdf4;
            border: 1px solid #bbf7d0;
            color: #166534;
            padding: 1.25rem 1rem;
            border-radius: 8px;
            font-size: 0.95rem;
            line-height: 1.6;
        }
        .form-group {
            margin-bottom: 1.25rem;
        }
        label {
            display: block;
            margin-bottom: 0.375rem;
            font-size: 0.875rem;
            font-weight: 600;
            color: #334155;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 0.65rem 0.875rem;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 0.95rem;
            box-sizing: border-box;
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }
        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #0d9488;
            box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.15);
        }
        .help-text {
            font-size: 0.75rem;
            color: #64748b;
            margin-top: 0.35rem;
        }
        .btn-submit {
            width: 100%;
            background-color: #0d9488;
            color: #ffffff;
            border: none;
            border-radius: 6px;
            padding: 0.8rem 1rem;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s ease;
            margin-top: 0.5rem;
        }
        .btn-submit:hover {
            background-color: #0f766e;
        }
        .btn-login {
            display: inline-block;
            margin-top: 1.25rem;
            background-color: #0d9488;
            color: #ffffff;
            padding: 0.75rem 1.5rem;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
        }
        .critical-warning {
            background: #fffbeb;
            border: 1px solid #fef3c7;
            color: #92400e;
            padding: 0.875rem;
            border-radius: 6px;
            font-size: 0.85rem;
            margin-top: 1rem;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>City Vet Management System</h1>
        <p>Initial Administrator Setup</p>
    </div>
    <div class="body">
        <?php if ($success): ?>
            <div class="alert-success">
                <strong>Administrator Account Created!</strong>
                <p>Username: <strong><?php echo htmlspecialchars($createdUsername); ?></strong><br>Email: <strong><?php echo htmlspecialchars($createdEmail); ?></strong></p>
                <div class="critical-warning">
                    <strong>CRITICAL SECURITY ACTION REQUIRED:</strong><br>
                    Delete <code>bootstrap_admin.php</code> from your server root now before launching the site.
                </div>
                <div style="text-align: center;">
                    <a href="index.html" class="btn-login">Go to Login</a>
                </div>
            </div>
        <?php else: ?>
            <?php if (!empty($error)): ?>
                <div class="alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            <form method="POST" action="bootstrap_admin.php">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                <div class="form-group">
                    <label for="username">Administrator Username</label>
                    <input type="text" id="username" name="username" required value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" placeholder="admin">
                    <div class="help-text">Between 3 and 50 characters</div>
                </div>
                <div class="form-group">
                    <label for="email">Administrator Email</label>
                    <input type="email" id="email" name="email" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" placeholder="admin@example.com">
                    <div class="help-text">Used for sign-in and system notifications</div>
                </div>
                <div class="form-group">
                    <label for="phone_number">Phone Number</label>
                    <input type="text" id="phone_number" name="phone_number" value="<?php echo htmlspecialchars($_POST['phone_number'] ?? ''); ?>" placeholder="09123456789">
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required placeholder="Enter strong password">
                    <div class="help-text">Minimum 8 characters, with uppercase, lowercase, number, and special character</div>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" required placeholder="Re-enter password">
                </div>
                <button type="submit" class="btn-submit">Create Primary Administrator</button>
            </form>
        <?php endif; ?>
    </div>
</div>
</body>
</html>