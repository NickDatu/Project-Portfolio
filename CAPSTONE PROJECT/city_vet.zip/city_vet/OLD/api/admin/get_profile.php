<?php
require_once '../../config/session.php';
header("Content-Type: application/json; charset=UTF-8");

require_once '../../config/db_connection.php'; 

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || (int)$_SESSION['role_id'] !== 1) {
    http_response_code(403);
    echo json_encode(["status" => "error", "error" => "Unauthorized: Administrator access only"]);
    exit();
}

$user_id = (int)$_SESSION['user_id'];
$query = $conn->prepare("SELECT Username, Email, Phone_number FROM users WHERE User_ID = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["status" => "error", "error" => "Profile not found"]);
    exit();
}

$admin = $result->fetch_assoc();
echo json_encode([
    "status" => "success",
    "username" => $admin['Username'],
    "email" => $admin['Email'],
    "phone" => $admin['Phone_number'] ?? '',
    "phone_number" => $admin['Phone_number'] ?? ''
]);