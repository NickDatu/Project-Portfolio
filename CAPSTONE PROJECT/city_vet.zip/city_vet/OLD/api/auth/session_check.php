<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once '../../config/session.php';

header("Content-Type: application/json; charset=UTF-8");

$timeoutSeconds = 30 * 60;

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "User not logged in"]);
    exit();
}

$shouldTouch = ($_GET['touch'] ?? '1') !== '0';
if ($shouldTouch) {
    $_SESSION['last_activity'] = time();
    require_once '../../config/db_connection.php';
    if (isset($conn) && $conn instanceof mysqli && !$conn->connect_error) {
        $presence = $conn->prepare("UPDATE users SET Is_Online = 1, Last_Activity = NOW() WHERE User_ID = ?");
        if ($presence) {
            $presence->bind_param("i", $_SESSION['user_id']);
            $presence->execute();
            $presence->close();
        }
    }
}

$allowedPages = [
    'admin' => 1,
    'vet' => 2,
    'owner' => 3,
    'staff' => 4,
];

$required_role = null;
if (isset($_GET['page']) && isset($allowedPages[strtolower(trim($_GET['page']))])) {
    $required_role = $allowedPages[strtolower(trim($_GET['page']))];
}

if ($required_role !== null) {
    if (!isset($_SESSION['role_id']) || (int)$_SESSION['role_id'] !== $required_role) {
        http_response_code(403);
        echo json_encode(["status" => "error", "message" => "Access denied. You do not have permission for this dashboard."]);
        exit();
    }
}

$displayName = isset($_SESSION['username']) ? $_SESSION['username'] : "User";

echo json_encode([
    "status" => "success",
    "user" => [
        "id" => (int)$_SESSION['user_id'],
        "name" => $displayName,
        "role" => (int)$_SESSION['role_id']
    ],
    "csrf_token" => getCsrfToken(),
    "timeout_minutes" => (int)($timeoutSeconds / 60)
]);
