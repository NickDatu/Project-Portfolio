<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../system/audit_helper.php';

if (isset($_SESSION['user_id'])) {
    $userId = (int)$_SESSION['user_id'];
    $presence = $conn->prepare("UPDATE users SET Is_Online = 0, Last_Activity = NULL WHERE User_ID = ?");
    if ($presence) {
        $presence->bind_param("i", $userId);
        $presence->execute();
        $presence->close();
    }
    auditLog($conn, $userId, "Logout", "sessions", 0, ['event_type' => 'security']);
}

$_SESSION = [];
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
session_destroy();

$expectsJson = isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false;

if ($expectsJson) {
    header("Content-Type: application/json");
    echo json_encode(["status" => "success", "message" => "Logged out successfully."]);
} else {
    header("Location: ../../login.html");
}
exit();
