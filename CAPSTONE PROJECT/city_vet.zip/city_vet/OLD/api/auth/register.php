<?php
header("Content-Type: application/json; charset=UTF-8");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Referrer-Policy: strict-origin-when-cross-origin");

require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../notifications/notify.php';
require_once '../system/audit_helper.php';

$data = json_decode(file_get_contents("php://input"), true);
if (is_null($data)) { $data = $_POST; }

if (empty($data['email']) || empty($data['password']) || empty($data['fname']) || empty($data['lname'])) {
    echo json_encode(["status" => "error", "message" => "Please fill in all required fields."]);
    exit();
}

if (($data['password'] ?? '') !== ($data['confirm_password'] ?? '')) {
    echo json_encode(["status" => "error", "message" => "Password confirmation does not match."]);
    exit();
}

$password = (string)($data['password'] ?? '');
if (!validateStrongPassword($password)) {
    echo json_encode([
        "status" => "error",
        "message" => "Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character."
    ]);
    exit();
}

$check = $conn->prepare("SELECT User_ID FROM users WHERE Email = ?");
$check->bind_param("s", $data['email']); 
$check->execute();
if ($check->get_result()->num_rows > 0) {
    echo json_encode(["status" => "error", "message" => "This Email is already registered."]);
    $check->close();
    $conn->close();
    exit();
}
$check->close();

$conn->begin_transaction();
try {
    $hashed_pass = password_hash($password, PASSWORD_BCRYPT);
    $role_id = 3;
    
    $stmt1 = $conn->prepare("INSERT INTO users (Role_ID, Username, Password_Hash, Email, Phone_number) VALUES (?, ?, ?, ?, ?)");
    $stmt1->bind_param("issss", $role_id, $data['email'], $hashed_pass, $data['email'], $data['phone']);
    if (!$stmt1->execute()) {
        throw new Exception("Failed to create user account.");
    }
    $new_user_id = $conn->insert_id;
    $stmt1->close();

    $full_address = ($data['address'] ?? '') . ", " . ($data['barangay'] ?? '');
    $stmt2 = $conn->prepare("INSERT INTO owners (User_ID, First_name, Last_name, Contact_Number, Address) VALUES (?, ?, ?, ?, ?)");
    $stmt2->bind_param("issss", $new_user_id, $data['fname'], $data['lname'], $data['phone'], $full_address);
    if (!$stmt2->execute()) {
        throw new Exception("Failed to create owner record.");
    }
    $stmt2->close();

    $conn->commit();

    auditLog($conn, $new_user_id, 'Register Account', 'users', $new_user_id);

    $welcomeMessage = "Welcome to City Vet, {$data['fname']}! Your account has been registered. You may now log in and manage your pets and appointments.";
    $emailResult = sendResendEmail($data['email'], "Welcome to City Vet", $welcomeMessage);
    $smsResult = sendSemaphoreSms($data['phone'], $welcomeMessage);

    echo json_encode([
        "status" => "success",
        "message" => "Registration Successful! Please Login.",
        "email_sent" => $emailResult["sent"] ?? false,
        "email_message" => $emailResult["message"] ?? "",
        "sms_sent" => $smsResult["sent"] ?? false,
        "sms_message" => $smsResult["message"] ?? ""
    ]);

} catch (Throwable $e) {
    try {
        $conn->rollback();
    } catch (Throwable $rbErr) {}
    error_log("Registration error: " . $e->getMessage());
    echo json_encode(["status" => "error", "message" => "Registration failed due to a server error. Please try again later."]);
}

$conn->close();
