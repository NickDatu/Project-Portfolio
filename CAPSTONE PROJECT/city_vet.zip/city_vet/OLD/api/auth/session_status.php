<?php
require_once '../../config/session.php';

header("Content-Type: application/json; charset=UTF-8");

$timeoutSeconds = 30 * 60;
$shouldTouch = ($_GET['touch'] ?? '1') !== '0';

if (isset($_SESSION['user_id'])) {
    if ($shouldTouch) {
        $_SESSION['last_activity'] = time();
        require_once '../../config/db_connection.php';
        $presence = $conn->prepare("UPDATE users SET Is_Online = 1, Last_Activity = NOW() WHERE User_ID = ?");
        if ($presence) {
            $presence->bind_param("i", $_SESSION['user_id']);
            $presence->execute();
            $presence->close();
        }
    }

    echo json_encode([
        "status" => "logged_in",
        "user_id" => (int)$_SESSION['user_id'],
        "role_id" => (int)$_SESSION['role_id'],
        "username" => $_SESSION['username'] ?? '',
        "timeout_minutes" => (int)($timeoutSeconds / 60),
        "csrf_token" => getCsrfToken()
    ]);
} else {
    echo json_encode(["status" => "logged_out"]);
}
