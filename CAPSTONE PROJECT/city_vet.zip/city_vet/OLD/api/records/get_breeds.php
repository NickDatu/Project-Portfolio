<?php
header("Content-Type: application/json; charset=UTF-8");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Referrer-Policy: strict-origin-when-cross-origin");

require_once '../../config/db_connection.php';

$sql = "SELECT Breed_ID, Species_ID, Breed_Name FROM breeds WHERE Status = 'active' ORDER BY Breed_Name ASC";
$result = $conn->query($sql);

$breedsBySpecies = [];

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $s_id = (int)$row['Species_ID'];
        if (!isset($breedsBySpecies[$s_id])) {
            $breedsBySpecies[$s_id] = [];
        }
        $breedsBySpecies[$s_id][] = [
            'id' => (int)$row['Breed_ID'],
            'name' => $row['Breed_Name']
        ];
    }
}

echo json_encode($breedsBySpecies);