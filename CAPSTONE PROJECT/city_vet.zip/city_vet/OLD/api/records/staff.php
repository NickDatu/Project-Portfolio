<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../system/audit_helper.php';

header("Content-Type: application/json; charset=UTF-8");

function writeAuditLog($conn, $userId, $action, $tableAffected, $recordId = 0) {
    return auditLog($conn, $userId, $action, $tableAffected, $recordId);
}

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || (int)$_SESSION['role_id'] !== 1) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied. Administrators only."]);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents("php://input"), true);
$actorId = (int)$_SESSION['user_id'];

if ($method === 'GET') {
    $sql = "SELECT s.Staff_ID, s.First_name, s.Last_name, s.Position, s.Status, 
                   u.User_ID, u.Email, u.Phone_number, r.Role_name 
            FROM staff s
            JOIN users u ON s.User_ID = u.User_ID
            JOIN roles r ON u.Role_ID = r.Role_ID
            ORDER BY s.Last_name ASC";
    
    $result = $conn->query($sql);
    $staff = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $staff[] = $row;
        }
    }
    echo json_encode($staff);
    exit();
}

if ($method === 'POST') {
    requireCsrf();

    $action = $input['action'] ?? '';

    if ($action === 'create' || $action === 'create_staff') {
        $fname = trim((string)($input['fname'] ?? ($input['first_name'] ?? '')));
        $lname = trim((string)($input['lname'] ?? ($input['last_name'] ?? '')));
        $email = trim((string)($input['email'] ?? ''));
        $password = (string)($input['password'] ?? '');

        if (empty($email) || empty($password) || empty($fname) || empty($lname)) {
            http_response_code(400);
            echo json_encode(["status" => "error", "message" => "All required credentials and profile details must be provided."]);
            exit();
        }

        $role_id = isset($input['role_id']) ? (int)$input['role_id'] : 4;
        $allowedRoles = [1, 2, 4];
        if (!in_array($role_id, $allowedRoles, true)) {
            http_response_code(400);
            echo json_encode(["status" => "error", "message" => "Invalid employee role assigned."]);
            exit();
        }

        if (!validateStrongPassword($password)) {
            http_response_code(400);
            echo json_encode(["status" => "error", "message" => "Password must be at least 8 characters long and include uppercase, lowercase, number, and special character."]);
            exit();
        }

        $checkEmail = $conn->prepare("SELECT User_ID FROM users WHERE Email = ? LIMIT 1");
        $checkEmail->bind_param("s", $email);
        $checkEmail->execute();
        if ($checkEmail->get_result()->num_rows > 0) {
            $checkEmail->close();
            http_response_code(400);
            echo json_encode(["status" => "error", "message" => "That email is already registered."]);
            exit();
        }
        $checkEmail->close();

        $conn->begin_transaction();
        try {
            $hashed_pass = password_hash($password, PASSWORD_BCRYPT);
            $phone = $input['phone'] ?? '';
            $username = explode('@', $email)[0];
            
            $stmt1 = $conn->prepare("INSERT INTO users (Role_ID, Username, Password_Hash, Email, Phone_number) VALUES (?, ?, ?, ?, ?)");
            $stmt1->bind_param("issss", $role_id, $username, $hashed_pass, $email, $phone);
            $stmt1->execute();
            $user_id = $conn->insert_id;
            $stmt1->close();

            $position = $input['position'] ?? 'Clinic Staff';
            $stmt2 = $conn->prepare("INSERT INTO staff (User_ID, First_name, Last_name, Position) VALUES (?, ?, ?, ?)");
            $stmt2->bind_param("isss", $user_id, $fname, $lname, $position);
            $stmt2->execute();
            $staff_id = $conn->insert_id;
            $stmt2->close();

            $conn->commit();
            writeAuditLog($conn, $actorId, "Create Staff Account", "staff", $staff_id);
            echo json_encode(["status" => "success", "message" => "Employee added successfully"]);
        } catch (Throwable $e) {
            $conn->rollback();
            error_log("Error in staff.php create: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(["status" => "error", "message" => "Unable to add employee."]);
        }
        exit();
    }

    if ($action === 'toggle_status') {
        $staffId = (int)($input['staff_id'] ?? 0);
        if (!$staffId) {
            http_response_code(400);
            echo json_encode(["status" => "error", "message" => "Invalid staff ID."]);
            exit();
        }

        $checkStaff = $conn->prepare("SELECT s.User_ID, s.Status, u.Role_ID FROM staff s JOIN users u ON s.User_ID = u.User_ID WHERE s.Staff_ID = ?");
        $checkStaff->bind_param("i", $staffId);
        $checkStaff->execute();
        $staffRow = $checkStaff->get_result()->fetch_assoc();
        $checkStaff->close();

        if (!$staffRow) {
            http_response_code(404);
            echo json_encode(["status" => "error", "message" => "Staff member not found."]);
            exit();
        }

        $targetUserId = (int)$staffRow['User_ID'];
        $new_status = ($staffRow['Status'] === 'active') ? 'resigned' : 'active';
        $user_status = ($new_status === 'active') ? 'active' : 'inactive';

        if ($targetUserId === $actorId && $user_status === 'inactive') {
            http_response_code(400);
            echo json_encode(["status" => "error", "message" => "Administrators cannot deactivate their own account."]);
            exit();
        }

        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("UPDATE staff SET Status = ? WHERE Staff_ID = ?");
            $stmt->bind_param("si", $new_status, $staffId);
            $stmt->execute();

            $stmt2 = $conn->prepare("UPDATE users SET Status = ? WHERE User_ID = ?");
            $stmt2->bind_param("si", $user_status, $targetUserId);
            $stmt2->execute();

            $conn->commit();
            $log_action = ($new_status === 'active') ? "Reactivate Staff Account" : "Deactivate Staff Account";
            writeAuditLog($conn, $actorId, $log_action, "staff", $staffId);
            echo json_encode(["status" => "success", "message" => "Status updated"]);
        } catch (Throwable $e) {
            $conn->rollback();
            error_log("Error in staff.php toggle_status: " . $e->getMessage());
            echo json_encode(["status" => "error", "message" => "Update failed"]);
        }
        exit();
    }
}
