<?php
require_once '../../config/session.php';
header("Content-Type: application/json; charset=UTF-8");

require_once '../../config/db_connection.php';

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access Denied"]);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $sql = "SELECT 
                o.Owner_ID, 
                o.First_name, 
                o.Last_name, 
                o.Contact_Number, 
                o.Address, 
                u.Email,
                o.Status,
                COUNT(p.Pet_ID) as Pet_Count
            FROM owners o
            JOIN users u ON o.User_ID = u.User_ID
            LEFT JOIN pets p ON o.Owner_ID = p.Owner_ID AND p.Status = 'active'
            WHERE o.Status = 'active'
            GROUP BY o.Owner_ID
            ORDER BY o.Last_name ASC";

    $result = $conn->query($sql);
    $owners = [];

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $owners[] = $row;
        }
    }

    echo json_encode($owners);
    exit();
}