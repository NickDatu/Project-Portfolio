<?php
function auditLog($conn, $userId, $action, $tableAffected, $recordId = 0, array $options = []) {
    if (!($conn instanceof mysqli)) return false;

    try {
        $actorId = $userId ? (int)$userId : null;
        $entityId = $recordId ? (int)$recordId : null;
        $eventType = isset($options['event_type']) ? substr((string)$options['event_type'], 0, 50) : 'data_change';
        $outcome = isset($options['outcome']) ? substr((string)$options['outcome'], 0, 20) : 'success';
        $requestMethod = isset($_SERVER['REQUEST_METHOD']) ? substr($_SERVER['REQUEST_METHOD'], 0, 10) : null;
        $endpoint = isset($_SERVER['SCRIPT_NAME']) ? substr($_SERVER['SCRIPT_NAME'], 0, 255) : null;
        $ipAddress = isset($_SERVER['REMOTE_ADDR']) ? substr($_SERVER['REMOTE_ADDR'], 0, 45) : null;
        $sessionId = (session_status() === PHP_SESSION_ACTIVE && session_id()) ? hash('sha256', session_id()) : null;

        $metadataJson = null;
        if (!empty($options['metadata']) && is_array($options['metadata'])) {
            $sensitiveKeys = ['password', 'password_hash', 'token', 'secret', 'confirm_password', 'current_password', 'new_password', 'auth_token', 'csrf_token', 'cookie', 'session_id', 'api_key', 'jwt'];
            $cleanMeta = [];
            foreach ($options['metadata'] as $k => $v) {
                if (in_array(strtolower($k), $sensitiveKeys, true)) {
                    $cleanMeta[$k] = '[REDACTED]';
                } elseif (is_array($v)) {
                    $cleanMeta[$k] = array_values($v);
                } else {
                    $cleanMeta[$k] = is_scalar($v) ? $v : strval($v);
                }
            }
            $metadataJson = json_encode($cleanMeta, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        }

        $stmt = $conn->prepare(
            "INSERT INTO audit_logs (User_ID, Action, Event_Type, Table_Affected, Record_ID, Outcome, Request_Method, Endpoint, IP_Address, Session_ID, Metadata) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );

        if ($stmt) {
            $stmt->bind_param(
                'isssissssss',
                $actorId,
                $action,
                $eventType,
                $tableAffected,
                $entityId,
                $outcome,
                $requestMethod,
                $endpoint,
                $ipAddress,
                $sessionId,
                $metadataJson
            );
            $ok = $stmt->execute();
            $stmt->close();
            return $ok;
        }

        $stmt = $conn->prepare(
            "INSERT INTO audit_logs (User_ID, Action, Table_Affected, Record_ID) VALUES (?, ?, ?, ?)"
        );
        if (!$stmt) return false;

        $stmt->bind_param('issi', $actorId, $action, $tableAffected, $entityId);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    } catch (Throwable $e) {
        error_log("Audit log warning: " . $e->getMessage());
        return false;
    }
}
