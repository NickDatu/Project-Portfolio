<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db_connection.php';
require_once __DIR__ . '/audit_helper.php';

header("Content-Type: application/json; charset=UTF-8");

if (!$conn) {
    die(json_encode(["status" => "error", "message" => "Database connection failed"]));
}

function writeAuditLog($conn, $userId, $action, $tableAffected, $recordId = 0) {
    if (!$userId) return;

    $stmt = $conn->prepare("INSERT INTO audit_logs (User_ID, Action, Table_Affected, Record_ID) VALUES (?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("issi", $userId, $action, $tableAffected, $recordId);
        $stmt->execute();
        $stmt->close();
    }
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 1) {
        http_response_code(403);
        echo json_encode(["status" => "error", "message" => "Access denied. Administrators only."]);
        exit();
    }

    $query = "SELECT
                u.User_ID,
                u.Username,
                u.Email,
                u.Phone_number,
                u.Status,
                u.Role_ID
              FROM users u
              ORDER BY u.Created_At DESC";

    $result = $conn->query($query);
    $users = [];

    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
    }

    echo json_encode($users);
    exit();
}

if ($method !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Invalid request method."]);
    exit();
}

requireCsrf();

$rawInput = file_get_contents("php://input");
if ($rawInput === '' && php_sapi_name() === 'cli') {
    $rawInput = file_get_contents("php://stdin");
}
$data = json_decode($rawInput);
if (!$data && !empty($_POST)) {
    $data = (object)$_POST;
}
$action = $data->action ?? ($_POST['action'] ?? '');
$actorId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;

if ($action === 'update_credentials') {
    if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 1) {
        http_response_code(403);
        echo json_encode(["status" => "error", "message" => "Access denied. Administrators only."]);
        exit();
    }

    $email = trim((string)($data->email ?? ''));
    $id = (int)($data->staff_id ?? 0);

    if (!$id || empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(["status" => "error", "message" => "Valid user details are required."]);
        exit();
    }

    $dup = $conn->prepare("SELECT User_ID FROM users WHERE Email = ? AND User_ID != ?");
    $dup->bind_param("si", $email, $id);
    $dup->execute();
    if ($dup->get_result()->num_rows > 0) {
        echo json_encode(["status" => "error", "message" => "That email is already registered to another user."]);
        exit();
    }

    if (!empty($data->password)) {
        if (!validateStrongPassword((string)$data->password)) {
            echo json_encode(["status" => "error", "message" => "Password must be at least 8 characters long and include uppercase, lowercase, number, and special character."]);
            exit();
        }
        $pass_hash = password_hash($data->password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET Email = ?, Password_Hash = ? WHERE User_ID = ?");
        $stmt->bind_param("ssi", $email, $pass_hash, $id);
        $logAction = "Update User Email and Password";
    } else {
        $stmt = $conn->prepare("UPDATE users SET Email = ? WHERE User_ID = ?");
        $stmt->bind_param("si", $email, $id);
        $logAction = "Update User Email";
    }

    if ($stmt->execute()) {
        writeAuditLog($conn, $actorId, $logAction, "users", $id);
        echo json_encode(["status" => "success"]);
    } else {
        error_log("Error in all_users.php update_credentials: " . $conn->error);
        echo json_encode(["status" => "error", "message" => "Unable to update credentials."]);
    }
    exit();
}

if ($action === 'toggle_status') {
    if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 1) {
        http_response_code(403);
        echo json_encode(["status" => "error", "message" => "Access denied. Administrators only."]);
        exit();
    }

    $id = (int)($data->staff_id ?? 0);
    $currentStatus = $data->current_status ?? '';
    $newStatus = ($currentStatus === 'active') ? 'inactive' : 'active';

    if (!$id) {
        echo json_encode(["status" => "error", "message" => "Missing user ID."]);
        exit();
    }

    if ($id === $actorId && $newStatus === 'inactive') {
        echo json_encode(["status" => "error", "message" => "You cannot deactivate your own administrative account."]);
        exit();
    }

    $checkUser = $conn->prepare("SELECT Status FROM users WHERE User_ID = ?");
    $checkUser->bind_param("i", $id);
    $checkUser->execute();
    $uRow = $checkUser->get_result()->fetch_assoc();
    $checkUser->close();

    if (!$uRow) {
        echo json_encode(["status" => "error", "message" => "User not found."]);
        exit();
    }

    if ($uRow['Status'] === $newStatus) {
        echo json_encode(["status" => "success", "message" => "Status unchanged."]);
        exit();
    }

    $stmt = $conn->prepare("UPDATE users SET Status = ? WHERE User_ID = ? AND Status = ?");
    $stmt->bind_param("sis", $newStatus, $id, $uRow['Status']);

    if ($stmt->execute() && $stmt->affected_rows === 1) {
        $logAction = ($newStatus === 'active') ? "Activate User Account" : "Deactivate User Account";
        writeAuditLog($conn, $actorId, $logAction, "users", $id);
        echo json_encode(["status" => "success"]);
    } else {
        error_log("Error in all_users.php toggle_status: " . $conn->error);
        echo json_encode(["status" => "error", "message" => "Unable to update user status."]);
    }
    exit();
}

if ($action === 'update_profile') {
    $userId = $actorId;

    if (!$userId) {
        http_response_code(401);
        echo json_encode(["status" => "error", "message" => "Unauthorized session."]);
        exit();
    }

    $inputData = is_array($data) ? $data : (is_object($data) ? (array)$data : $_POST);

    $stmtUser = $conn->prepare("SELECT User_ID, Username, Email, Phone_number, Password_Hash, Role_ID FROM users WHERE User_ID = ? LIMIT 1");
    $stmtUser->bind_param("i", $userId);
    $stmtUser->execute();
    $currentUser = $stmtUser->get_result()->fetch_assoc();
    $stmtUser->close();

    if (!$currentUser) {
        http_response_code(404);
        echo json_encode(["status" => "error", "message" => "User not found."]);
        exit();
    }

    $currentPasswordInput = (string)($inputData['current_password'] ?? '');
    $hasUsername = array_key_exists('username', $inputData);
    $newUsername = $hasUsername ? trim((string)$inputData['username']) : null;

    $hasEmail = array_key_exists('email', $inputData);
    $newEmail = $hasEmail ? trim((string)$inputData['email']) : null;

    $phoneKey = array_key_exists('phone_number', $inputData) ? 'phone_number' : (array_key_exists('phone', $inputData) ? 'phone' : null);
    $hasPhone = ($phoneKey !== null);
    $newPhone = $hasPhone ? trim((string)$inputData[$phoneKey]) : null;

    $hasPassword = array_key_exists('password', $inputData) && (string)$inputData['password'] !== '';
    $newPassword = $hasPassword ? (string)$inputData['password'] : '';

    $fieldsToUpdate = [];
    $updatedFieldNames = [];
    $requiresPasswordConfirm = false;

    // 1. Username validation & detection
    if ($hasUsername) {
        if ($newUsername === '') {
            echo json_encode(["status" => "error", "message" => "Username cannot be empty."]);
            exit();
        }
        if ($newUsername !== $currentUser['Username']) {
            $fieldsToUpdate['Username'] = $newUsername;
            $updatedFieldNames[] = 'username';
        }
    }

    // 2. Email validation & detection
    if ($hasEmail) {
        if ($newEmail === '' || !filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
            auditLog($conn, $userId, 'Update Profile', 'users', $userId, [
                'event_type' => 'validation',
                'outcome' => 'failure',
                'metadata' => ['reason' => 'invalid_email_format']
            ]);
            echo json_encode(["status" => "error", "message" => "Please provide a valid email address."]);
            exit();
        }
        if (strtolower($newEmail) !== strtolower((string)$currentUser['Email'])) {
            $dup = $conn->prepare("SELECT User_ID FROM users WHERE Email = ? AND User_ID != ? LIMIT 1");
            $dup->bind_param("si", $newEmail, $userId);
            $dup->execute();
            if ($dup->get_result()->num_rows > 0) {
                $dup->close();
                auditLog($conn, $userId, 'Update Profile', 'users', $userId, [
                    'event_type' => 'validation',
                    'outcome' => 'failure',
                    'metadata' => ['reason' => 'email_already_exists']
                ]);
                echo json_encode(["status" => "error", "message" => "That email address is already registered."]);
                exit();
            }
            $dup->close();

            $fieldsToUpdate['Email'] = $newEmail;
            $updatedFieldNames[] = 'email';
            $requiresPasswordConfirm = true;
        }
    }

    // 3. Phone validation & detection
    if ($hasPhone) {
        $cleanedPhone = preg_replace('/[\s\-()]/', '', $newPhone);
        if ($cleanedPhone !== '') {
            if (!preg_match('/^(\+?[0-9]{7,15})$/', $cleanedPhone)) {
                auditLog($conn, $userId, 'Update Profile', 'users', $userId, [
                    'event_type' => 'validation',
                    'outcome' => 'failure',
                    'metadata' => ['reason' => 'invalid_phone_format']
                ]);
                echo json_encode(["status" => "error", "message" => "Please provide a valid phone number (7-15 digits)."]);
                exit();
            }
        }
        if ($cleanedPhone !== (string)($currentUser['Phone_number'] ?? '')) {
            $fieldsToUpdate['Phone_number'] = $cleanedPhone;
            $updatedFieldNames[] = 'phone_number';
            $requiresPasswordConfirm = true;
        }
    }

    // 4. Password validation & detection
    if ($hasPassword) {
        if (!validateStrongPassword($newPassword)) {
            auditLog($conn, $userId, 'Update Profile', 'users', $userId, [
                'event_type' => 'validation',
                'outcome' => 'failure',
                'metadata' => ['reason' => 'weak_password']
            ]);
            echo json_encode([
                "status" => "error",
                "message" => "Password must be at least 8 characters and include uppercase, lowercase, a number, and a special character."
            ]);
            exit();
        }
        $fieldsToUpdate['Password_Hash'] = password_hash($newPassword, PASSWORD_BCRYPT);
        $updatedFieldNames[] = 'password';
        $requiresPasswordConfirm = true;
    }

    // 5. Current password verification for sensitive updates
    if ($requiresPasswordConfirm && $currentPasswordInput === '') {
        auditLog($conn, $userId, 'Update Profile', 'users', $userId, [
            'event_type' => 'security',
            'outcome' => 'failure',
            'metadata' => ['reason' => 'missing_current_password']
        ]);
        echo json_encode(["status" => "error", "message" => "Current password confirmation is required to update sensitive information."]);
        exit();
    }

    if ($currentPasswordInput !== '') {
        if (!password_verify($currentPasswordInput, $currentUser['Password_Hash'])) {
            auditLog($conn, $userId, 'Update Profile', 'users', $userId, [
                'event_type' => 'security',
                'outcome' => 'failure',
                'metadata' => ['reason' => 'invalid_credentials']
            ]);
            echo json_encode(["status" => "error", "message" => "Verification failed. Incorrect current password."]);
            exit();
        }
    }

    // 6. Check if any updates need to be applied
    if (empty($fieldsToUpdate)) {
        echo json_encode([
            "status" => "success",
            "message" => "No changes were made.",
            "updated_fields" => [],
            "username" => $currentUser['Username'],
            "email" => $currentUser['Email'],
            "phone" => $currentUser['Phone_number'] ?? ''
        ]);
        exit();
    }

    // 7. Execute ACID Transaction
    $conn->begin_transaction();
    try {
        $setClauses = [];
        $bindTypes = '';
        $bindParams = [];

        foreach ($fieldsToUpdate as $col => $val) {
            $setClauses[] = "`$col` = ?";
            $bindTypes .= 's';
            $bindParams[] = $val;
        }

        $sql = "UPDATE `users` SET " . implode(', ', $setClauses) . " WHERE `User_ID` = ?";
        $bindTypes .= 'i';
        $bindParams[] = $userId;

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Users update prepare failed: " . $conn->error);
        }
        $stmt->bind_param($bindTypes, ...$bindParams);
        if (!$stmt->execute()) {
            throw new Exception("Users update execute failed: " . $stmt->error);
        }
        $stmt->close();

        // Synchronize with owners table if user is Owner (Role 3) and phone was updated
        $roleId = (int)$currentUser['Role_ID'];
        if ($roleId === 3 && array_key_exists('Phone_number', $fieldsToUpdate)) {
            $ownerPhone = $fieldsToUpdate['Phone_number'];
            $syncOwner = $conn->prepare("UPDATE owners SET Contact_number = ? WHERE User_ID = ?");
            if (!$syncOwner) {
                throw new Exception("Owner sync prepare failed: " . $conn->error);
            }
            $syncOwner->bind_param("si", $ownerPhone, $userId);
            if (!$syncOwner->execute()) {
                throw new Exception("Owner sync execute failed: " . $syncOwner->error);
            }
            $syncOwner->close();
        }

        // Record audit entry
        $actionName = in_array('password', $updatedFieldNames, true) ? 'Update Profile and Password' : 'Update Profile';
        auditLog($conn, $userId, $actionName, 'users', $userId, [
            'event_type' => 'data_change',
            'outcome' => 'success',
            'metadata' => ['updated_fields' => $updatedFieldNames]
        ]);

        $conn->commit();

        // Update active session values
        if (isset($fieldsToUpdate['Username'])) {
            $_SESSION['username'] = $fieldsToUpdate['Username'];
        }
        if (isset($fieldsToUpdate['Email'])) {
            $_SESSION['email'] = $fieldsToUpdate['Email'];
        }

        echo json_encode([
            "status" => "success",
            "message" => "Profile updated successfully.",
            "updated_fields" => $updatedFieldNames,
            "username" => $fieldsToUpdate['Username'] ?? $currentUser['Username'],
            "email" => $fieldsToUpdate['Email'] ?? $currentUser['Email'],
            "phone" => $fieldsToUpdate['Phone_number'] ?? ($currentUser['Phone_number'] ?? '')
        ]);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log("Error in all_users.php update_profile: " . $e->getMessage());

        auditLog($conn, $userId, 'Update Profile', 'users', $userId, [
            'event_type' => 'system_error',
            'outcome' => 'failure',
            'metadata' => ['reason' => 'database_error']
        ]);

        echo json_encode(["status" => "error", "message" => "An error occurred while saving your profile. Changes were rolled back."]);
    }
    exit();
}

echo json_encode(["status" => "error", "message" => "Unknown action."]);
