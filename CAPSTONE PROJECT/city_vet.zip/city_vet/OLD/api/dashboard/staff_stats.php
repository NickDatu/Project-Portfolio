<?php
require_once '../../config/session.php';
header("Content-Type: application/json; charset=UTF-8");

require_once '../../config/db_connection.php';

if (!isset($_SESSION['user_id']) || !in_array((int)($_SESSION['role_id'] ?? 0), [1, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit();
}

$response = ['stats' => [], 'schedule' => []];

$count_sql = "SELECT COUNT(*) as total FROM appointments a JOIN pets p ON a.Pet_ID = p.Pet_ID AND p.Status != 'archived' WHERE DATE(a.Appointment_Date) = CURDATE() AND a.Status != 'Cancelled'";
$countRes = $conn->query($count_sql);
$response['stats']['today_appointments'] = (int)($countRes ? ($countRes->fetch_assoc()['total'] ?? 0) : 0);

$sql = "SELECT COUNT(*) as count FROM pets WHERE Status = 'active'";
$petRes = $conn->query($sql);
$response['stats']['total_patients'] = (int)($petRes ? ($petRes->fetch_assoc()['count'] ?? 0) : 0);

$sql = "SELECT COUNT(*) AS count FROM users
        WHERE Status = 'active' AND Role_ID IN (1, 2, 4) AND Is_Online = 1
          AND Last_Activity >= DATE_SUB(NOW(), INTERVAL 3 MINUTE)";
$staffRes = $conn->query($sql);
$response['stats']['active_staff'] = (int)($staffRes ? ($staffRes->fetch_assoc()['count'] ?? 0) : 0);

$sql = "
    SELECT 
        a.Appointment_ID,
        p.Pet_ID,
        a.Notes,
        o.Contact_number,
        DATE_FORMAT(a.Appointment_Date, '%l:%i %p') as Time,
        p.Name as Pet,
        o.First_name as Owner_F,
        o.Last_name as Owner_L,
        CASE
            WHEN a.Event_ID IS NOT NULL AND (LOWER(ce.Title) LIKE '%spay%' OR LOWER(ce.Title) LIKE '%neuter%') THEN 'Spay/Neuter'
            WHEN s.Service_Name IS NOT NULL THEN s.Service_Name
            ELSE 'General Consultation'
        END AS Service,
        sp.Species_Name as Species,
        a.Status as Status,
        a.Appointment_Date as SortDate
    FROM appointments a
    JOIN pets p ON a.Pet_ID = p.Pet_ID AND p.Status != 'archived'
    JOIN owners o ON p.Owner_ID = o.Owner_ID
    LEFT JOIN species sp ON p.Species_ID = sp.Species_ID
    LEFT JOIN services s ON a.Service_ID = s.Service_ID
    LEFT JOIN calendar_events ce ON ce.Event_ID = a.Event_ID
    WHERE DATE(a.Appointment_Date) = CURDATE()
      AND a.Status != 'Cancelled'
    ORDER BY SortDate ASC";

$result = $conn->query($sql);

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $response['schedule'][] = $row;
    }
} else {
    error_log("Error in staff_stats.php: " . $conn->error);
}

echo json_encode($response);
