<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../system/audit_helper.php';

header("Content-Type: application/json; charset=UTF-8");

function writeAuditLog($conn, $userId, $action, $tableAffected, $recordId = 0) {
    return auditLog($conn, $userId, $action, $tableAffected, $recordId);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Method not allowed"]);
    exit();
}

requireCsrf();

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit();
}

$user_id = (int)$_SESSION['user_id'];
$rawInput = file_get_contents("php://input");
$jsonData = (!empty($rawInput)) ? json_decode($rawInput, true) : null;
$pet_id = isset($_POST['pet_id']) ? (int)$_POST['pet_id'] : (isset($jsonData['pet_id']) ? (int)$jsonData['pet_id'] : 0);
$note_text = trim($_POST['note_text'] ?? ($jsonData['note_text'] ?? ''));

if (!$pet_id || $note_text === '') {
    echo json_encode(["status" => "error", "message" => "Pet and note text are required."]);
    exit();
}

$owner_stmt = $conn->prepare("
    SELECT p.Pet_ID
    FROM pets p
    JOIN owners o ON p.Owner_ID = o.Owner_ID
    WHERE p.Pet_ID = ? AND o.User_ID = ? AND p.Status != 'archived'
    LIMIT 1
");
$owner_stmt->bind_param("ii", $pet_id, $user_id);
$owner_stmt->execute();
$owner_result = $owner_stmt->get_result();

if ($owner_result->num_rows === 0) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Pet not found or access denied."]);
    exit();
}

$stmt = $conn->prepare("INSERT INTO pet_notes (Pet_ID, Note_Text) VALUES (?, ?)");
$stmt->bind_param("is", $pet_id, $note_text);

if ($stmt->execute()) {
    $note_id = $conn->insert_id;
    writeAuditLog($conn, $user_id, "Add Pet Note", "pet_notes", $note_id);
    echo json_encode(["status" => "success", "message" => "Note added successfully."]);
} else {
    error_log("Error in add_note.php: " . $stmt->error);
    echo json_encode(["status" => "error", "message" => "Failed to add note."]);
}
