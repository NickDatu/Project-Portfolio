<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';

header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Method not allowed. POST required."]);
    exit();
}

requireCsrf();

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit();
}

function writeAuditLog($conn, $userId, $action, $tableAffected, $recordId = 0) {
    if (!$userId) return;

    $stmt = $conn->prepare("INSERT INTO audit_logs (User_ID, Action, Table_Affected, Record_ID) VALUES (?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("issi", $userId, $action, $tableAffected, $recordId);
        $stmt->execute();
        $stmt->close();
    }
}

$pet_id = 0;
if (isset($_POST['id'])) {
    $pet_id = (int)$_POST['id'];
} elseif (isset($_POST['pet_id'])) {
    $pet_id = (int)$_POST['pet_id'];
} else {
    $rawInput = file_get_contents("php://input");
    if (!empty($rawInput)) {
        $jsonInput = json_decode($rawInput, true);
        if (isset($jsonInput['id'])) {
            $pet_id = (int)$jsonInput['id'];
        } elseif (isset($jsonInput['pet_id'])) {
            $pet_id = (int)$jsonInput['pet_id'];
        }
    }
}

if ($pet_id > 0) {
    $user_id = (int)$_SESSION['user_id'];
    $role_id = isset($_SESSION['role_id']) ? (int)$_SESSION['role_id'] : 0;

    if ($role_id === 1 || $role_id === 4) {
        $check_stmt = $conn->prepare("SELECT Pet_ID FROM pets WHERE Pet_ID = ? AND Status != 'archived'");
        $check_stmt->bind_param("i", $pet_id);
    } else {
        $check_stmt = $conn->prepare("
            SELECT p.Pet_ID
            FROM pets p
            JOIN owners o ON p.Owner_ID = o.Owner_ID
            WHERE p.Pet_ID = ? AND o.User_ID = ? AND p.Status != 'archived'
        ");
        $check_stmt->bind_param("ii", $pet_id, $user_id);
    }

    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows === 0) {
        $check_stmt->close();
        echo json_encode(["status" => "error", "message" => "Pet not found or already archived."]);
        exit();
    }
    $check_stmt->close();

    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE pets SET Status = 'archived' WHERE Pet_ID = ? AND Status != 'archived'");
        $stmt->bind_param("i", $pet_id);
        $stmt->execute();
        
        if ($stmt->affected_rows === 0) {
            $stmt->close();
            $conn->rollback();
            echo json_encode(["status" => "error", "message" => "Pet could not be archived or already archived."]);
            exit();
        }
        $stmt->close();

        $cancelDirect = $conn->prepare("UPDATE appointments SET Status = 'Cancelled' WHERE Pet_ID = ? AND Status IN ('Pending', 'Confirmed', 'Checked In', 'In Consultation')");
        $cancelDirect->bind_param("i", $pet_id);
        $cancelDirect->execute();
        $cancelDirect->close();

        $findAppts = $conn->prepare("SELECT DISTINCT a.Appointment_ID FROM appointment_pets ap JOIN appointments a ON a.Appointment_ID = ap.Appointment_ID WHERE ap.Pet_ID = ? AND a.Status IN ('Pending', 'Confirmed', 'Checked In', 'In Consultation')");
        $findAppts->bind_param("i", $pet_id);
        $findAppts->execute();
        $res = $findAppts->get_result();
        $affectedApptIds = [];
        while ($row = $res->fetch_assoc()) {
            $affectedApptIds[] = (int)$row['Appointment_ID'];
        }
        $findAppts->close();

        $delPets = $conn->prepare("DELETE ap FROM appointment_pets ap JOIN appointments a ON a.Appointment_ID = ap.Appointment_ID WHERE ap.Pet_ID = ? AND a.Status IN ('Pending', 'Confirmed', 'Checked In', 'In Consultation')");
        $delPets->bind_param("i", $pet_id);
        $delPets->execute();
        $delPets->close();

        if (!empty($affectedApptIds)) {
            $checkRemaining = $conn->prepare("SELECT COUNT(*) as count FROM appointment_pets WHERE Appointment_ID = ?");
            $cancelEventAppt = $conn->prepare("UPDATE appointments SET Status = 'Cancelled' WHERE Appointment_ID = ?");
            foreach ($affectedApptIds as $appId) {
                $checkRemaining->bind_param("i", $appId);
                $checkRemaining->execute();
                $count = (int)$checkRemaining->get_result()->fetch_assoc()['count'];
                if ($count === 0) {
                    $cancelEventAppt->bind_param("i", $appId);
                    $cancelEventAppt->execute();
                }
            }
            $checkRemaining->close();
            $cancelEventAppt->close();
        }

        $conn->commit();
        $actorId = (int)$_SESSION['user_id'];
        writeAuditLog($conn, $actorId, "Archive Pet Record", "pets", $pet_id);
        echo json_encode(["status" => "success", "message" => "Pet has been archived."]);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log("Error in delete_pet.php: " . $e->getMessage());
        echo json_encode(["status" => "error", "message" => "Unable to archive pet."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "No pet ID provided"]);
}
