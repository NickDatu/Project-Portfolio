<?php
require_once '../../config/session.php';
header("Content-Type: application/json; charset=UTF-8");

require_once '../../config/db_connection.php'; 

if (!isset($_SESSION['user_id'])) { 
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Unauthorized"]); 
    exit(); 
}

$user_id = (int)$_SESSION['user_id'];

$owner_stmt = $conn->prepare("SELECT Owner_ID, First_name FROM owners WHERE User_ID = ? LIMIT 1");
$owner_stmt->bind_param("i", $user_id);
$owner_stmt->execute();
$owner_res = $owner_stmt->get_result();

if ($owner_res->num_rows === 0) {
    echo json_encode(["status" => "error", "message" => "Owner profile not found"]);
    exit();
}

$owner = $owner_res->fetch_assoc();
$owner_id = (int)$owner['Owner_ID'];

$breeds = [];
$breed_q = $conn->query("SELECT Breed_ID, Species_ID, Breed_Name FROM breeds WHERE Status = 'active'");
if ($breed_q) {
    while($b = $breed_q->fetch_assoc()) {
        $breeds[] = $b; 
    }
}

if (isset($_GET['id'])) {
    $pet_id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT p.*, b.Breed_Name, s.Species_Name FROM pets p 
            LEFT JOIN breeds b ON p.Breed_ID = b.Breed_ID
            LEFT JOIN species s ON p.Species_ID = s.Species_ID
            WHERE p.Pet_ID = ? AND p.Owner_ID = ? AND p.Status != 'archived'");
    $stmt->bind_param("ii", $pet_id, $owner_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $pet = $result->fetch_assoc();
        
        $age_display = "Unknown";
        if ($pet['Birthdate']) {
            $dob = new DateTime($pet['Birthdate']);
            $now = new DateTime();
            $age_display = $now->diff($dob)->y . " Years";
        }
        $pet['Age_Display'] = $age_display;
        $pet['Birthdate_Formatted'] = date("F j, Y", strtotime($pet['Birthdate']));

        $notes = [];
        $notes_stmt = $conn->prepare("SELECT * FROM pet_notes WHERE Pet_ID = ? ORDER BY Created_At DESC");
        $notes_stmt->bind_param("i", $pet_id);
        $notes_stmt->execute();
        $notes_res = $notes_stmt->get_result();
        while ($n = $notes_res->fetch_assoc()) {
            $n['Date_Formatted'] = date("M j, Y", strtotime($n['Created_At']));
            $notes[] = $n;
        }

        $history_sql = "
            (SELECT Visit_Date as Date, COALESCE(Treatment, 'General Checkup') as Treatment, Notes, 'Medical Record' as Type 
             FROM medical_records WHERE Pet_ID = ? AND is_deleted = 0)
            UNION ALL
            (SELECT a.Appointment_Date as Date,
                    CASE
                        WHEN a.Event_ID IS NOT NULL AND (LOWER(ce.Title) LIKE '%spay%' OR LOWER(ce.Title) LIKE '%neuter%') THEN 'Spay/Neuter'
                        WHEN s.Service_Name IS NOT NULL THEN s.Service_Name
                        ELSE 'General Consultation'
                    END AS Treatment,
                    a.Notes, 'Consultation' as Type
             FROM appointments a
             LEFT JOIN services s ON a.Service_ID = s.Service_ID
             LEFT JOIN calendar_events ce ON ce.Event_ID = a.Event_ID
             WHERE a.Pet_ID = ? AND a.Status = 'Completed')
            ORDER BY Date DESC";

        $hist_stmt = $conn->prepare($history_sql);
        $hist_stmt->bind_param("ii", $pet_id, $pet_id);
        $hist_stmt->execute();
        $history_res = $hist_stmt->get_result();
        $history = [];
        if ($history_res) {
            while ($h = $history_res->fetch_assoc()) {
                $history[] = $h;
            }
        }

        echo json_encode([
            "status" => "success", 
            "mode" => "detail", 
            "owner_name" => $owner['First_name'], 
            "pet" => $pet, 
            "notes" => $notes,
            "history" => $history,
            "all_breeds" => $breeds 
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Pet not found"]);
    }

} else {
    $pets = [];
    $stmt = $conn->prepare("SELECT p.Pet_ID, p.Name, p.Status, p.Gender, p.Weight, p.Profile_Pic, b.Breed_Name, s.Species_Name FROM pets p 
            LEFT JOIN breeds b ON p.Breed_ID = b.Breed_ID 
            LEFT JOIN species s ON p.Species_ID = s.Species_ID
            WHERE p.Owner_ID = ? AND p.Status != 'archived'");
    $stmt->bind_param("i", $owner_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) { $pets[] = $row; }

    echo json_encode([
        "status" => "success", 
        "mode" => "list", 
        "owner_name" => $owner['First_name'], 
        "pets" => $pets,
        "all_breeds" => $breeds 
    ]);
}
