<?php
require_once '../../config/session.php';
header('Content-Type: application/json; charset=UTF-8');

require_once '../../config/db_connection.php';

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied."]);
    exit;
}

$search = isset($_GET['query']) ? "%" . trim($_GET['query']) . "%" : "%%";

$sql = "SELECT p.Pet_ID, p.Name as Pet_Name, o.First_name, o.Last_name, s.Species_Name 
        FROM pets p
        JOIN owners o ON p.Owner_ID = o.Owner_ID
        LEFT JOIN species s ON p.Species_ID = s.Species_ID
        WHERE (o.First_name LIKE ? OR o.Last_name LIKE ? OR p.Name LIKE ?)
          AND p.Status = 'active'
        LIMIT 10";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $search, $search, $search);
$stmt->execute();
$result = $stmt->get_result();

echo json_encode($result->fetch_all(MYSQLI_ASSOC));