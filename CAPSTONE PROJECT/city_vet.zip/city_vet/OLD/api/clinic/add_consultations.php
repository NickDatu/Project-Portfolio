<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../system/audit_helper.php';

header('Content-Type: application/json; charset=UTF-8');

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied."]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();

    $rawInput = file_get_contents("php://input");
    $jsonData = (!empty($rawInput)) ? json_decode($rawInput, true) : null;

    $owner_id = (int)($_POST['owner_id'] ?? ($jsonData['owner_id'] ?? 0));
    $pet_id = (int)($_POST['pet_id'] ?? ($jsonData['pet_id'] ?? 0));
    $vet_id = !empty($_POST['vet_id'] ?? ($jsonData['vet_id'] ?? null)) ? (int)($_POST['vet_id'] ?? $jsonData['vet_id']) : 1;
    $subject = trim($_POST['treatment'] ?? ($jsonData['treatment'] ?? ($_POST['subject'] ?? ($jsonData['subject'] ?? ''))));
    $description = trim($_POST['symptoms'] ?? ($jsonData['symptoms'] ?? ($_POST['description'] ?? ($jsonData['description'] ?? ''))));
    $status = 'Completed'; 
    $date = date('Y-m-d H:i:s');

    if (!$owner_id || !$pet_id || $subject === '') {
        echo json_encode(["status" => "error", "message" => "Owner, pet, and treatment subject are required."]);
        exit();
    }

    $checkPet = $conn->prepare("SELECT Pet_ID FROM pets WHERE Pet_ID = ? AND Owner_ID = ? AND Status != 'archived' LIMIT 1");
    $checkPet->bind_param("ii", $pet_id, $owner_id);
    $checkPet->execute();
    if ($checkPet->get_result()->num_rows === 0) {
        $checkPet->close();
        echo json_encode(["status" => "error", "message" => "Pet does not belong to owner or is archived."]);
        exit();
    }
    $checkPet->close();

    $sql = "INSERT INTO consultations (Owner_ID, Pet_ID, Vet_ID, Subject, Concern_Description, Status, Consultation_Date) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiissss", $owner_id, $pet_id, $vet_id, $subject, $description, $status, $date);

    if ($stmt->execute()) {
        $conId = (int)$conn->insert_id;
        auditLog($conn, (int)$_SESSION['user_id'], 'Create Consultation', 'consultations', $conId, [
            'metadata' => ['owner_id' => (int)$owner_id, 'pet_id' => (int)$pet_id, 'vet_id' => (int)$vet_id, 'status' => $status]
        ]);
        echo json_encode(["status" => "success", "message" => "Consultation recorded!"]);
    } else {
        error_log("Error in add_consultations.php: " . $stmt->error);
        echo json_encode(["status" => "error", "message" => "Unable to record consultation."]);
    }
    $stmt->close();
}
