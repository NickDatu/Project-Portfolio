<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
header("Content-Type: application/json; charset=UTF-8");

if ($conn instanceof mysqli) $conn->set_charset("utf8mb4");

function respond($payload, $code = 200) {
    http_response_code($code);
    echo json_encode($payload);
    exit();
}

function requireRole($roles) {
    if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], $roles, true)) {
        respond(["status" => "error", "message" => "Access denied."], 403);
    }
}

function auditLog($conn, $action, $table, $recordId = 0) {
    $userId = (int)($_SESSION['user_id'] ?? 0);
    if (!$userId) return;
    $stmt = $conn->prepare("INSERT INTO audit_logs (User_ID, Action, Table_Affected, Record_ID) VALUES (?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("issi", $userId, $action, $table, $recordId);
        $stmt->execute();
    }
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $mode = $_GET['mode'] ?? 'queue';

    if ($mode === 'roster') {
        requireRole([1, 2, 4]);
        $eventId = (int)($_GET['event_id'] ?? 0);
        if (!$eventId) respond(["status" => "error", "message" => "Missing event ID."], 422);

        $stmt = $conn->prepare("
            SELECT ce.Title, ce.Event_Date, ce.Max_Slots,
                   a.Appointment_ID, a.Status,
                   o.First_name, o.Last_name, o.Contact_number,
                   GROUP_CONCAT(CONCAT(p.Name, ' (', COALESCE(sp.Species_Name, 'Pet'), ')') ORDER BY p.Name SEPARATOR ', ') AS Pets,
                   COUNT(ap.Pet_ID) AS Pet_Count
            FROM calendar_events ce
            LEFT JOIN appointments a ON a.Event_ID = ce.Event_ID AND a.Status != 'Cancelled'
            LEFT JOIN owners o ON o.Owner_ID = a.Owner_ID
            LEFT JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID
            LEFT JOIN pets p ON p.Pet_ID = ap.Pet_ID AND p.Status != 'archived'
            LEFT JOIN species sp ON sp.Species_ID = p.Species_ID
            WHERE ce.Event_ID = ?
            GROUP BY a.Appointment_ID, ce.Event_ID
            ORDER BY o.Last_name ASC, o.First_name ASC
        ");
        $stmt->bind_param("i", $eventId);
        $stmt->execute();
        $result = $stmt->get_result();
        $rows = [];
        $event = null;
        while ($row = $result->fetch_assoc()) {
            if (!$event) {
                $event = [
                    "Title" => $row["Title"],
                    "Event_Date" => $row["Event_Date"],
                    "Max_Slots" => $row["Max_Slots"]
                ];
            }
            if ($row['Appointment_ID']) $rows[] = $row;
        }
        respond(["status" => "success", "event" => $event, "roster" => $rows]);
    }

    requireRole([1, 2]);
    $sql = "
        SELECT a.Appointment_ID, a.Pet_ID, a.Owner_ID, a.Service_ID, a.Appointment_Date, a.Status, a.Notes,
               p.Name AS Pet_Name, p.Gender, p.Weight,
               o.First_name AS Owner_First, o.Last_name AS Owner_Last, o.Contact_number, o.Address,
               sp.Species_Name, b.Breed_Name, s.Service_Name
        FROM appointments a
        JOIN pets p ON p.Pet_ID = a.Pet_ID AND p.Status != 'archived'
        JOIN owners o ON o.Owner_ID = a.Owner_ID
        LEFT JOIN species sp ON sp.Species_ID = p.Species_ID
        LEFT JOIN breeds b ON b.Breed_ID = p.Breed_ID
        LEFT JOIN services s ON s.Service_ID = a.Service_ID
        WHERE DATE(a.Appointment_Date) = CURDATE()
          AND a.Status = 'In Consultation'
        ORDER BY a.Appointment_Date ASC
    ";
    $result = $conn->query($sql);
    $queue = [];
    while ($row = $result->fetch_assoc()) {
        $row['Time'] = date('h:i A', strtotime($row['Appointment_Date']));
        $queue[] = $row;
    }
    respond(["status" => "success", "queue" => $queue]);
}

if ($method !== 'POST') respond(["status" => "error", "message" => "Invalid request method."], 405);

requireCsrf();

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) $input = $_POST;
$action = $input['action'] ?? '';

if ($action === 'create_walkin_queue') {
    requireRole([1, 4]);
    $ownerId = (int)($input['owner_id'] ?? 0);
    $petId = (int)($input['pet_id'] ?? 0);
    $serviceId = (int)($input['service_id'] ?? 0);
    $notes = trim($input['notes'] ?? 'Walk-in consultation');

    if (!$ownerId || !$petId || !$serviceId) {
        respond(["status" => "error", "message" => "Owner, pet, and service are required."], 422);
    }

    $check = $conn->prepare("SELECT Pet_ID FROM pets WHERE Pet_ID = ? AND Owner_ID = ? AND Status = 'active'");
    $check->bind_param("ii", $petId, $ownerId);
    $check->execute();
    if (!$check->get_result()->fetch_assoc()) {
        respond(["status" => "error", "message" => "Selected pet does not belong to this owner."], 422);
    }

    $appointmentDate = date('Y-m-d H:i:s');
    $stmt = $conn->prepare("
        INSERT INTO appointments (Owner_ID, Pet_ID, Service_ID, Appointment_Date, Status, Notes)
        VALUES (?, ?, ?, ?, 'Checked In', ?)
    ");
    $stmt->bind_param("iiiss", $ownerId, $petId, $serviceId, $appointmentDate, $notes);
    if ($stmt->execute()) {
        $appointmentId = $conn->insert_id;
        $apStmt = $conn->prepare("INSERT INTO appointment_pets (Appointment_ID, Pet_ID) VALUES (?, ?)");
        $apStmt->bind_param("ii", $appointmentId, $petId);
        $apStmt->execute();
        $apStmt->close();
        auditLog($conn, "Create Walk-in Queue Item", "appointments", $appointmentId);
        respond(["status" => "success", "appointment_id" => $appointmentId]);
    }

    respond(["status" => "error", "message" => "Unable to add walk-in to queue."], 500);
}

if ($action === 'update_status') {
    requireRole([1, 4]);
    $appointmentId = (int)($input['appointment_id'] ?? 0);
    $status = $input['status'] ?? '';
    $allowed = ['Checked In', 'In Consultation', 'No Show', 'Completed', 'Cancelled'];
    if (!$appointmentId || !in_array($status, $allowed, true)) {
        respond(["status" => "error", "message" => "Invalid status update."], 422);
    }

    $check = $conn->prepare("SELECT a.Status, p.Status AS Pet_Status FROM appointments a JOIN pets p ON a.Pet_ID = p.Pet_ID WHERE a.Appointment_ID = ?");
    $check->bind_param("i", $appointmentId);
    $check->execute();
    $current = $check->get_result()->fetch_assoc();
    $check->close();

    if (!$current) {
        respond(["status" => "error", "message" => "Appointment not found."], 404);
    }
    if ($current['Pet_Status'] === 'archived') {
        respond(["status" => "error", "message" => "Pet is archived."], 422);
    }

    $curStatus = $current['Status'];
    if ($curStatus === $status) {
        respond(["status" => "success", "message" => "Status unchanged."]);
    }

    $validTransitions = [
        'Pending' => ['Confirmed', 'Cancelled'],
        'Confirmed' => ['Checked In', 'Cancelled', 'No Show'],
        'Checked In' => ['In Consultation', 'Completed', 'Cancelled', 'No Show'],
        'In Consultation' => ['Completed', 'Checked In', 'Cancelled', 'No Show'],
        'No Show' => [],
        'Completed' => [],
        'Cancelled' => []
    ];

    if (!isset($validTransitions[$curStatus]) || !in_array($status, $validTransitions[$curStatus], true)) {
        respond(["status" => "error", "message" => "Invalid status transition from {$curStatus} to {$status}."], 422);
    }

    $stmt = $conn->prepare("UPDATE appointments SET Status = ? WHERE Appointment_ID = ? AND Status = ?");
    $stmt->bind_param("sis", $status, $appointmentId, $curStatus);
    if ($stmt->execute() && $stmt->affected_rows === 1) {
        auditLog($conn, "Update Queue Status to {$status}", "appointments", $appointmentId);
        respond(["status" => "success"]);
    }
    respond(["status" => "error", "message" => "Unable to update queue status."], 500);
}

if ($action === 'save_consultation') {
    requireRole([1, 2, 4]);
    $appointmentId = (int)($input['appointment_id'] ?? 0);
    $petId = (int)($input['pet_id'] ?? 0);
    $treatment = trim($input['treatment'] ?? '');
    $notes = trim($input['notes'] ?? '');
    $followUpDate = trim($input['follow_up_date'] ?? '');
    $vetId = (int)$_SESSION['user_id'];

    if (!$appointmentId || !$petId || $treatment === '') {
        respond(["status" => "error", "message" => "Appointment, pet, and treatment are required."], 422);
    }

    $conn->begin_transaction();
    try {
        $checkRel = $conn->prepare("
            SELECT a.Appointment_ID, a.Status, p.Status AS Pet_Status
            FROM appointments a
            JOIN pets p ON a.Pet_ID = p.Pet_ID
            WHERE a.Appointment_ID = ? AND a.Pet_ID = ?
            LIMIT 1
            FOR UPDATE
        ");
        $checkRel->bind_param("ii", $appointmentId, $petId);
        $checkRel->execute();
        $rel = $checkRel->get_result()->fetch_assoc();
        $checkRel->close();

        if (!$rel) {
            $conn->rollback();
            respond(["status" => "error", "message" => "Appointment does not match the specified pet or does not exist."], 422);
        }
        if ($rel['Pet_Status'] === 'archived') {
            $conn->rollback();
            respond(["status" => "error", "message" => "Pet is archived."], 422);
        }
        if (!in_array($rel['Status'], ['Checked In', 'In Consultation'], true)) {
            $conn->rollback();
            respond(["status" => "error", "message" => "Cannot add consultation to an appointment with status " . $rel['Status'] . "."], 422);
        }

        $stmt = $conn->prepare("
            INSERT INTO medical_records (Appointment_ID, Pet_ID, Vet_ID, Treatment, Visit_Date, Notes)
            VALUES (?, ?, ?, ?, NOW(), ?)
        ");
        $stmt->bind_param("iiiss", $appointmentId, $petId, $vetId, $treatment, $notes);
        $stmt->execute();
        $recordId = $conn->insert_id;

        $update = $conn->prepare("UPDATE appointments SET Status = 'Completed', Vet_ID = ? WHERE Appointment_ID = ? AND Status IN ('Checked In', 'In Consultation')");
        $update->bind_param("ii", $vetId, $appointmentId);
        $update->execute();
        if ($update->affected_rows !== 1) {
            throw new Exception("Unable to transition appointment to Completed.");
        }

        $followUpId = null;
        if ($followUpDate !== '') {
            $appt = $conn->prepare("SELECT Owner_ID, Service_ID FROM appointments WHERE Appointment_ID = ?");
            $appt->bind_param("i", $appointmentId);
            $appt->execute();
            $apptRow = $appt->get_result()->fetch_assoc();
            $appt->close();
            if ($apptRow) {
                $followUpDateTime = $followUpDate . ' 08:00:00';
                $followNotes = "Follow-up appointment from consultation #{$recordId}.";
                $serviceId = $apptRow['Service_ID'] ? (int)$apptRow['Service_ID'] : null;
                $ownerId = (int)$apptRow['Owner_ID'];
                $insertFollow = $conn->prepare("
                    INSERT INTO appointments (Owner_ID, Pet_ID, Service_ID, Vet_ID, Appointment_Date, Status, Notes)
                    SELECT ?, p.Pet_ID, ?, ?, ?, 'Confirmed', ?
                    FROM pets p
                    WHERE p.Pet_ID = ? AND p.Status != 'archived'
                ");
                $insertFollow->bind_param("iiiissi", $ownerId, $serviceId, $vetId, $followUpDateTime, $followNotes, $petId);
                $insertFollow->execute();
                if ($insertFollow->affected_rows !== 1) {
                    throw new Exception("Unable to create follow-up appointment: pet is archived or inactive.");
                }
                $followUpId = $conn->insert_id;
                $insertFollow->close();

                $apStmt = $conn->prepare("INSERT INTO appointment_pets (Appointment_ID, Pet_ID) VALUES (?, ?)");
                $apStmt->bind_param("ii", $followUpId, $petId);
                $apStmt->execute();
                $apStmt->close();

                $notice = $conn->prepare("
                    INSERT INTO notifications (User_ID, Title, Message, Type)
                    SELECT o.User_ID, 'Follow-up Appointment Scheduled',
                           CONCAT('A follow-up appointment has been scheduled on ', DATE_FORMAT(?, '%M %d, %Y'), '.'),
                           'Appointment'
                    FROM owners o WHERE o.Owner_ID = ?
                ");
                $notice->bind_param("si", $followUpDateTime, $ownerId);
                $notice->execute();
                $notice->close();
            }
        }

        auditLog($conn, "Save Vet Consultation", "medical_records", $recordId);
        $conn->commit();
        respond(["status" => "success", "record_id" => $recordId, "follow_up_id" => $followUpId]);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log("Error in vet_queue.php save_consultation: " . $e->getMessage());
        respond(["status" => "error", "message" => "Unable to save consultation."], 500);
    }
}

respond(["status" => "error", "message" => "Unknown action."], 400);
