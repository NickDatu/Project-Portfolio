<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../system/audit_helper.php';

header('Content-Type: application/json; charset=UTF-8');

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied."]);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];

$rawInput = file_get_contents("php://input");
$jsonData = (!empty($rawInput)) ? json_decode($rawInput, true) : null;

$action = $_POST['action'] ?? ($jsonData['action'] ?? ($_GET['action'] ?? ''));

if (in_array($action, ['add', 'update', 'delete'], true) && $method !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Method not allowed. POST required."]);
    exit();
}

if ($method === 'POST') {
    requireCsrf();
}

if ($action === 'add' && $method === 'POST') {
    $pet_id = (int)($_POST['pet_id'] ?? ($jsonData['pet_id'] ?? 0));
    $treatment = trim($_POST['treatment'] ?? ($jsonData['treatment'] ?? ''));
    $notes = trim($_POST['symptoms'] ?? ($jsonData['symptoms'] ?? ($_POST['notes'] ?? ($jsonData['notes'] ?? ''))));
    
    if (!$pet_id || $treatment === '') {
        echo json_encode(["status" => "error", "message" => "Pet and treatment are required."]);
        exit();
    }

    $checkPet = $conn->prepare("SELECT Pet_ID FROM pets WHERE Pet_ID = ? AND Status != 'archived' LIMIT 1");
    $checkPet->bind_param("i", $pet_id);
    $checkPet->execute();
    if ($checkPet->get_result()->num_rows === 0) {
        $checkPet->close();
        echo json_encode(["status" => "error", "message" => "Pet not found or is archived."]);
        exit();
    }
    $checkPet->close();

    $sql = "INSERT INTO medical_records (Pet_ID, Treatment, Notes, Visit_Date) VALUES (?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $pet_id, $treatment, $notes);
    
    if ($stmt->execute()) {
        $recId = (int)$conn->insert_id;
        auditLog($conn, (int)$_SESSION['user_id'], 'Create Medical Record', 'medical_records', $recId, ['metadata' => ['pet_id' => (int)$pet_id]]);
        echo json_encode(["status" => "success", "message" => "Record saved"]);
    } else {
        error_log("Error in manage_consultations.php add: " . $stmt->error);
        echo json_encode(["status" => "error", "message" => "Unable to save record."]);
    }
    $stmt->close();
    exit();
}

if ($action === 'update' && $method === 'POST') {
    $id = (int)($_POST['id'] ?? ($jsonData['id'] ?? 0));
    $treatment = trim($_POST['treatment'] ?? ($jsonData['treatment'] ?? ''));
    $notes = trim($_POST['symptoms'] ?? ($jsonData['symptoms'] ?? ($_POST['notes'] ?? ($jsonData['notes'] ?? ''))));

    if (!$id || $treatment === '') {
        echo json_encode(["status" => "error", "message" => "Record ID and treatment are required."]);
        exit();
    }

    $chk = $conn->prepare("SELECT m.Treatment, m.Notes, p.Status AS Pet_Status FROM medical_records m JOIN pets p ON m.Pet_ID = p.Pet_ID WHERE m.Record_ID = ? AND (m.is_deleted = 0 OR m.is_deleted IS NULL)");
    $chk->bind_param("i", $id);
    $chk->execute();
    $exist = $chk->get_result()->fetch_assoc();
    $chk->close();

    if (!$exist) {
        echo json_encode(["status" => "error", "message" => "Record not found."]);
        exit();
    }

    if ($exist['Pet_Status'] === 'archived') {
        echo json_encode(["status" => "error", "message" => "Target pet is archived."]);
        exit();
    }

    $isNoOp = ($exist['Treatment'] === $treatment && (string)$exist['Notes'] === (string)$notes);
    if ($isNoOp) {
        echo json_encode(["status" => "success", "message" => "Updated"]);
        exit();
    }

    $sql = "UPDATE medical_records m JOIN pets p ON m.Pet_ID = p.Pet_ID SET m.Treatment=?, m.Notes=? WHERE m.Record_ID=? AND (m.is_deleted = 0 OR m.is_deleted IS NULL) AND p.Status != 'archived'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $treatment, $notes, $id);
    
    if ($stmt->execute() && $stmt->affected_rows === 1) {
        auditLog($conn, (int)$_SESSION['user_id'], 'Update Medical Record', 'medical_records', (int)$id);
        echo json_encode(["status" => "success", "message" => "Updated"]);
    } else {
        error_log("Error in manage_consultations.php update: " . $stmt->error);
        echo json_encode(["status" => "error", "message" => "Unable to update record."]);
    }
    $stmt->close();
    exit();
}

if ($action === 'delete' && $method === 'POST') {
    $id = (int)($_POST['id'] ?? ($jsonData['id'] ?? 0));
    if (!$id) {
        echo json_encode(["status" => "error", "message" => "Record ID is required."]);
        exit();
    }

    $chkDel = $conn->prepare("SELECT m.Record_ID, p.Status AS Pet_Status FROM medical_records m JOIN pets p ON m.Pet_ID = p.Pet_ID WHERE m.Record_ID = ? AND (m.is_deleted = 0 OR m.is_deleted IS NULL)");
    $chkDel->bind_param("i", $id);
    $chkDel->execute();
    $delRow = $chkDel->get_result()->fetch_assoc();
    $chkDel->close();

    if (!$delRow) {
        echo json_encode(["status" => "error", "message" => "Record not found or already deleted."]);
        exit();
    }

    if ($delRow['Pet_Status'] === 'archived') {
        echo json_encode(["status" => "error", "message" => "Target pet is archived."]);
        exit();
    }

    $sql = "UPDATE medical_records m JOIN pets p ON m.Pet_ID = p.Pet_ID SET m.is_deleted = 1 WHERE m.Record_ID = ? AND (m.is_deleted = 0 OR m.is_deleted IS NULL) AND p.Status != 'archived'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute() && $stmt->affected_rows === 1) {
        auditLog($conn, (int)$_SESSION['user_id'], 'Archive Medical Record', 'medical_records', (int)$id);
        echo json_encode(["status" => "success"]);
    } else {
        error_log("Error in manage_consultations.php delete: " . $stmt->error);
        echo json_encode(["status" => "error", "message" => "Unable to archive record."]);
    }
    $stmt->close();
    exit();
}

if ($action === 'get_single' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT m.* FROM medical_records m JOIN pets p ON m.Pet_ID = p.Pet_ID WHERE m.Record_ID = ? AND (m.is_deleted = 0 OR m.is_deleted IS NULL) AND p.Status != 'archived'");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $rec = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($rec) {
        echo json_encode($rec);
    } else {
        echo json_encode(["status" => "error", "message" => "Record not found."]);
    }
    exit();
}

echo json_encode(["status" => "error", "message" => "Invalid action."]);
