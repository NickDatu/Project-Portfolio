<?php
header('Content-Type: application/json; charset=UTF-8');
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Referrer-Policy: strict-origin-when-cross-origin");

require_once('../../config/db_connection.php');

try {
    if (!isset($conn)) {
        throw new Exception("Database connection not found.");
    }

    $query = "SELECT Diagnosis_ID, Diagnosis_Name FROM diagnosis_master ORDER BY Diagnosis_Name ASC";
    $result = $conn->query($query);

    if (!$result) {
        error_log("Query error in get_diagnosis_master.php: " . $conn->error);
        throw new Exception("Query failed.");
    }

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode($data);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        "status" => "error", 
        "message" => "Unable to load diagnosis master list."
    ]);
}