<?php
require_once '../../config/session.php';
header('Content-Type: application/json; charset=UTF-8');

require_once '../../config/db_connection.php';

if (!isset($_SESSION['user_id'], $_SESSION['role_id'])) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit;
}

$roleId = (int)$_SESSION['role_id'];
$userId = (int)$_SESSION['user_id'];
$pet_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($pet_id <= 0) {
    echo json_encode(["status" => "error", "message" => "Invalid Pet ID"]);
    exit;
}

if (!in_array($roleId, [1, 2, 3, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied."]);
    exit;
}

try {
    if ($roleId === 3) {
        $owner_stmt = $conn->prepare("SELECT Owner_ID FROM owners WHERE User_ID = ? LIMIT 1");
        $owner_stmt->bind_param("i", $userId);
        $owner_stmt->execute();
        $owner_res = $owner_stmt->get_result()->fetch_assoc();
        if (!$owner_res) {
            http_response_code(403);
            echo json_encode(["status" => "error", "message" => "Owner profile not found"]);
            exit;
        }
        $owner_id = (int)$owner_res['Owner_ID'];

        $pet_sql = "SELECT p.*, o.First_name, o.Last_name, o.Contact_number, o.Address, 
                           s.Species_Name, b.Breed_Name
                    FROM pets p
                    JOIN owners o ON p.Owner_ID = o.Owner_ID
                    LEFT JOIN species s ON p.Species_ID = s.Species_ID
                    LEFT JOIN breeds b ON p.Breed_ID = b.Breed_ID
                    WHERE p.Pet_ID = ? AND p.Owner_ID = ? AND p.Status = 'active'";
        $stmt = $conn->prepare($pet_sql);
        $stmt->bind_param("ii", $pet_id, $owner_id);
    } else {
        $pet_sql = "SELECT p.*, o.First_name, o.Last_name, o.Contact_number, o.Address, 
                           s.Species_Name, b.Breed_Name
                    FROM pets p
                    JOIN owners o ON p.Owner_ID = o.Owner_ID
                    LEFT JOIN species s ON p.Species_ID = s.Species_ID
                    LEFT JOIN breeds b ON p.Breed_ID = b.Breed_ID
                    WHERE p.Pet_ID = ? AND p.Status = 'active'";
        $stmt = $conn->prepare($pet_sql);
        $stmt->bind_param("i", $pet_id);
    }

    $stmt->execute();
    $pet_details = $stmt->get_result()->fetch_assoc();

    if (!$pet_details) {
        echo json_encode(["status" => "error", "message" => "Pet not found"]);
        exit;
    }

    $history_sql = "
        (SELECT Visit_Date as Date, Treatment, Notes, 'Medical Record' as Type 
         FROM medical_records WHERE Pet_ID = ? AND is_deleted = 0)
        UNION ALL
        (SELECT Consultation_Date as Date, Subject as Treatment, Concern_Description as Notes, 'Consultation' as Type 
         FROM consultations WHERE Pet_ID = ? AND Status = 'Completed')
        ORDER BY Date DESC";

    $hist_stmt = $conn->prepare($history_sql);
    $hist_stmt->bind_param("ii", $pet_id, $pet_id);
    $hist_stmt->execute();
    $history = $hist_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $notes_sql = "SELECT Note_Text, Created_At FROM pet_notes WHERE Pet_ID = ? ORDER BY Created_At DESC";
    $notes_stmt = $conn->prepare($notes_sql);
    $notes_stmt->bind_param("i", $pet_id);
    $notes_stmt->execute();
    $notes_res = $notes_stmt->get_result();
    $notes = [];
    while ($nrow = $notes_res->fetch_assoc()) {
        $nrow['Date_Formatted'] = date("M j, Y", strtotime($nrow['Created_At']));
        $notes[] = $nrow;
    }

    echo json_encode([
        "status" => "success",
        "details" => $pet_details,
        "history" => $history,
        "notes" => $notes
    ]);

} catch (Throwable $e) {
    error_log("Error in get_pet_info.php: " . $e->getMessage());
    echo json_encode(["status" => "error", "message" => "Unable to load pet details."]);
}