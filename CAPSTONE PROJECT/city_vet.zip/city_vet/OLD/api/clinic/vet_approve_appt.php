<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once dirname(__DIR__) . '/system/audit_helper.php';

header("Content-Type: application/json; charset=UTF-8");

function writeAuditLog($conn, $userId, $action, $tableAffected, $recordId = 0) {
    return auditLog($conn, $userId, $action, $tableAffected, $recordId);
}

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    http_response_code(403);
    auditLog($conn, null, 'Unauthorized Appointment Approval', 'appointments', 0, ['event_type' => 'security', 'outcome' => 'denied']);
    echo json_encode(["success" => false, "error" => "Access denied"]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();

    $data = json_decode(file_get_contents("php://input"), true);
    $id = isset($data['id']) ? (int)$data['id'] : null;

    if ($id && isset($conn)) {
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("UPDATE appointments a JOIN pets p ON a.Pet_ID = p.Pet_ID SET a.Status = 'Confirmed' WHERE a.Appointment_ID = ? AND a.Status = 'Pending' AND p.Status != 'archived'");
            $stmt->bind_param("i", $id);
            $stmt->execute();

            if ($stmt->affected_rows === 1) {
                $actorId = (int)$_SESSION['user_id'];
                writeAuditLog($conn, $actorId, "Approve Appointment", "appointments", $id);
                $conn->commit();
                echo json_encode(["success" => true]);
            } else {
                $conn->rollback();
                echo json_encode(["success" => false, "error" => "Appointment cannot be approved (already processed or pet is archived)."]);
            }
            $stmt->close();
        } catch (Throwable $e) {
            $conn->rollback();
            echo json_encode(["success" => false, "error" => "Unable to approve appointment."]);
        }
    } else {
        echo json_encode(["success" => false, "error" => "Invalid ID or Connection"]);
    }
}
