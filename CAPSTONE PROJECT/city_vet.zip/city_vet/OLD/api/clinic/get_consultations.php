<?php
require_once '../../config/session.php';
header('Content-Type: application/json; charset=UTF-8');

require_once '../../config/db_connection.php';

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied."]);
    exit;
}

try {
    $sql = "SELECT c.Consultation_ID, c.Consultation_Date as Visit_Date, c.Subject as Treatment, 
                   c.Concern_Description as Symptoms, p.Name as Pet_Name, o.First_name as Owner_Name
            FROM consultations c
            JOIN pets p ON c.Pet_ID = p.Pet_ID AND p.Status != 'archived'
            JOIN owners o ON c.Owner_ID = o.Owner_ID
            WHERE c.Status != 'Cancelled'
            ORDER BY c.Consultation_Date DESC";
    
    $result = $conn->query($sql);
    $records = [];

    while($row = $result->fetch_assoc()) {
        $records[] = $row;
    }

    $todayRes = $conn->query("SELECT COUNT(*) as count FROM consultations WHERE DATE(Consultation_Date) = CURDATE() AND Status != 'Cancelled'");
    $today = $todayRes ? $todayRes->fetch_assoc() : ['count' => 0];
    
    $totalRes = $conn->query("SELECT COUNT(*) as count FROM consultations WHERE Status != 'Cancelled'");
    $total = $totalRes ? $totalRes->fetch_assoc() : ['count' => 0];

    echo json_encode([
        "status" => "success",
        "today" => (int)$today['count'],
        "total" => (int)$total['count'],
        "records" => $records
    ]);

} catch (Throwable $e) {
    error_log("Error in get_consultations.php: " . $e->getMessage());
    echo json_encode(["status" => "error", "message" => "Unable to load consultations."]);
}