<?php
require_once '../../config/session.php';
header("Content-Type: application/json; charset=UTF-8");

require_once '../../config/db_connection.php'; 

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "error" => "Unauthorized: Vet access only"]);
    exit();
}

$user_id = (int)$_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT s.First_name, s.Last_name, s.Position, u.Email, u.Username, u.Phone_number 
    FROM staff s
    JOIN users u ON s.User_ID = u.User_ID
    WHERE s.User_ID = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["status" => "error", "error" => "Vet profile not found"]);
    exit();
}

$vet = $result->fetch_assoc();

echo json_encode([
    "status" => "success",
    "username" => $vet['Username'],
    "first_name" => $vet['First_name'],
    "last_name" => $vet['Last_name'],
    "position" => $vet['Position'] ?? 'Veterinarian',
    "email" => $vet['Email'],
    "phone" => $vet['Phone_number'] ?? '',
    "phone_number" => $vet['Phone_number'] ?? ''
]);