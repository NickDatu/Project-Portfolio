<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../system/audit_helper.php';

header("Content-Type: application/json; charset=UTF-8");

if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 1) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access Denied: Administrators only."]);
    exit();
}

function validateInput($data) {
    $errors = [];
    if (empty($data['service_name'])) $errors[] = "Service Name is required.";
    if (empty($data['category_id'])) $errors[] = "Category is required.";
    if (!isset($data['price']) || !is_numeric($data['price'])) $errors[] = "Valid Price is required.";
    return $errors;
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $where = isset($_GET['all']) ? "" : "WHERE s.Status = 'active'";
    $sql = "SELECT s.Service_ID, s.Service_Name, s.Price, s.Status, c.Category_Name, s.Category_ID 
            FROM Services s
            JOIN Service_Categories c ON s.Category_ID = c.Category_ID
            $where 
            ORDER BY s.Service_Name ASC";
            
    $result = $conn->query($sql);
    $services = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $services[] = $row;
        }
    }
    echo json_encode($services);
    exit();
}

if ($method === 'POST') {
    requireCsrf();
    $data = json_decode(file_get_contents("php://input"), true);
    $action = $data['action'] ?? '';

    if ($action === 'create') {
        $errors = validateInput($data);
        if (!empty($errors)) {
            echo json_encode(["status" => "error", "message" => $errors[0]]);
            exit();
        }

        $check = $conn->prepare("SELECT Service_ID FROM Services WHERE Service_Name = ? AND Status = 'active'");
        $check->bind_param("s", $data['service_name']);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            echo json_encode(["status" => "error", "message" => "Service name already exists."]);
            exit();
        }

        $stmt = $conn->prepare("INSERT INTO Services (Category_ID, Service_Name, Price) VALUES (?, ?, ?)");
        $stmt->bind_param("isd", $data['category_id'], $data['service_name'], $data['price']);
        
        if ($stmt->execute()) {
            auditLog($conn, (int)$_SESSION['user_id'], 'Create Service', 'services', (int)$conn->insert_id, [
                'metadata' => ['category_id' => (int)$data['category_id'], 'service_name' => $data['service_name'], 'price' => (float)$data['price']]
            ]);
            echo json_encode(["status" => "success", "message" => "Service created successfully."]);
        } else {
            error_log("Error in services.php create: " . $conn->error);
            echo json_encode(["status" => "error", "message" => "Unable to create service."]);
        }
        exit();
    }

    if ($action === 'update') {
        $errors = validateInput($data);
        if (!empty($errors)) {
            echo json_encode(["status" => "error", "message" => $errors[0]]);
            exit();
        }

        $sid = (int)($data['service_id'] ?? 0);
        $checkExist = $conn->prepare("SELECT Category_ID, Service_Name, Price FROM Services WHERE Service_ID = ? AND Status = 'active'");
        $checkExist->bind_param("i", $sid);
        $checkExist->execute();
        $curr = $checkExist->get_result()->fetch_assoc();
        $checkExist->close();
        if (!$curr) {
            echo json_encode(["status" => "error", "message" => "Service not found or inactive."]);
            exit();
        }

        $isNoOp = ((int)$curr['Category_ID'] === (int)$data['category_id'] && $curr['Service_Name'] === $data['service_name'] && (float)$curr['Price'] === (float)$data['price']);
        if ($isNoOp) {
            echo json_encode(["status" => "success", "message" => "Service updated."]);
            exit();
        }

        $check = $conn->prepare("SELECT Service_ID FROM Services WHERE Service_Name = ? AND Service_ID != ? AND Status = 'active'");
        $check->bind_param("si", $data['service_name'], $sid);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            echo json_encode(["status" => "error", "message" => "Service name already exists."]);
            exit();
        }

        $stmt = $conn->prepare("UPDATE Services SET Category_ID=?, Service_Name=?, Price=? WHERE Service_ID=? AND Status = 'active'");
        $stmt->bind_param("isdi", $data['category_id'], $data['service_name'], $data['price'], $sid);

        if ($stmt->execute() && $stmt->affected_rows === 1) {
            auditLog($conn, (int)$_SESSION['user_id'], 'Update Service', 'services', $sid, [
                'metadata' => ['category_id' => (int)$data['category_id'], 'service_name' => $data['service_name'], 'price' => (float)$data['price']]
            ]);
            echo json_encode(["status" => "success", "message" => "Service updated."]);
        } else {
            error_log("Error in services.php update: " . $conn->error);
            echo json_encode(["status" => "error", "message" => "Unable to update service."]);
        }
        $stmt->close();
        exit();
    }

    if ($action === 'delete') {
        $sid = (int)($data['service_id'] ?? 0);
        if (!$sid) {
            echo json_encode(["status" => "error", "message" => "ID required."]);
            exit();
        }

        $stmt = $conn->prepare("UPDATE Services SET Status = 'inactive' WHERE Service_ID = ? AND Status = 'active'");
        $stmt->bind_param("i", $sid);

        if ($stmt->execute() && $stmt->affected_rows === 1) {
            auditLog($conn, (int)$_SESSION['user_id'], 'Archive Service', 'services', $sid);
            echo json_encode(["status" => "success", "message" => "Service archived."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Service not found or already inactive."]);
        }
        $stmt->close();
        exit();
    }

    if ($action === 'restore') {
        $sid = (int)($data['service_id'] ?? 0);
        if (!$sid) {
            echo json_encode(["status" => "error", "message" => "ID required."]);
            exit();
        }

        $stmt = $conn->prepare("UPDATE Services SET Status = 'active' WHERE Service_ID = ? AND Status = 'inactive'");
        $stmt->bind_param("i", $sid);

        if ($stmt->execute() && $stmt->affected_rows === 1) {
            auditLog($conn, (int)$_SESSION['user_id'], 'Restore Service', 'services', $sid);
            echo json_encode(["status" => "success", "message" => "Service restored."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Service not found or already active."]);
        }
        $stmt->close();
        exit();
    }
}
