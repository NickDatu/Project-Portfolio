# City Vet Management System — Database Installation Guide

This guide details how to install, configure, and verify the database for the City Vet Management System on standard shared hosting environments, including InfinityFree, cPanel, and local phpMyAdmin instances.

---

## 1. Prerequisites

Before beginning the installation, ensure you have:
- Access to your hosting control panel (e.g., VistaPanel on InfinityFree, cPanel, or Plesk).
- phpMyAdmin access for your MySQL/MariaDB database.
- The consolidated database schema file: `DATABASE/deployment_clean_schema.sql`.

---

## 2. Step-by-Step Installation Process

### Step 2.1: Create the MySQL Database
1. Log in to your hosting control panel.
2. Locate the **MySQL Databases** section.
3. In the "Create New Database" input, enter a name (for example, `cityvet`).
4. On shared hosting, your database name will receive an account prefix (e.g., `if0_38400001_cityvet`).
5. Note down the following database connection credentials displayed in your control panel:
   - **MySQL Hostname**: (e.g., `sql100.infinityfree.com` or `localhost`)
   - **MySQL Database Name**: (e.g., `if0_38400001_cityvet`)
   - **MySQL Username**: (e.g., `if0_38400001`)
   - **MySQL Password**: (Your hosting account vPanel/FTP password)
   - **MySQL Port**: `3306` (default)

### Step 2.2: Launch phpMyAdmin
1. In your hosting control panel, click on the **phpMyAdmin** icon next to your newly created database.
2. In phpMyAdmin, click on your target database name in the left-hand sidebar navigation to ensure the target database is selected.

### Step 2.3: Import the Consolidated Clean Schema
1. Click the **Import** tab in the top navigation bar of phpMyAdmin.
2. Under **File to import**, click **Choose File** (or "Browse").
3. Select `DATABASE/deployment_clean_schema.sql` from your deployment package.
4. Ensure the character set is set to **utf-8**.
5. Leave other settings at default values.
6. Scroll to the bottom and click the **Import** (or **Go**) button.
7. Wait for the import to finish. You should see a green success notification:
   > "Import has been successfully finished, queries executed."

---

## 3. Schema Structure & Table Verification

The consolidated schema creates exactly **25 tables** in proper foreign-key dependency order:

| Category | Tables | Description |
| :--- | :--- | :--- |
| **System & Reference** | `roles`, `species`, `breeds`, `service_categories`, `services`, `diagnosis_master`, `first_aid_contents`, `login_rate_limits` | Foundational reference catalogs, services list, system diagnosis codes, and rate limiting |
| **Accounts & Profiles** | `users`, `staff`, `owners` | User authentication, staff accounts, and pet owner profiles |
| **Content & Scheduling** | `calendar_events`, `carousel_images`, `first_aid_videos`, `homepage_posts`, `notifications`, `vet_availability` | Public CMS content, spay/neuter events, notifications, and veterinarian shift slots |
| **Clinical Records** | `pets`, `pet_notes`, `vaccinations`, `appointments`, `consultations`, `appointment_pets`, `medical_records`, `audit_logs` | Pet profiles, appointments, consultation sessions, treatments, and immutable audit trail |

### Reference Seed Data Check
The following baseline catalogs are automatically populated upon import:
- `roles`: 4 rows (1: Administrator, 2: Veterinarian, 3: Pet Owner, 4: Staff)
- `species`: 4 rows (Dog, Cat, Other/Exotic, fish)
- `breeds`: 33 rows across species
- `service_categories`: 3 rows (Consultation, Surgery, Vaccination)
- `services`: 7 standard veterinary services
- `diagnosis_master`: 4 core diagnosis categories

### Security by Design: Clean Accounts Table
Notice that table `users` contains **0 rows** after importing `deployment_clean_schema.sql`. This is intentional:
- No hardcoded or default administrator credentials exist in the schema.
- This prevents credential leakage and default password attacks.
- The primary administrator account is created during initial deployment via `bootstrap_admin.php`.

---

## 4. Troubleshooting Common Import Issues

### Issue 1: "Script timeout passed" or "Maximum execution time exceeded"
- **Cause**: Shared hosting phpMyAdmin execution limits (often 30 or 60 seconds).
- **Resolution**: `deployment_clean_schema.sql` is intentionally lightweight (~24 KB) and contains no bulk test data, executing in under 2 seconds. If a timeout occurs, paste the contents of `deployment_clean_schema.sql` into the phpMyAdmin **SQL** tab in 2 chunks (Tables 1-13 first, then Tables 14-25).

### Issue 2: "Foreign key constraint is incorrectly formed"
- **Cause**: Tables imported out of order or foreign key checking enabled during drop/create.
- **Resolution**: The script automatically handles this with `SET FOREIGN_KEY_CHECKS = 0;` at the beginning and `SET FOREIGN_KEY_CHECKS = 1;` at the end. Verify that these statements were not stripped during copying.

### Issue 3: Access Denied / Cannot Connect
- **Cause**: Incorrect database username/password or connecting to `localhost` instead of the remote database host provided by the host.
- **Resolution**: On InfinityFree and similar hosts, the MySQL server is NOT on `localhost`. Use the exact database hostname provided (e.g., `sql123.infinityfree.com`).

---

## 5. Next Step

After completing database import, proceed to configure `config/app_config.php` and initialize the primary administrator via `bootstrap_admin.php` as detailed in [DEPLOYMENT_GUIDE.md](../DEPLOYMENT_GUIDE.md).
