-- City Vet Management System
-- Consolidated Clean Deployment Schema & Foundational Seed Data
-- Target: MySQL / MariaDB (Standard Shared Hosting / phpMyAdmin Compatible)
-- Generated: 2026-09-10 04:58:38

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

DROP TABLE IF EXISTS `audit_logs`;
DROP TABLE IF EXISTS `medical_records`;
DROP TABLE IF EXISTS `appointment_pets`;
DROP TABLE IF EXISTS `consultations`;
DROP TABLE IF EXISTS `appointments`;
DROP TABLE IF EXISTS `vaccinations`;
DROP TABLE IF EXISTS `pet_notes`;
DROP TABLE IF EXISTS `pets`;
DROP TABLE IF EXISTS `vet_availability`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `homepage_posts`;
DROP TABLE IF EXISTS `first_aid_videos`;
DROP TABLE IF EXISTS `carousel_images`;
DROP TABLE IF EXISTS `calendar_events`;
DROP TABLE IF EXISTS `owners`;
DROP TABLE IF EXISTS `staff`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `login_rate_limits`;
DROP TABLE IF EXISTS `first_aid_contents`;
DROP TABLE IF EXISTS `diagnosis_master`;
DROP TABLE IF EXISTS `services`;
DROP TABLE IF EXISTS `service_categories`;
DROP TABLE IF EXISTS `breeds`;
DROP TABLE IF EXISTS `species`;
DROP TABLE IF EXISTS `roles`;

-- --------------------------------------------------------
-- Table structure for table `roles`
-- --------------------------------------------------------
CREATE TABLE `roles` (
  `Role_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Role_name` varchar(50) NOT NULL,
  `Description` text DEFAULT NULL,
  `Status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`Role_ID`),
  UNIQUE KEY `Role_name` (`Role_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Seed data for `roles`
INSERT INTO `roles` (`Role_ID`, `Role_name`, `Description`, `Status`) VALUES
('1', 'Administrator', 'Full system access', 'active'),
('2', 'Veterinarian', 'Medical record access', 'active'),
('3', 'Pet Owner', 'Client/Pet management', 'active'),
('4', 'Staff', 'Front desk operations', 'active');

-- --------------------------------------------------------
-- Table structure for table `species`
-- --------------------------------------------------------
CREATE TABLE `species` (
  `Species_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Species_Name` varchar(50) NOT NULL,
  `Status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`Species_ID`),
  UNIQUE KEY `Species_Name` (`Species_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Seed data for `species`
INSERT INTO `species` (`Species_ID`, `Species_Name`, `Status`) VALUES
('1', 'Dog', 'active'),
('2', 'Cat', 'active'),
('3', 'Other/Exotic', 'active'),
('4', 'fish', 'active');

-- --------------------------------------------------------
-- Table structure for table `breeds`
-- --------------------------------------------------------
CREATE TABLE `breeds` (
  `Breed_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Species_ID` int(11) NOT NULL,
  `Breed_Name` varchar(100) NOT NULL,
  `Status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`Breed_ID`),
  KEY `Species_ID` (`Species_ID`),
  CONSTRAINT `breeds_ibfk_1` FOREIGN KEY (`Species_ID`) REFERENCES `species` (`Species_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Seed data for `breeds`
INSERT INTO `breeds` (`Breed_ID`, `Species_ID`, `Breed_Name`, `Status`) VALUES
('1', '1', 'Aspin (Asong Pinoy)', 'active'),
('2', '1', 'Shih Tzu', 'active'),
('3', '1', 'German Shepherd', 'active'),
('4', '1', 'Golden Retriever', 'active'),
('5', '1', 'Labrador Retriever', 'active'),
('6', '1', 'Bulldog', 'active'),
('7', '1', 'Husky', 'active'),
('8', '1', 'Beagle', 'active'),
('9', '1', 'Chihuahua', 'active'),
('10', '1', 'Pug', 'active'),
('11', '1', 'Poodle', 'active'),
('12', '1', 'Chow Chow', 'active'),
('13', '1', 'Rottweiler', 'active'),
('14', '1', 'Pomeranian', 'active'),
('15', '1', 'American Bully', 'active'),
('16', '1', 'Belgian Malinois', 'active'),
('17', '1', 'Dachshund', 'active'),
('18', '1', 'Jack Russell Terrier', 'active'),
('19', '1', 'Dalmatian', 'active'),
('20', '1', 'Boxer', 'active'),
('21', '2', 'Puspin (Pusang Pinoy)', 'active'),
('22', '2', 'Siamese', 'active'),
('23', '2', 'Persian', 'active'),
('24', '2', 'Maine Coon', 'active'),
('25', '2', 'Bengal', 'active'),
('26', '2', 'British Shorthair', 'active'),
('27', '2', 'Ragdoll', 'active'),
('28', '2', 'Munchkin', 'active'),
('29', '2', 'Sphynx', 'active'),
('30', '3', 'Native Rabbit', 'active'),
('31', '3', 'Guinea Pig', 'active'),
('32', '3', 'Hamster', 'active'),
('33', '4', 'isda', 'active');

-- --------------------------------------------------------
-- Table structure for table `service_categories`
-- --------------------------------------------------------
CREATE TABLE `service_categories` (
  `Category_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Category_Name` varchar(50) NOT NULL,
  `Status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`Category_ID`),
  UNIQUE KEY `Category_Name` (`Category_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Seed data for `service_categories`
INSERT INTO `service_categories` (`Category_ID`, `Category_Name`, `Status`) VALUES
('1', 'Consultation', 'active'),
('2', 'Surgery', 'active'),
('3', 'Vaccination', 'active');

-- --------------------------------------------------------
-- Table structure for table `services`
-- --------------------------------------------------------
CREATE TABLE `services` (
  `Service_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Category_ID` int(11) NOT NULL,
  `Service_Name` varchar(100) NOT NULL,
  `Price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `Status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`Service_ID`),
  UNIQUE KEY `Service_Name` (`Service_Name`),
  KEY `Category_ID` (`Category_ID`),
  CONSTRAINT `services_ibfk_1` FOREIGN KEY (`Category_ID`) REFERENCES `service_categories` (`Category_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Seed data for `services`
INSERT INTO `services` (`Service_ID`, `Category_ID`, `Service_Name`, `Price`, `Status`) VALUES
('1', '1', 'General Checkup', '0.00', 'active'),
('2', '1', 'Online Consultation', '0.00', 'active'),
('3', '2', 'Spay/Neuter (Cat)', '20.00', 'active'),
('4', '2', 'Spay/Neuter (Dog)', '20.00', 'active'),
('5', '3', 'Anti-Rabies Shot', '300.00', 'inactive'),
('6', '3', 'Deworming', '0.00', 'active'),
('7', '3', '5-in-1 Vaccine', '0.00', 'active');

-- --------------------------------------------------------
-- Table structure for table `diagnosis_master`
-- --------------------------------------------------------
CREATE TABLE `diagnosis_master` (
  `Diagnosis_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Diagnosis_Name` varchar(100) NOT NULL,
  `Description` text DEFAULT NULL,
  `Status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`Diagnosis_ID`),
  UNIQUE KEY `Diagnosis_Name` (`Diagnosis_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Seed data for `diagnosis_master`
INSERT INTO `diagnosis_master` (`Diagnosis_ID`, `Diagnosis_Name`, `Description`, `Status`) VALUES
('1', 'Preventive Care', 'Used for Anti-Rabies, Deworming, and other routine shots.', 'active'),
('2', 'Surgical Procedure', 'Used for Spay, Neuter, or minor surgeries.', 'active'),
('3', 'Follow-up/Routine', 'Used for post-op checkups or progress monitoring.', 'active'),
('4', 'Clinical Observation', 'Used when a pet is brought in for general symptoms.', 'active');

-- --------------------------------------------------------
-- Table structure for table `first_aid_contents`
-- --------------------------------------------------------
CREATE TABLE `first_aid_contents` (
  `Content_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(150) NOT NULL,
  `Description` text NOT NULL,
  `Steps_Html` text NOT NULL,
  `Video_URL` varchar(255) DEFAULT NULL,
  `Status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`Content_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `login_rate_limits`
-- --------------------------------------------------------
CREATE TABLE `login_rate_limits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `email` varchar(255) NOT NULL DEFAULT '',
  `failed_attempts` int(11) NOT NULL DEFAULT 1,
  `last_attempt` int(11) NOT NULL,
  `locked_until` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ip_email` (`ip_address`,`email`),
  KEY `idx_last_attempt` (`last_attempt`),
  KEY `idx_ip` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `users`
-- --------------------------------------------------------
CREATE TABLE `users` (
  `User_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Role_ID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password_Hash` varchar(255) NOT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Phone_number` varchar(20) DEFAULT NULL,
  `Status` enum('active','inactive','banned') DEFAULT 'active',
  `Is_Online` tinyint(1) NOT NULL DEFAULT 0,
  `Last_Activity` datetime DEFAULT NULL,
  `Created_At` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`User_ID`),
  UNIQUE KEY `Username` (`Username`),
  UNIQUE KEY `Email` (`Email`),
  KEY `Role_ID` (`Role_ID`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`Role_ID`) REFERENCES `roles` (`Role_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `staff`
-- --------------------------------------------------------
CREATE TABLE `staff` (
  `Staff_ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) NOT NULL,
  `First_name` varchar(100) DEFAULT NULL,
  `Last_name` varchar(100) DEFAULT NULL,
  `Position` varchar(50) DEFAULT NULL,
  `Status` enum('active','resigned','on_leave') DEFAULT 'active',
  `Is_Online` tinyint(1) NOT NULL DEFAULT 0,
  `Last_Activity` datetime DEFAULT NULL,
  PRIMARY KEY (`Staff_ID`),
  UNIQUE KEY `User_ID` (`User_ID`),
  CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `users` (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `owners`
-- --------------------------------------------------------
CREATE TABLE `owners` (
  `Owner_ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) NOT NULL,
  `First_name` varchar(100) NOT NULL,
  `Last_name` varchar(100) NOT NULL,
  `Contact_number` varchar(15) NOT NULL,
  `Address` text DEFAULT NULL,
  `Status` enum('active','inactive') DEFAULT 'active',
  `Registration_Date` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`Owner_ID`),
  UNIQUE KEY `User_ID` (`User_ID`),
  CONSTRAINT `owners_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `users` (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `calendar_events`
-- --------------------------------------------------------
CREATE TABLE `calendar_events` (
  `Event_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(150) NOT NULL,
  `Event_Type` enum('SpayNeuter','General') NOT NULL DEFAULT 'SpayNeuter',
  `Event_Date` date NOT NULL,
  `Max_Slots` int(11) NOT NULL,
  `Content` text DEFAULT NULL,
  `Created_By` int(11) DEFAULT NULL,
  `Status` enum('Open','Closed','Cancelled') NOT NULL DEFAULT 'Open',
  `Created_At` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Event_ID`),
  KEY `Created_By` (`Created_By`),
  CONSTRAINT `calendar_events_created_by_fk` FOREIGN KEY (`Created_By`) REFERENCES `users` (`User_ID`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `carousel_images`
-- --------------------------------------------------------
CREATE TABLE `carousel_images` (
  `Carousel_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(150) NOT NULL,
  `Subtitle` varchar(255) DEFAULT NULL,
  `Image_Path` varchar(255) NOT NULL,
  `Sort_Order` int(11) NOT NULL DEFAULT 0,
  `Status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `Created_By` int(11) DEFAULT NULL,
  `Created_At` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Carousel_ID`),
  KEY `Created_By` (`Created_By`),
  CONSTRAINT `carousel_images_created_by_fk` FOREIGN KEY (`Created_By`) REFERENCES `users` (`User_ID`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `first_aid_videos`
-- --------------------------------------------------------
CREATE TABLE `first_aid_videos` (
  `Video_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(150) NOT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `Embed_Url` varchar(500) NOT NULL,
  `Tags` varchar(255) DEFAULT NULL,
  `Sort_Order` int(11) NOT NULL DEFAULT 0,
  `Status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `Created_By` int(11) DEFAULT NULL,
  `Created_At` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Video_ID`),
  KEY `Status` (`Status`),
  KEY `Created_By` (`Created_By`),
  CONSTRAINT `first_aid_videos_created_by_fk` FOREIGN KEY (`Created_By`) REFERENCES `users` (`User_ID`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `homepage_posts`
-- --------------------------------------------------------
CREATE TABLE `homepage_posts` (
  `Post_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Section` enum('highlight','announcement') NOT NULL DEFAULT 'announcement',
  `Title` varchar(150) NOT NULL,
  `Subtitle` varchar(255) DEFAULT NULL,
  `Badge` varchar(60) DEFAULT NULL,
  `Image_Path` varchar(255) DEFAULT NULL,
  `Sort_Order` int(11) NOT NULL DEFAULT 0,
  `Status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `Created_By` int(11) DEFAULT NULL,
  `Created_At` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Post_ID`),
  KEY `Section` (`Section`),
  KEY `Created_By` (`Created_By`),
  CONSTRAINT `homepage_posts_created_by_fk` FOREIGN KEY (`Created_By`) REFERENCES `users` (`User_ID`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `notifications`
-- --------------------------------------------------------
CREATE TABLE `notifications` (
  `Notification_ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `Message` text NOT NULL,
  `Type` enum('Appointment','Vaccination','Consultation','System','SpayNeuter') NOT NULL,
  `Is_Read` tinyint(1) DEFAULT 0,
  `Sent_At` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`Notification_ID`),
  KEY `User_ID` (`User_ID`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `users` (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `vet_availability`
-- --------------------------------------------------------
CREATE TABLE `vet_availability` (
  `Availability_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Vet_User_ID` int(11) NOT NULL,
  `Day_Of_Week` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
  `Start_Time` time NOT NULL,
  `End_Time` time NOT NULL,
  `Status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`Availability_ID`),
  KEY `Vet_User_ID` (`Vet_User_ID`),
  CONSTRAINT `vet_availability_ibfk_1` FOREIGN KEY (`Vet_User_ID`) REFERENCES `users` (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `pets`
-- --------------------------------------------------------
CREATE TABLE `pets` (
  `Pet_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Owner_ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Species_ID` int(11) DEFAULT NULL,
  `Breed_ID` int(11) DEFAULT NULL,
  `Gender` enum('Male','Female','Unknown') DEFAULT 'Unknown',
  `Birthdate` date DEFAULT NULL,
  `Weight` decimal(5,2) DEFAULT NULL,
  `Color_Markings` varchar(100) DEFAULT NULL,
  `Status` enum('active','deceased','transferred','archived') DEFAULT 'active',
  `Profile_Pic` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Pet_ID`),
  KEY `Owner_ID` (`Owner_ID`),
  KEY `Species_ID` (`Species_ID`),
  KEY `Breed_ID` (`Breed_ID`),
  CONSTRAINT `pets_ibfk_1` FOREIGN KEY (`Owner_ID`) REFERENCES `owners` (`Owner_ID`),
  CONSTRAINT `pets_ibfk_2` FOREIGN KEY (`Species_ID`) REFERENCES `species` (`Species_ID`),
  CONSTRAINT `pets_ibfk_3` FOREIGN KEY (`Breed_ID`) REFERENCES `breeds` (`Breed_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `pet_notes`
-- --------------------------------------------------------
CREATE TABLE `pet_notes` (
  `Note_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Pet_ID` int(11) NOT NULL,
  `Note_Text` text DEFAULT NULL,
  `Created_At` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`Note_ID`),
  KEY `Pet_ID` (`Pet_ID`),
  CONSTRAINT `pet_notes_ibfk_1` FOREIGN KEY (`Pet_ID`) REFERENCES `pets` (`Pet_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `vaccinations`
-- --------------------------------------------------------
CREATE TABLE `vaccinations` (
  `Vaccination_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Pet_ID` int(11) NOT NULL,
  `Vaccine_Name` varchar(100) NOT NULL,
  `Date_Administered` date NOT NULL,
  `Next_Due_Date` date DEFAULT NULL,
  `Vet_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`Vaccination_ID`),
  KEY `Pet_ID` (`Pet_ID`),
  CONSTRAINT `vaccinations_ibfk_1` FOREIGN KEY (`Pet_ID`) REFERENCES `pets` (`Pet_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `appointments`
-- --------------------------------------------------------
CREATE TABLE `appointments` (
  `Appointment_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Event_ID` int(11) DEFAULT NULL,
  `Owner_ID` int(11) NOT NULL,
  `Pet_ID` int(11) NOT NULL,
  `Service_ID` int(11) DEFAULT NULL,
  `Vet_ID` int(11) DEFAULT NULL,
  `Appointment_Date` datetime NOT NULL,
  `Status` enum('Pending','Confirmed','Checked In','In Consultation','Completed','No Show','Cancelled') DEFAULT 'Pending',
  `Confirmed_At` datetime DEFAULT NULL,
  `Notes` text DEFAULT NULL,
  PRIMARY KEY (`Appointment_ID`),
  KEY `Owner_ID` (`Owner_ID`),
  KEY `Pet_ID` (`Pet_ID`),
  KEY `Service_ID` (`Service_ID`),
  KEY `idx_appointments_event_status` (`Event_ID`,`Status`),
  CONSTRAINT `appointments_event_fk` FOREIGN KEY (`Event_ID`) REFERENCES `calendar_events` (`Event_ID`) ON DELETE SET NULL,
  CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`Owner_ID`) REFERENCES `owners` (`Owner_ID`),
  CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`Pet_ID`) REFERENCES `pets` (`Pet_ID`),
  CONSTRAINT `appointments_ibfk_3` FOREIGN KEY (`Service_ID`) REFERENCES `services` (`Service_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `consultations`
-- --------------------------------------------------------
CREATE TABLE `consultations` (
  `Consultation_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Owner_ID` int(11) NOT NULL,
  `Pet_ID` int(11) NOT NULL,
  `Vet_ID` int(11) DEFAULT NULL,
  `Subject` varchar(255) DEFAULT NULL,
  `Concern_Description` text DEFAULT NULL,
  `Status` enum('Pending','Ongoing','Completed','Cancelled') DEFAULT 'Pending',
  `Meeting_Link` varchar(255) DEFAULT NULL,
  `Consultation_Date` datetime DEFAULT NULL,
  `Created_At` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`Consultation_ID`),
  KEY `Owner_ID` (`Owner_ID`),
  KEY `Pet_ID` (`Pet_ID`),
  KEY `Vet_ID` (`Vet_ID`),
  CONSTRAINT `consultations_ibfk_1` FOREIGN KEY (`Owner_ID`) REFERENCES `owners` (`Owner_ID`),
  CONSTRAINT `consultations_ibfk_2` FOREIGN KEY (`Pet_ID`) REFERENCES `pets` (`Pet_ID`),
  CONSTRAINT `consultations_ibfk_3` FOREIGN KEY (`Vet_ID`) REFERENCES `users` (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `appointment_pets`
-- --------------------------------------------------------
CREATE TABLE `appointment_pets` (
  `Appointment_Pet_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Appointment_ID` int(11) NOT NULL,
  `Pet_ID` int(11) NOT NULL,
  PRIMARY KEY (`Appointment_Pet_ID`),
  UNIQUE KEY `uniq_appointment_pet` (`Appointment_ID`,`Pet_ID`),
  KEY `Pet_ID` (`Pet_ID`),
  CONSTRAINT `appointment_pets_appointment_fk` FOREIGN KEY (`Appointment_ID`) REFERENCES `appointments` (`Appointment_ID`) ON DELETE CASCADE,
  CONSTRAINT `appointment_pets_pet_fk` FOREIGN KEY (`Pet_ID`) REFERENCES `pets` (`Pet_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `medical_records`
-- --------------------------------------------------------
CREATE TABLE `medical_records` (
  `Record_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Appointment_ID` int(11) DEFAULT NULL,
  `Pet_ID` int(11) NOT NULL,
  `Vet_ID` int(11) DEFAULT NULL,
  `Diagnosis_ID` int(11) DEFAULT NULL,
  `Treatment` text DEFAULT NULL,
  `Visit_Date` datetime DEFAULT current_timestamp(),
  `Notes` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`Record_ID`),
  KEY `Pet_ID` (`Pet_ID`),
  KEY `Vet_ID` (`Vet_ID`),
  KEY `fk_medical_diagnosis` (`Diagnosis_ID`),
  KEY `idx_medical_records_appointment` (`Appointment_ID`),
  CONSTRAINT `fk_medical_diagnosis` FOREIGN KEY (`Diagnosis_ID`) REFERENCES `diagnosis_master` (`Diagnosis_ID`),
  CONSTRAINT `medical_records_appointment_fk` FOREIGN KEY (`Appointment_ID`) REFERENCES `appointments` (`Appointment_ID`) ON DELETE SET NULL,
  CONSTRAINT `medical_records_ibfk_1` FOREIGN KEY (`Pet_ID`) REFERENCES `pets` (`Pet_ID`),
  CONSTRAINT `medical_records_ibfk_2` FOREIGN KEY (`Vet_ID`) REFERENCES `users` (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `audit_logs`
-- --------------------------------------------------------
CREATE TABLE `audit_logs` (
  `Log_ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) DEFAULT NULL,
  `Action` varchar(255) DEFAULT NULL,
  `Event_Type` varchar(50) NOT NULL DEFAULT 'data_change',
  `Table_Affected` varchar(50) DEFAULT NULL,
  `Record_ID` int(11) DEFAULT NULL,
  `Outcome` varchar(20) NOT NULL DEFAULT 'success',
  `Request_Method` varchar(10) DEFAULT NULL,
  `Endpoint` varchar(255) DEFAULT NULL,
  `IP_Address` varchar(45) DEFAULT NULL,
  `Session_ID` varchar(128) DEFAULT NULL,
  `Metadata` longtext DEFAULT NULL,
  `Timestamp` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`Log_ID`),
  KEY `idx_audit_timestamp` (`Timestamp`),
  KEY `idx_audit_actor_timestamp` (`User_ID`,`Timestamp`),
  KEY `idx_audit_entity_record` (`Table_Affected`,`Record_ID`),
  KEY `idx_audit_action_timestamp` (`Action`,`Timestamp`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `users` (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

SET FOREIGN_KEY_CHECKS = 1;
