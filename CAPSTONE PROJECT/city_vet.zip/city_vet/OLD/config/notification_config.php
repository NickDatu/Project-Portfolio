<?php
$appConfigFile = __DIR__ . '/app_config.php';
if (file_exists($appConfigFile)) {
    require_once $appConfigFile;
}

$localConfig = __DIR__ . '/notification_config.local.php';
if (file_exists($localConfig)) {
    require_once $localConfig;
}

if (!defined('RESEND_API_KEY')) {
    define('RESEND_API_KEY', getenv('RESEND_API_KEY') ?: 'PASTE_RESEND_API_KEY_HERE');
}

if (!defined('RESEND_FROM_EMAIL')) {
    define('RESEND_FROM_EMAIL', getenv('RESEND_FROM_EMAIL') ?: 'City Vet <onboarding@resend.dev>');
}

if (!defined('SEMAPHORE_API_KEY')) {
    define('SEMAPHORE_API_KEY', getenv('SEMAPHORE_API_KEY') ?: 'PASTE_SEMAPHORE_API_KEY_HERE');
}

if (!defined('SEMAPHORE_SENDER_NAME')) {
    define('SEMAPHORE_SENDER_NAME', getenv('SEMAPHORE_SENDER_NAME') ?: '');
}
