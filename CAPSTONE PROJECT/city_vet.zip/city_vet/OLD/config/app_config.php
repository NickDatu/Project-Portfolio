<?php
if (!defined('DB_HOST')) define('DB_HOST', 'sql107.infinityfree.com');      // MySQL Hostname from vPanel
if (!defined('DB_USER')) define('DB_USER', 'if0_42649367');                // MySQL Username
if (!defined('DB_PASS')) define('DB_PASS', 'Wwb9C4mFJfX');        // Hosting account password
if (!defined('DB_NAME')) define('DB_NAME', 'if0_42649367_city_vet_db');    // Full Database Name

if (!defined('APP_ENV')) define('APP_ENV', 'production');
if (!defined('BASE_URL')) define('BASE_URL', 'cityvet.freedev.app'); // Your live site URL

if (!defined('RESEND_API_KEY')) define('RESEND_API_KEY', '');
if (!defined('RESEND_FROM_EMAIL')) define('RESEND_FROM_EMAIL', 'City Vet <onboarding@resend.dev>');

if (!defined('SEMAPHORE_API_KEY')) define('SEMAPHORE_API_KEY', '');
if (!defined('SEMAPHORE_SENDER_NAME')) define('SEMAPHORE_SENDER_NAME', '');