(function () {
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    let viewDate = new Date();
    let events = [];
    let config = {};

    function eventByDate(dateStr) {
        return events.find(event => event.Event_Date === dateStr);
    }

    function isPast(dateStr) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return new Date(`${dateStr}T00:00:00`) < today;
    }

    function escapeHtml(str) {
        if (str === null || str === undefined) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function render() {
        const grid = document.getElementById(config.gridId);
        const monthLabel = document.getElementById(config.monthId);
        if (!grid || !monthLabel) return;

        const month = viewDate.getMonth();
        const year = viewDate.getFullYear();
        monthLabel.innerText = `${monthNames[month]} ${year}`;

        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        let html = '';

        for (let i = 0; i < firstDay; i++) {
            html += '<div class="h-12 md:h-20 rounded-lg bg-gray-50 border border-gray-100 opacity-50"></div>';
        }

        for (let day = 1; day <= daysInMonth; day++) {
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const event = eventByDate(dateStr);
            const isClosed = event && (event.Status === 'Closed' || isPast(event.Event_Date));
            const isFull = event && (event.Is_Full || parseInt(event.Remaining_Slots, 10) <= 0 || isClosed);
            const canClick = event && typeof config.onEventClick === 'function';
            const cellClass = event
                ? (isFull ? 'bg-red-50 border-red-100 text-red-700' : 'bg-teal-50 border-teal-200 text-[#00796B]')
                : 'bg-white border-gray-200 text-gray-400';
            let badge = '';
            let dot = '';
            let eventTitleEscaped = '';
            let eventIdInt = 0;

            if (event) {
                eventTitleEscaped = escapeHtml(event.Title);
                eventIdInt = parseInt(event.Event_ID, 10) || 0;
                dot = `<span class="w-1.5 h-1.5 rounded-full ${isFull ? 'bg-red-500' : 'bg-[#00796B]'} mt-0.5 md:hidden"></span>`;
                if (isClosed) {
                    badge = '<span class="hidden md:inline-block mt-1 rounded px-2 py-1 text-[10px] font-bold bg-gray-200 text-gray-700">Closed</span>';
                } else if (!isFull) {
                    const remaining = parseInt(event.Remaining_Slots, 10);
                    if (remaining > 0) {
                        badge = `<span class="hidden md:inline-block mt-1 rounded px-2 py-1 text-[10px] font-bold bg-white text-[#00796B]">${remaining} slot${remaining !== 1 ? 's' : ''} left</span>`;
                    }
                }
            }

            html += `
                <div class="h-12 md:h-20 rounded-lg border p-1 md:p-2 flex flex-col items-center justify-center ${cellClass} ${canClick ? 'cursor-pointer hover:shadow-sm transition' : ''}" ${canClick ? `onclick="CityVetSpayCalendar.openEvent(${eventIdInt})"` : ''}>
                    <span class="text-xs md:text-sm font-black">${day}</span>
                    ${event ? `<span class="hidden md:block mt-1 w-full truncate text-[10px] font-bold leading-tight" title="${eventTitleEscaped}">${eventTitleEscaped}</span>` : ''}
                    ${dot}
                    ${badge}
                </div>
            `;
        }

        grid.innerHTML = html;
    }

    async function load() {
        try {
            const res = await fetch('../../api/calendar/events.php');
            const data = await res.json();
            events = data.status === 'success' ? data.events : [];
        } catch (error) {
            events = [];
        }
        render();
    }

    window.CityVetSpayCalendar = {
        init(options) {
            config = options;
            load();
        },
        changeMonth(dir) {
            viewDate.setMonth(viewDate.getMonth() + dir);
            render();
        },
        openEvent(eventId) {
            const event = events.find(item => parseInt(item.Event_ID, 10) === parseInt(eventId, 10));
            if (event && typeof config.onEventClick === 'function') {
                config.onEventClick(event);
            }
        },
        reload() {
            load();
        }
    };
})();
