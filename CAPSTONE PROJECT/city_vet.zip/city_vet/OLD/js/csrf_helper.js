(function() {
    if (window.cityVetCsrfHelperLoaded) return;
    window.cityVetCsrfHelperLoaded = true;

    window.cityVetCsrfToken = window.cityVetCsrfToken || sessionStorage.getItem('cityvet_csrf_token') || '';

    window.escapeHtml = function(str) {
        if (str === null || str === undefined) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    };

    async function ensureCsrfToken() {
        if (window.cityVetCsrfToken) return window.cityVetCsrfToken;
        try {
            const res = await originalFetch('../../api/auth/session_status.php?touch=0', {
                headers: { 'Accept': 'application/json' }
            });
            if (res.ok) {
                const data = await res.json();
                if (data && data.csrf_token) {
                    window.cityVetCsrfToken = data.csrf_token;
                    sessionStorage.setItem('cityvet_csrf_token', data.csrf_token);
                    return data.csrf_token;
                }
            }
        } catch (e) {}
        return '';
    }

    const originalFetch = window.fetch;
    window.fetch = async function(resource, init) {
        let method = 'GET';
        if (init && init.method) {
            method = init.method.toUpperCase();
        } else if (resource instanceof Request && resource.method) {
            method = resource.method.toUpperCase();
        }

        let isSameOrigin = false;
        try {
            const urlString = (typeof resource === 'string') ? resource : (resource instanceof Request ? resource.url : String(resource));
            const parsed = new URL(urlString, window.location.origin);
            isSameOrigin = (parsed.origin === window.location.origin);
        } catch (e) {
            isSameOrigin = false;
        }

        const mutatingMethods = ['POST', 'PUT', 'PATCH', 'DELETE'];
        if (isSameOrigin && mutatingMethods.includes(method)) {
            const token = window.cityVetCsrfToken || (await ensureCsrfToken());
            if (token) {
                if (!init) {
                    init = {};
                }
                if (init.headers instanceof Headers) {
                    if (!init.headers.has('X-CSRF-Token')) {
                        init.headers.set('X-CSRF-Token', token);
                    }
                } else if (Array.isArray(init.headers)) {
                    const hasToken = init.headers.some(h => (h[0] && h[0].toLowerCase() === 'x-csrf-token'));
                    if (!hasToken) {
                        init.headers.push(['X-CSRF-Token', token]);
                    }
                } else {
                    init.headers = init.headers || {};
                    if (!init.headers['X-CSRF-Token'] && !init.headers['x-csrf-token']) {
                        init.headers['X-CSRF-Token'] = token;
                    }
                }

                if (init.body instanceof FormData) {
                    if (!init.body.has('csrf_token')) {
                        init.body.append('csrf_token', token);
                    }
                }
            }
        }

        const response = await originalFetch.call(this, resource, init);

        if (response.status === 401) {
            const clone = response.clone();
            clone.json().then(data => {
                if (data && (data.code === 'SESSION_EXPIRED' || data.status === 'timeout')) {
                    sessionStorage.removeItem('cityvet_csrf_token');
                    window.location.href = '../../login.html';
                }
            }).catch(() => {});
        }

        return response;
    };

    let lastInteraction = 0;
    const sendActivityTouch = () => {
        const now = Date.now();
        if (now - lastInteraction < 30000) return;
        lastInteraction = now;

        originalFetch('../../api/auth/session_status.php?touch=1', {
            headers: { 'Accept': 'application/json' }
        }).then(res => res.json()).then(data => {
            if (data && data.csrf_token) {
                window.cityVetCsrfToken = data.csrf_token;
                sessionStorage.setItem('cityvet_csrf_token', data.csrf_token);
            }
            if (data && data.status !== 'logged_in') {
                sessionStorage.removeItem('cityvet_csrf_token');
                window.location.href = '../../login.html';
            }
        }).catch(() => {});
    };

    ['click', 'keydown', 'touchstart', 'scroll'].forEach(evt => {
        document.addEventListener(evt, sendActivityTouch, { passive: true });
    });

    const passiveSessionCheck = () => {
        originalFetch('../../api/auth/session_status.php?touch=0', {
            headers: { 'Accept': 'application/json' }
        }).then(res => res.json()).then(data => {
            if (data && data.status !== 'logged_in') {
                sessionStorage.removeItem('cityvet_csrf_token');
                window.location.href = '../../login.html';
            } else if (data && data.csrf_token) {
                window.cityVetCsrfToken = data.csrf_token;
                sessionStorage.setItem('cityvet_csrf_token', data.csrf_token);
            }
        }).catch(() => {});
    };

    setInterval(passiveSessionCheck, 30000);
    ensureCsrfToken();
})();
