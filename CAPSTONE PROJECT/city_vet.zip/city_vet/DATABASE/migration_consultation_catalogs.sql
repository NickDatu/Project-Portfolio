CREATE TABLE IF NOT EXISTS `treatment_catalog` (
  `Treatment_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Treatment_Name` varchar(120) NOT NULL,
  `Status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `Created_At` datetime NOT NULL DEFAULT current_timestamp(),
  `Updated_At` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Treatment_ID`),
  UNIQUE KEY `uq_treatment_name` (`Treatment_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `medicine_catalog` (
  `Medicine_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Medicine_Name` varchar(120) NOT NULL,
  `Status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `Created_At` datetime NOT NULL DEFAULT current_timestamp(),
  `Updated_At` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Medicine_ID`),
  UNIQUE KEY `uq_medicine_name` (`Medicine_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT IGNORE INTO `treatment_catalog` (`Treatment_Name`) VALUES
('General Consultation'),
('General Checkup'),
('Physical Examination'),
('Anti-Rabies Vaccination'),
('5-in-1 Vaccination'),
('Parvo Vaccination'),
('Deworming'),
('Spay/Neuter'),
('Post-Operative Checkup'),
('Wound Care'),
('Ear Cleaning');

INSERT IGNORE INTO `medicine_catalog` (`Medicine_Name`) VALUES
('Amoxicillin'),
('Cephalexin'),
('Doxycycline'),
('Metronidazole'),
('Meloxicam'),
('Carprofen'),
('Prednisolone'),
('Diphenhydramine'),
('Pyrantel Pamoate'),
('Fenbendazole'),
('Praziquantel'),
('Fipronil');
