-- City Vet - migration: medical history columns + Live Ticket Queue
-- Safe to run more than once (idempotent). Target: MariaDB 10.4+ (XAMPP) / phpMyAdmin.
-- NOTE: the application also applies this automatically the first time the affected
-- pages/APIs are used, so running it by hand is optional but recommended.

-- 1) Columns the code reads/writes on medical history (missing in older imports, which
--    caused HTTP 500 on vet_queue.php and "Unable to load consultations" on vet history).
ALTER TABLE `medical_records`
  ADD COLUMN IF NOT EXISTS `Booklet` varchar(255) DEFAULT NULL AFTER `Notes`,
  ADD COLUMN IF NOT EXISTS `Medicine_Used` text DEFAULT NULL AFTER `Booklet`,
  ADD COLUMN IF NOT EXISTS `Medicine_Picture` varchar(255) DEFAULT NULL AFTER `Medicine_Used`;

ALTER TABLE `appointments`
  ADD COLUMN IF NOT EXISTS `Vet_ID` int(11) DEFAULT NULL AFTER `Service_ID`;

-- --------------------------------------------------------
-- Live ticket queue (separate from the walk-in / spay-neuter queue)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `live_queue_services` (
  `Service_Code` varchar(20) NOT NULL,
  `Service_Name` varchar(60) NOT NULL,
  `Sort_Order` int(11) NOT NULL DEFAULT 0,
  `Status` enum('active','inactive') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`Service_Code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT IGNORE INTO `live_queue_services` (`Service_Code`, `Service_Name`, `Sort_Order`) VALUES
('VACCINATION', 'Vaccination', 1),
('CONSULTATION', 'Consultation', 2),
('DEWORMING', 'Deworming', 3),
('OTHER', 'Other', 99);

CREATE TABLE IF NOT EXISTS `live_queue_counters` (
  `Session_Date` date NOT NULL,
  `Service_Code` varchar(20) NOT NULL,
  `Last_Number` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Session_Date`, `Service_Code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `live_queue_tickets` (
  `Ticket_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Session_Date` date NOT NULL,
  `Service_Code` varchar(20) NOT NULL,
  `Ticket_Number` int(11) NOT NULL,
  `Owner_ID` int(11) NOT NULL,
  `Pet_ID` int(11) DEFAULT NULL,
  `Status` enum('Waiting','Called','Serving','Completed','Skipped','Cancelled') NOT NULL DEFAULT 'Waiting',
  `Recall_Count` int(11) NOT NULL DEFAULT 0,
  `Created_By` int(11) DEFAULT NULL,
  `Handled_By` int(11) DEFAULT NULL,
  `Created_At` datetime NOT NULL DEFAULT current_timestamp(),
  `Called_At` datetime DEFAULT NULL,
  `Serving_At` datetime DEFAULT NULL,
  `Completed_At` datetime DEFAULT NULL,
  `Last_Recalled_At` datetime DEFAULT NULL,
  PRIMARY KEY (`Ticket_ID`),
  UNIQUE KEY `uniq_ticket_per_session` (`Session_Date`, `Service_Code`, `Ticket_Number`),
  KEY `idx_lq_session_status` (`Session_Date`, `Status`),
  KEY `idx_lq_owner` (`Owner_ID`),
  KEY `idx_lq_pet` (`Pet_ID`),
  KEY `idx_lq_service` (`Service_Code`),
  KEY `idx_lq_created_by` (`Created_By`),
  KEY `idx_lq_handled_by` (`Handled_By`),
  CONSTRAINT `lq_tickets_service_fk` FOREIGN KEY (`Service_Code`) REFERENCES `live_queue_services` (`Service_Code`),
  CONSTRAINT `lq_tickets_owner_fk` FOREIGN KEY (`Owner_ID`) REFERENCES `owners` (`Owner_ID`),
  CONSTRAINT `lq_tickets_pet_fk` FOREIGN KEY (`Pet_ID`) REFERENCES `pets` (`Pet_ID`) ON DELETE SET NULL,
  CONSTRAINT `lq_tickets_created_by_fk` FOREIGN KEY (`Created_By`) REFERENCES `users` (`User_ID`) ON DELETE SET NULL,
  CONSTRAINT `lq_tickets_handled_by_fk` FOREIGN KEY (`Handled_By`) REFERENCES `users` (`User_ID`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
