UPDATE `services` SET `Service_Name` = 'Anti-Rabies Vaccination' WHERE `Service_Name` = 'Anti-Rabies Shot';
UPDATE `services` SET `Service_Name` = '5-in-1 Vaccination' WHERE `Service_Name` = '5-in-1 Vaccine';
INSERT INTO `services` (`Category_ID`, `Service_Name`, `Price`, `Status`)
SELECT 3, 'Parvo Vaccination', 0.00, 'active'
WHERE NOT EXISTS (SELECT 1 FROM `services` WHERE `Service_Name` = 'Parvo Vaccination');
UPDATE `species` SET `Species_Name` = 'Fish' WHERE `Species_Name` = 'fish';
UPDATE `breeds` SET `Breed_Name` = 'Other Fish' WHERE `Breed_Name` = 'isda';
