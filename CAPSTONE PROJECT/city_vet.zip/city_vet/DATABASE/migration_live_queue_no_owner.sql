-- Live ticket queue: tickets no longer need a registered pet owner.
-- Run once in phpMyAdmin (the app also applies this automatically on first queue request).
ALTER TABLE `live_queue_tickets` MODIFY `Owner_ID` int(11) DEFAULT NULL;
SET @add_note_sql = IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = 'live_queue_tickets'
       AND COLUMN_NAME = 'Note') = 0,
    'ALTER TABLE `live_queue_tickets` ADD COLUMN `Note` varchar(100) DEFAULT NULL AFTER `Pet_ID`',
    'SELECT 1'
);
PREPARE add_note_stmt FROM @add_note_sql;
EXECUTE add_note_stmt;
DEALLOCATE PREPARE add_note_stmt;
