UPDATE `species` SET `Status` = 'inactive' WHERE `Species_Name` NOT IN ('Dog', 'Cat');
UPDATE `breeds` SET `Status` = 'inactive' WHERE `Species_ID` IN (SELECT `Species_ID` FROM `species` WHERE `Species_Name` NOT IN ('Dog', 'Cat'));

