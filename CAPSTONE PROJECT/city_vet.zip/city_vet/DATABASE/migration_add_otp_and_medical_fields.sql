CREATE TABLE IF NOT EXISTS `otp_codes` (
  `OTP_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Purpose` varchar(50) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Code_Hash` varchar(255) DEFAULT NULL,
  `Expires_At` datetime DEFAULT NULL,
  `Attempts` int(11) DEFAULT 0,
  `Used_At` datetime DEFAULT NULL,
  `Created_At` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`OTP_ID`),
  KEY `Email` (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `medical_records`
  ADD COLUMN IF NOT EXISTS `Booklet` varchar(255) DEFAULT NULL AFTER `Notes`,
  ADD COLUMN IF NOT EXISTS `Medicine_Used` text DEFAULT NULL AFTER `Booklet`,
  ADD COLUMN IF NOT EXISTS `Medicine_Picture` varchar(255) DEFAULT NULL AFTER `Medicine_Used`;
