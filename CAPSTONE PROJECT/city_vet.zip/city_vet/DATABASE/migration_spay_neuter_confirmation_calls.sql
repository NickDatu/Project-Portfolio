-- Tracks staff call attempts and owner callback confirmation for spay/neuter bookings.
ALTER TABLE appointments
  ADD COLUMN IF NOT EXISTS Confirmation_Attempts int unsigned NOT NULL DEFAULT 0 AFTER Confirmed_At,
  ADD COLUMN IF NOT EXISTS Last_Contacted_At datetime DEFAULT NULL AFTER Confirmation_Attempts,
  ADD COLUMN IF NOT EXISTS Callback_Deadline datetime DEFAULT NULL AFTER Last_Contacted_At,
  ADD COLUMN IF NOT EXISTS Owner_Confirmed_At datetime DEFAULT NULL AFTER Callback_Deadline,
  ADD COLUMN IF NOT EXISTS Owner_Confirmed_By int(11) DEFAULT NULL AFTER Owner_Confirmed_At,
  ADD COLUMN IF NOT EXISTS Callback_SMS_Sent_At datetime DEFAULT NULL AFTER Owner_Confirmed_By,
  ADD COLUMN IF NOT EXISTS Reminder_SMS_Sent_At datetime DEFAULT NULL AFTER Callback_SMS_Sent_At;
