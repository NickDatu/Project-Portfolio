UPDATE `live_queue_services` SET `Status` = 'inactive' WHERE `Service_Code` NOT IN ('GEN_CHECKUP', 'ANTI_RABIES', '5IN1_VAX', 'PARVO_VAX', 'DEWORMING', 'ONLINE_CONSULT');
INSERT INTO `live_queue_services` (`Service_Code`, `Service_Name`, `Sort_Order`, `Status`) VALUES
('GEN_CHECKUP', 'General Checkup', 1, 'active'),
('ANTI_RABIES', 'Anti-Rabies Vaccination', 2, 'active'),
('5IN1_VAX', '5-in-1 Vaccination', 3, 'active'),
('PARVO_VAX', 'Parvo Vaccination', 4, 'active'),
('DEWORMING', 'Deworming', 5, 'active'),
('ONLINE_CONSULT', 'Online Consultation', 6, 'active')
ON DUPLICATE KEY UPDATE `Service_Name` = VALUES(`Service_Name`), `Sort_Order` = VALUES(`Sort_Order`), `Status` = 'active';
UPDATE `services` SET `Status` = 'active' WHERE `Service_Name` = 'Anti-Rabies Vaccination';
