-- Pet ownership transfer requests. OTPs are scoped to one pet and target owner.
CREATE TABLE IF NOT EXISTS `pet_transfer_requests` (
  `Transfer_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Pet_ID` int(11) NOT NULL,
  `From_Owner_ID` int(11) NOT NULL,
  `To_Owner_ID` int(11) NOT NULL,
  `OTP_Hash` varchar(255) NOT NULL,
  `Expires_At` datetime NOT NULL,
  `Attempts` int(11) NOT NULL DEFAULT 0,
  `Status` enum('pending','completed','cancelled','expired') NOT NULL DEFAULT 'pending',
  `Created_At` datetime NOT NULL DEFAULT current_timestamp(),
  `Completed_At` datetime DEFAULT NULL,
  PRIMARY KEY (`Transfer_ID`),
  KEY `idx_ptr_pet` (`Pet_ID`),
  KEY `idx_ptr_from_owner` (`From_Owner_ID`),
  KEY `idx_ptr_to_owner` (`To_Owner_ID`),
  KEY `idx_ptr_status` (`Status`),
  KEY `idx_ptr_expires` (`Expires_At`),
  CONSTRAINT `ptr_pet_fk` FOREIGN KEY (`Pet_ID`) REFERENCES `pets` (`Pet_ID`),
  CONSTRAINT `ptr_from_owner_fk` FOREIGN KEY (`From_Owner_ID`) REFERENCES `owners` (`Owner_ID`),
  CONSTRAINT `ptr_to_owner_fk` FOREIGN KEY (`To_Owner_ID`) REFERENCES `owners` (`Owner_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
