ALTER TABLE owners ADD COLUMN IF NOT EXISTS Owner_Code VARCHAR(32) NULL;
ALTER TABLE owners ADD UNIQUE KEY IF NOT EXISTS uq_owners_owner_code (Owner_Code);
ALTER TABLE pets ADD COLUMN IF NOT EXISTS Pet_Code VARCHAR(32) NULL;
ALTER TABLE pets ADD UNIQUE KEY IF NOT EXISTS uq_pets_pet_code (Pet_Code);
ALTER TABLE medical_records ADD COLUMN IF NOT EXISTS Lot_Number VARCHAR(100) NULL;

CREATE TABLE IF NOT EXISTS pet_external_records (
    External_Record_ID INT NOT NULL AUTO_INCREMENT,
    Pet_ID INT NOT NULL,
    Source_Clinic VARCHAR(255) NULL,
    Record_Type ENUM('Vaccination','Treatment','Deworming','Other') NOT NULL DEFAULT 'Other',
    Record_Date DATE NULL,
    Name VARCHAR(255) NULL,
    Medicine VARCHAR(255) NULL,
    Dosage VARCHAR(120) NULL,
    Lot_Number VARCHAR(100) NULL,
    Provider VARCHAR(255) NULL,
    Notes TEXT NULL,
    Attachment_Path VARCHAR(255) NULL,
    Created_By INT NULL,
    Created_At DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Verified_By INT NULL,
    Verified_At DATETIME NULL,
    Is_Deleted TINYINT(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (External_Record_ID),
    KEY idx_external_pet (Pet_ID),
    CONSTRAINT pet_external_records_pet_fk FOREIGN KEY (Pet_ID) REFERENCES pets(Pet_ID) ON DELETE CASCADE,
    CONSTRAINT pet_external_records_created_by_fk FOREIGN KEY (Created_By) REFERENCES users(User_ID) ON DELETE SET NULL,
    CONSTRAINT pet_external_records_verified_by_fk FOREIGN KEY (Verified_By) REFERENCES users(User_ID) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE calendar_events ADD COLUMN IF NOT EXISTS Correction_Reason VARCHAR(255) NULL;
ALTER TABLE calendar_events ADD COLUMN IF NOT EXISTS Corrected_By INT NULL;
ALTER TABLE calendar_events ADD COLUMN IF NOT EXISTS Corrected_At DATETIME NULL;
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS Correction_Reason VARCHAR(255) NULL;
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS Corrected_By INT NULL;
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS Corrected_At DATETIME NULL;

UPDATE owners SET Owner_Code = CONCAT('OWN-', YEAR(COALESCE(Registration_Date, NOW())), '-', LPAD(Owner_ID, 6, '0')) WHERE Owner_Code IS NULL OR Owner_Code = '';
UPDATE pets p JOIN owners o ON o.Owner_ID = p.Owner_ID SET p.Pet_Code = CONCAT('PET-', YEAR(COALESCE(o.Registration_Date, NOW())), '-', LPAD(p.Pet_ID, 6, '0')) WHERE p.Pet_Code IS NULL OR p.Pet_Code = '';
