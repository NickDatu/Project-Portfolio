-- Veterinarian "Officer of the Day" schedule (date-based).
-- Safe to re-run. Source: City Veterinary Office, Schedule of Officer/s of the Day, October 2026.
-- Duty rows are only created for veterinarian accounts whose staff First_name / Last_name match
-- (same last name + same first given name). Names with no account are skipped: create the account
-- and re-run, or use Staff > Veterinarian Schedule > Import.

CREATE TABLE IF NOT EXISTS `vet_duty_schedule` (
  `Duty_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Duty_Date` date NOT NULL,
  `Vet_User_ID` int(11) NOT NULL,
  `Created_By` int(11) DEFAULT NULL,
  `Created_At` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`Duty_ID`),
  UNIQUE KEY `uq_duty_date_vet` (`Duty_Date`, `Vet_User_ID`),
  KEY `idx_duty_vet` (`Vet_User_ID`),
  CONSTRAINT `vet_duty_vet_fk` FOREIGN KEY (`Vet_User_ID`) REFERENCES `users` (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT IGNORE INTO `vet_duty_schedule` (`Duty_Date`, `Vet_User_ID`)
SELECT t.duty_date, u.User_ID
FROM (
    SELECT '2026-10-01' AS duty_date, 'Xandrah' AS first_name, 'Brua' AS last_name UNION ALL
    SELECT '2026-10-02' AS duty_date, 'Rod' AS first_name, 'Baylo' AS last_name UNION ALL
    SELECT '2026-10-05' AS duty_date, 'Ruperto' AS first_name, 'Desuyo' AS last_name UNION ALL
    SELECT '2026-10-06' AS duty_date, 'Christopher' AS first_name, 'Gonzales' AS last_name UNION ALL
    SELECT '2026-10-07' AS duty_date, 'Norman' AS first_name, 'Enriquez' AS last_name UNION ALL
    SELECT '2026-10-08' AS duty_date, 'Xandrah' AS first_name, 'Brua' AS last_name UNION ALL
    SELECT '2026-10-09' AS duty_date, 'Rod' AS first_name, 'Baylo' AS last_name UNION ALL
    SELECT '2026-10-12' AS duty_date, 'Ruperto' AS first_name, 'Desuyo' AS last_name UNION ALL
    SELECT '2026-10-13' AS duty_date, 'Christopher' AS first_name, 'Gonzales' AS last_name UNION ALL
    SELECT '2026-10-14' AS duty_date, 'Norman' AS first_name, 'Enriquez' AS last_name UNION ALL
    SELECT '2026-10-15' AS duty_date, 'Xandrah' AS first_name, 'Brua' AS last_name UNION ALL
    SELECT '2026-10-16' AS duty_date, 'Rod' AS first_name, 'Baylo' AS last_name UNION ALL
    SELECT '2026-10-19' AS duty_date, 'Ruperto' AS first_name, 'Desuyo' AS last_name UNION ALL
    SELECT '2026-10-20' AS duty_date, 'Christopher' AS first_name, 'Gonzales' AS last_name UNION ALL
    SELECT '2026-10-21' AS duty_date, 'Norman' AS first_name, 'Enriquez' AS last_name UNION ALL
    SELECT '2026-10-22' AS duty_date, 'Xandrah' AS first_name, 'Brua' AS last_name UNION ALL
    SELECT '2026-10-23' AS duty_date, 'Rod' AS first_name, 'Baylo' AS last_name UNION ALL
    SELECT '2026-10-26' AS duty_date, 'Ruperto' AS first_name, 'Desuyo' AS last_name UNION ALL
    SELECT '2026-10-27' AS duty_date, 'Christopher' AS first_name, 'Gonzales' AS last_name UNION ALL
    SELECT '2026-10-28' AS duty_date, 'Norman' AS first_name, 'Enriquez' AS last_name UNION ALL
    SELECT '2026-10-29' AS duty_date, 'Xandrah' AS first_name, 'Brua' AS last_name UNION ALL
    SELECT '2026-10-30' AS duty_date, 'Rod' AS first_name, 'Baylo' AS last_name
) AS t
JOIN staff s ON LOWER(TRIM(s.Last_name)) = LOWER(t.last_name)
            AND LOWER(TRIM(s.First_name)) LIKE CONCAT(LOWER(t.first_name), '%')
JOIN users u ON u.User_ID = s.User_ID AND u.Role_ID = 2;
