INSERT INTO breeds (Species_ID, Breed_Name, Status)
SELECT 1, 'Mongrel (Mix Breed)', 'active'
FROM DUAL
WHERE NOT EXISTS (
    SELECT 1 FROM breeds WHERE Species_ID = 1 AND Breed_Name = 'Mongrel (Mix Breed)'
);
