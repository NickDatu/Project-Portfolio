CREATE TABLE IF NOT EXISTS `consultation_findings` (
  `Finding_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Record_ID` int(11) NOT NULL,
  `Pet_ID` int(11) NOT NULL,
  `Weight_Status` varchar(30) DEFAULT NULL,
  `Body_Condition_Score` tinyint DEFAULT NULL,
  `Purpose` longtext DEFAULT NULL,
  `Findings` longtext DEFAULT NULL,
  `Diagnosis_Text` text DEFAULT NULL,
  `Recommendations` text DEFAULT NULL,
  `Created_At` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Finding_ID`), UNIQUE KEY `uq_consultation_finding_record` (`Record_ID`), KEY `idx_consultation_finding_pet` (`Pet_ID`),
  CONSTRAINT `consultation_findings_record_fk` FOREIGN KEY (`Record_ID`) REFERENCES `medical_records` (`Record_ID`) ON DELETE CASCADE,
  CONSTRAINT `consultation_findings_pet_fk` FOREIGN KEY (`Pet_ID`) REFERENCES `pets` (`Pet_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `vaccination_schedule_rules` (
  `Rule_ID` int(11) NOT NULL AUTO_INCREMENT, `Species_ID` int(11) NOT NULL, `Age_Weeks` int(11) NOT NULL,
  `Procedure_Name` varchar(100) NOT NULL, `Repeat_Value` int(11) NOT NULL, `Repeat_Unit` enum('days','weeks','months','years') NOT NULL,
  `Repeat_Note` varchar(120) DEFAULT NULL, `Sort_Order` int(11) NOT NULL DEFAULT 0, `Status` enum('active','inactive') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`Rule_ID`), UNIQUE KEY `uq_vaccination_rule` (`Species_ID`,`Age_Weeks`,`Procedure_Name`), KEY `idx_vaccination_rule_species` (`Species_ID`),
  CONSTRAINT `vaccination_rules_species_fk` FOREIGN KEY (`Species_ID`) REFERENCES `species` (`Species_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT IGNORE INTO `vaccination_schedule_rules` (`Species_ID`,`Age_Weeks`,`Procedure_Name`,`Repeat_Value`,`Repeat_Unit`,`Repeat_Note`,`Sort_Order`)
SELECT s.Species_ID, x.Age_Weeks, x.Procedure_Name, x.Repeat_Value, x.Repeat_Unit, x.Repeat_Note, x.Sort_Order FROM species s JOIN (
SELECT 2 Age_Weeks,'Deworming' Procedure_Name,2 Repeat_Value,'weeks' Repeat_Unit,NULL Repeat_Note,1 Sort_Order UNION ALL SELECT 4,'Deworming',2,'weeks',NULL,2 UNION ALL SELECT 6,'Deworming',4,'weeks',NULL,3 UNION ALL SELECT 6,'5-in-1 Vaccine',2,'weeks','Private clinic',4 UNION ALL SELECT 8,'5-in-1 Vaccine',2,'weeks','Private clinic',5 UNION ALL SELECT 10,'Deworming',4,'weeks',NULL,6 UNION ALL SELECT 10,'5-in-1 Vaccine',3,'months',NULL,7 UNION ALL SELECT 12,'Anti-Rabies Vaccination',1,'years','City Veterinary Office',8 UNION ALL SELECT 14,'5-in-1 Vaccine',1,'years','City Veterinary Office',9
) x WHERE s.Species_Name='Dog'
UNION ALL SELECT s.Species_ID, x.Age_Weeks, x.Procedure_Name, x.Repeat_Value, x.Repeat_Unit, x.Repeat_Note, x.Sort_Order FROM species s JOIN (
SELECT 4 Age_Weeks,'Deworming' Procedure_Name,2 Repeat_Value,'weeks' Repeat_Unit,NULL Repeat_Note,1 Sort_Order UNION ALL SELECT 6,'Deworming',2,'weeks',NULL,2 UNION ALL SELECT 8,'3-in-1 or 4-in-1 Vaccine',2,'weeks',NULL,3 UNION ALL SELECT 8,'Deworming',3,'months',NULL,4 UNION ALL SELECT 11,'3-in-1 or 4-in-1 Vaccine',3,'weeks',NULL,5 UNION ALL SELECT 12,'Anti-Rabies Vaccination',1,'years','City Veterinary Office',6 UNION ALL SELECT 14,'3-in-1 or 4-in-1 Vaccine',1,'years',NULL,7
) x WHERE s.Species_Name='Cat';

DELETE r FROM `vaccination_schedule_rules` r JOIN `species` s ON s.Species_ID=r.Species_ID WHERE s.Species_Name='Dog' AND r.Age_Weeks=1 AND r.Procedure_Name='Deworming';
UPDATE `vaccination_schedule_rules` r JOIN `species` s ON s.Species_ID=r.Species_ID SET r.Repeat_Value=2 WHERE s.Species_Name='Dog' AND r.Age_Weeks=4 AND r.Procedure_Name='Deworming';

INSERT IGNORE INTO `services` (`Category_ID`,`Service_Name`,`Price`,`Status`) SELECT Category_ID,'3-in-1 / 4-in-1 Vaccination',0.00,'active' FROM service_categories WHERE Category_Name='Vaccination' LIMIT 1;
