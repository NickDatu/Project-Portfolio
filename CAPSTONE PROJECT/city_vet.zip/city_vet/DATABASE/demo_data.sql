-- Optional, repeatable demo records for local defense/demo use.
-- Apply after DATABASE/deployment_clean_schema.sql and migrations.
-- Demo account password for all seeded users: DemoVet!2026
START TRANSACTION;

INSERT INTO users (Role_ID, Username, Password_Hash, Email, Phone_number, Status)
SELECT 3, 'demo.owner.alice', '$2y$10$vqbbDORgf4QYc9IoktB9W.V0MHFX9W1Ekh5yoAGj9KgKkcSeVJXby', 'alice.demo@example.test', '09170000001', 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE Username = 'demo.owner.alice');
INSERT INTO users (Role_ID, Username, Password_Hash, Email, Phone_number, Status)
SELECT 3, 'demo.owner.ben', '$2y$10$vqbbDORgf4QYc9IoktB9W.V0MHFX9W1Ekh5yoAGj9KgKkcSeVJXby', 'ben.demo@example.test', '09170000002', 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE Username = 'demo.owner.ben');
INSERT INTO users (Role_ID, Username, Password_Hash, Email, Phone_number, Status)
SELECT 3, 'demo.owner.cara', '$2y$10$vqbbDORgf4QYc9IoktB9W.V0MHFX9W1Ekh5yoAGj9KgKkcSeVJXby', 'cara.demo@example.test', '09170000003', 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE Username = 'demo.owner.cara');
INSERT INTO users (Role_ID, Username, Password_Hash, Email, Phone_number, Status)
SELECT 3, 'demo.owner.diego', '$2y$10$vqbbDORgf4QYc9IoktB9W.V0MHFX9W1Ekh5yoAGj9KgKkcSeVJXby', 'diego.demo@example.test', '09170000004', 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE Username = 'demo.owner.diego');
INSERT INTO users (Role_ID, Username, Password_Hash, Email, Phone_number, Status)
SELECT 2, 'demo.vet', '$2y$10$vqbbDORgf4QYc9IoktB9W.V0MHFX9W1Ekh5yoAGj9KgKkcSeVJXby', 'vet.demo@example.test', '09170000005', 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE Username = 'demo.vet');
INSERT INTO users (Role_ID, Username, Password_Hash, Email, Phone_number, Status)
SELECT 4, 'demo.staff', '$2y$10$vqbbDORgf4QYc9IoktB9W.V0MHFX9W1Ekh5yoAGj9KgKkcSeVJXby', 'staff.demo@example.test', '09170000006', 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE Username = 'demo.staff');
INSERT INTO users (Role_ID, Username, Password_Hash, Email, Phone_number, Status)
SELECT 1, 'demo.admin', '$2y$10$vqbbDORgf4QYc9IoktB9W.V0MHFX9W1Ekh5yoAGj9KgKkcSeVJXby', 'admin.demo@example.test', '09170000007', 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE Username = 'demo.admin');
INSERT INTO users (Role_ID, Username, Password_Hash, Email, Phone_number, Status)
SELECT 2, 'demo.vet.brua', '$2y$10$vqbbDORgf4QYc9IoktB9W.V0MHFX9W1Ekh5yoAGj9KgKkcSeVJXby', 'dr.brua@example.test', '09170000011', 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE Username = 'demo.vet.brua');
INSERT INTO users (Role_ID, Username, Password_Hash, Email, Phone_number, Status)
SELECT 2, 'demo.vet.baylo', '$2y$10$vqbbDORgf4QYc9IoktB9W.V0MHFX9W1Ekh5yoAGj9KgKkcSeVJXby', 'dr.baylo@example.test', '09170000012', 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE Username = 'demo.vet.baylo');
INSERT INTO users (Role_ID, Username, Password_Hash, Email, Phone_number, Status)
SELECT 2, 'demo.vet.desuyo', '$2y$10$vqbbDORgf4QYc9IoktB9W.V0MHFX9W1Ekh5yoAGj9KgKkcSeVJXby', 'dr.desuyo@example.test', '09170000013', 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE Username = 'demo.vet.desuyo');
INSERT INTO users (Role_ID, Username, Password_Hash, Email, Phone_number, Status)
SELECT 2, 'demo.vet.gonzales', '$2y$10$vqbbDORgf4QYc9IoktB9W.V0MHFX9W1Ekh5yoAGj9KgKkcSeVJXby', 'dr.gonzales@example.test', '09170000014', 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE Username = 'demo.vet.gonzales');
INSERT INTO users (Role_ID, Username, Password_Hash, Email, Phone_number, Status)
SELECT 2, 'demo.vet.enriquez', '$2y$10$vqbbDORgf4QYc9IoktB9W.V0MHFX9W1Ekh5yoAGj9KgKkcSeVJXby', 'dr.enriquez@example.test', '09170000015', 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE Username = 'demo.vet.enriquez');

INSERT INTO owners (User_ID, First_name, Last_name, Contact_number, Address, Status)
SELECT u.User_ID, 'Alice', 'Reyes', '09170000001', '12 Sampaguita Street, Quezon City', 'active'
FROM users u WHERE u.Username = 'demo.owner.alice'
AND NOT EXISTS (SELECT 1 FROM owners o WHERE o.User_ID = u.User_ID);
INSERT INTO owners (User_ID, First_name, Last_name, Contact_number, Address, Status)
SELECT u.User_ID, 'Ben', 'Santos', '09170000002', '8 Mabini Avenue, Quezon City', 'active'
FROM users u WHERE u.Username = 'demo.owner.ben'
AND NOT EXISTS (SELECT 1 FROM owners o WHERE o.User_ID = u.User_ID);
INSERT INTO owners (User_ID, First_name, Last_name, Contact_number, Address, Status)
SELECT u.User_ID, 'Cara', 'Dela Cruz', '09170000003', '25 Acacia Road, Marikina City', 'active'
FROM users u WHERE u.Username = 'demo.owner.cara'
AND NOT EXISTS (SELECT 1 FROM owners o WHERE o.User_ID = u.User_ID);
INSERT INTO owners (User_ID, First_name, Last_name, Contact_number, Address, Status)
SELECT u.User_ID, 'Diego', 'Mendoza', '09170000004', '4 Riverside Lane, Pasig City', 'active'
FROM users u WHERE u.Username = 'demo.owner.diego'
AND NOT EXISTS (SELECT 1 FROM owners o WHERE o.User_ID = u.User_ID);

INSERT INTO staff (User_ID, First_name, Last_name, Position, Status)
SELECT u.User_ID, 'Jamie', 'Navarro', 'Veterinarian', 'active'
FROM users u WHERE u.Username = 'demo.vet'
AND NOT EXISTS (SELECT 1 FROM staff s WHERE s.User_ID = u.User_ID);
INSERT INTO staff (User_ID, First_name, Last_name, Position, Status)
SELECT u.User_ID, 'Taylor', 'Garcia', 'Office Staff', 'active'
FROM users u WHERE u.Username = 'demo.staff'
AND NOT EXISTS (SELECT 1 FROM staff s WHERE s.User_ID = u.User_ID);
INSERT INTO staff (User_ID, First_name, Last_name, Position, Status)
SELECT u.User_ID, 'Morgan', 'Lim', 'Administrator', 'active'
FROM users u WHERE u.Username = 'demo.admin'
AND NOT EXISTS (SELECT 1 FROM staff s WHERE s.User_ID = u.User_ID);
INSERT INTO staff (User_ID, First_name, Last_name, Position, Status)
SELECT u.User_ID, 'Xandrah', 'Brua', 'Veterinarian', 'active'
FROM users u WHERE u.Username = 'demo.vet.brua'
AND NOT EXISTS (SELECT 1 FROM staff s WHERE s.User_ID = u.User_ID);
INSERT INTO staff (User_ID, First_name, Last_name, Position, Status)
SELECT u.User_ID, 'Rod', 'Baylo', 'Veterinarian', 'active'
FROM users u WHERE u.Username = 'demo.vet.baylo'
AND NOT EXISTS (SELECT 1 FROM staff s WHERE s.User_ID = u.User_ID);
INSERT INTO staff (User_ID, First_name, Last_name, Position, Status)
SELECT u.User_ID, 'Ruperto', 'Desuyo', 'Veterinarian', 'active'
FROM users u WHERE u.Username = 'demo.vet.desuyo'
AND NOT EXISTS (SELECT 1 FROM staff s WHERE s.User_ID = u.User_ID);
INSERT INTO staff (User_ID, First_name, Last_name, Position, Status)
SELECT u.User_ID, 'Christopher', 'Gonzales', 'Veterinarian', 'active'
FROM users u WHERE u.Username = 'demo.vet.gonzales'
AND NOT EXISTS (SELECT 1 FROM staff s WHERE s.User_ID = u.User_ID);
INSERT INTO staff (User_ID, First_name, Last_name, Position, Status)
SELECT u.User_ID, 'Norman', 'Enriquez', 'Veterinarian', 'active'
FROM users u WHERE u.Username = 'demo.vet.enriquez'
AND NOT EXISTS (SELECT 1 FROM staff s WHERE s.User_ID = u.User_ID);

INSERT INTO pets (Owner_ID, Name, Species_ID, Breed_ID, Gender, Birthdate, Weight, Color_Markings, Status)
SELECT o.Owner_ID, 'Mochi', 1, 1, 'Female', '2021-03-14', 12.40, 'Tan and white', 'active'
FROM owners o JOIN users u ON u.User_ID = o.User_ID
WHERE u.Username = 'demo.owner.alice'
AND NOT EXISTS (SELECT 1 FROM pets p WHERE p.Owner_ID = o.Owner_ID AND p.Name = 'Mochi');
INSERT INTO pets (Owner_ID, Name, Species_ID, Breed_ID, Gender, Birthdate, Weight, Color_Markings, Status)
SELECT o.Owner_ID, 'Bubbles', 2, 21, 'Female', '2024-05-01', 3.20, 'Orange tabby', 'active'
FROM owners o JOIN users u ON u.User_ID = o.User_ID
WHERE u.Username = 'demo.owner.alice'
AND NOT EXISTS (SELECT 1 FROM pets p WHERE p.Owner_ID = o.Owner_ID AND p.Name = 'Bubbles');
INSERT INTO pets (Owner_ID, Name, Species_ID, Breed_ID, Gender, Birthdate, Weight, Color_Markings, Status)
SELECT o.Owner_ID, 'Luna', 2, 21, 'Female', '2020-11-08', 4.10, 'Calico', 'active'
FROM owners o JOIN users u ON u.User_ID = o.User_ID
WHERE u.Username = 'demo.owner.ben'
AND NOT EXISTS (SELECT 1 FROM pets p WHERE p.Owner_ID = o.Owner_ID AND p.Name = 'Luna');
INSERT INTO pets (Owner_ID, Name, Species_ID, Breed_ID, Gender, Birthdate, Weight, Color_Markings, Status)
SELECT o.Owner_ID, 'Pepper', 1, 1, 'Male', '2022-06-02', 18.70, 'Black brindle', 'active'
FROM owners o JOIN users u ON u.User_ID = o.User_ID
WHERE u.Username = 'demo.owner.cara'
AND NOT EXISTS (SELECT 1 FROM pets p WHERE p.Owner_ID = o.Owner_ID AND p.Name = 'Pepper');
INSERT INTO pets (Owner_ID, Name, Species_ID, Breed_ID, Gender, Birthdate, Weight, Color_Markings, Status)
SELECT o.Owner_ID, 'Tofu', 1, 1, 'Male', '2023-02-20', 12.00, 'White', 'active'
FROM owners o JOIN users u ON u.User_ID = o.User_ID
WHERE u.Username = 'demo.owner.diego'
AND NOT EXISTS (SELECT 1 FROM pets p WHERE p.Owner_ID = o.Owner_ID AND p.Name = 'Tofu');
INSERT INTO pets (Owner_ID, Name, Species_ID, Breed_ID, Gender, Birthdate, Weight, Color_Markings, Status)
SELECT o.Owner_ID, 'Scout', 1, 1, 'Male', '2019-09-19', 22.30, 'Brown', 'active'
FROM owners o JOIN users u ON u.User_ID = o.User_ID
WHERE u.Username = 'demo.owner.diego'
AND NOT EXISTS (SELECT 1 FROM pets p WHERE p.Owner_ID = o.Owner_ID AND p.Name = 'Scout');

INSERT INTO calendar_events (Title, Event_Type, Event_Date, Max_Slots, Content, Status)
SELECT 'Demo Spay and Neuter Event', 'SpayNeuter', '2026-09-12', 20, 'Demo history: includes confirmed, catered, cancelled, and no-show bookings.', 'Closed'
WHERE NOT EXISTS (SELECT 1 FROM calendar_events WHERE Title = 'Demo Spay and Neuter Event');
INSERT INTO calendar_events (Title, Event_Type, Event_Date, Max_Slots, Content, Status)
SELECT 'Demo Community Pet Wellness Day', 'SpayNeuter', '2026-11-15', 12, 'Future demo event for calendar, booking, and event detail testing.', 'Open'
WHERE NOT EXISTS (SELECT 1 FROM calendar_events WHERE Title = 'Demo Community Pet Wellness Day');
INSERT INTO calendar_events (Title, Event_Type, Event_Date, Max_Slots, Content, Status)
SELECT 'Demo Microchip Event', 'General', '2026-11-15', 0, 'General event for the same-day multi-event calendar demonstration.', 'Open'
WHERE NOT EXISTS (SELECT 1 FROM calendar_events WHERE Title = 'Demo Microchip Event');
INSERT INTO calendar_events (Title, Event_Type, Event_Date, Max_Slots, Content, Status)
SELECT 'Demo Vaccination Drive', 'General', '2026-11-15', 0, 'General event for the same-day multi-event calendar demonstration.', 'Open'
WHERE NOT EXISTS (SELECT 1 FROM calendar_events WHERE Title = 'Demo Vaccination Drive');

INSERT INTO appointments (Event_ID, Owner_ID, Pet_ID, Service_ID, Vet_ID, Appointment_Date, Status, Confirmed_At, Notes)
SELECT ce.Event_ID, o.Owner_ID, p.Pet_ID, 4, s.Staff_ID, '2026-09-12 09:00:00', 'Confirmed', '2026-09-01 10:00:00', 'Demo confirmed booking.'
FROM calendar_events ce
JOIN users u ON u.Username = 'demo.owner.alice'
JOIN owners o ON o.User_ID = u.User_ID
JOIN pets p ON p.Owner_ID = o.Owner_ID AND p.Name = 'Mochi'
LEFT JOIN staff s ON s.User_ID = (SELECT User_ID FROM users WHERE Username = 'demo.vet')
WHERE ce.Title = 'Demo Spay and Neuter Event'
AND NOT EXISTS (SELECT 1 FROM appointments a WHERE a.Event_ID = ce.Event_ID AND a.Pet_ID = p.Pet_ID);
INSERT INTO appointments (Event_ID, Owner_ID, Pet_ID, Service_ID, Vet_ID, Appointment_Date, Status, Confirmed_At, Notes)
SELECT ce.Event_ID, o.Owner_ID, p.Pet_ID, 3, s.Staff_ID, '2026-09-12 09:30:00', 'Completed', '2026-09-02 11:00:00', 'Demo catered booking.'
FROM calendar_events ce
JOIN users u ON u.Username = 'demo.owner.ben'
JOIN owners o ON o.User_ID = u.User_ID
JOIN pets p ON p.Owner_ID = o.Owner_ID AND p.Name = 'Luna'
LEFT JOIN staff s ON s.User_ID = (SELECT User_ID FROM users WHERE Username = 'demo.vet')
WHERE ce.Title = 'Demo Spay and Neuter Event'
AND NOT EXISTS (SELECT 1 FROM appointments a WHERE a.Event_ID = ce.Event_ID AND a.Pet_ID = p.Pet_ID);
INSERT INTO appointments (Event_ID, Owner_ID, Pet_ID, Service_ID, Vet_ID, Appointment_Date, Status, Confirmed_At, Notes)
SELECT ce.Event_ID, o.Owner_ID, p.Pet_ID, 4, s.Staff_ID, '2026-09-12 10:00:00', 'Cancelled', NULL, 'Demo cancellation before event day.'
FROM calendar_events ce
JOIN users u ON u.Username = 'demo.owner.cara'
JOIN owners o ON o.User_ID = u.User_ID
JOIN pets p ON p.Owner_ID = o.Owner_ID AND p.Name = 'Pepper'
LEFT JOIN staff s ON s.User_ID = (SELECT User_ID FROM users WHERE Username = 'demo.vet')
WHERE ce.Title = 'Demo Spay and Neuter Event'
AND NOT EXISTS (SELECT 1 FROM appointments a WHERE a.Event_ID = ce.Event_ID AND a.Pet_ID = p.Pet_ID);
INSERT INTO appointments (Event_ID, Owner_ID, Pet_ID, Service_ID, Vet_ID, Appointment_Date, Status, Confirmed_At, Notes)
SELECT ce.Event_ID, o.Owner_ID, p.Pet_ID, 4, s.Staff_ID, '2026-09-12 10:30:00', 'No Show', '2026-09-03 09:00:00', 'Demo confirmed booking marked no-show.'
FROM calendar_events ce
JOIN users u ON u.Username = 'demo.owner.diego'
JOIN owners o ON o.User_ID = u.User_ID
JOIN pets p ON p.Owner_ID = o.Owner_ID AND p.Name = 'Scout'
LEFT JOIN staff s ON s.User_ID = (SELECT User_ID FROM users WHERE Username = 'demo.vet')
WHERE ce.Title = 'Demo Spay and Neuter Event'
AND NOT EXISTS (SELECT 1 FROM appointments a WHERE a.Event_ID = ce.Event_ID AND a.Pet_ID = p.Pet_ID);
INSERT INTO appointments (Event_ID, Owner_ID, Pet_ID, Service_ID, Vet_ID, Appointment_Date, Status, Notes)
SELECT ce.Event_ID, o.Owner_ID, p.Pet_ID, 4, s.Staff_ID, '2026-11-15 09:00:00', 'Pending', 'Future demo booking awaiting confirmation.'
FROM calendar_events ce
JOIN users u ON u.Username = 'demo.owner.alice'
JOIN owners o ON o.User_ID = u.User_ID
JOIN pets p ON p.Owner_ID = o.Owner_ID AND p.Name = 'Mochi'
LEFT JOIN staff s ON s.User_ID = (SELECT User_ID FROM users WHERE Username = 'demo.vet')
WHERE ce.Title = 'Demo Community Pet Wellness Day'
AND NOT EXISTS (SELECT 1 FROM appointments a WHERE a.Event_ID = ce.Event_ID AND a.Pet_ID = p.Pet_ID);
INSERT INTO appointments (Event_ID, Owner_ID, Pet_ID, Service_ID, Vet_ID, Appointment_Date, Status, Confirmed_At, Notes)
SELECT ce.Event_ID, o.Owner_ID, p.Pet_ID, 3, s.Staff_ID, '2026-11-15 09:30:00', 'Confirmed', '2026-10-01 10:00:00', 'Future demo booking confirmed by office staff.'
FROM calendar_events ce
JOIN users u ON u.Username = 'demo.owner.ben'
JOIN owners o ON o.User_ID = u.User_ID
JOIN pets p ON p.Owner_ID = o.Owner_ID AND p.Name = 'Luna'
LEFT JOIN staff s ON s.User_ID = (SELECT User_ID FROM users WHERE Username = 'demo.vet')
WHERE ce.Title = 'Demo Community Pet Wellness Day'
AND NOT EXISTS (SELECT 1 FROM appointments a WHERE a.Event_ID = ce.Event_ID AND a.Pet_ID = p.Pet_ID);
INSERT INTO appointments (Event_ID, Owner_ID, Pet_ID, Service_ID, Vet_ID, Appointment_Date, Status, Notes)
SELECT ce.Event_ID, o.Owner_ID, p.Pet_ID, 4, s.Staff_ID, '2026-11-15 10:00:00', 'Pending', 'Future demo booking for staff cancellation testing.'
FROM calendar_events ce
JOIN users u ON u.Username = 'demo.owner.cara'
JOIN owners o ON o.User_ID = u.User_ID
JOIN pets p ON p.Owner_ID = o.Owner_ID AND p.Name = 'Pepper'
LEFT JOIN staff s ON s.User_ID = (SELECT User_ID FROM users WHERE Username = 'demo.vet')
WHERE ce.Title = 'Demo Community Pet Wellness Day'
AND NOT EXISTS (SELECT 1 FROM appointments a WHERE a.Event_ID = ce.Event_ID AND a.Pet_ID = p.Pet_ID);

INSERT INTO appointment_pets (Appointment_ID, Pet_ID)
SELECT a.Appointment_ID, a.Pet_ID
FROM appointments a
JOIN calendar_events ce ON ce.Event_ID = a.Event_ID
WHERE ce.Title = 'Demo Spay and Neuter Event'
AND NOT EXISTS (SELECT 1 FROM appointment_pets ap WHERE ap.Appointment_ID = a.Appointment_ID AND ap.Pet_ID = a.Pet_ID);
INSERT INTO appointment_pets (Appointment_ID, Pet_ID)
SELECT a.Appointment_ID, a.Pet_ID
FROM appointments a
JOIN calendar_events ce ON ce.Event_ID = a.Event_ID
WHERE ce.Title = 'Demo Community Pet Wellness Day'
AND NOT EXISTS (SELECT 1 FROM appointment_pets ap WHERE ap.Appointment_ID = a.Appointment_ID AND ap.Pet_ID = a.Pet_ID);

INSERT INTO consultations (Owner_ID, Pet_ID, Vet_ID, Subject, Concern_Description, Status, Consultation_Date)
SELECT o.Owner_ID, p.Pet_ID, uvet.User_ID, 'Annual wellness check', 'Routine examination; appetite and activity are normal.', 'Completed', '2026-08-04 10:00:00'
FROM users u JOIN owners o ON o.User_ID = u.User_ID
JOIN pets p ON p.Owner_ID = o.Owner_ID AND p.Name = 'Mochi'
JOIN users uvet ON uvet.Username = 'demo.vet'
WHERE u.Username = 'demo.owner.alice'
AND NOT EXISTS (SELECT 1 FROM consultations c WHERE c.Owner_ID = o.Owner_ID AND c.Pet_ID = p.Pet_ID AND c.Subject = 'Annual wellness check');
INSERT INTO consultations (Owner_ID, Pet_ID, Vet_ID, Subject, Concern_Description, Status, Consultation_Date)
SELECT o.Owner_ID, p.Pet_ID, uvet.User_ID, 'Dental assessment', 'Mild tartar noted; home dental care discussed.', 'Completed', '2026-07-21 14:30:00'
FROM users u JOIN owners o ON o.User_ID = u.User_ID
JOIN pets p ON p.Owner_ID = o.Owner_ID AND p.Name = 'Luna'
JOIN users uvet ON uvet.Username = 'demo.vet'
WHERE u.Username = 'demo.owner.ben'
AND NOT EXISTS (SELECT 1 FROM consultations c WHERE c.Owner_ID = o.Owner_ID AND c.Pet_ID = p.Pet_ID AND c.Subject = 'Dental assessment');

INSERT INTO medical_records (Pet_ID, Vet_ID, Diagnosis_ID, Treatment, Visit_Date, Notes, Booklet, Medicine_Used)
SELECT p.Pet_ID, uvet.User_ID, 1, 'Anti-Rabies Vaccination', '2026-01-15 10:00:00', 'Tolerated vaccination well.', 'Vaccination booklet updated.', 'Anti-rabies vaccine'
FROM users u JOIN owners o ON o.User_ID = u.User_ID
JOIN pets p ON p.Owner_ID = o.Owner_ID AND p.Name = 'Mochi'
JOIN users uvet ON uvet.Username = 'demo.vet'
WHERE u.Username = 'demo.owner.alice'
AND NOT EXISTS (SELECT 1 FROM medical_records m WHERE m.Pet_ID = p.Pet_ID AND m.Visit_Date = '2026-01-15 10:00:00' AND m.Treatment = 'Anti-Rabies Vaccination');
INSERT INTO medical_records (Pet_ID, Vet_ID, Diagnosis_ID, Treatment, Visit_Date, Notes, Booklet, Medicine_Used)
SELECT p.Pet_ID, uvet.User_ID, 1, 'Parvo Vaccination', '2026-09-30 11:30:00', 'Follow-up due in one month.', 'Vaccination booklet updated.', 'Parvovirus vaccine'
FROM users u JOIN owners o ON o.User_ID = u.User_ID
JOIN pets p ON p.Owner_ID = o.Owner_ID AND p.Name = 'Luna'
JOIN users uvet ON uvet.Username = 'demo.vet'
WHERE u.Username = 'demo.owner.ben'
AND NOT EXISTS (SELECT 1 FROM medical_records m WHERE m.Pet_ID = p.Pet_ID AND m.Visit_Date = '2026-09-30 11:30:00' AND m.Treatment = 'Parvo Vaccination');
INSERT INTO medical_records (Pet_ID, Vet_ID, Diagnosis_ID, Treatment, Visit_Date, Notes)
SELECT p.Pet_ID, uvet.User_ID, 1, 'Deworming', '2026-08-10 09:15:00', 'Routine parasite prevention; not a vaccination.'
FROM users u JOIN owners o ON o.User_ID = u.User_ID
JOIN pets p ON p.Owner_ID = o.Owner_ID AND p.Name = 'Tofu'
JOIN users uvet ON uvet.Username = 'demo.vet'
WHERE u.Username = 'demo.owner.diego'
AND NOT EXISTS (SELECT 1 FROM medical_records m WHERE m.Pet_ID = p.Pet_ID AND m.Visit_Date = '2026-08-10 09:15:00' AND m.Treatment = 'Deworming');

INSERT INTO vaccinations (Pet_ID, Vaccine_Name, Date_Administered, Next_Due_Date, Vet_ID)
SELECT p.Pet_ID, 'Anti-Rabies Vaccination', '2026-01-15', '2027-01-15', uvet.User_ID
FROM users u JOIN owners o ON o.User_ID = u.User_ID
JOIN pets p ON p.Owner_ID = o.Owner_ID AND p.Name = 'Mochi'
JOIN users uvet ON uvet.Username = 'demo.vet'
WHERE u.Username = 'demo.owner.alice'
AND NOT EXISTS (SELECT 1 FROM vaccinations v WHERE v.Pet_ID = p.Pet_ID AND v.Vaccine_Name = 'Anti-Rabies Vaccination' AND v.Date_Administered = '2026-01-15');
INSERT INTO vaccinations (Pet_ID, Vaccine_Name, Date_Administered, Next_Due_Date, Vet_ID)
SELECT p.Pet_ID, 'Parvo Vaccination', '2026-09-30', '2026-10-30', uvet.User_ID
FROM users u JOIN owners o ON o.User_ID = u.User_ID
JOIN pets p ON p.Owner_ID = o.Owner_ID AND p.Name = 'Luna'
JOIN users uvet ON uvet.Username = 'demo.vet'
WHERE u.Username = 'demo.owner.ben'
AND NOT EXISTS (SELECT 1 FROM vaccinations v WHERE v.Pet_ID = p.Pet_ID AND v.Vaccine_Name = 'Parvo Vaccination' AND v.Date_Administered = '2026-09-30');

INSERT IGNORE INTO `vet_duty_schedule` (`Duty_Date`, `Vet_User_ID`)
SELECT t.duty_date, u.User_ID
FROM (
    SELECT '2026-10-01' AS duty_date, 'Xandrah' AS first_name, 'Brua' AS last_name UNION ALL
    SELECT '2026-10-02' AS duty_date, 'Rod' AS first_name, 'Baylo' AS last_name UNION ALL
    SELECT '2026-10-05' AS duty_date, 'Ruperto' AS first_name, 'Desuyo' AS last_name UNION ALL
    SELECT '2026-10-06' AS duty_date, 'Christopher' AS first_name, 'Gonzales' AS last_name UNION ALL
    SELECT '2026-10-07' AS duty_date, 'Norman' AS first_name, 'Enriquez' AS last_name UNION ALL
    SELECT '2026-10-08' AS duty_date, 'Xandrah' AS first_name, 'Brua' AS last_name UNION ALL
    SELECT '2026-10-09' AS duty_date, 'Rod' AS first_name, 'Baylo' AS last_name UNION ALL
    SELECT '2026-10-12' AS duty_date, 'Ruperto' AS first_name, 'Desuyo' AS last_name UNION ALL
    SELECT '2026-10-13' AS duty_date, 'Christopher' AS first_name, 'Gonzales' AS last_name UNION ALL
    SELECT '2026-10-14' AS duty_date, 'Norman' AS first_name, 'Enriquez' AS last_name UNION ALL
    SELECT '2026-10-15' AS duty_date, 'Xandrah' AS first_name, 'Brua' AS last_name UNION ALL
    SELECT '2026-10-16' AS duty_date, 'Rod' AS first_name, 'Baylo' AS last_name UNION ALL
    SELECT '2026-10-19' AS duty_date, 'Ruperto' AS first_name, 'Desuyo' AS last_name UNION ALL
    SELECT '2026-10-20' AS duty_date, 'Christopher' AS first_name, 'Gonzales' AS last_name UNION ALL
    SELECT '2026-10-21' AS duty_date, 'Norman' AS first_name, 'Enriquez' AS last_name UNION ALL
    SELECT '2026-10-22' AS duty_date, 'Xandrah' AS first_name, 'Brua' AS last_name UNION ALL
    SELECT '2026-10-23' AS duty_date, 'Rod' AS first_name, 'Baylo' AS last_name UNION ALL
    SELECT '2026-10-26' AS duty_date, 'Ruperto' AS first_name, 'Desuyo' AS last_name UNION ALL
    SELECT '2026-10-27' AS duty_date, 'Christopher' AS first_name, 'Gonzales' AS last_name UNION ALL
    SELECT '2026-10-28' AS duty_date, 'Norman' AS first_name, 'Enriquez' AS last_name UNION ALL
    SELECT '2026-10-29' AS duty_date, 'Xandrah' AS first_name, 'Brua' AS last_name UNION ALL
    SELECT '2026-10-30' AS duty_date, 'Rod' AS first_name, 'Baylo' AS last_name
) AS t
JOIN staff s ON LOWER(TRIM(s.Last_name)) = LOWER(t.last_name)
            AND LOWER(TRIM(s.First_name)) LIKE CONCAT(LOWER(t.first_name), '%')
JOIN users u ON u.User_ID = s.User_ID AND u.Role_ID = 2;

UPDATE services SET Status = 'active' WHERE Service_Name = 'Anti-Rabies Vaccination';

COMMIT;
