SET @owner_barangay_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'owners' AND COLUMN_NAME = 'Barangay');
SET @owner_barangay_sql := IF(@owner_barangay_exists = 0, 'ALTER TABLE owners ADD COLUMN Barangay varchar(100) DEFAULT NULL AFTER Address', 'SELECT 1');
PREPARE owner_barangay_stmt FROM @owner_barangay_sql;
EXECUTE owner_barangay_stmt;
DEALLOCATE PREPARE owner_barangay_stmt;

SET @event_barangay_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'calendar_events' AND COLUMN_NAME = 'Barangay');
SET @event_barangay_sql := IF(@event_barangay_exists = 0, 'ALTER TABLE calendar_events ADD COLUMN Barangay varchar(100) DEFAULT NULL AFTER Event_Date', 'SELECT 1');
PREPARE event_barangay_stmt FROM @event_barangay_sql;
EXECUTE event_barangay_stmt;
DEALLOCATE PREPARE event_barangay_stmt;
