# City Vet Management System — Database Installation Guide

This guide details how to install, configure, and verify the database for the City Vet Management System on standard shared hosting environments, including InfinityFree, cPanel, and local phpMyAdmin instances.

---

## 1. Prerequisites

Before beginning the installation, ensure you have:
- Access to your hosting control panel or local MySQL/MariaDB server.
- phpMyAdmin access or MySQL CLI client.
- The consolidated database schema file: `DATABASE/deployment_clean_schema.sql`.
- The sequential migration scripts located in `DATABASE/`.

---

## 2. Step-by-Step Installation Process

### Step 2.1: Create the MySQL Database
1. Create a database named `city_vet_verify` (or host-specific database name).
2. Set character set to `utf8mb4` and collation to `utf8mb4_general_ci`.

### Step 2.2: Import Schema and Migrations in Order
Run the base schema followed by every migration in the exact sequence listed below:

1. `DATABASE/deployment_clean_schema.sql`
   Baseline database tables, foreign keys, and system seed catalogs.

2. `DATABASE/migration_services_proper_names.sql`
   Standardizes service casing and proper display names across services.

3. `DATABASE/migration_add_otp_and_medical_fields.sql`
   Adds one-time password verification columns and medical history extensions.

4. `DATABASE/migration_live_queue_and_medical.sql`
   Integrates live ticket queue structures with medical records and consultation tracking.

5. `DATABASE/migration_live_queue_no_owner.sql`
   Enables ownerless and petless walk-in ticket creation for rapid reception entry.

6. `DATABASE/migration_add_mongrel_breed.sql`
   Adds Mongrel / Aspin breed options to Dog and Cat catalogs.

7. `DATABASE/migration_vet_duty_schedule.sql`
   Creates `vet_duty_schedule` table for Officer of the Day schedule imports and assignments.

8. `DATABASE/migration_consultation_catalogs.sql`
   Establishes consultation treatments and medicines master dropdown catalogs, removing manual booklet entry.

9. `DATABASE/migration_walkin_services.sql`
   Restricts walk-in queue services to General Checkup, Anti-Rabies Vaccination, 5-in-1 Vaccination, Parvo Vaccination, Deworming, and Online Consultation, ensuring Spay/Neuter remains event-only.

10. `DATABASE/migration_restrict_species.sql`
    Deactivates Other/Exotic and Fish species and their associated breeds, restricting active registration to Dog and Cat.

11. `DATABASE/migration_consultation_template.sql`
    Adds consultation findings and the data-driven Dog/Cat vaccination schedule rules.

12. `DATABASE/migration_notification_event_links.sql`
    Adds nullable calendar-event links to notifications.

13. `DATABASE/migration_event_barangay_targeting.sql`
    Adds barangay targeting fields for event notifications and owner matching.

14. `DATABASE/migration_spay_neuter_confirmation_calls.sql`
    Adds staff confirmation/callback tracking fields for Spay/Neuter appointments.

15. `DATABASE/demo_data.sql` (Optional for demo and staging verification)
    Seeds accounts for Administrator, Staff, Pet Owners, and Veterinarians (Brua, Baylo, Desuyo, Gonzales, Enriquez) with scheduled shifts and sample records.

### Step 2.3: Verification Command (PowerShell CLI)
For local testing or verification environments:

```powershell
$mysql = "C:\xampp\mysql\bin\mysql.exe"
$db = "city_vet_verify"

& $mysql -u root -e "CREATE DATABASE IF NOT EXISTS $db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"
& $env:ComSpec /c "`"$mysql`" -u root $db < `"DATABASE\deployment_clean_schema.sql`""
& $env:ComSpec /c "`"$mysql`" -u root $db < `"DATABASE\migration_services_proper_names.sql`""
& $env:ComSpec /c "`"$mysql`" -u root $db < `"DATABASE\migration_add_otp_and_medical_fields.sql`""
& $env:ComSpec /c "`"$mysql`" -u root $db < `"DATABASE\migration_live_queue_and_medical.sql`""
& $env:ComSpec /c "`"$mysql`" -u root $db < `"DATABASE\migration_live_queue_no_owner.sql`""
& $env:ComSpec /c "`"$mysql`" -u root $db < `"DATABASE\migration_add_mongrel_breed.sql`""
& $env:ComSpec /c "`"$mysql`" -u root $db < `"DATABASE\migration_vet_duty_schedule.sql`""
& $env:ComSpec /c "`"$mysql`" -u root $db < `"DATABASE\migration_consultation_catalogs.sql`""
& $env:ComSpec /c "`"$mysql`" -u root $db < `"DATABASE\migration_walkin_services.sql`""
& $env:ComSpec /c "`"$mysql`" -u root $db < `"DATABASE\migration_restrict_species.sql`""
& $env:ComSpec /c "`"$mysql`" -u root $db < `"DATABASE\migration_consultation_template.sql`""
& $env:ComSpec /c "`"$mysql`" -u root $db < `"DATABASE\migration_notification_event_links.sql`""
& $env:ComSpec /c "`"$mysql`" -u root $db < `"DATABASE\migration_event_barangay_targeting.sql`""
& $env:ComSpec /c "`"$mysql`" -u root $db < `"DATABASE\migration_spay_neuter_confirmation_calls.sql`""
& $env:ComSpec /c "`"$mysql`" -u root $db < `"DATABASE\demo_data.sql`""
```

---

## 3. Schema Structure & Table Verification

Run `DATABASE/migration_consultation_template.sql` after `DATABASE/migration_consultation_catalogs.sql` and before the walk-in-services migration. It is idempotent and adds `consultation_findings`, `vaccination_schedule_rules`, and the cat vaccination service.

Run `DATABASE/migration_notification_event_links.sql` after the consultation-template migration to add nullable event links to notifications.

The full database installation contains the following primary table groups:

| Category | Tables | Description |
| :--- | :--- | :--- |
| System & Reference | `roles`, `species`, `breeds`, `service_categories`, `services`, `diagnosis_master`, `treatment_catalog`, `medicine_catalog`, `login_rate_limits` | Foundational reference catalogs, treatments/medicines master lists, diagnosis codes, and rate limiting |
| Accounts & Profiles | `users`, `staff`, `owners` | User authentication, staff accounts, and pet owner profiles |
| Content & Scheduling | `calendar_events`, `carousel_images`, `first_aid_videos`, `homepage_posts`, `notifications`, `vet_duty_schedule`, `vet_availability` | Public CMS content, spay/neuter events, notifications, officer-of-the-day shift schedule, and weekly veterinarian availability |
| Clinical Records | `pets`, `pet_notes`, `vaccinations`, `appointments`, `consultations`, `appointment_pets`, `medical_records`, `live_queue`, `live_queue_services`, `audit_logs` | Pet records, walk-in queue tickets, appointments, consultation sessions, treatments, and immutable audit trail |

---

## 4. Troubleshooting Common Import Issues

### Issue 1: "Duplicate column name" or "Key already exists"
- Resolution: All migrations use conditional checks (`IF NOT EXISTS` or check routines) to support idempotent execution. Ensure scripts are executed in the exact numerical sequence specified above.

### Issue 2: "Foreign key constraint fails"
- Resolution: Ensure base tables from `deployment_clean_schema.sql` are created before migrations. Ensure `SET FOREIGN_KEY_CHECKS = 0;` is present at the start of import operations.
