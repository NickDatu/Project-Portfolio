# City Vet Reports & Analytics — Metric Definitions

All report dates use **Asia/Manila**. Date ranges are inclusive and use the appointment's **appointments.Appointment_Date**, except Rabies doses, which use **vaccinations.Date_Administered**.

## Eligibility rule

Reports include appointments whose owner has **owners.Status = active** and whose pet has **pets.Status not archived**. Inactive owners and archived pets are excluded consistently from appointment, client, program, trend, heatmap, and vaccination counts.

## KPI definitions

- **Appointments in range**: count of eligible appointment records with **Appointment_Date** between the selected start date at **00:00:00** and the day after the selected end date at **00:00:00**. Cancelled appointments are included.
- **Clients in range**: distinct eligible **Owner_ID** values with at least one appointment in the range.
- **No-show / cancellation rate**: **(No Show + Cancelled) / (Completed + No Show + Cancelled) × 100**. The denominator is resolved appointments only. If the denominator is zero, the result is **0%**.

## Program definitions

An appointment belongs to:

- **Spay & Neuter** when its service name contains **spay** or **neuter**.
- **Rabies Vaccination** when its service name contains **rabies**.

For each program:

- **Registered**: all eligible matching appointment records, including cancelled records.
- **Served**: status **Completed**.
- **Scheduled**: statuses **Pending**, **Confirmed**, **Checked In**, or **In Consultation**.
- **Non-appearance**: status **No Show**.
- **Cancelled**: status **Cancelled**.

Therefore, **Registered = Served + Scheduled + Non-appearance + Cancelled**.

## Other metrics

- **Rabies doses administered**: saved vaccination records whose vaccine name contains **rabies**, counted by **Date_Administered**, with archived pets and inactive owners excluded.
- **Peak consultation demand**: eligible appointment slots grouped by Asia/Manila weekday and hour. Status **Cancelled** is excluded.
- **Trend buckets**: daily for ranges up to 31 days, weekly for ranges up to 180 days, and monthly for longer ranges. Empty buckets are included as zero. Weeks begin Monday.
- **Overall**: ignores picker dates and uses the first and last eligible appointment dates in the database.

## Reconciliation checks

The API returns and the page displays checks for:

1. Sum of all status counts equals total appointments.
2. Each program's Registered count equals Served + Scheduled + Non-appearance + Cancelled.
3. Sum of trend appointment buckets equals the appointment KPI.
4. Sum of non-cancelled heatmap cells equals total appointments minus cancelled appointments.

A mismatch is displayed as a visible warning rather than being hidden.
