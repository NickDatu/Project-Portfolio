(function() {
    if (window.CityVetNotifications) return;

    let notifications = [];
    let unreadCount = 0;
    let isDropdownOpen = false;
    let expandedNotificationId = null;

    function escapeHtml(str) {
        if (str === null || str === undefined) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function formatDate(val) {
        if (!val) return '';
        const d = new Date(String(val).replace(' ', 'T'));
        if (isNaN(d.getTime())) return String(val);
        return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    }

    async function fetchNotifications() {
        try {
            const res = await fetch('../../api/notifications/list.php');
            if (!res.ok) return;
            const data = await res.json();
            if (data.status === 'success') {
                notifications = data.notifications || [];
                unreadCount = parseInt(data.unread_count, 10) || 0;
                updateBadge();
                if (isDropdownOpen) {
                    renderList();
                }
            }
        } catch (e) {}
    }

    function updateBadge() {
        const badge = document.getElementById('notificationBadge');
        if (!badge) return;
        if (unreadCount > 0) {
            badge.innerText = unreadCount > 99 ? '99+' : unreadCount;
            badge.classList.remove('hidden');
        } else {
            badge.innerText = '0';
            badge.classList.add('hidden');
        }
    }

    function renderList() {
        const list = document.getElementById('notificationList');
        if (!list) return;

        if (notifications.length === 0) {
            list.innerHTML = '<div class="p-4 text-center text-gray-400">No notifications.</div>';
            return;
        }

        list.innerHTML = notifications.map(n => {
            const isUnread = n.Is_Read === 0;
            const expanded = expandedNotificationId === n.Notification_ID;
            return `
                <div onclick="CityVetNotifications.toggleDetails(${n.Notification_ID})" class="p-3 transition cursor-pointer hover:bg-gray-50 flex gap-2 items-start ${isUnread ? 'bg-teal-50/50' : 'bg-white'}">
                    <div class="mt-1 flex-shrink-0">
                        <span class="inline-block w-2 h-2 rounded-full ${isUnread ? 'bg-teal-600' : 'bg-transparent'}"></span>
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center justify-between gap-1">
                            <h4 class="font-bold text-gray-800 text-xs break-words ${isUnread ? 'text-[#00796B]' : ''}">${escapeHtml(n.Title)}</h4>
                            <span class="text-[10px] text-gray-400 whitespace-nowrap">${escapeHtml(formatDate(n.Sent_At))}</span>
                        </div>
                        <p class="text-xs text-gray-600 mt-0.5 ${expanded ? 'whitespace-pre-line' : 'line-clamp-2'}">${escapeHtml(n.Message)}</p>
                        ${expanded && n.Event_ID ? `<button type="button" onclick="event.stopPropagation(); CityVetNotifications.openEvent(${n.Event_ID})" class="mt-2 rounded-lg bg-[#00796B] px-2.5 py-1.5 text-[11px] font-bold text-white hover:bg-[#004D40]">View event${n.Event_Title ? ': ' + escapeHtml(n.Event_Title) : ''}</button>` : ''}
                        ${expanded ? '<p class="mt-1 text-[10px] text-gray-400">Click outside this notification to close it.</p>' : ''}
                    </div>
                </div>
            `;
        }).join('');
    }

    function toggleDropdown() {
        const dropdown = document.getElementById('notificationDropdown');
        if (!dropdown) return;
        isDropdownOpen = !dropdown.classList.contains('hidden');
        if (isDropdownOpen) {
            dropdown.classList.add('hidden');
            isDropdownOpen = false;
        } else {
            dropdown.classList.remove('hidden');
            isDropdownOpen = true;
            renderList();
        }
    }

    function closeDropdown() {
        const dropdown = document.getElementById('notificationDropdown');
        if (dropdown) {
            dropdown.classList.add('hidden');
            isDropdownOpen = false;
        }
    }

    async function markRead(notificationId) {
        try {
            const res = await fetch('../../api/notifications/list.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'mark_read', notification_id: notificationId })
            });
            if (res.ok) {
                const data = await res.json();
                if (data.status === 'success') {
                    const item = notifications.find(n => n.Notification_ID === notificationId);
                    if (item) item.Is_Read = 1;
                    unreadCount = data.unread_count !== undefined ? parseInt(data.unread_count, 10) : Math.max(0, unreadCount - 1);
                    updateBadge();
                    renderList();
                }
            }
        } catch (e) {}
    }

    async function toggleDetails(notificationId) {
        expandedNotificationId = expandedNotificationId === notificationId ? null : notificationId;
        await markRead(notificationId);
        renderList();
    }

    function openEvent(eventId) {
        const path = window.location.pathname;
        let target;
        if (path.includes('/owner/')) target = '../../views/owner/appointments.html?event_id=' + encodeURIComponent(eventId);
        else if (path.includes('/admin/')) target = '../../views/admin/dashboard.html?event_id=' + encodeURIComponent(eventId);
        else if (path.includes('/staff/')) target = '../../views/staff/dashboard.html?event_id=' + encodeURIComponent(eventId);
        else target = '../../views/vet/dashboard.html?event_id=' + encodeURIComponent(eventId);
        window.location.href = target;
    }

    async function markAllRead() {
        try {
            const res = await fetch('../../api/notifications/list.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'mark_all_read' })
            });
            if (res.ok) {
                const data = await res.json();
                if (data.status === 'success') {
                    notifications.forEach(n => { n.Is_Read = 1; });
                    unreadCount = 0;
                    updateBadge();
                    renderList();
                }
            }
        } catch (e) {}
    }

    document.addEventListener('click', function(e) {
        const container = document.getElementById('sidebar-notification-container');
        if (container && !container.contains(e.target)) {
            closeDropdown();
        }
    });

    window.CityVetNotifications = {
        fetch: fetchNotifications,
        toggleDropdown: toggleDropdown,
        closeDropdown: closeDropdown,
        markRead: markRead,
        toggleDetails: toggleDetails,
        openEvent: openEvent,
        markAllRead: markAllRead
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', fetchNotifications);
    } else {
        fetchNotifications();
    }

    setInterval(fetchNotifications, 30000);
})();
