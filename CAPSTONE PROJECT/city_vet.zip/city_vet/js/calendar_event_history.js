(function () {
    const targetId = 'calendar-event-history';
    let filter = { mode: 'date', value: '' };
    let filterReady = false;
    let eventType = '';
    let eventTitle = '';

    function count(value) {
        return parseInt(value || 0, 10);
    }

    function summary(label, value, color) {
        return `<div class="rounded-xl border border-gray-100 bg-gray-50 p-3 text-center">
            <p class="text-xl font-black ${color}">${count(value)}</p>
            <p class="text-[10px] font-bold uppercase tracking-wide text-gray-500">${label}</p>
        </div>`;
    }

    async function correctBooking(appointmentId, currentStatus) {
        const result = await Swal.fire({ title: 'Correct pet booking status', input: 'select', inputOptions: { Pending: 'Pending', Confirmed: 'Confirmed', 'Checked In': 'Checked In', 'In Consultation': 'In Consultation', Completed: 'Completed', 'No Show': 'No Show', Cancelled: 'Cancelled' }, inputValue: currentStatus, showCancelButton: true, confirmButtonText: 'Continue' });
        if (!result.isConfirmed) return;
        const reason = await Swal.fire({ title: 'Reason required', input: 'textarea', showCancelButton: true, confirmButtonText: 'Save correction', inputValidator: v => !v || v.trim().length < 5 ? 'Please provide at least 5 characters.' : undefined });
        if (!reason.isConfirmed) return;
        const response = await fetch('../../api/calendar/events.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'correct_past_status', appointment_id: appointmentId, status: result.value, reason: reason.value }) });
        const data = await response.json(); if (data.status !== 'success') throw new Error(data.message || 'Unable to correct booking.');
        await Swal.fire('Corrected', data.message, 'success'); load();
    }
    window.correctPastBooking = correctBooking;

    async function load() {
        const target = document.getElementById(targetId);
        if (!target) return;
        if (!filterReady) {
            filterReady = true;
            CityVetUI.mountDateFilter('calendar-event-history-filter', function (nextFilter) {
                filter = nextFilter;
                load();
            });
        }

        const params = new URLSearchParams({ mode: 'history' });
        if (filter.value) params.set(filter.mode, filter.value);
        if (eventType) params.set('event_type', eventType);
        if (eventTitle) params.set('event_title', eventTitle);
        target.querySelector('[data-history-state]').textContent = 'Loading event history...';
        try {
            const response = await fetch('../../api/calendar/events.php?' + params.toString());
            const data = await response.json();
            if (!response.ok || data.status !== 'success') {
                throw new Error(data.message || 'Unable to load event history.');
            }

            const totals = data.totals || {};
            target.querySelector('[data-history-state]').textContent = data.history.length
                ? ''
                : 'No events found for this period.';
            target.querySelector('[data-history-totals]').innerHTML = [
                summary('Events', totals.events, 'text-gray-800'),
                summary('Booked', totals.booked, 'text-blue-700'),
                summary('Confirmed', totals.confirmed, 'text-teal-700'),
                summary('Completed', totals.catered, 'text-green-700'),
                summary('Cancelled', totals.cancelled, 'text-gray-600'),
                summary('Did Not Show', totals.no_show, 'text-rose-600'),
                summary('Not Confirmed', totals.pending, 'text-orange-600')
            ].join('');

            const body = target.querySelector('[data-history-rows]');
            if (!data.history.length) {
                body.innerHTML = '';
                return;
            }
            body.innerHTML = data.history.map(event => `
                <tr class="border-t border-gray-100 hover:bg-gray-50">
                    <td class="px-4 py-3 font-semibold text-gray-800">${CityVetUI.esc(event.Title)} ${event.Corrected_At ? '<span class="ml-1 rounded bg-amber-100 px-1.5 py-0.5 text-[10px] text-amber-700">Corrected</span>' : ''}</td>
                    <td class="px-4 py-3 whitespace-nowrap">${CityVetUI.esc(CityVetUI.formatDate(event.Event_Date))}</td>
                    <td class="px-4 py-3 text-center">${count(event.Total_Booked)} / ${count(event.Max_Slots)}</td>
                    <td class="px-4 py-3 text-center">${count(event.Confirmed_Count)}</td>
                    <td class="px-4 py-3 text-center">${count(event.Catered_Count)}</td>
                    <td class="px-4 py-3 text-center">${count(event.Cancelled_Count)}</td>
                    <td class="px-4 py-3 text-center">${count(event.No_Show_Count)}</td>
                    <td class="px-4 py-3 text-center">${count(event.Pending_Count)}</td>
                    <td class="px-4 py-3 text-center text-xs text-gray-400">Use booking status below</td>
                </tr>${(event.Bookings || []).map(booking => `<tr class="bg-slate-50"><td colspan="2" class="px-8 py-2 text-xs text-slate-600">Booking #${Number(booking.Appointment_ID)} ${booking.Corrected_At ? '<span class="rounded bg-amber-100 px-1 text-amber-700">Corrected</span>' : ''}</td><td colspan="5" class="px-4 py-2 text-xs text-slate-600">Status: ${CityVetUI.esc(booking.Status)}${booking.Correction_Reason ? ' · '+CityVetUI.esc(booking.Correction_Reason) : ''}</td><td class="px-4 py-2 text-center"><button type="button" class="rounded bg-amber-50 px-2 py-1 text-[10px] font-bold text-amber-700" onclick="correctPastBooking(${Number(booking.Appointment_ID)}, '${CityVetUI.esc(booking.Status)}')">Edit</button></td></tr>`).join('')}`).join('');
        } catch (error) {
            target.querySelector('[data-history-state]').textContent = error.message || 'Unable to load event history.';
            target.querySelector('[data-history-state]').classList.add('text-red-500');
            target.querySelector('[data-history-totals]').innerHTML = '';
            target.querySelector('[data-history-rows]').innerHTML = '';
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        const typeFilter = document.getElementById('event-history-type-filter');
        const titleFilter = document.getElementById('event-history-title-filter');
        if (typeFilter) typeFilter.addEventListener('change', () => {
            eventType = typeFilter.value;
            load();
        });
        if (titleFilter) titleFilter.addEventListener('input', () => {
            eventTitle = titleFilter.value.trim();
            load();
        });
        load();
    });
})();
