(function () {
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    let viewDate = new Date();
    let events = [];
    let config = {};

    function isPast(dateStr) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return new Date(`${dateStr}T00:00:00`) < today;
    }

    function escapeHtml(str) {
        if (str === null || str === undefined) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function eventsByDate(dateStr) {
        return events.filter(event => event.Event_Date === dateStr);
    }

    function render() {
        const grid = document.getElementById(config.gridId);
        const monthLabel = document.getElementById(config.monthId);
        if (!grid || !monthLabel) return;

        const month = viewDate.getMonth();
        const year = viewDate.getFullYear();
        const monthValue = `${year}-${String(month + 1).padStart(2, '0')}`;
        if (monthLabel.tagName === 'INPUT') monthLabel.value = monthValue;
        else monthLabel.innerText = `${monthNames[month]} ${year}`;

        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        let html = '';

        for (let i = 0; i < firstDay; i++) {
            html += '<div class="min-h-[3rem] md:min-h-[7rem] rounded-lg bg-gray-50 border border-gray-100 opacity-50"></div>';
        }

        for (let day = 1; day <= daysInMonth; day++) {
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const dayEvents = eventsByDate(dateStr);
            const hasEvents = dayEvents.length > 0;
            const canClick = hasEvents && typeof config.onEventClick === 'function';
            let cellClass = 'bg-white border-gray-200 text-gray-400';
            let chips = '';

            if (hasEvents) {
                const tones = dayEvents.map(e => window.CityVetUI.eventTone(e));
                if (tones.every(t => t === 'closed')) cellClass = 'bg-gray-100 border-gray-200 text-gray-600';
                else if (tones.includes('open')) cellClass = 'bg-teal-50 border-teal-200 text-[#00796B]';
                else if (tones.includes('full')) cellClass = 'bg-red-50 border-red-100 text-red-700';
                else cellClass = 'bg-blue-50 border-blue-200 text-blue-700';
                chips = window.CityVetUI.dayEventChips(dayEvents, 3);
            }

            html += `
                <div class="min-h-[3rem] md:min-h-[7rem] rounded-lg border p-1 md:p-2 flex flex-col items-center justify-start ${cellClass} ${canClick ? 'cursor-pointer hover:shadow-sm transition' : ''}" ${canClick ? `onclick="CityVetSpayCalendar.openDay('${dateStr}')"` : ''}>
                    <span class="text-xs md:text-sm font-black">${day}</span>
                    ${chips}
                </div>
            `;
        }

        grid.innerHTML = html;
    }

    async function load() {
        try {
            const res = await fetch('../../api/calendar/events.php');
            const data = await res.json();
            events = data.status === 'success' ? data.events : [];
        } catch (error) {
            events = [];
        }
        render();
    }

    window.CityVetSpayCalendar = {
        init(options) {
            config = options;
            const monthLabel = document.getElementById(config.monthId);
            if (monthLabel && monthLabel.tagName === 'INPUT') {
                monthLabel.addEventListener('change', (event) => {
                    if (!event.target.value) return;
                    const [year, month] = event.target.value.split('-').map(Number);
                    viewDate = new Date(year, month - 1, 1);
                    render();
                });
            }
            load();
        },
        changeMonth(dir) {
            viewDate.setMonth(viewDate.getMonth() + dir);
            render();
        },
        openDay(dateStr) {
            const dayEvents = eventsByDate(dateStr);
            if (dayEvents.length === 0) return;
            if (dayEvents.length === 1 || !window.Swal) {
                this.openEvent(dayEvents[0].Event_ID);
                return;
            }
            const cards = dayEvents.map(e => window.CityVetUI.eventDetailHtml(e, {
                staff: true,
                actionsHtml: `<div class="mt-3"><button onclick="Swal.close(); CityVetSpayCalendar.openEvent(${parseInt(e.Event_ID, 10)})" class="w-full rounded-lg bg-[#00796B] px-3 py-2 text-xs font-bold text-white hover:bg-teal-700 transition">Open Details</button></div>`
            })).join('<div class="h-2"></div>');
            Swal.fire({
                title: window.CityVetUI.formatDate(dateStr),
                html: `<div class="max-h-[60vh] overflow-y-auto pr-1">${cards}</div>`,
                width: 520,
                confirmButtonText: 'Close'
            });
        },
        openEvent(eventId) {
            const event = events.find(item => parseInt(item.Event_ID, 10) === parseInt(eventId, 10));
            if (event && typeof config.onEventClick === 'function') {
                config.onEventClick(event);
            }
        },
        reload() {
            load();
        }
    };
})();
