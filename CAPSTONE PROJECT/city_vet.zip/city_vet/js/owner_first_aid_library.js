const firstAidVideoLibrary = [];

async function loadFirstAidVideosFromCms() {
    try {
        const response = await fetch('../../api/cms/first_aid_videos.php?public=1');
        const data = await response.json();

        if (data.status !== 'success' || !Array.isArray(data.items)) {
            renderFirstAidVideoGallery([]);
            return [];
        }

        const normalized = data.items
            .filter(item => item && item.Status === 'active')
            .map(item => ({
                title: item.Title,
                description: item.Description || '',
                embedUrl: item.Embed_Url || '',
                tags: (item.Tags || '').split(',').map(tag => tag.trim()).filter(Boolean),
                petCategory: item.Pet_Category || 'all',
                videoType: item.Video_Type || 'General Emergency'
            }));

        firstAidVideoLibrary.splice(0, firstAidVideoLibrary.length, ...normalized);
        renderFirstAidVideoGallery(firstAidVideoLibrary);
        return firstAidVideoLibrary;
    } catch (error) {
        console.error('Failed to load first aid videos from CMS:', error);
        renderFirstAidVideoGallery([]);
        return [];
    }
}

function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function sanitizeEmbedUrl(url) {
    if (!url || typeof url !== 'string') return 'about:blank';
    const trimmed = url.trim();
    const match = trimmed.match(/^https:\/\/(www\.)?(youtube\.com\/embed\/|youtube-nocookie\.com\/embed\/)[a-zA-Z0-9_-]+/);
    return match ? match[0] : 'about:blank';
}

function renderFirstAidVideoGallery(videos = firstAidVideoLibrary) {
    const container = document.getElementById('firstAidVideoGallery');
    const countElement = document.getElementById('firstAidResultsCount');

    if (!container) return;

    if (!videos.length) {
        container.innerHTML = `
            <div class="col-span-full p-6 rounded-2xl border border-dashed border-rose-200 bg-rose-50 text-center text-rose-700">
                <i class="fa-solid fa-magnifying-glass mr-2"></i>
                No emergency videos match that search. Try terms like “bleeding”, “heatstroke”, or “choking”.
            </div>
        `;
        if (countElement) countElement.textContent = '0 videos found';
        return;
    }

    container.innerHTML = videos.map(video => {
        const safeUrl = sanitizeEmbedUrl(video.embedUrl);
        const safeTitle = escapeHtml(video.title);
        const safeDesc = escapeHtml(video.description);
        return `
        <article class="group overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm hover:shadow-lg transition-all duration-200">
            <div class="aspect-video bg-gray-950">
                <iframe
                    src="${safeUrl}"
                    title="${safeTitle}"
                    class="w-full h-full"
                    loading="lazy"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen>
                </iframe>
            </div>
            <div class="p-4">
                <div class="flex items-center justify-between gap-2 mb-2">
                    <span class="inline-flex items-center rounded-full bg-teal-50 px-2.5 py-1 text-[11px] font-bold text-[#00796B] uppercase tracking-wide">
                        <i class="fa-solid fa-heart-pulse mr-1"></i> First Aid
                    </span>
                            <span class="text-[11px] font-semibold text-gray-400">${escapeHtml(video.videoType)} · ${escapeHtml(video.petCategory)}</span>
                </div>
                <h4 class="text-base font-bold text-gray-800 mb-2">${safeTitle}</h4>
                <p class="text-sm text-gray-600 leading-relaxed">${safeDesc}</p>
            </div>
        </article>
        `;
    }).join('');

    if (countElement) {
        countElement.textContent = `${videos.length} video${videos.length === 1 ? '' : 's'} found`;
    }
}

function filterFirstAidVideos(searchTerm) {
    const normalized = searchTerm.trim().toLowerCase();

    if (!normalized) {
        return firstAidVideoLibrary;
    }

    return firstAidVideoLibrary.filter(video => {
        const haystack = [
            video.title,
            video.description,
            video.tags.join(' ')
        ].join(' ').toLowerCase();

        return haystack.includes(normalized);
    });
}

function filterFirstAidLibrary() {
    const search = document.getElementById('firstAidSearch')?.value || '';
    const category = document.getElementById('firstAidCategory')?.value || 'all';
    const type = document.getElementById('firstAidType')?.value || 'all';
    const normalized = search.trim().toLowerCase();
    const filtered = firstAidVideoLibrary.filter(video => {
        const matchesCategory = category === 'all' || video.petCategory === category || video.petCategory === 'all';
        const matchesType = type === 'all' || video.videoType === type;
        const haystack = [video.title, video.description, video.tags.join(' ')].join(' ').toLowerCase();
        return matchesCategory && matchesType && (!normalized || haystack.includes(normalized));
    });
    renderFirstAidVideoGallery(filtered);
}

function openYouTubeSearch(searchTerm) {
    const term = (searchTerm || '').trim();
    if (!term) return;

    const youtubeSearchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(term + ' pet first aid')}`;
    window.open(youtubeSearchUrl, '_blank', 'noopener');
}

async function initFirstAidVideoLibrary() {
    const searchInput = document.getElementById('firstAidSearch');

    if (!searchInput) return;

    await loadFirstAidVideosFromCms();

    const categorySelect = document.getElementById('firstAidCategory');
    const typeSelect = document.getElementById('firstAidType');
    if (typeSelect) {
        [...new Set(firstAidVideoLibrary.map(video => video.videoType).filter(Boolean))].sort().forEach(type => typeSelect.insertAdjacentHTML('beforeend', `<option value="${escapeHtml(type)}">${escapeHtml(type)}</option>`));
    }
    categorySelect?.addEventListener('change', filterFirstAidLibrary);
    typeSelect?.addEventListener('change', filterFirstAidLibrary);

    searchInput.addEventListener('input', function () {
        filterFirstAidLibrary();
    });

    searchInput.addEventListener('keydown', function (event) {
        if (event.key === 'Enter') {
            event.preventDefault();
            openYouTubeSearch(this.value);
        }
    });
}

document.addEventListener('DOMContentLoaded', initFirstAidVideoLibrary);
