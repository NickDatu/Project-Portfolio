(function () {
    var records = [];
    var overlay = null;
    var PICTURE_RE = /^uploads\/medicine\/[A-Za-z0-9_-]+\.(jpg|jpeg|png|webp|gif)$/i;

    function el(tag, className, text) {
        var node = document.createElement(tag);
        if (className) node.className = className;
        if (text !== undefined && text !== null) node.textContent = text;
        return node;
    }

    function formatDate(value) {
        if (!value) return '--';
        var d = new Date(String(value).replace(' ', 'T'));
        if (isNaN(d.getTime())) return String(value);
        return d.toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
    }

    function field(label, value, wide) {
        var box = el('div', wide ? 'sm:col-span-2' : '');
        box.appendChild(el('p', 'text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1', label));
        var shown = (value === undefined || value === null || String(value).trim() === '') ? '--' : String(value);
        box.appendChild(el('p', 'text-sm font-semibold text-gray-800 whitespace-pre-wrap break-words', shown));
        return box;
    }

    function pictureUrl(path) {
        var clean = String(path || '').trim();
        if (!clean || !PICTURE_RE.test(clean)) return '';
        return '../../' + clean;
    }

    function findingsBlock(findings) {
        if (!findings) return null;
        var box = el('div', 'mt-6 border border-gray-200 rounded-xl p-4 sm:col-span-2');
        box.appendChild(el('h4', 'font-bold text-sm text-[#004D40] mb-3', 'Examination Template'));
        if (findings.weight_status) box.appendChild(field('Weight Status', findings.weight_status));
        if (findings.body_condition_score) box.appendChild(field('Body Condition Score', findings.body_condition_score + ' / 9'));
        if (Array.isArray(findings.purpose) && findings.purpose.length) box.appendChild(field('Purpose', findings.purpose.join(', ')));
        var systems = findings.findings || {};
        Object.keys(systems).forEach(function (key) {
            var item = systems[key] || {}, values = Object.keys(item.items || {}).filter(function (x) { return item.items[x]; });
            if (!item.normal && !values.length && !item.other) return;
            var text = item.normal ? 'Appear Normal' : values.concat(item.other ? ['Other: ' + item.other] : []).join(', ');
            box.appendChild(field(key.replace(/_/g, ' '), text, true));
        });
        if (findings.diagnosis) box.appendChild(field('Diagnosis', findings.diagnosis, true));
        if (findings.recommendations) box.appendChild(field('Recommendations', findings.recommendations, true));
        return box;
    }

    function printEsc(value) {
        return String(value === undefined || value === null ? '' : value)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
    }

    function printField(label, value) {
        var shown = value === undefined || value === null || String(value).trim() === '' ? '--' : value;
        return '<div class="field"><div class="label">' + printEsc(label) + '</div><div class="value">' + printEsc(shown) + '</div></div>';
    }

    function printFindings(findings) {
        if (!findings) return '';
        if (typeof findings === 'string') { try { findings = JSON.parse(findings); } catch (e) { return ''; } }
        var html = '<section><h2>Examination Template</h2><div class="grid">';
        html += printField('Weight Status', findings.weight_status);
        html += printField('Body Condition Score', findings.body_condition_score ? findings.body_condition_score + ' / 9' : '');
        html += printField('Purpose', Array.isArray(findings.purpose) ? findings.purpose.join(', ') : '');
        html += '</div>';
        var systems = findings.findings || {};
        Object.keys(systems).forEach(function (key) {
            var item = systems[key] || {}, values = Object.keys(item.items || {}).filter(function (x) { return item.items[x]; });
            if (!item.normal && !values.length && !item.other) return;
            var text = item.normal ? 'Appear Normal' : values.concat(item.other ? ['Other: ' + item.other] : []).join(', ');
            html += printField(key.replace(/_/g, ' '), text);
        });
        html += printField('Diagnosis', findings.diagnosis) + printField('Recommendations', findings.recommendations) + '</section>';
        return html;
    }

    function printRecord(rec) {
        var date = rec.Date || rec.Visit_Date;
        var notes = rec.Notes !== undefined && rec.Notes !== null ? rec.Notes : rec.Symptoms;
        var image = pictureUrl(rec.Medicine_Picture);
        var imageHtml = image ? '<div class="field full"><div class="label">Medicine Picture</div><img class="medicine-image" src="' + printEsc(new URL(image, window.location.href).href) + '" alt="Medicine picture"></div>' : '';
        var html = '<div class="title"><h1>City Veterinary Office - Cagayan de Oro</h1><p>Medical Record / Field Treatment and Consultation Form</p></div><div class="grid">' +
            printField('Pet', rec.Pet_Name) + printField('Date', formatDate(date)) + printField('Type', rec.Type || 'Medical Record') + printField('Veterinarian', rec.Vet_Name || 'Staff (no vet assigned)') +
            printField('Treatment / Procedure', rec.Treatment) + printField('Medicine Used', rec.Medicine_Used) + printField('Symptoms / History / Notes', notes) + imageHtml + '</div>' +
            printFindings(rec.findings || rec.Findings) + '<footer><div class="signature">Veterinarian / Technician</div><div>Printed ' + printEsc(formatDate(new Date())) + '</div></footer>';
        var sheet = document.createElement('div');
        sheet.id = 'cityvet-print-sheet';
        sheet.innerHTML = html;
        document.body.appendChild(sheet);
        var style = document.createElement('style');
        style.id = 'cityvet-print-style';
        style.textContent = '@page{size:A4;margin:16mm}#cityvet-print-sheet{display:none}*{box-sizing:border-box}@media print{body *{visibility:hidden!important}#cityvet-print-sheet,#cityvet-print-sheet *{visibility:visible!important}#cityvet-print-sheet{display:block;position:absolute;left:0;top:0;width:100%;font-family:Arial,sans-serif;color:#172033;font-size:12px;line-height:1.45;background:white}.title{border-bottom:3px solid #00796B;padding-bottom:10px;margin-bottom:16px}.title h1{font-size:20px;color:#004D40;margin:0 0 4px}.title p{margin:0;color:#64748b}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px 24px}.field{break-inside:avoid;margin-bottom:10px}.field.full{grid-column:1/-1}.label{font-size:9px;font-weight:bold;letter-spacing:.12em;text-transform:uppercase;color:#64748b;margin-bottom:2px}.value{white-space:pre-wrap;word-break:break-word;font-weight:600;color:#172033}.medicine-image{display:block;max-width:170px;max-height:190px;object-fit:contain;border:1px solid #cbd5e1;border-radius:6px;padding:4px}section{border-top:1px solid #cbd5e1;margin-top:18px;padding-top:12px;break-inside:auto}h2{font-size:14px;color:#004D40;margin:0 0 10px}footer{border-top:1px solid #cbd5e1;margin-top:26px;padding-top:16px;display:flex;justify-content:space-between}.signature{width:45%;border-top:1px solid #172033;padding-top:5px;margin-top:28px}}';
        document.head.appendChild(style);
        var cleanup = function () { sheet.remove(); style.remove(); window.removeEventListener('afterprint', cleanup); };
        window.addEventListener('afterprint', cleanup);
        setTimeout(function () { window.print(); }, 250);
    }

    function close() {
        if (overlay) {
            overlay.remove();
            overlay = null;
        }
        document.removeEventListener('keydown', onKey);
    }

    function onKey(e) {
        if (e.key === 'Escape') close();
    }

    function open(rec) {
        if (!rec) return;
        close();

        var type = rec.Type || 'Medical Record';
        var date = rec.Date || rec.Visit_Date;
        var notes = rec.Notes !== undefined && rec.Notes !== null ? rec.Notes : rec.Symptoms;
        var vet = rec.Vet_Name || '';
        var imgUrl = pictureUrl(rec.Medicine_Picture);

        overlay = el('div', 'fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm');
        overlay.setAttribute('role', 'dialog');
        overlay.setAttribute('aria-modal', 'true');
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) close();
        });

        var card = el('div', 'bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden');

        var header = el('div', 'px-6 py-4 bg-[#00796B] text-white flex items-center justify-between');
        var titleWrap = el('div');
        titleWrap.appendChild(el('h3', 'font-bold text-lg', 'Medical Record Details'));
        titleWrap.appendChild(el('p', 'text-xs text-teal-100', formatDate(date) + ' \u2022 ' + type));
        header.appendChild(titleWrap);
        var closeX = el('button', 'text-white/80 hover:text-white text-2xl leading-none px-2', '\u00D7');
        closeX.setAttribute('type', 'button');
        closeX.setAttribute('aria-label', 'Close');
        closeX.addEventListener('click', close);
        header.appendChild(closeX);
        card.appendChild(header);

        var body = el('div', 'p-6 overflow-y-auto');
        var grid = el('div', 'grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-5');
        if (rec.Pet_Name) grid.appendChild(field('Pet', rec.Pet_Name));
        grid.appendChild(field('Date', formatDate(date)));
        grid.appendChild(field('Type', type));
        grid.appendChild(field('Veterinarian', vet || 'Staff (no vet assigned)'));
        grid.appendChild(field('Treatment / Procedure', rec.Treatment, true));
        grid.appendChild(field('Medicine Used', rec.Medicine_Used, true));

        var picBox = el('div', 'sm:col-span-2');
        picBox.appendChild(el('p', 'text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2', 'Medicine Picture'));
        if (imgUrl) {
            var link = el('a', 'inline-block');
            link.href = imgUrl;
            link.target = '_blank';
            link.rel = 'noopener';
            link.title = 'Open full size';
            var img = el('img', 'max-h-72 max-w-full rounded-xl border border-gray-200 object-contain bg-gray-50');
            img.src = imgUrl;
            img.alt = 'Medicine picture';
            img.addEventListener('error', function () {
                picBox.removeChild(link);
                picBox.appendChild(el('p', 'text-sm text-gray-400 italic', 'Picture could not be loaded.'));
            });
            link.appendChild(img);
            picBox.appendChild(link);
            picBox.appendChild(el('p', 'text-[11px] text-gray-400 mt-1', 'Click the picture to open it full size.'));
        } else {
            picBox.appendChild(el('p', 'text-sm text-gray-400 italic', 'No picture on file.'));
        }
        grid.appendChild(picBox);

        grid.appendChild(field('Notes / Observations', notes, true));
        body.appendChild(grid);
        var findings = findingsBlock(rec.findings || rec.Findings);
        if (findings) body.appendChild(findings);
        card.appendChild(body);

        var footer = el('div', 'px-6 py-4 bg-gray-50 border-t border-gray-100 flex justify-end gap-2');
        var printBtn = el('button', 'px-5 py-2 rounded-lg border border-[#00796B] text-[#00796B] text-sm font-bold', 'Print Form');
        printBtn.type = 'button'; printBtn.addEventListener('click', function () { printRecord(rec); }); footer.appendChild(printBtn);
        var closeBtn = el('button', 'px-5 py-2 rounded-lg bg-[#00796B] hover:bg-teal-700 text-white text-sm font-bold', 'Close');
        closeBtn.setAttribute('type', 'button');
        closeBtn.addEventListener('click', close);
        footer.appendChild(closeBtn);
        card.appendChild(footer);

        overlay.appendChild(card);
        document.body.appendChild(overlay);
        document.addEventListener('keydown', onKey);
    }

    window.MedicalRecordModal = {
        setRecords: function (rows) { records = Array.isArray(rows) ? rows : []; },
        openAt: function (index) { open(records[index]); },
        open: open,
        close: close
    };
})();
