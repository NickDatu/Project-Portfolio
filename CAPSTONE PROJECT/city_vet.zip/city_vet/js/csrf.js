(function () {
    async function getToken(endpoint) {
        const response = await fetch(endpoint, {
            headers: { 'Accept': 'application/json' }
        });
        const data = await response.json();
        if (!response.ok || !data || data.status !== 'success' || typeof data.csrf_token !== 'string') {
            throw new Error(data && data.message ? data.message : 'Unable to obtain a security token.');
        }
        return data.csrf_token;
    }

    window.CityVetCsrf = { getToken };
})();
