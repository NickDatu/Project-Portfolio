(function () {
    function esc(v) {
        return String(v === null || v === undefined ? '' : v)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
    }
    function fmt(s, withTime) {
        if (!s) return '--';
        const d = new Date(String(s).replace(' ', 'T'));
        if (isNaN(d)) return '--';
        return withTime
            ? d.toLocaleString([], { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
            : d.toLocaleDateString([], { year: 'numeric', month: 'long', day: 'numeric' });
    }
    function row(label, value) {
        return '<div class="py-2 border-b border-gray-50"><p class="text-[11px] uppercase tracking-wider text-gray-400 font-bold">' + esc(label) +
            '</p><p class="font-semibold text-gray-800 break-words">' + (esc(value) || '--') + '</p></div>';
    }
    function render(d) {
        const rows = [
            '<div class="py-2 border-b border-gray-50"><p class="text-[11px] uppercase tracking-wider text-gray-400 font-bold">Full Name</p><p id="profile-full-name" class="font-semibold text-gray-800 break-words">' + (esc(d.full_name) || '--') + '</p></div>',
            row('Role', d.role_name), row('Username', d.username),
            row('Email', d.email), row('Phone', d.phone || (d.details && d.details['Contact Number'])),
        ];
        Object.keys(d.details || {}).forEach(k => { if (k !== 'Contact Number') rows.push(row(k, d.details[k])); });
        rows.push(row('Account Status', d.account_status), row('Member Since', fmt(d.member_since)), row('Last Activity', fmt(d.last_activity, true)));
        const stats = Object.keys(d.stats || {}).map(k =>
            '<div class="bg-teal-50 rounded-2xl p-4 text-center"><p class="text-2xl font-black text-[#00796B]">' + esc(d.stats[k]) +
            '</p><p class="text-[11px] uppercase tracking-wider text-gray-500 font-bold mt-1">' + esc(k) + '</p></div>').join('');
        const fields = d.profile_fields || {};
        const isOwner = d.role_id === 3;
        const field = (id, label, value, wide) => '<label class="block ' + (wide ? 'sm:col-span-2' : '') +
            '"><span class="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">' + label +
            '</span><input id="' + id + '" value="' + esc(value) + '" maxlength="' + (id === 'profile-address' ? '5000' : (id === 'profile-contact' ? '15' : '100')) +
            '" class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:ring-2 focus:ring-[#00796B] outline-none"' +
            (id === 'profile-address' ? '' : ' required') + '></label>';
        return '<h3 class="font-bold text-gray-800 text-lg mb-4"><i class="fa-solid fa-id-card text-[#00796B] mr-2"></i>Profile Details</h3>' +
            '<div class="grid grid-cols-1 sm:grid-cols-2 gap-x-8">' + rows.join('') + '</div>' +
            '<form id="profile-details-form" class="mt-5 border-t border-gray-100 pt-5"><h4 class="font-bold text-gray-700 mb-3">Personal Details</h4>' +
            '<div class="grid grid-cols-1 sm:grid-cols-2 gap-3">' +
            field('profile-first-name', 'First Name', fields.first_name || '') +
            field('profile-last-name', 'Last Name', fields.last_name || '') +
            (isOwner ? field('profile-contact', 'Contact Number', fields.contact_number || '', false) +
                field('profile-address', 'Address', fields.address || '', true) : '') +
            '</div><div class="flex items-center gap-3 mt-4"><button type="submit" class="rounded-lg bg-[#00796B] px-4 py-2 text-sm font-bold text-white hover:bg-[#004D40]">Save Personal Details</button>' +
            '<span id="profile-details-message" class="text-sm" role="status"></span></div></form>' +
            (stats ? '<div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5">' + stats + '</div>' : '');
    }
    async function saveDetails(form, reload) {
        form.addEventListener('submit', async function (event) {
            event.preventDefault();
            const message = document.getElementById('profile-details-message');
            const payload = {
                first_name: document.getElementById('profile-first-name').value.trim(),
                last_name: document.getElementById('profile-last-name').value.trim()
            };
            const contact = document.getElementById('profile-contact');
            const address = document.getElementById('profile-address');
            if (contact) payload.contact_number = contact.value.trim();
            if (address) payload.address = address.value.trim();
            message.textContent = 'Saving...';
            message.className = 'text-sm text-gray-500';
            try {
                const response = await fetch('../../api/auth/update_profile_details.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const result = await response.json();
                if (!response.ok || result.status !== 'success') throw new Error(result.message || 'Unable to save details.');
                await reload();
                const currentMessage = document.getElementById('profile-details-message');
                currentMessage.textContent = result.message;
                currentMessage.className = 'text-sm text-green-700';
            } catch (error) {
                const currentMessage = document.getElementById('profile-details-message');
                if (currentMessage) {
                    currentMessage.textContent = error.message || 'Unable to save details.';
                    currentMessage.className = 'text-sm text-red-600';
                }
            }
        });
    }
    async function load(box) {
        const res = await fetch('../../api/auth/profile_overview.php');
        const json = await res.json();
        if (!res.ok || json.status !== 'success') throw new Error(json.message || 'Failed');
        box.innerHTML = render(json.data);
        saveDetails(document.getElementById('profile-details-form'), function () { return load(box); });
    }
    async function init() {
        const anchor = document.getElementById('section-general');
        if (!anchor || document.getElementById('profile-overview')) return;
        const box = document.createElement('div');
        box.id = 'profile-overview';
        box.className = 'bg-white rounded-3xl shadow-sm border border-gray-100 p-8 mb-6';
        box.innerHTML = '<p class="text-gray-400 text-sm">Loading profile details...</p>';
        anchor.parentNode.insertBefore(box, anchor);
        try {
            await load(box);
        } catch (e) {
            box.innerHTML = '<p class="text-red-500 text-sm">Unable to load profile details.</p>';
        }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
