function mountCityVetTopBanner() {
    const content = document.querySelector('#sidebar-container ~ .flex-1'); if (!content || document.getElementById('cityvet-top-banner')) return;
    const banner=document.createElement('div');banner.id='cityvet-top-banner';banner.className='w-full bg-[#004D40] text-white px-4 lg:px-8 py-3 grid grid-cols-3 items-center gap-3 shadow-sm';banner.innerHTML='<div class="text-left"><p class="font-black tracking-wide text-sm">ADMINISTRATOR PORTAL</p></div><div class="text-center"><p class="font-black tracking-widest text-lg">CITY VET</p></div><div class="text-right"><p id="cityvet-banner-name" class="font-black text-base">Loading...</p><p class="text-xs text-teal-200">Administrator</p></div>';content.insertBefore(banner,content.firstElementChild);fetch('../../api/auth/session_check.php?page=admin').then(r=>r.json()).then(d=>{const n=document.getElementById('cityvet-banner-name');if(n)n.textContent=d.user?.name||'Administrator';}).catch(()=>{});
}

function loadSidebar() {
    const sidebarContainer = document.getElementById('sidebar-container');
    if (!sidebarContainer) return;
    if (!document.getElementById('cityvet-responsive-css')) {
        const stylesheet = document.createElement('link');
        stylesheet.id = 'cityvet-responsive-css'; stylesheet.rel = 'stylesheet'; stylesheet.href = '../../css/responsive.css?v=20260901_3';
        document.head.appendChild(stylesheet);
    }
    if (!document.getElementById('cityvet-csrf-helper')) {
        const csrfScript = document.createElement('script');
        csrfScript.id = 'cityvet-csrf-helper'; csrfScript.src = '../../js/csrf_helper.js?v=20260910_1';
        document.head.appendChild(csrfScript);
    }
    const currentPage = window.location.pathname.split("/").pop();

    const getLinkClass = (pageName) => {
        const baseClass = "flex items-center px-4 py-3 rounded-xl transition-all duration-200 mb-1";
        const activeClass = "bg-[#00796B] text-white font-semibold shadow-md";
        const inactiveClass = "text-teal-50 hover:bg-[#00796B]/20 hover:text-white";
        return `${baseClass} ${currentPage === pageName ? activeClass : inactiveClass}`;
    };

    sidebarContainer.classList.add('lg:w-64', 'lg:flex-none');
    sidebarContainer.innerHTML = `
    <div id="sidebar-overlay" class="lg:hidden fixed inset-0 z-40 hidden bg-slate-950/50"></div>
    <aside id="sidebar" class="bg-[#004D40] text-white w-64 h-screen flex flex-col shadow-2xl fixed inset-y-0 left-0 transform -translate-x-full lg:translate-x-0 z-50 transition-transform duration-300 ease-in-out border-r border-[#00332B]">
        
        <div class="px-4 pt-4 flex items-center gap-2">
            <button onclick="window.history.length > 1 ? history.back() : window.location.href = '../../login.html'" class="flex-1 flex items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-sm font-bold text-white hover:bg-white/10 transition">
                <i class="fa-solid fa-arrow-left"></i> Back
            </button>
        </div>

        <div class="h-24 flex-shrink-0 flex items-center justify-center border-b border-[#00332B] bg-gradient-to-r from-[#004D40] to-[#00796B] mt-3">
            <div class="flex items-center gap-3 text-white">
                <img src="../../uploads/logo/City%20vet%20logo.jpg" alt="City Vet logo" class="w-10 h-10 rounded-full bg-white/10">
                <h1 class="text-sm font-black tracking-wide">ADMINISTRATOR PORTAL</h1>
            </div>
        </div>
        
        <nav class="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
            <a href="dashboard.html" class="${getLinkClass('dashboard.html')}">
                <i class="fa-solid fa-gauge-high mr-3 w-6 text-center"></i> Dashboard
            </a>
            
            <p class="px-4 text-[10px] font-bold text-teal-400 uppercase mt-6 mb-2 tracking-[0.2em]">Records</p>
            <a href="owners.html" class="${getLinkClass('owners.html')}">
                <i class="fa-solid fa-users mr-3 w-6 text-center"></i> Pet Owners & Pets
            </a>
            <a href="staff.html" class="${getLinkClass('staff.html')}">
                <i class="fa-solid fa-user-doctor mr-3 w-6 text-center"></i> Employee Records
            </a>
            
            <p class="px-4 text-[10px] font-bold text-teal-400 uppercase mt-6 mb-2 tracking-[0.2em]">Office Ops</p>
            <a href="appointments.html" class="${getLinkClass('appointments.html')}">
                <i class="fa-regular fa-calendar-check mr-3 w-6 text-center"></i> Appointments
            </a>
            <a href="../staff/vet_schedule.html" class="${getLinkClass('vet_schedule.html')}">
                <i class="fa-solid fa-calendar-days mr-3 w-6 text-center"></i> Veterinarian Schedule
            </a>
            <a href="consultations.html" class="${getLinkClass('consultations.html')}">
                <i class="fa-solid fa-stethoscope mr-3 w-6 text-center"></i> Consultations
            </a>
            <a href="vaccination_rules.html" class="${getLinkClass('vaccination_rules.html')}">
                <i class="fa-solid fa-syringe mr-3 w-6 text-center"></i> Vaccination & Deworming
            </a>
            <a href="species_breeds.html" class="${getLinkClass('species_breeds.html')}">
                <i class="fa-solid fa-dog mr-3 w-6 text-center"></i> Species & Breeds
            </a>
            
            <p class="px-4 text-[10px] font-bold text-teal-400 uppercase mt-6 mb-2 tracking-[0.2em]">System Control</p>
            <a href="reports.html" class="${getLinkClass('reports.html')}">
                <i class="fa-solid fa-file-invoice mr-3 w-6 text-center"></i> Reports & Analytics
            </a>
            <a href="audit_logs.html" class="${getLinkClass('audit_logs.html')}">
                <i class="fa-solid fa-clock-rotate-left mr-3 w-6 text-center"></i> System Audit Logs
            </a>
            <a href="user_management.html" class="${getLinkClass('user_management.html')}">
                <i class="fa-solid fa-users-gear mr-3 w-6 text-center"></i> User Management
            </a>
            <a href="profile_settings.html" class="${getLinkClass('profile_settings.html')}">
                <i class="fa-solid fa-user-shield mr-3 w-6 text-center"></i> Admin Profile
            </a>
        </nav>

        <div class="p-4 border-t border-[#00332B] flex-shrink-0 mb-2 bg-[#00332B]/30">
            <button onclick="logout()" class="w-full flex items-center justify-center px-4 py-3 text-red-300 hover:bg-red-900/30 rounded-xl font-bold transition-all border border-transparent hover:border-red-900/50">
                <i class="fa-solid fa-right-from-bracket mr-2"></i> Sign Out
            </button>
        </div>
    </aside>`;
    initializeResponsiveSidebar(sidebarContainer);
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlays = [document.getElementById('sidebar-overlay'), document.getElementById('mobileOverlay')].filter(Boolean);
    if (!sidebar) return;
    const isClosed = sidebar.classList.contains('-translate-x-full');
    if (isClosed) {
        sidebar.classList.remove('-translate-x-full');
        overlays.forEach(el => el.classList.remove('hidden'));
    } else {
        sidebar.classList.add('-translate-x-full');
        overlays.forEach(el => el.classList.add('hidden'));
    }
}
window.toggleSidebar = toggleSidebar;

function initializeResponsiveSidebar(container) {
    const sidebar = container.querySelector('#sidebar');
    const overlay = container.querySelector('#sidebar-overlay') || document.getElementById('mobileOverlay');

    const legacyToggle = document.getElementById('sidebar-toggle');
    if (legacyToggle) legacyToggle.remove();

    if (!sidebar) return;
    const syncLayout = () => { container.style.flex = window.innerWidth >= 1024 ? '0 0 16rem' : '0 0 0'; };
    syncLayout();

    const close = () => {
        sidebar.classList.add('-translate-x-full');
        if (overlay) overlay.classList.add('hidden');
        const mobOverlay = document.getElementById('mobileOverlay');
        if (mobOverlay) mobOverlay.classList.add('hidden');
    };

    if (overlay) overlay.addEventListener('click', close);
    const mobOverlay = document.getElementById('mobileOverlay');
    if (mobOverlay && mobOverlay !== overlay) mobOverlay.addEventListener('click', close);

    sidebar.querySelectorAll('a').forEach(link => link.addEventListener('click', close));
    window.addEventListener('resize', () => {
        syncLayout();
        if (window.innerWidth >= 1024) {
            close();
        }
    });
}

loadSidebar();
mountCityVetTopBanner();
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        const sidebarContainer = document.getElementById('sidebar-container');
        if (sidebarContainer) initializeResponsiveSidebar(sidebarContainer);
    });
}

function startSessionTimeoutWatcher() {
    if (window.cityVetSessionWatcherStarted) return;
    window.cityVetSessionWatcherStarted = true;

    const checkSessionTimeout = () => {
        fetch('../../api/auth/session_status.php?touch=0', { headers: { 'Accept': 'application/json' } })
            .then(res => res.json())
            .then(data => {
                if (data.status !== 'logged_in') {
                    window.location.href = '../../login.html';
                }
            })
            .catch(() => {
                window.location.href = '../../login.html';
            });
    };

    let lastClientTouch = 0;
    const touchSession = () => {
        const now = Date.now();
        if (now - lastClientTouch < 30000) return;
        lastClientTouch = now;

        fetch('../../api/auth/session_status.php', { headers: { 'Accept': 'application/json' } })
            .then(res => res.json())
            .then(data => {
                if (data.status !== 'logged_in') {
                    window.location.href = '../../login.html';
                }
            })
            .catch(() => {});
    };

    ['click', 'keydown', 'change', 'scroll'].forEach(eventName => {
        document.addEventListener(eventName, touchSession, { passive: true });
    });

    setInterval(checkSessionTimeout, 15000);
    checkSessionTimeout();
}
startSessionTimeoutWatcher();

function logout() {
    const doLogout = () => {
        fetch('../../api/auth/logout.php', { headers: { 'Accept': 'application/json' } })
            .then(() => { window.location.href = '../../login.html'; })
            .catch(() => { window.location.href = '../../login.html'; });
    };

    if (typeof Swal !== 'undefined') {
        Swal.fire({
            title: 'Logout Session?',
            text: "You will need to login again to access your account.",
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#00796B',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Logout',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                doLogout();
            }
        });
    } else {
        if (confirm("Are you sure you want to log out?")) {
            doLogout();
        }
    }
}
window.logout = logout;
