(function () {
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    function esc(value) {
        if (value === null || value === undefined) return '';
        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function toDateKey(value) {
        if (!value) return '';
        return String(value).substring(0, 10);
    }

    function matchesDateFilter(value, filter) {
        if (!filter || !filter.value) return true;
        const key = toDateKey(value);
        if (!key) return false;
        if (filter.mode === 'date') return key === filter.value;
        if (filter.mode === 'month') return key.substring(0, 7) === filter.value;
        if (filter.mode === 'year') return key.substring(0, 4) === String(filter.value);
        return true;
    }

    function formatDate(value) {
        const key = toDateKey(value);
        if (!key) return '';
        const parts = key.split('-').map(Number);
        if (parts.length !== 3 || parts.some(isNaN)) return key;
        return `${monthNames[parts[1] - 1]} ${parts[2]}, ${parts[0]}`;
    }

    function todayKey() {
        const d = new Date();
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    }

    function isPastDate(value) {
        return toDateKey(value) < todayKey();
    }

    const pastLabels = {
        'Pending': 'Not Confirmed',
        'Confirmed': 'Was Confirmed',
        'Checked In': 'Checked In',
        'In Consultation': 'Was Consulted',
        'Completed': 'Catered',
        'No Show': 'Did Not Show',
        'Cancelled': 'Cancelled',
        'Closed': 'Was Closed',
        'Open': 'Was Open'
    };

    function statusLabel(status, isPast) {
        if (!isPast) return status;
        return pastLabels[status] || status;
    }

    function statusClass(status) {
        switch (status) {
            case 'Pending': return 'bg-orange-50 text-orange-600 border-orange-200';
            case 'Confirmed': return 'bg-green-50 text-green-700 border-green-200';
            case 'Checked In': return 'bg-sky-50 text-sky-700 border-sky-200';
            case 'In Consultation': return 'bg-blue-50 text-blue-700 border-blue-200';
            case 'Completed': return 'bg-teal-50 text-teal-700 border-teal-200';
            case 'No Show': return 'bg-rose-100 text-rose-700 border-rose-300';
            case 'Cancelled': return 'bg-gray-100 text-gray-600 border-gray-300';
            default: return 'bg-gray-100 text-gray-600 border-gray-200';
        }
    }

    function statusBadge(status, isPast) {
        return `<span class="px-2 py-0.5 rounded border text-[10px] font-bold uppercase whitespace-nowrap ${statusClass(status)}">${esc(statusLabel(status, isPast))}</span>`;
    }


    function eventIsClosed(e) {
        return e.Status === 'Closed' || isPastDate(e.Event_Date);
    }

    function eventTone(e) {
        if (eventIsClosed(e)) return 'closed';
        if (e.Event_Type === 'Holiday') return 'holiday';
        if (e.Event_Type === 'General') return 'general';
        const remaining = parseInt(e.Remaining_Slots, 10);
        if (e.Is_Full || (!isNaN(remaining) && remaining <= 0)) return 'full';
        return 'open';
    }

    const toneChip = {
        closed: 'bg-gray-200 text-gray-600',
        general: 'bg-blue-100 text-blue-700',
        holiday: 'bg-amber-100 text-amber-800',
        full: 'bg-red-100 text-red-700',
        open: 'bg-teal-100 text-[#00796B]'
    };
    const toneDot = {
        closed: 'bg-gray-400',
        general: 'bg-blue-500',
        holiday: 'bg-amber-500',
        full: 'bg-red-500',
        open: 'bg-[#00796B]'
    };

    function dayEventChips(events, maxShown) {
        if (!events || events.length === 0) return '';
        const limit = maxShown || 3;
        const chips = events.slice(0, limit).map(e => {
            const tone = eventTone(e);
            let tail = '';
            if (e.Event_Type === 'Holiday') {
                tail = 'Holiday';
            } else if (e.Event_Type === 'General') {
                tail = 'General';
            } else if (eventIsClosed(e)) {
                tail = 'Closed';
            } else {
                tail = `${parseInt(e.Used_Slots || 0, 10)}/${parseInt(e.Max_Slots || 0, 10)}`;
            }
            return `<span class="hidden md:block w-full truncate rounded px-1 py-0.5 text-[9px] font-bold leading-tight ${toneChip[tone]}" title="${esc(e.Title)} - ${esc(tail)}">${esc(e.Title)} · ${esc(tail)}</span>`;
        }).join('');
        const more = events.length > limit ? `<span class="hidden md:block text-[9px] font-bold text-gray-500">+${events.length - limit} more</span>` : '';
        const dots = events.slice(0, 4).map(e => `<span class="w-1.5 h-1.5 rounded-full ${toneDot[eventTone(e)]}"></span>`).join('');
        return `<div class="hidden md:flex flex-col gap-0.5 w-full mt-1">${chips}${more}</div><div class="flex md:hidden gap-0.5 mt-0.5">${dots}</div>`;
    }

    function countLine(label, value, cls) {
        return `<span class="inline-block mr-3 mb-1"><span class="text-gray-500">${esc(label)}:</span> <strong class="${cls || 'text-gray-800'}">${parseInt(value || 0, 10)}</strong></span>`;
    }

    function eventDetailHtml(e, opts) {
        const options = opts || {};
        const past = eventIsClosed(e);
        const isSpay = e.Event_Type === 'SpayNeuter';
        const isHoliday = e.Event_Type === 'Holiday';
        const typeLabel = isSpay ? 'Spay & Neuter' : (isHoliday ? 'Holiday' : 'General Event');
        const typeCls = isSpay ? 'bg-teal-100 text-[#00796B]' : (isHoliday ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-700');
        const stateCls = isHoliday ? 'bg-amber-100 text-amber-800' : (past ? 'bg-gray-200 text-gray-700' : (eventTone(e) === 'full' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'));
        const stateTxt = isHoliday ? 'Office Closed' : (past ? 'Closed' : (eventTone(e) === 'full' ? 'Fully Booked' : 'Open'));
        let body = `
            <div class="flex items-start justify-between gap-2">
                <div>
                    <p class="font-bold text-gray-800 text-sm">${esc(e.Title)}</p>
                    <p class="text-xs text-gray-500">${esc(formatDate(e.Event_Date))}${e.Barangay ? ` - ${esc(e.Barangay)}` : ''}</p>
                </div>
                <div class="flex flex-col items-end gap-1">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold ${typeCls}">${typeLabel}</span>
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold ${stateCls}">${stateTxt}</span>
                </div>
            </div>`;
        if (isSpay) {
            const max = parseInt(e.Max_Slots || 0, 10);
            const used = parseInt(e.Used_Slots || 0, 10);
            const remaining = Math.max(0, max - used);
            body += `<div class="mt-2 text-xs">${countLine('Total Pet Slots', max)}${countLine('Confirmed Pet Slots', used, 'text-teal-700')}${countLine('Pet Slots Left', remaining, remaining > 0 ? 'text-green-700' : 'text-red-600')}`;
            if (options.staff) {
                body += `${countLine('Pending', e.Pending_Count, 'text-orange-600')}${countLine(past ? 'Catered' : 'Completed', e.Catered_Count, 'text-teal-700')}${countLine('Cancelled', e.Cancelled_Count, 'text-gray-600')}${countLine(past ? 'Did Not Show' : 'No Show', e.No_Show_Count, 'text-rose-600')}`;
            }
            body += '</div>';
        }
        if (e.Content) {
            body += `<p class="mt-2 text-xs text-gray-600 leading-relaxed whitespace-pre-line">${esc(e.Content)}</p>`;
        }
        return `<div class="text-left rounded-xl border border-gray-200 bg-white p-3">${body}${options.actionsHtml || ''}</div>`;
    }


    function weekdayDateString(date) {
        while (date.getDay() === 0 || date.getDay() === 6) date.setDate(date.getDate() + 1);
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    }

    function defaultFollowUpFor(serviceText, birthdate, speciesName) {
        const text = String(serviceText || '').toLowerCase();
        if (birthdate && speciesName) {
            const birth = new Date(`${birthdate}T00:00:00`);
            const ageWeeks = Math.floor((Date.now() - birth.getTime()) / 604800000);
            const species = String(speciesName).toLowerCase();
            const isDog = species.indexOf('dog') !== -1 || species.indexOf('canine') !== -1;
            const isCat = species.indexOf('cat') !== -1 || species.indexOf('feline') !== -1;
            const procedure = text.indexOf('deworm') !== -1 ? 'deworming'
                : text.indexOf('anti-rabies') !== -1 || text.indexOf('rabies') !== -1 ? 'rabies'
                : text.indexOf('5-in-1') !== -1 ? 'dog-vaccine'
                : text.indexOf('3-in-1') !== -1 || text.indexOf('4-in-1') !== -1 ? 'cat-vaccine' : '';
            const schedules = {
                cat: [
                    { ageWeeks: 4, procedure: 'deworming', value: 2, unit: 'weeks' },
                    { ageWeeks: 6, procedure: 'deworming', value: 2, unit: 'weeks' },
                    { ageWeeks: 8, procedure: 'cat-vaccine', value: 2, unit: 'weeks' },
                    { ageWeeks: 8, procedure: 'deworming', value: 3, unit: 'months' },
                    { ageWeeks: 11, procedure: 'cat-vaccine', value: 3, unit: 'weeks' },
                    { ageWeeks: 12, procedure: 'rabies', value: 1, unit: 'years' },
                    { ageWeeks: 14, procedure: 'cat-vaccine', value: 1, unit: 'years' }
                ],
                dog: [
                    { ageWeeks: 2, procedure: 'deworming', value: 2, unit: 'weeks' },
                    { ageWeeks: 4, procedure: 'deworming', value: 2, unit: 'weeks' },
                    { ageWeeks: 6, procedure: 'deworming', value: 4, unit: 'weeks' },
                    { ageWeeks: 6, procedure: 'dog-vaccine', value: 2, unit: 'weeks' },
                    { ageWeeks: 8, procedure: 'dog-vaccine', value: 2, unit: 'weeks' },
                    { ageWeeks: 10, procedure: 'deworming', value: 4, unit: 'weeks' },
                    { ageWeeks: 10, procedure: 'dog-vaccine', value: 3, unit: 'months' },
                    { ageWeeks: 12, procedure: 'rabies', value: 1, unit: 'years' },
                    { ageWeeks: 14, procedure: 'dog-vaccine', value: 1, unit: 'years' }
                ]
            };
            const speciesKey = isDog ? 'dog' : isCat ? 'cat' : '';
            const schedule = (schedules[speciesKey] || [])
                .filter(rule => rule.procedure === procedure && ageWeeks >= rule.ageWeeks)
                .pop();
            if (schedule) {
                const target = new Date();
                const originalDay = target.getDate();
                if (schedule.unit === 'weeks') {
                    target.setDate(originalDay + schedule.value * 7);
                } else {
                    target.setDate(1);
                    if (schedule.unit === 'months') target.setMonth(target.getMonth() + schedule.value);
                    else target.setFullYear(target.getFullYear() + schedule.value);
                    const lastDay = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
                    target.setDate(Math.min(originalDay, lastDay));
                }
                return weekdayDateString(target);
            }

            // A known dog/cat procedure must follow the age table; do not replace
            // a missing age row with an unrelated generic one-year date.
            if (speciesKey && procedure) return '';
        }
        let months = 0;
        if (text.indexOf('parvo') !== -1) months = 1;
        else if (text.indexOf('vaccin') !== -1) months = 12;
        else return '';
        const now = new Date();
        const day = now.getDate();
        const target = new Date(now.getFullYear(), now.getMonth() + months, 1);
        const lastDay = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
        target.setDate(Math.min(day, lastDay));
        return weekdayDateString(target);
    }

    function formatPetAge(birthdate, asOf = new Date()) {
        if (!birthdate) return 'Unknown';
        const dob = new Date(`${birthdate}T00:00:00`);
        const now = asOf instanceof Date ? new Date(asOf) : new Date(asOf);
        if (Number.isNaN(dob.getTime()) || Number.isNaN(now.getTime()) || dob > now) return 'Unknown';
        const elapsedWeeks = Math.floor((new Date(now.getFullYear(), now.getMonth(), now.getDate()) - dob) / 604800000);
        return `${Math.max(0, elapsedWeeks)} ${elapsedWeeks === 1 ? 'week' : 'weeks'} old`;
    }

    function enableLoadingStates() {
        if (window.__cityVetLoadingStatesBound) return;
        window.__cityVetLoadingStatesBound = true;
        const active = new Map();
        let recentAction = null;
        const isButton = element => element && (element.tagName === 'BUTTON' || (element.tagName === 'INPUT' && /submit|button/i.test(element.type)) || (element.tagName === 'A' && element.getAttribute('role') === 'button'));
        const optedOut = element => element && (element.closest('[data-no-loading]') || element.closest('.swal2-container'));
        const restore = button => {
            const state = active.get(button);
            if (!state) return;
            clearTimeout(state.safetyTimer);
            clearTimeout(state.probeTimer);
            if (button.innerHTML === state.loadingHtml) button.innerHTML = state.html;
            button.className = state.className;
            button.style.cssText = state.style;
            button.disabled = state.disabled;
            if (state.ariaBusy === null) button.removeAttribute('aria-busy'); else button.setAttribute('aria-busy', state.ariaBusy);
            if (state.ariaDisabled === null) button.removeAttribute('aria-disabled'); else button.setAttribute('aria-disabled', state.ariaDisabled);
            active.delete(button);
            if (recentAction && recentAction.button === button) recentAction = null;
        };
        const begin = button => {
            if (!isButton(button) || optedOut(button) || active.has(button)) return active.get(button) || null;
            const state = { button, pending: 0, fetchStarted: false, started: Date.now(), html: button.innerHTML, loadingHtml: '<i class="fa-solid fa-spinner fa-spin mr-2"></i>Processing...', className: button.className, style: button.style.cssText, disabled: button.disabled, ariaBusy: button.getAttribute('aria-busy'), ariaDisabled: button.getAttribute('aria-disabled') };
            active.set(button, state);
            button.disabled = true;
            button.setAttribute('aria-busy', 'true');
            button.classList.add('opacity-70', 'cursor-wait');
            if (button.tagName === 'A') button.setAttribute('aria-disabled', 'true');
            button.innerHTML = state.loadingHtml;
            state.probeTimer = setTimeout(() => { if (state.pending === 0 && !state.fetchStarted) restore(button); }, 300);
            state.safetyTimer = setTimeout(() => restore(button), 20000);
            recentAction = state;
            return state;
        };
        document.addEventListener('click', event => {
            const button = event.target.closest && event.target.closest('button, input[type="submit"], input[type="button"], a[role="button"]');
            const formSubmit = button && button.form && ((button.tagName === 'BUTTON' && (!button.type || button.type === 'submit')) || (button.tagName === 'INPUT' && button.type === 'submit'));
            if (button && !button.disabled && !formSubmit) begin(button);
        }, true);
        document.addEventListener('submit', event => {
            if (!event.submitter) return;
            if (active.has(event.submitter)) {
                event.preventDefault();
                event.stopImmediatePropagation();
                return;
            }
            begin(event.submitter);
        }, true);
        const originalFetch = window.fetch;
        window.fetch = function (...args) {
            const state = recentAction && active.get(recentAction.button) && Date.now() - recentAction.started < 20000 ? recentAction : null;
            if (state) { state.pending++; state.fetchStarted = true; }
            return originalFetch.apply(this, args).finally(() => {
                if (!state) return;
                state.pending = Math.max(0, state.pending - 1);
                if (state.pending === 0) restore(state.button);
            });
        };
    }

    function mountDateFilter(containerId, onChange) {
        const container = document.getElementById(containerId);
        if (!container) return null;
        const state = { mode: 'date', value: '' };
        const inputClass = 'border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs bg-white focus:ring-2 focus:ring-[#00796B] outline-none';
        container.innerHTML = `
            <div class="flex flex-wrap items-center gap-2">
                <select data-role="mode" class="${inputClass}">
                    <option value="date">Date</option>
                    <option value="month">Month</option>
                    <option value="year">Year</option>
                </select>
                <span data-role="slot"></span>
                <button type="button" data-role="clear" class="text-xs font-bold text-gray-500 hover:text-[#00796B] px-2 py-1.5">Clear</button>
            </div>
        `;
        const modeSelect = container.querySelector('[data-role="mode"]');
        const slot = container.querySelector('[data-role="slot"]');
        const clearBtn = container.querySelector('[data-role="clear"]');

        function renderInput() {
            let input;
            if (state.mode === 'year') {
                const nowYear = new Date().getFullYear();
                input = document.createElement('input');
                input.type = 'number';
                input.min = '2000';
                input.max = String(nowYear + 5);
                input.placeholder = String(nowYear);
                input.className = inputClass + ' w-24';
            } else {
                input = document.createElement('input');
                input.type = state.mode === 'month' ? 'month' : 'date';
                input.className = inputClass;
            }
            input.value = state.value || '';
            input.addEventListener('input', () => {
                state.value = input.value;
                if (state.mode === 'year' && input.value && String(input.value).length !== 4) return;
                onChange({ mode: state.mode, value: state.value });
            });
            slot.innerHTML = '';
            slot.appendChild(input);
        }

        modeSelect.addEventListener('change', () => {
            state.mode = modeSelect.value;
            state.value = '';
            renderInput();
            onChange({ mode: state.mode, value: '' });
        });
        clearBtn.addEventListener('click', () => {
            state.value = '';
            renderInput();
            onChange({ mode: state.mode, value: '' });
        });
        renderInput();
        return {
            get: () => ({ mode: state.mode, value: state.value })
        };
    }

    function attachDateFilter(bodyId, onChange) {
        const body = document.getElementById(bodyId);
        if (!body) return null;
        const table = body.closest('table');
        const host = (table && (table.closest('.overflow-x-auto') || table)) || body;
        const id = bodyId + '-date-filter';
        if (document.getElementById(id)) return null;
        const bar = document.createElement('div');
        bar.id = id;
        bar.className = 'px-4 sm:px-6 py-3 border-b border-gray-100 bg-white flex items-center gap-2 flex-wrap';
        bar.innerHTML = '<span class="text-[11px] font-bold uppercase tracking-wider text-gray-400"><i class="fa-solid fa-filter mr-1"></i>Filter by</span><span data-role="mount"></span>';
        host.parentNode.insertBefore(bar, host);
        const mount = bar.querySelector('[data-role="mount"]');
        mount.id = id + '-mount';
        return mountDateFilter(mount.id, onChange);
    }

    window.CityVetUI = {
        attachDateFilter,
        esc,
        toDateKey,
        matchesDateFilter,
        formatDate,
        todayKey,
        isPastDate,
        statusLabel,
        statusClass,
        statusBadge,
        eventIsClosed,
        eventTone,
        dayEventChips,
        eventDetailHtml,
        defaultFollowUpFor,
        formatPetAge,
        mountDateFilter,
        enableLoadingStates
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', enableLoadingStates); else enableLoadingStates();
})();
