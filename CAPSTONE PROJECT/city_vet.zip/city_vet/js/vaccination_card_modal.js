(function () {
    var API = '../../api/clinic/vaccination_record.php';
    var UPLOADS = '../../uploads/pets/';

    function esc(v) {
        return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    function fmtDate(v) {
        if (!v) return '—';
        var d = new Date(String(v).substring(0, 10) + 'T00:00:00');
        if (isNaN(d)) return esc(v);
        return d.toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' });
    }

    function injectStyles() {
        if (document.getElementById('vc-styles')) return;
        var css = '' +
            '#vc-modal{position:fixed;inset:0;z-index:9999;background:rgba(15,23,42,.6);overflow-y:auto;-webkit-overflow-scrolling:touch}' +
            '#vc-modal .vc-bar{position:sticky;top:0;z-index:2;display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 16px;background:#004D40;color:#fff}' +
            '#vc-modal .vc-bar button{display:inline-flex;align-items:center;gap:8px;border:0;border-radius:8px;padding:8px 14px;font-weight:700;font-size:14px;cursor:pointer}' +
            '#vc-modal .vc-close{background:rgba(255,255,255,.15);color:#fff}' +
            '#vc-modal .vc-print{background:#fff;color:#004D40}' +
            '#vc-modal .vc-wrap{max-width:900px;margin:16px auto;padding:0 12px 32px}' +
            '#vc-card{background:#fff;border:2px solid #00796B;border-radius:12px;padding:20px}' +
            '#vc-card .vc-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;border-bottom:2px solid #00796B;padding-bottom:12px;margin-bottom:16px}' +
            '#vc-card .vc-agency{font-size:10px;letter-spacing:.16em;text-transform:uppercase;color:#475569;line-height:1.5}' +
            '#vc-card .vc-title{font-size:22px;font-weight:800;color:#004D40;line-height:1.2}' +
            '#vc-card .vc-grid{display:grid;grid-template-columns:1fr;gap:16px}' +
            '@media(min-width:640px){#vc-card .vc-grid{grid-template-columns:1fr 180px}}' +
            '#vc-card .vc-fields{display:grid;grid-template-columns:1fr 1fr;gap:12px 16px}' +
            '#vc-card .vc-l{font-size:10px;text-transform:uppercase;letter-spacing:.1em;color:#64748b;font-weight:700}' +
            '#vc-card .vc-v{border-bottom:1px solid #cbd5e1;min-height:24px;padding-bottom:2px;font-weight:600;color:#0f172a;word-break:break-word}' +
            '#vc-card .vc-photo{width:100%;max-width:160px;aspect-ratio:1/1;border:1px dashed #94a3b8;border-radius:8px;display:flex;align-items:center;justify-content:center;overflow:hidden;background:#f8fafc;color:#94a3b8;font-size:40px}' +
            '#vc-card .vc-photo img{width:100%;height:100%;object-fit:cover}' +
            '#vc-card .vc-tw{overflow-x:auto;margin-top:18px}' +
            '#vc-card table{width:100%;border-collapse:collapse;font-size:13px;min-width:480px}' +
            '#vc-card th,#vc-card td{border:1px solid #cbd5e1;padding:8px;text-align:left}' +
            '#vc-card th{background:#e0f2f1;color:#004D40;text-transform:uppercase;font-size:11px;letter-spacing:.06em}' +
            '#vc-card .vc-sign{display:flex;justify-content:space-between;gap:24px;margin-top:28px;flex-wrap:wrap}' +
            '#vc-card .vc-line{border-top:1px solid #0f172a;padding-top:4px;min-width:220px;font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:#475569}' +
            '@media print{body.vc-open>*:not(#vc-modal){display:none!important}' +
            '#vc-modal{position:static!important;background:#fff!important;overflow:visible!important}' +
            '#vc-modal .vc-bar{display:none!important}#vc-modal .vc-wrap{margin:0;max-width:none;padding:0}' +
            '#vc-card{border:1px solid #000;border-radius:0}}';
        var st = document.createElement('style');
        st.id = 'vc-styles';
        st.textContent = css;
        document.head.appendChild(st);
    }

    function field(label, value) {
        return '<div><div class="vc-l">' + esc(label) + '</div><div class="vc-v">' + (value ? esc(value) : '—') + '</div></div>';
    }

    function render(data) {
        var pet = data.pet || {}, owner = data.owner || {};
        var vacc = Array.isArray(data.vaccinations) ? data.vaccinations : [];
        var photo = pet.Profile_Pic
            ? '<img src="' + UPLOADS + encodeURIComponent(pet.Profile_Pic) + '" alt="">'
            : '<i class="fa-solid fa-paw"></i>';
        var rows = vacc.length ? vacc.map(function (v) {
            return '<tr><td>' + esc(v.Vaccine_Name || 'N/A') + '</td><td>' + esc(v.Medicine || 'N/A') + '</td><td>' + esc(v.Dosage || 'N/A') + '</td><td>' + esc(v.Lot_Number || 'N/A') + '</td><td>' + fmtDate(v.Date_Administered) + '</td><td>' +
                fmtDate(v.Next_Due_Date) + '</td><td>' + esc(v.Vet_Name || 'City Vet Office') + '</td><td>City Veterinary Office</td></tr>';
        }).join('') : '<tr><td colspan="8" style="text-align:center;padding:24px;color:#64748b">No vaccination records on file for this pet.</td></tr>';
        var external = Array.isArray(data.external_records) ? data.external_records : [];
        var externalRows = external.length ? external.map(function (v) { return '<tr><td>' + esc(v.Name || v.Medicine || 'N/A') + '</td><td>' + esc(v.Dosage || 'N/A') + '</td><td>' + esc(v.Lot_Number || 'N/A') + '</td><td>' + fmtDate(v.Record_Date) + '</td><td>N/A</td><td>' + esc(v.Provider || 'N/A') + '</td><td>' + esc(v.Source_Clinic || 'Other clinic') + '</td></tr>'; }).join('') : '<tr><td colspan="7" style="text-align:center;padding:16px;color:#64748b">No external records.</td></tr>';
        var recommended = (data.next_recommended || []).map(function (r) { return esc(r.Procedure_Name) + ' (' + esc(r.Next_Due_Date) + ')'; }).join(', ');

        return '<div id="vc-card">' +
            '<div class="vc-head"><div>' +
            '<div class="vc-agency">Republic of the Philippines<br>City of Cagayan de Oro</div>' +
            '<div class="vc-title">City Veterinary Office</div></div>' +
            '<div style="text-align:right"><div class="vc-agency">Official Record</div><div class="vc-title" style="font-size:18px">Vaccination Card</div></div></div>' +
            '<div class="vc-grid"><div class="vc-fields">' +
            field('Owner', owner.Name) + field('Contact', owner.Contact_Number) +
            field('Pet Code', pet.Pet_Code || 'N/A') + field('Pet Name', pet.Name) + field('Species', pet.Species) +
            field('Breed', pet.Breed) + field('Color / Markings', pet.Color) +
            field('Sex', pet.Gender) + field('Age', pet.Age) +
            field('Birthdate', pet.Birthdate ? fmtDate(pet.Birthdate) : '') + field('Weight', pet.Weight) + field('Owner Code', owner.Owner_Code || 'N/A') + field('Address / Barangay', [owner.Address, owner.Barangay].filter(Boolean).join(' / ')) +
            '</div><div><div class="vc-l" style="margin-bottom:4px">Pet Photo</div><div class="vc-photo">' + photo + '</div></div></div>' +
            '<div class="vc-tw"><div class="vc-l" style="margin-bottom:6px;font-size:12px">Vaccination History</div><table><thead><tr><th>Vaccine</th><th>Medicine used</th><th>Dosage</th><th>Lot / Batch</th><th>Date Administered</th><th>Next Due</th><th>Veterinarian</th><th>Clinic</th></tr></thead><tbody>' +
            rows + '</tbody></table></div>' +
            '<div class="vc-tw"><div class="vc-l" style="margin-bottom:6px;font-size:12px">Records from other clinics (not issued by City Vet)</div><table><thead><tr><th>Record</th><th>Dosage</th><th>Lot / Batch</th><th>Date</th><th>Next Due</th><th>Provider</th><th>Source Clinic</th></tr></thead><tbody>' + externalRows + '</tbody></table></div>' +
            (recommended ? '<div class="vc-tw" style="margin-top:12px"><div class="vc-l">Next recommended</div><div class="vc-v">' + recommended + '</div></div>' : '') +
            '<div class="vc-sign"><div class="vc-line">Veterinarian signature over printed name</div>' +
            '<div><div class="vc-l">Valid until</div><div class="vc-v" style="font-size:16px">' + fmtDate(data.valid_until) + '</div></div></div>' +
            '<div class="vc-agency" style="margin-top:12px">Date printed: ' + fmtDate(new Date()) + ' &middot; Printed from City Vet system.</div>' +
            '</div>';
    }

    var pushed = false;

    function closeModal(fromPop) {
        var m = document.getElementById('vc-modal');
        if (!m) return;
        m.remove();
        document.body.classList.remove('vc-open');
        document.body.style.overflow = '';
        document.removeEventListener('keydown', onKey);
        if (pushed && !fromPop) { pushed = false; history.back(); }
        pushed = false;
    }

    function onKey(e) { if (e.key === 'Escape') closeModal(); }

    window.addEventListener('popstate', function () {
        if (document.getElementById('vc-modal')) closeModal(true);
    });

    window.openVaccinationCard = function (petId) {
        injectStyles();
        closeModal(true);
        var m = document.createElement('div');
        m.id = 'vc-modal';
        m.innerHTML = '<div class="vc-bar"><button type="button" class="vc-close"><i class="fa-solid fa-arrow-left"></i> Back</button>' +
            '<button type="button" class="vc-print"><i class="fa-solid fa-print"></i> Print</button></div>' +
            '<div class="vc-wrap"><div id="vc-body" style="background:#fff;border-radius:12px;padding:40px;text-align:center;color:#64748b">Loading vaccination record...</div></div>';
        document.body.appendChild(m);
        document.body.classList.add('vc-open');
        document.body.style.overflow = 'hidden';
        m.querySelector('.vc-close').addEventListener('click', function () { closeModal(); });
        m.querySelector('.vc-print').addEventListener('click', function () { window.print(); });
        m.addEventListener('click', function (e) { if (e.target === m) closeModal(); });
        document.addEventListener('keydown', onKey);
        try { history.pushState({ vc: 1 }, ''); pushed = true; } catch (e) { pushed = false; }

        fetch(API + '?pet_id=' + encodeURIComponent(petId), { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.status !== 'success') throw new Error(data.message || 'Unable to load record.');
                document.getElementById('vc-body').outerHTML = render(data);
            })
            .catch(function (err) {
                var b = document.getElementById('vc-body');
                if (b) b.innerHTML = '<span style="color:#b91c1c">' + esc(err.message) + '</span>';
            });
    };
})();
