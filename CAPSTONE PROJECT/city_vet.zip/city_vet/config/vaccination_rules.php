<?php

function petAgeInWeeks($birthdate, $asOf = null): ?int {
    if (!$birthdate) return null;
    try {
        $dob = new DateTime((string)$birthdate);
        $date = $asOf ? new DateTime((string)$asOf) : new DateTime('today');
        if ($dob > $date) return 0;
        return (int)floor(($date->getTimestamp() - $dob->getTimestamp()) / 604800);
    } catch (Throwable $e) { return null; }
}

function cityVetNextDueDate($baseDate, int $value, string $unit): string {
    $date = new DateTime((string)$baseDate);
    if (in_array($unit, ['days', 'weeks'], true)) {
        $days = $unit === 'weeks' ? $value * 7 : $value;
        $date->modify('+' . $days . ' days');
        while ((int)$date->format('N') >= 6) $date->modify('+1 day');
        return $date->format('Y-m-d');
    }
    $months = $unit === 'years' ? $value * 12 : $value;
    $day = (int)$date->format('j');
    $date->setDate((int)$date->format('Y'), (int)$date->format('n'), 1);
    $date->modify('+' . $months . ' months');
    $date->setDate((int)$date->format('Y'), (int)$date->format('n'), min($day, (int)$date->format('t')));
    while ((int)$date->format('N') >= 6) $date->modify('+1 day');
    return $date->format('Y-m-d');
}

function cityVetRulesForPet(mysqli $conn, int $speciesId): array {
    $stmt = $conn->prepare("SELECT Rule_ID, Species_ID, Age_Weeks, Procedure_Name, Repeat_Value, Repeat_Unit, Repeat_Note, Sort_Order FROM vaccination_schedule_rules WHERE Species_ID = ? AND Status = 'active' ORDER BY Age_Weeks, Sort_Order, Rule_ID");
    $stmt->bind_param('i', $speciesId); $stmt->execute(); $result = $stmt->get_result(); $rules = [];
    while ($row = $result->fetch_assoc()) $rules[] = $row;
    $stmt->close(); return $rules;
}

function cityVetDueProcedures(mysqli $conn, int $petId, $asOf = null): array {
    $stmt = $conn->prepare('SELECT Species_ID, Birthdate FROM pets WHERE Pet_ID = ? LIMIT 1');
    $stmt->bind_param('i', $petId); $stmt->execute(); $pet = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$pet || !$pet['Birthdate']) return [];
    $ageWeeks = petAgeInWeeks($pet['Birthdate'], $asOf); if ($ageWeeks === null) return [];
    $rules = cityVetRulesForPet($conn, (int)$pet['Species_ID']); $eligible = [];
    foreach ($rules as $rule) if ((int)$rule['Age_Weeks'] <= $ageWeeks) $eligible[] = $rule;
    if (!$eligible) return [];
    $maxAge = max(array_column($eligible, 'Age_Weeks'));
    $eligible = array_values(array_filter($eligible, static fn($r) => (int)$r['Age_Weeks'] === $maxAge));
    $doneStmt = $conn->prepare("SELECT Vaccine_Name AS Procedure_Name, Date_Administered AS Done_Date FROM vaccinations WHERE Pet_ID = ? UNION ALL SELECT Treatment, DATE(Visit_Date) FROM medical_records WHERE Pet_ID = ? AND (is_deleted = 0 OR is_deleted IS NULL)");
    $doneStmt->bind_param('ii', $petId, $petId); $doneStmt->execute(); $doneResult = $doneStmt->get_result(); $done = [];
    while ($row = $doneResult->fetch_assoc()) $done[] = $row;
    $doneStmt->close();
    $out = [];
    foreach ($eligible as $rule) {
        $keywords = preg_split('/\s+or\s+|\s*\/\s*/i', $rule['Procedure_Name']); $satisfied = false;
        foreach ($done as $record) { foreach ($keywords as $keyword) if ($keyword !== '' && stripos((string)$record['Procedure_Name'], trim($keyword)) !== false) { $satisfied = true; break 2; } }
        if (!$satisfied) { $rule['Next_Due_Date'] = cityVetNextDueDate($asOf ?: date('Y-m-d'), (int)$rule['Repeat_Value'], $rule['Repeat_Unit']); $out[] = $rule; }
    }
    return $out;
}
