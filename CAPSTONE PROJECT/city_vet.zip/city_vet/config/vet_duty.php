<?php














if (!function_exists('cityVetEnsureDutySchema')) {
    function cityVetEnsureDutySchema(mysqli $conn): void {
        static $done = false;
        if ($done) return;
        $done = true;
        try {
            $conn->query("
                CREATE TABLE IF NOT EXISTS `vet_duty_schedule` (
                  `Duty_ID` int(11) NOT NULL AUTO_INCREMENT,
                  `Duty_Date` date NOT NULL,
                  `Vet_User_ID` int(11) NOT NULL,
                  `Created_By` int(11) DEFAULT NULL,
                  `Created_At` datetime DEFAULT current_timestamp(),
                  PRIMARY KEY (`Duty_ID`),
                  UNIQUE KEY `uq_duty_date_vet` (`Duty_Date`, `Vet_User_ID`),
                  KEY `idx_duty_vet` (`Vet_User_ID`),
                  CONSTRAINT `vet_duty_vet_fk` FOREIGN KEY (`Vet_User_ID`) REFERENCES `users` (`User_ID`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
            ");
        } catch (Throwable $e) {
            error_log('cityVetEnsureDutySchema failed: ' . $e->getMessage());
        }
    }
}

if (!function_exists('cityVetNormalizeDate')) {
    
    function cityVetNormalizeDate($value): ?string {
        $value = trim((string)$value);
        if ($value === '') return null;
        $d = DateTime::createFromFormat('Y-m-d', substr($value, 0, 10));
        if (!$d || $d->format('Y-m-d') !== substr($value, 0, 10)) {
            $ts = strtotime($value);
            return $ts === false ? null : date('Y-m-d', $ts);
        }
        return $d->format('Y-m-d');
    }
}

if (!function_exists('cityVetListActiveVets')) {
    
    function cityVetListActiveVets(mysqli $conn): array {
        $res = $conn->query(
            "SELECT u.User_ID AS Vet_ID,
                    COALESCE(s.First_name, '') AS First_name,
                    COALESCE(s.Last_name, '') AS Last_name,
                    COALESCE(NULLIF(TRIM(CONCAT(COALESCE(s.First_name, ''), ' ', COALESCE(s.Last_name, ''))), ''), u.Username) AS Full_Name
             FROM users u
             LEFT JOIN staff s ON s.User_ID = u.User_ID
             WHERE u.Role_ID = 2 AND u.Status = 'active'
               AND (s.Status IS NULL OR s.Status = 'active')
             ORDER BY Full_Name ASC"
        );
        $out = [];
        while ($res && ($row = $res->fetch_assoc())) {
            $row['Vet_ID'] = (int)$row['Vet_ID'];
            $out[] = $row;
        }
        return $out;
    }
}

if (!function_exists('cityVetNameTokens')) {
    
    function cityVetNameTokens(string $name): array {
        $name = mb_strtolower($name, 'UTF-8');
        $name = preg_replace('/\b(dr|dra|vet|dvm)\b\.?/u', ' ', $name);
        $name = preg_replace('/[^\p{L}\s\-]/u', ' ', $name);
        $parts = preg_split('/\s+/u', trim($name), -1, PREG_SPLIT_NO_EMPTY) ?: [];
        return array_values(array_filter($parts, fn($p) => mb_strlen($p, 'UTF-8') > 1));
    }
}

if (!function_exists('cityVetMatchVetByName')) {
    




    function cityVetMatchVetByName(array $vets, string $printedName): ?array {
        $tok = cityVetNameTokens($printedName);
        if (count($tok) < 2) return null;
        $last = end($tok);
        $first = $tok[0];
        $hits = [];
        foreach ($vets as $v) {
            $vl = cityVetNameTokens((string)$v['Last_name']);
            $vf = cityVetNameTokens((string)$v['First_name']);
            if (!$vl || !$vf) continue;
            if (end($vl) === $last && $vf[0] === $first) {
                $hits[] = $v;
            }
        }
        return count($hits) === 1 ? $hits[0] : null;
    }
}

if (!function_exists('cityVetParseDutyText')) {
    







    function cityVetParseDutyText(string $text, string $defaultMonth): array {
        $schedule = [];
        $lines = preg_split('/\R/u', $text) ?: [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || stripos($line, 'weekend') !== false) continue;
            $line = preg_replace('/^(mon|tue|tues|wed|thu|thur|thurs|fri|sat|sun)[a-z]*\.?[\s,]+/iu', '', $line);

            $date = null;
            $rest = '';
            if (preg_match('/^(\d{4}-\d{2}-\d{2})[\s,;\t:\-]*(.+)$/u', $line, $m)) {
                $date = cityVetNormalizeDate($m[1]);
                $rest = $m[2];
            } elseif (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})[\s,;\t:\-]*(.+)$/u', $line, $m)) {
                $date = cityVetNormalizeDate(sprintf('%04d-%02d-%02d', $m[3], $m[1], $m[2]));
                $rest = $m[4];
            } elseif (preg_match('/^(\d{1,2})(?!\d)[\s,;\t:\-\.]*(.+)$/u', $line, $m) && preg_match('/^\d{4}-\d{2}$/', $defaultMonth)) {
                $date = cityVetNormalizeDate($defaultMonth . '-' . sprintf('%02d', $m[1]));
                $rest = $m[2];
            }
            if ($date === null || trim($rest) === '') continue;

            $names = preg_split('/\s*(?:;|\||&|\/|\band\b)\s*/iu', $rest, -1, PREG_SPLIT_NO_EMPTY) ?: [];
            foreach ($names as $n) {
                $n = trim($n, " \t,");
                if ($n === '') continue;
                $schedule[$date][] = $n;
            }
        }
        ksort($schedule);
        return $schedule;
    }
}

if (!function_exists('cityVetMonthHasSchedule')) {
    function cityVetMonthHasSchedule(mysqli $conn, string $date): bool {
        cityVetEnsureDutySchema($conn);
        $start = date('Y-m-01', strtotime($date));
        $end = date('Y-m-t', strtotime($date));
        $stmt = $conn->prepare("SELECT 1 FROM vet_duty_schedule WHERE Duty_Date BETWEEN ? AND ? LIMIT 1");
        $stmt->bind_param('ss', $start, $end);
        $stmt->execute();
        $has = (bool)$stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $has;
    }
}

if (!function_exists('cityVetGetDutyVets')) {
    



    function cityVetGetDutyVets(mysqli $conn, $dateValue): array {
        cityVetEnsureDutySchema($conn);
        $date = cityVetNormalizeDate($dateValue) ?? date('Y-m-d');
        $nameSql = "COALESCE(NULLIF(TRIM(CONCAT(COALESCE(s.First_name, ''), ' ', COALESCE(s.Last_name, ''))), ''), u.Username)";

        if (cityVetMonthHasSchedule($conn, $date)) {
            $stmt = $conn->prepare(
                "SELECT u.User_ID AS Vet_ID, $nameSql AS Full_Name
                 FROM vet_duty_schedule d
                 JOIN users u ON u.User_ID = d.Vet_User_ID
                 LEFT JOIN staff s ON s.User_ID = u.User_ID
                 WHERE d.Duty_Date = ? AND u.Role_ID = 2 AND u.Status = 'active'
                   AND (s.Status IS NULL OR s.Status = 'active')
                 ORDER BY Full_Name ASC, u.User_ID ASC"
            );
            $stmt->bind_param('s', $date);
        } else {
            
            $day = date('l', strtotime($date));
            $stmt = $conn->prepare(
                "SELECT DISTINCT u.User_ID AS Vet_ID, $nameSql AS Full_Name
                 FROM vet_availability va
                 JOIN users u ON u.User_ID = va.Vet_User_ID
                 LEFT JOIN staff s ON s.User_ID = u.User_ID
                 WHERE va.Day_Of_Week = ? AND va.Status = 'active'
                   AND u.Role_ID = 2 AND u.Status = 'active'
                   AND (s.Status IS NULL OR s.Status = 'active')
                 ORDER BY Full_Name ASC, u.User_ID ASC"
            );
            $stmt->bind_param('s', $day);
        }
        $stmt->execute();
        $res = $stmt->get_result();
        $out = [];
        while ($row = $res->fetch_assoc()) {
            $out[] = ['Vet_ID' => (int)$row['Vet_ID'], 'Full_Name' => trim($row['Full_Name'])];
        }
        $stmt->close();
        return $out;
    }
}

if (!function_exists('cityVetGetDutyVetId')) {
    
    function cityVetGetDutyVetId(mysqli $conn, $dateValue): ?int {
        $vets = cityVetGetDutyVets($conn, $dateValue);
        return $vets ? (int)$vets[0]['Vet_ID'] : null;
    }
}

if (!function_exists('cityVetIsVetOnDuty')) {
    function cityVetIsVetOnDuty(mysqli $conn, int $vetId, $dateValue): bool {
        if ($vetId <= 0) return false;
        foreach (cityVetGetDutyVets($conn, $dateValue) as $v) {
            if ($v['Vet_ID'] === $vetId) return true;
        }
        return false;
    }
}
