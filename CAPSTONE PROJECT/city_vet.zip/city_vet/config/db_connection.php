<?php
$appConfigFile = __DIR__ . '/app_config.php';
if (file_exists($appConfigFile)) {
    require_once $appConfigFile;
}
if (!defined('NO_SHOW_DEACTIVATE_THRESHOLD')) {
    define('NO_SHOW_DEACTIVATE_THRESHOLD', 3);
}

$isProduction = (defined('APP_ENV') && APP_ENV === 'production') || (getenv('APP_ENV') === 'production');
$serverName = $_SERVER['SERVER_NAME'] ?? '';
$isLocalhost = ($serverName === 'localhost' || $serverName === '127.0.0.1' || php_sapi_name() === 'cli');

$host = defined('DB_HOST') ? DB_HOST : (getenv('DB_HOST') ?: null);
$username = defined('DB_USER') ? DB_USER : (getenv('DB_USER') ?: null);
$password = defined('DB_PASS') ? DB_PASS : (getenv('DB_PASS') !== false ? getenv('DB_PASS') : null);
$database = defined('DB_NAME') ? DB_NAME : (getenv('DB_NAME') ?: null);

if (!$isProduction && $isLocalhost) {
    if ($host === null || $host === '' || $host === 'CHANGE_ME_HOST') {
        $host = 'localhost';
    }
    if ($username === null || $username === '' || $username === 'CHANGE_ME_USER') {
        $username = 'root';
    }
    if ($password === null || $password === 'CHANGE_ME_PASSWORD') {
        $password = '';
    }
    if ($database === null || $database === '' || $database === 'CHANGE_ME_DATABASE') {
        $database = 'city_vet_db';
    }
}

if (empty($host) || empty($username) || empty($database) || $host === 'CHANGE_ME_HOST' || $username === 'CHANGE_ME_USER' || $database === 'CHANGE_ME_DATABASE') {
    error_log("Database configuration missing or invalid.");
    http_response_code(500);
    header("Content-Type: application/json; charset=UTF-8");
    die(json_encode(["status" => "error", "message" => "Database connection failed. Please try again later."]));
}

$conn = @new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    error_log("Database connection error: " . $conn->connect_error);
    http_response_code(500);
    header("Content-Type: application/json; charset=UTF-8");
    die(json_encode(["status" => "error", "message" => "Database connection failed. Please try again later."]));
}

if (!$conn->query("SET time_zone = '+08:00'")) {
    error_log("Database timezone configuration error: " . $conn->error);
    http_response_code(500);
    header("Content-Type: application/json; charset=UTF-8");
    die(json_encode(["status" => "error", "message" => "Database connection failed. Please try again later."]));
}