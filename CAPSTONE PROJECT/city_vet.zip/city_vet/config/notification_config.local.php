<?php
// Local-only mail settings. Do not commit this file.
if (!defined('SMTP_HOST')) define('SMTP_HOST', 'smtp.gmail.com');
if (!defined('SMTP_PORT')) define('SMTP_PORT', 587);
if (!defined('SMTP_USERNAME')) define('SMTP_USERNAME', 'cityvetoffice.notifications@gmail.com');
if (!defined('SMTP_PASSWORD')) define('SMTP_PASSWORD', 'ehbirrokzzwmscjf');
if (!defined('SMTP_ENCRYPTION')) define('SMTP_ENCRYPTION', 'tls');
if (!defined('SMTP_FROM_EMAIL')) define('SMTP_FROM_EMAIL', SMTP_USERNAME);
if (!defined('SMTP_FROM_NAME')) define('SMTP_FROM_NAME', 'City Vet CDO');

// IPROG SMS settings. Paste your API token here; do not commit or share this file.
if (!defined('IPROG_SMS_ENABLED')) define('IPROG_SMS_ENABLED', true);
if (!defined('IPROG_API_TOKEN')) define('IPROG_API_TOKEN', 'e0859f39d614c1736ee19f1732175176ca6c6a84');
