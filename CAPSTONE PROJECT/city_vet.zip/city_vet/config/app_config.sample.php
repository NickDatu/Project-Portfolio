<?php
if (!defined('DB_HOST')) define('DB_HOST', 'CHANGE_ME_HOST');
if (!defined('DB_USER')) define('DB_USER', 'CHANGE_ME_USER');
if (!defined('DB_PASS')) define('DB_PASS', 'CHANGE_ME_PASS');
if (!defined('DB_NAME')) define('DB_NAME', 'CHANGE_ME_NAME');

if (!defined('APP_ENV')) define('APP_ENV', 'production');
if (!defined('BASE_URL')) define('BASE_URL', '');
if (!defined('APP_TIMEZONE')) define('APP_TIMEZONE', 'Asia/Manila');

if (!defined('RESEND_API_KEY')) define('RESEND_API_KEY', '');
if (!defined('RESEND_FROM_EMAIL')) define('RESEND_FROM_EMAIL', 'City Vet <onboarding@resend.dev>');

if (!defined('SEMAPHORE_API_KEY')) define('SEMAPHORE_API_KEY', '');
if (!defined('SEMAPHORE_SENDER_NAME')) define('SEMAPHORE_SENDER_NAME', '');

if (!defined('SMTP_HOST')) define('SMTP_HOST', 'smtp.gmail.com');
if (!defined('SMTP_PORT')) define('SMTP_PORT', 587);
if (!defined('SMTP_USERNAME')) define('SMTP_USERNAME', '');
if (!defined('SMTP_PASSWORD')) define('SMTP_PASSWORD', '');
if (!defined('SMTP_ENCRYPTION')) define('SMTP_ENCRYPTION', 'tls');
if (!defined('SMTP_FROM_EMAIL')) define('SMTP_FROM_EMAIL', '');
if (!defined('SMTP_FROM_NAME')) define('SMTP_FROM_NAME', 'City Vet CDO');

if (!defined('NO_SHOW_DEACTIVATE_THRESHOLD')) define('NO_SHOW_DEACTIVATE_THRESHOLD', 3);
