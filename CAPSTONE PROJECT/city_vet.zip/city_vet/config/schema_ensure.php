<?php














if (!function_exists('cityVetColumnExists')) {
    function cityVetColumnExists(mysqli $conn, string $table, string $column): bool {
        $stmt = $conn->prepare(
            "SELECT COUNT(*) AS c FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?"
        );
        $stmt->bind_param('ss', $table, $column);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return (int)($row['c'] ?? 0) > 0;
    }
}

if (!function_exists('cityVetTableExists')) {
    function cityVetTableExists(mysqli $conn, string $table): bool {
        $stmt = $conn->prepare(
            "SELECT COUNT(*) AS c FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?"
        );
        $stmt->bind_param('s', $table);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return (int)($row['c'] ?? 0) > 0;
    }
}

if (!function_exists('cityVetEnsureMedicalSchema')) {
    


    function cityVetEnsureMedicalSchema(mysqli $conn): void {
        static $done = false;
        if ($done) return;
        $done = true;

        try {
            $medicalColumns = [
                'Booklet'          => "ALTER TABLE `medical_records` ADD COLUMN `Booklet` varchar(255) DEFAULT NULL AFTER `Notes`",
                'Medicine_Used'    => "ALTER TABLE `medical_records` ADD COLUMN `Medicine_Used` text DEFAULT NULL AFTER `Booklet`",
                'Medicine_Picture' => "ALTER TABLE `medical_records` ADD COLUMN `Medicine_Picture` varchar(255) DEFAULT NULL AFTER `Medicine_Used`",
            ];
            foreach ($medicalColumns as $col => $sql) {
                if (!cityVetColumnExists($conn, 'medical_records', $col)) {
                    $conn->query($sql);
                }
            }

            if (!cityVetColumnExists($conn, 'appointments', 'Vet_ID')) {
                $conn->query("ALTER TABLE `appointments` ADD COLUMN `Vet_ID` int(11) DEFAULT NULL AFTER `Service_ID`");
            }
        } catch (Throwable $e) {
            error_log('cityVetEnsureMedicalSchema failed: ' . $e->getMessage());
        }
    }
}

if (!function_exists('cityVetEnsurePetTransferSchema')) {
    function cityVetEnsurePetTransferSchema(mysqli $conn): void {
        static $done = false; if ($done) return; $done = true;
        try {
            $conn->query("CREATE TABLE IF NOT EXISTS `pet_transfer_requests` (
                `Transfer_ID` int(11) NOT NULL AUTO_INCREMENT,
                `Pet_ID` int(11) NOT NULL,
                `From_Owner_ID` int(11) NOT NULL,
                `To_Owner_ID` int(11) NOT NULL,
                `OTP_Hash` varchar(255) NOT NULL,
                `Expires_At` datetime NOT NULL,
                `Attempts` int(11) NOT NULL DEFAULT 0,
                `Status` enum('pending','completed','cancelled','expired') NOT NULL DEFAULT 'pending',
                `Created_At` datetime NOT NULL DEFAULT current_timestamp(),
                `Completed_At` datetime DEFAULT NULL,
                PRIMARY KEY (`Transfer_ID`),
                KEY `idx_ptr_pet` (`Pet_ID`),
                KEY `idx_ptr_from_owner` (`From_Owner_ID`),
                KEY `idx_ptr_to_owner` (`To_Owner_ID`),
                KEY `idx_ptr_status` (`Status`),
                KEY `idx_ptr_expires` (`Expires_At`),
                CONSTRAINT `ptr_pet_fk` FOREIGN KEY (`Pet_ID`) REFERENCES `pets` (`Pet_ID`),
                CONSTRAINT `ptr_from_owner_fk` FOREIGN KEY (`From_Owner_ID`) REFERENCES `owners` (`Owner_ID`),
                CONSTRAINT `ptr_to_owner_fk` FOREIGN KEY (`To_Owner_ID`) REFERENCES `owners` (`Owner_ID`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
        } catch (Throwable $e) { error_log('cityVetEnsurePetTransferSchema failed: ' . $e->getMessage()); }
    }
}

if (!function_exists('cityVetEnsureConsultationCatalogSchema')) {
    function cityVetEnsureConsultationCatalogSchema(mysqli $conn): void {
        static $done = false;
        if ($done) return;
        $done = true;

        try {
            $conn->query("CREATE TABLE IF NOT EXISTS `treatment_catalog` (
                `Treatment_ID` int(11) NOT NULL AUTO_INCREMENT,
                `Treatment_Name` varchar(120) NOT NULL,
                `Status` enum('active','inactive') NOT NULL DEFAULT 'active',
                `Created_At` datetime NOT NULL DEFAULT current_timestamp(),
                `Updated_At` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
                PRIMARY KEY (`Treatment_ID`),
                UNIQUE KEY `uq_treatment_name` (`Treatment_Name`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

            $conn->query("CREATE TABLE IF NOT EXISTS `medicine_catalog` (
                `Medicine_ID` int(11) NOT NULL AUTO_INCREMENT,
                `Medicine_Name` varchar(120) NOT NULL,
                `Status` enum('active','inactive') NOT NULL DEFAULT 'active',
                `Created_At` datetime NOT NULL DEFAULT current_timestamp(),
                `Updated_At` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
                PRIMARY KEY (`Medicine_ID`),
                UNIQUE KEY `uq_medicine_name` (`Medicine_Name`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

            $conn->query("INSERT IGNORE INTO `treatment_catalog` (`Treatment_Name`) VALUES
                ('General Consultation'), ('General Checkup'), ('Physical Examination'),
                ('Anti-Rabies Vaccination'), ('5-in-1 Vaccination'), ('Parvo Vaccination'),
                ('Deworming'), ('Spay/Neuter'), ('Post-Operative Checkup'), ('Wound Care'), ('Ear Cleaning')");
            $conn->query("INSERT IGNORE INTO `medicine_catalog` (`Medicine_Name`) VALUES
                ('Amoxicillin'), ('Cephalexin'), ('Doxycycline'), ('Metronidazole'),
                ('Meloxicam'), ('Carprofen'), ('Prednisolone'), ('Diphenhydramine'),
                ('Pyrantel Pamoate'), ('Fenbendazole'), ('Praziquantel'), ('Fipronil')");
        } catch (Throwable $e) {
            error_log('cityVetEnsureConsultationCatalogSchema failed: ' . $e->getMessage());
        }
    }
}

if (!function_exists('cityVetEnsureLiveQueueSchema')) {
    



    function cityVetEnsureLiveQueueSchema(mysqli $conn): void {
        static $done = false;
        if ($done) return;
        $done = true;

        try {
            if (cityVetTableExists($conn, 'live_queue_tickets')
                && cityVetTableExists($conn, 'live_queue_services')
                && cityVetTableExists($conn, 'live_queue_counters')) {
                
                if (cityVetColumnExists($conn, 'live_queue_tickets', 'Owner_ID')) {
                    $conn->query("ALTER TABLE `live_queue_tickets` MODIFY `Owner_ID` int(11) DEFAULT NULL");
                }
                if (!cityVetColumnExists($conn, 'live_queue_tickets', 'Note')) {
                    $conn->query("ALTER TABLE `live_queue_tickets` ADD COLUMN `Note` varchar(100) DEFAULT NULL AFTER `Pet_ID`");
                }
                return;
            }

            $conn->query("
                CREATE TABLE IF NOT EXISTS `live_queue_services` (
                  `Service_Code` varchar(20) NOT NULL,
                  `Service_Name` varchar(60) NOT NULL,
                  `Sort_Order` int(11) NOT NULL DEFAULT 0,
                  `Status` enum('active','inactive') NOT NULL DEFAULT 'active',
                  PRIMARY KEY (`Service_Code`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
            ");

            $conn->query("
                INSERT INTO `live_queue_services` (`Service_Code`, `Service_Name`, `Sort_Order`, `Status`) VALUES
                ('GEN_CHECKUP', 'General Checkup', 1, 'active'),
                ('ANTI_RABIES', 'Anti-Rabies Vaccination', 2, 'active'),
                ('5IN1_VAX', '5-in-1 Vaccination', 3, 'active'),
                ('PARVO_VAX', 'Parvo Vaccination', 4, 'active'),
                ('DEWORMING', 'Deworming', 5, 'active'),
                ('ONLINE_CONSULT', 'Online Consultation', 6, 'active')
                ON DUPLICATE KEY UPDATE `Service_Name` = VALUES(`Service_Name`), `Sort_Order` = VALUES(`Sort_Order`), `Status` = 'active'
            ");

            
            
            $conn->query("
                CREATE TABLE IF NOT EXISTS `live_queue_counters` (
                  `Session_Date` date NOT NULL,
                  `Service_Code` varchar(20) NOT NULL,
                  `Last_Number` int(11) NOT NULL DEFAULT 0,
                  PRIMARY KEY (`Session_Date`, `Service_Code`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
            ");

            $conn->query("
                CREATE TABLE IF NOT EXISTS `live_queue_tickets` (
                  `Ticket_ID` int(11) NOT NULL AUTO_INCREMENT,
                  `Session_Date` date NOT NULL,
                  `Service_Code` varchar(20) NOT NULL,
                  `Ticket_Number` int(11) NOT NULL,
                  `Owner_ID` int(11) DEFAULT NULL,
                  `Pet_ID` int(11) DEFAULT NULL,
                  `Note` varchar(100) DEFAULT NULL,
                  `Status` enum('Waiting','Called','Serving','Completed','Skipped','Cancelled') NOT NULL DEFAULT 'Waiting',
                  `Recall_Count` int(11) NOT NULL DEFAULT 0,
                  `Created_By` int(11) DEFAULT NULL,
                  `Handled_By` int(11) DEFAULT NULL,
                  `Created_At` datetime NOT NULL DEFAULT current_timestamp(),
                  `Called_At` datetime DEFAULT NULL,
                  `Serving_At` datetime DEFAULT NULL,
                  `Completed_At` datetime DEFAULT NULL,
                  `Last_Recalled_At` datetime DEFAULT NULL,
                  PRIMARY KEY (`Ticket_ID`),
                  UNIQUE KEY `uniq_ticket_per_session` (`Session_Date`, `Service_Code`, `Ticket_Number`),
                  KEY `idx_lq_session_status` (`Session_Date`, `Status`),
                  KEY `idx_lq_owner` (`Owner_ID`),
                  KEY `idx_lq_pet` (`Pet_ID`),
                  KEY `idx_lq_service` (`Service_Code`),
                  KEY `idx_lq_created_by` (`Created_By`),
                  KEY `idx_lq_handled_by` (`Handled_By`),
                  CONSTRAINT `lq_tickets_service_fk` FOREIGN KEY (`Service_Code`) REFERENCES `live_queue_services` (`Service_Code`),
                  CONSTRAINT `lq_tickets_owner_fk` FOREIGN KEY (`Owner_ID`) REFERENCES `owners` (`Owner_ID`),
                  CONSTRAINT `lq_tickets_pet_fk` FOREIGN KEY (`Pet_ID`) REFERENCES `pets` (`Pet_ID`) ON DELETE SET NULL,
                  CONSTRAINT `lq_tickets_created_by_fk` FOREIGN KEY (`Created_By`) REFERENCES `users` (`User_ID`) ON DELETE SET NULL,
                  CONSTRAINT `lq_tickets_handled_by_fk` FOREIGN KEY (`Handled_By`) REFERENCES `users` (`User_ID`) ON DELETE SET NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
            ");
        } catch (Throwable $e) {
            error_log('cityVetEnsureLiveQueueSchema failed: ' . $e->getMessage());
        }
    }
}

if (!function_exists('cityVetEnsureConsultationTemplateSchema')) {
    function cityVetEnsureConsultationTemplateSchema(mysqli $conn): void {
        static $done = false; if ($done) return; $done = true;
        try {
            $conn->query("CREATE TABLE IF NOT EXISTS consultation_findings (
                Finding_ID int(11) NOT NULL AUTO_INCREMENT, Record_ID int(11) NOT NULL, Pet_ID int(11) NOT NULL,
                Weight_Status varchar(30) DEFAULT NULL, Body_Condition_Score tinyint DEFAULT NULL, Purpose longtext DEFAULT NULL,
                Findings longtext DEFAULT NULL, Diagnosis_Text text DEFAULT NULL, Recommendations text DEFAULT NULL,
                Created_At datetime NOT NULL DEFAULT current_timestamp(), PRIMARY KEY (Finding_ID), UNIQUE KEY uq_consultation_finding_record (Record_ID),
                KEY idx_consultation_finding_pet (Pet_ID), CONSTRAINT consultation_findings_record_fk FOREIGN KEY (Record_ID) REFERENCES medical_records (Record_ID) ON DELETE CASCADE,
                CONSTRAINT consultation_findings_pet_fk FOREIGN KEY (Pet_ID) REFERENCES pets (Pet_ID) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
            $conn->query("CREATE TABLE IF NOT EXISTS vaccination_schedule_rules (
                Rule_ID int(11) NOT NULL AUTO_INCREMENT, Species_ID int(11) NOT NULL, Age_Weeks int(11) NOT NULL, Procedure_Name varchar(100) NOT NULL,
                Repeat_Value int(11) NOT NULL, Repeat_Unit enum('days','weeks','months','years') NOT NULL, Repeat_Note varchar(120) DEFAULT NULL,
                Sort_Order int(11) NOT NULL DEFAULT 0, Status enum('active','inactive') NOT NULL DEFAULT 'active', PRIMARY KEY (Rule_ID),
                UNIQUE KEY uq_vaccination_rule (Species_ID,Age_Weeks,Procedure_Name), KEY idx_vaccination_rule_species (Species_ID),
                CONSTRAINT vaccination_rules_species_fk FOREIGN KEY (Species_ID) REFERENCES species (Species_ID)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
            $speciesIds = [];
            $speciesResult = $conn->query("SELECT Species_ID, Species_Name FROM species WHERE Species_Name IN ('Dog', 'Cat')");
            while ($speciesRow = $speciesResult->fetch_assoc()) $speciesIds[$speciesRow['Species_Name']] = (int)$speciesRow['Species_ID'];
            $rules = [
                ['Dog',2,'Deworming',2,'weeks','',1],['Dog',4,'Deworming',2,'weeks','',2],['Dog',6,'Deworming',4,'weeks','',3],['Dog',6,'5-in-1 Vaccine',2,'weeks','Private veterinary office',4],['Dog',8,'5-in-1 Vaccine',2,'weeks','Private veterinary office',5],['Dog',10,'Deworming',4,'weeks','',6],['Dog',10,'5-in-1 Vaccine',3,'months','',7],['Dog',12,'Anti-Rabies Vaccination',1,'years','City Veterinary Office',8],['Dog',14,'5-in-1 Vaccine',1,'years','City Veterinary Office',9],
                ['Cat',4,'Deworming',2,'weeks','',1],['Cat',6,'Deworming',2,'weeks','',2],['Cat',8,'3-in-1 or 4-in-1 Vaccine',2,'weeks','',3],['Cat',8,'Deworming',3,'months','',4],['Cat',11,'3-in-1 or 4-in-1 Vaccine',3,'weeks','',5],['Cat',12,'Anti-Rabies Vaccination',1,'years','City Veterinary Office',6],['Cat',14,'3-in-1 or 4-in-1 Vaccine',1,'years','',7]
            ];
            $stmt = $conn->prepare("INSERT IGNORE INTO vaccination_schedule_rules (Species_ID,Age_Weeks,Procedure_Name,Repeat_Value,Repeat_Unit,Repeat_Note,Sort_Order) VALUES (?,?,?,?,?,?,?)");
            foreach ($rules as $rule) { $speciesId = $speciesIds[$rule[0]] ?? 0; if ($speciesId <= 0) continue; $stmt->bind_param('iisissi', $speciesId,$rule[1],$rule[2],$rule[3],$rule[4],$rule[5],$rule[6]); $stmt->execute(); }
            $stmt->close();
            $conn->query("INSERT IGNORE INTO services (Category_ID,Service_Name,Price,Status) SELECT Category_ID,'3-in-1 / 4-in-1 Vaccination',0.00,'active' FROM service_categories WHERE Category_Name='Vaccination' LIMIT 1");
        } catch (Throwable $e) { error_log('cityVetEnsureConsultationTemplateSchema failed: ' . $e->getMessage()); }
    }
}

if (!function_exists('cityVetEnsureNotificationSchema')) {
    function cityVetEnsureNotificationSchema(mysqli $conn): void {
        static $done = false; if ($done) return; $done = true;
        try {
            if (!cityVetColumnExists($conn, 'notifications', 'Event_ID')) {
                $conn->query("ALTER TABLE notifications ADD COLUMN Event_ID int(11) DEFAULT NULL AFTER Type");
                $conn->query("ALTER TABLE notifications ADD KEY idx_notifications_event (Event_ID)");
            }
        } catch (Throwable $e) { error_log('cityVetEnsureNotificationSchema failed: ' . $e->getMessage()); }
    }
}

if (!function_exists('cityVetEnsureEventBarangaySchema')) {
    function cityVetEnsureEventBarangaySchema(mysqli $conn): void {
        static $done = false; if ($done) return; $done = true;
        try {
            if (!cityVetColumnExists($conn, 'owners', 'Barangay')) {
                $conn->query("ALTER TABLE owners ADD COLUMN Barangay varchar(100) DEFAULT NULL AFTER Address");
            }
            if (!cityVetColumnExists($conn, 'calendar_events', 'Barangay')) {
                $conn->query("ALTER TABLE calendar_events ADD COLUMN Barangay varchar(100) DEFAULT NULL AFTER Event_Date");
            }
        } catch (Throwable $e) { error_log('cityVetEnsureEventBarangaySchema failed: ' . $e->getMessage()); }
    }
}

if (!function_exists('cityVetEnsureReminderRunSchema')) {
    function cityVetEnsureReminderRunSchema(mysqli $conn): void {
        try {
            $conn->query("CREATE TABLE IF NOT EXISTS cityvet_reminder_runs (
                Reminder_Key VARCHAR(80) NOT NULL PRIMARY KEY,
                Last_Run_Date DATE NULL,
                Updated_At DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        } catch (Throwable $e) { error_log('cityVetEnsureReminderRunSchema failed: ' . $e->getMessage()); }
    }
}

if (!function_exists('cityVetEnsurePanelRevisionSchema')) {
    function cityVetEnsurePanelRevisionSchema(mysqli $conn): void {
        static $done = false; if ($done) return; $done = true;
        try {
            $columns = [
                ['owners', 'Owner_Code', "ALTER TABLE owners ADD COLUMN Owner_Code VARCHAR(32) NULL"],
                ['pets', 'Pet_Code', "ALTER TABLE pets ADD COLUMN Pet_Code VARCHAR(32) NULL"],
                ['medical_records', 'Lot_Number', "ALTER TABLE medical_records ADD COLUMN Lot_Number VARCHAR(100) NULL"],
                ['calendar_events', 'Correction_Reason', "ALTER TABLE calendar_events ADD COLUMN Correction_Reason VARCHAR(255) NULL"],
                ['calendar_events', 'Corrected_By', "ALTER TABLE calendar_events ADD COLUMN Corrected_By INT NULL"],
                ['calendar_events', 'Corrected_At', "ALTER TABLE calendar_events ADD COLUMN Corrected_At DATETIME NULL"],
                ['appointments', 'Correction_Reason', "ALTER TABLE appointments ADD COLUMN Correction_Reason VARCHAR(255) NULL"],
                ['appointments', 'Corrected_By', "ALTER TABLE appointments ADD COLUMN Corrected_By INT NULL"],
                ['appointments', 'Corrected_At', "ALTER TABLE appointments ADD COLUMN Corrected_At DATETIME NULL"]
            ];
            foreach ($columns as $column) if (cityVetTableExists($conn, $column[0]) && !cityVetColumnExists($conn, $column[0], $column[1])) $conn->query($column[2]);
            $conn->query("CREATE TABLE IF NOT EXISTS pet_external_records (
                External_Record_ID INT NOT NULL AUTO_INCREMENT, Pet_ID INT NOT NULL,
                Source_Clinic VARCHAR(255) NULL, Record_Type ENUM('Vaccination','Treatment','Deworming','Other') NOT NULL DEFAULT 'Other',
                Record_Date DATE NULL, Name VARCHAR(255) NULL, Medicine VARCHAR(255) NULL, Dosage VARCHAR(120) NULL,
                Lot_Number VARCHAR(100) NULL, Provider VARCHAR(255) NULL, Notes TEXT NULL, Attachment_Path VARCHAR(255) NULL,
                Created_By INT NULL, Created_At DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, Verified_By INT NULL, Verified_At DATETIME NULL,
                Is_Deleted TINYINT(1) NOT NULL DEFAULT 0, PRIMARY KEY (External_Record_ID), KEY idx_external_pet (Pet_ID),
                CONSTRAINT pet_external_records_pet_fk FOREIGN KEY (Pet_ID) REFERENCES pets(Pet_ID) ON DELETE CASCADE,
                CONSTRAINT pet_external_records_created_by_fk FOREIGN KEY (Created_By) REFERENCES users(User_ID) ON DELETE SET NULL,
                CONSTRAINT pet_external_records_verified_by_fk FOREIGN KEY (Verified_By) REFERENCES users(User_ID) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
            $conn->query("UPDATE owners SET Owner_Code = CONCAT('OWN-', YEAR(COALESCE(Registration_Date, NOW())), '-', LPAD(Owner_ID, 6, '0')) WHERE Owner_Code IS NULL OR Owner_Code = ''");
            $conn->query("UPDATE pets p JOIN owners o ON o.Owner_ID = p.Owner_ID SET p.Pet_Code = CONCAT('PET-', YEAR(COALESCE(o.Registration_Date, NOW())), '-', LPAD(p.Pet_ID, 6, '0')) WHERE p.Pet_Code IS NULL OR p.Pet_Code = ''");
        } catch (Throwable $e) { error_log('cityVetEnsurePanelRevisionSchema failed: ' . $e->getMessage()); }
    }
}

if (!function_exists('cityVetEnsureCalendarEventTypeSchema')) {
    function cityVetEnsureCalendarEventTypeSchema(mysqli $conn): void {
        static $done = false; if ($done) return; $done = true;
        try {
            $conn->query("ALTER TABLE calendar_events MODIFY Event_Type ENUM('SpayNeuter','General','Holiday') NOT NULL DEFAULT 'SpayNeuter'");
        } catch (Throwable $e) { error_log('cityVetEnsureCalendarEventTypeSchema failed: ' . $e->getMessage()); }
    }
}

if (!function_exists('cityVetEnsureSpayConfirmationSchema')) {
    function cityVetEnsureSpayConfirmationSchema(mysqli $conn): void {
        static $done = false; if ($done) return; $done = true;
        try {
            $columns = [
                'Confirmation_Attempts' => "ALTER TABLE appointments ADD COLUMN Confirmation_Attempts int unsigned NOT NULL DEFAULT 0 AFTER Confirmed_At",
                'Last_Contacted_At' => "ALTER TABLE appointments ADD COLUMN Last_Contacted_At datetime DEFAULT NULL AFTER Confirmation_Attempts",
                'Callback_Deadline' => "ALTER TABLE appointments ADD COLUMN Callback_Deadline datetime DEFAULT NULL AFTER Last_Contacted_At",
                'Owner_Confirmed_At' => "ALTER TABLE appointments ADD COLUMN Owner_Confirmed_At datetime DEFAULT NULL AFTER Callback_Deadline",
                'Owner_Confirmed_By' => "ALTER TABLE appointments ADD COLUMN Owner_Confirmed_By int(11) DEFAULT NULL AFTER Owner_Confirmed_At",
                'Callback_SMS_Sent_At' => "ALTER TABLE appointments ADD COLUMN Callback_SMS_Sent_At datetime DEFAULT NULL AFTER Owner_Confirmed_By",
                'Reminder_SMS_Sent_At' => "ALTER TABLE appointments ADD COLUMN Reminder_SMS_Sent_At datetime DEFAULT NULL AFTER Callback_SMS_Sent_At",
            ];
            foreach ($columns as $column => $sql) {
                if (!cityVetColumnExists($conn, 'appointments', $column)) $conn->query($sql);
            }
        } catch (Throwable $e) { error_log('cityVetEnsureSpayConfirmationSchema failed: ' . $e->getMessage()); }
    }
}

if (!function_exists('cityVetCountWords')) {
    
    function cityVetCountWords(string $text): int {
        $parts = preg_split('/\s+/u', trim($text), -1, PREG_SPLIT_NO_EMPTY);
        return $parts === false ? 0 : count($parts);
    }
}

if (!function_exists('cityVetGetActiveVet')) {
    


    function cityVetGetActiveVet(mysqli $conn, int $userId): ?array {
        if ($userId <= 0) return null;
        $stmt = $conn->prepare(
            "SELECT u.User_ID,
                    COALESCE(NULLIF(TRIM(CONCAT(COALESCE(s.First_name, ''), ' ', COALESCE(s.Last_name, ''))), ''), u.Username) AS Full_Name
             FROM users u
             LEFT JOIN staff s ON s.User_ID = u.User_ID
             WHERE u.User_ID = ? AND u.Role_ID = 2 AND u.Status = 'active'
               AND (s.Status IS NULL OR s.Status = 'active')
             LIMIT 1"
        );
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $row ?: null;
    }
}

if (!function_exists('cityVetDefaultFollowUp')) {
    function cityVetDefaultFollowUp(int $months, int $years): string {
        $date = new DateTime('today');
        $day = (int)$date->format('j');
        $date->setDate((int)$date->format('Y'), (int)$date->format('n'), 1);
        $date->modify('+' . ($months + $years * 12) . ' months');
        $lastDay = (int)$date->format('t');
        $date->setDate((int)$date->format('Y'), (int)$date->format('n'), min($day, $lastDay));
        while ((int)$date->format('N') >= 6) $date->modify('+1 day');
        return $date->format('Y-m-d');
    }
}
