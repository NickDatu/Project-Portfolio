<?php
$appConfigFile = __DIR__ . '/app_config.php';
if (file_exists($appConfigFile)) {
    require_once $appConfigFile;
}

$localConfig = __DIR__ . '/notification_config.local.php';
if (file_exists($localConfig)) {
    require_once $localConfig;
}

if (!defined('RESEND_API_KEY')) {
    define('RESEND_API_KEY', getenv('RESEND_API_KEY') ?: 'PASTE_RESEND_API_KEY_HERE');
}

if (!defined('RESEND_FROM_EMAIL')) {
    define('RESEND_FROM_EMAIL', getenv('RESEND_FROM_EMAIL') ?: 'City Vet <onboarding@resend.dev>');
}

if (!defined('SEMAPHORE_API_KEY')) {
    define('SEMAPHORE_API_KEY', getenv('SEMAPHORE_API_KEY') ?: 'PASTE_SEMAPHORE_API_KEY_HERE');
}

if (!defined('SEMAPHORE_SENDER_NAME')) {
    define('SEMAPHORE_SENDER_NAME', getenv('SEMAPHORE_SENDER_NAME') ?: '');
}

if (!defined('IPROG_API_TOKEN')) {
    define('IPROG_API_TOKEN', getenv('IPROG_API_TOKEN') ?: 'PASTE_YOUR_IPROG_API_TOKEN_HERE');
}

// SMS is disabled while user/data migration is in progress. Enable explicitly when ready.
if (!defined('IPROG_SMS_ENABLED')) {
    define('IPROG_SMS_ENABLED', false);
}

if (!defined('SMTP_HOST')) define('SMTP_HOST', getenv('SMTP_HOST') ?: 'smtp.gmail.com');
if (!defined('SMTP_PORT')) define('SMTP_PORT', (int)(getenv('SMTP_PORT') ?: 587));
if (!defined('SMTP_USERNAME')) define('SMTP_USERNAME', getenv('SMTP_USERNAME') ?: '');
if (!defined('SMTP_PASSWORD')) define('SMTP_PASSWORD', getenv('SMTP_PASSWORD') ?: '');
if (!defined('SMTP_ENCRYPTION')) define('SMTP_ENCRYPTION', getenv('SMTP_ENCRYPTION') ?: 'tls');
if (!defined('SMTP_FROM_EMAIL')) define('SMTP_FROM_EMAIL', getenv('SMTP_FROM_EMAIL') ?: SMTP_USERNAME);
if (!defined('SMTP_FROM_NAME')) define('SMTP_FROM_NAME', getenv('SMTP_FROM_NAME') ?: 'City Vet CDO');
