<?php

function cityVetConsultationTemplateDefinition(): array {
    return [
        'weight_statuses' => ['Ideal Weight', 'Overweight', 'Underweight'],
        'systems' => [
            'mentation' => ['label' => 'Mentation/Attitude', 'items' => ['bar_qar' => 'BAR/QAR', 'depressed' => 'Depressed', 'aggressive' => 'Aggressive', 'anxious_fearful' => 'Anxious/Fearful']],
            'eyes' => ['label' => 'Eyes', 'items' => ['discharge' => 'Discharge', 'inflamed' => 'Inflamed', 'infection' => 'Infection', 'cataract' => 'Cataract', 'corneal_ulcer_lesion' => 'Corneal Ulcer/Lesion', 'eyelid_lesion_growth' => 'Eyelid Lesion/Growth']],
            'ears' => ['label' => 'Ears', 'items' => ['inflamed' => 'Inflamed', 'excessive_debris' => 'Excessive Debris', 'excessive_hair' => 'Excessive Hair', 'mites' => 'Mites', 'lesions_growths' => 'Lesions/Growths']],
            'mouth_teeth_gums' => ['label' => 'Mouth/Teeth/Gums', 'items' => ['broken_tooth' => 'Broken Tooth', 'gingivitis' => 'Gingivitis', 'calculus' => 'Calculus', 'ulcers_growths' => 'Ulcers/Growths']],
            'skin_coat' => ['label' => 'Skin/Coat', 'items' => ['parasites' => 'Parasites', 'alopecia' => 'Alopecia', 'redness' => 'Redness', 'lesions_ulcers' => 'Lesions/Ulcers', 'rash_dermatitis' => 'Rash/Dermatitis', 'dry_coat_dander' => 'Dry Coat/Dander', 'matted_hair' => 'Matted Hair', 'lumps_tumors' => 'Lumps/Tumors']],
            'neurologic' => ['label' => 'Neurologic', 'items' => ['seizure_tremor' => 'Seizure/Tremor', 'circling_head_tilt' => 'Circling/Head Tilt', 'paresis_paralysis' => 'Paresis/Paralysis', 'ataxia_gait_abnormality' => 'Ataxia/Gait Abnormality']],
            'respiratory_lungs' => ['label' => 'Respiratory/Lungs', 'items' => ['nasal_discharge' => 'Nasal Discharge', 'congestion' => 'Congestion', 'abnormal_sound' => 'Abnormal Sound', 'rapid_breathing' => 'Rapid Breathing', 'breathing_difficulty' => 'Breathing Difficulty', 'coughing' => 'Coughing']],
            'cardiac_heart' => ['label' => 'Cardiac/Heart', 'items' => ['heart_murmur' => 'Heart Murmur', 'abnormal_rhythm' => 'Abnormal Rhythm']],
            'gastrointestinal' => ['label' => 'Gastrointestinal', 'items' => ['parasites' => 'Parasites', 'vomiting' => 'Vomiting', 'abnormal_feces' => 'Abnormal Feces', 'diarrhea' => 'Diarrhea', 'inappetence' => 'Inappetence']],
            'abdomen' => ['label' => 'Abdomen', 'items' => ['enlarged_organ' => 'Enlarged Organ', 'fluid' => 'Fluid', 'painful_palpation' => 'Painful Palpation', 'mass_growth' => 'Mass/Growth']],
            'urogenital' => ['label' => 'Urogenital', 'items' => ['genital_discharge' => 'Genital Discharge', 'estrus_pregnancy' => 'Estrus/Pregnancy', 'mammary_gland_abnormality' => 'Mammary Gland Abnormality', 'abnormal_testicle' => 'Abnormal Testicle', 'abnormal_prostate' => 'Abnormal Prostate']],
            'musculoskeletal' => ['label' => 'Musculoskeletal', 'items' => ['pain' => 'Pain', 'swelling' => 'Swelling', 'lameness' => 'Lameness']],
        ],
        'purposes' => ['healthy' => 'Healthy', 'vitamins' => 'Vitamins', 'deworming' => 'Deworming']
    ];
}

function cityVetValidateConsultationFindings($raw): array {
    if ($raw === null || $raw === '' || $raw === []) return ['value' => null, 'error' => null];
    if (is_string($raw)) $raw = json_decode($raw, true);
    if (!is_array($raw)) return ['value' => null, 'error' => 'Consultation findings must be valid data.'];
    $definition = cityVetConsultationTemplateDefinition();
    $weight = $raw['weight_status'] ?? null;
    if ($weight !== null && !in_array($weight, $definition['weight_statuses'], true)) return ['value' => null, 'error' => 'Invalid weight status.'];
    $bcs = $raw['body_condition_score'] ?? null;
    if ($bcs !== null && (!filter_var($bcs, FILTER_VALIDATE_INT) || (int)$bcs < 1 || (int)$bcs > 9)) return ['value' => null, 'error' => 'Body Condition Score must be between 1 and 9.'];
    $purpose = $raw['purpose'] ?? [];
    if (!is_array($purpose) || count(array_diff(array_keys(array_filter($purpose)), array_keys($definition['purposes']))) > 0) return ['value' => null, 'error' => 'Invalid consultation purpose.'];
    $findings = $raw['findings'] ?? [];
    if (!is_array($findings)) return ['value' => null, 'error' => 'Invalid examination findings.'];
    $cleanFindings = [];
    foreach ($findings as $systemKey => $system) {
        if (!isset($definition['systems'][$systemKey]) || !is_array($system)) return ['value' => null, 'error' => 'Invalid examination system.'];
        $allowed = $definition['systems'][$systemKey]['items'];
        $items = $system['items'] ?? [];
        if (!is_array($items) || count(array_diff(array_keys($items), array_keys($allowed))) > 0) return ['value' => null, 'error' => 'Invalid examination item.'];
        $other = trim(strip_tags((string)($system['other'] ?? '')));
        if (mb_strlen($other) > 120) return ['value' => null, 'error' => 'Examination Other text must not exceed 120 characters.'];
        $cleanFindings[$systemKey] = ['normal' => !empty($system['normal']), 'items' => array_values(array_filter($items, 'is_scalar')), 'other' => $other];
    }
    $diagnosis = trim(strip_tags((string)($raw['diagnosis'] ?? '')));
    $recommendations = trim(strip_tags((string)($raw['recommendations'] ?? '')));
    if (mb_strlen($diagnosis) > 500) return ['value' => null, 'error' => 'Diagnosis must not exceed 500 characters.'];
    if (mb_strlen($recommendations) > 500) return ['value' => null, 'error' => 'Recommendations must not exceed 500 characters.'];
    $value = ['weight_status' => $weight, 'body_condition_score' => $bcs === null ? null : (int)$bcs, 'purpose' => array_values(array_keys(array_filter($purpose))), 'findings' => $cleanFindings, 'diagnosis' => $diagnosis, 'recommendations' => $recommendations];
    $hasData = $value['weight_status'] !== null || $value['body_condition_score'] !== null || $value['purpose'] || $value['findings'] || $value['diagnosis'] !== '' || $value['recommendations'] !== '';
    return ['value' => $hasData ? $value : null, 'error' => null];
}
