<?php
$appConfigFile = __DIR__ . '/app_config.php';
if (file_exists($appConfigFile)) {
    require_once $appConfigFile;
}
$appTimezone = defined('APP_TIMEZONE') ? APP_TIMEZONE : (getenv('APP_TIMEZONE') ?: 'Asia/Manila');
if (!date_default_timezone_set($appTimezone)) {
    error_log('Invalid APP_TIMEZONE: ' . $appTimezone . '; using Asia/Manila.');
    date_default_timezone_set('Asia/Manila');
}

if ((defined('APP_ENV') && APP_ENV === 'production') || (getenv('APP_ENV') === 'production')) {
    ini_set('display_errors', '0');
}

if (session_status() === PHP_SESSION_NONE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)
        || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https')
        || (!empty($_SERVER['HTTP_X_FORWARDED_SSL']) && strtolower($_SERVER['HTTP_X_FORWARDED_SSL']) === 'on');
    $currentParams = session_get_cookie_params();
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => $currentParams['domain'] ?? '',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_start();
}

header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Referrer-Policy: strict-origin-when-cross-origin");

if (isset($_SESSION['user_id'])) {
    $now = time();
    $idleLimit = 1800;
    $maxLifetime = 28800;

    if (isset($_SESSION['last_activity']) && ($now - (int)$_SESSION['last_activity']) > $idleLimit) {
        if (file_exists(__DIR__ . '/db_connection.php')) {
            require_once __DIR__ . '/db_connection.php';
            if (isset($conn) && $conn instanceof mysqli && !$conn->connect_error) {
                $uid = (int)$_SESSION['user_id'];
                $presence = $conn->prepare("UPDATE users SET Is_Online = 0, Last_Activity = NULL WHERE User_ID = ?");
                if ($presence) {
                    $presence->bind_param("i", $uid);
                    $presence->execute();
                    $presence->close();
                }
            }
        }
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
        http_response_code(401);
        echo json_encode(["status" => "timeout", "success" => false, "message" => "Session expired due to inactivity. Please log in again.", "code" => "SESSION_EXPIRED"]);
        exit();
    }

    if (isset($_SESSION['created_time']) && ($now - (int)$_SESSION['created_time']) > $maxLifetime) {
        if (file_exists(__DIR__ . '/db_connection.php')) {
            require_once __DIR__ . '/db_connection.php';
            if (isset($conn) && $conn instanceof mysqli && !$conn->connect_error) {
                $uid = (int)$_SESSION['user_id'];
                $presence = $conn->prepare("UPDATE users SET Is_Online = 0, Last_Activity = NULL WHERE User_ID = ?");
                if ($presence) {
                    $presence->bind_param("i", $uid);
                    $presence->execute();
                    $presence->close();
                }
            }
        }
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
        http_response_code(401);
        echo json_encode(["status" => "timeout", "success" => false, "message" => "Session maximum lifetime reached. Please log in again.", "code" => "SESSION_EXPIRED"]);
        exit();
    }

    $isPassivePoll = (isset($_GET['touch']) && (string)$_GET['touch'] === '0')
        || (isset($_GET['is_poll']) && (string)$_GET['is_poll'] === '1')
        || (isset($_SERVER['HTTP_X_BACKGROUND_POLL']) && $_SERVER['HTTP_X_BACKGROUND_POLL'] === '1');
    if (!$isPassivePoll) {
        $_SESSION['last_activity'] = $now;
    }
    if (!isset($_SESSION['created_time'])) {
        $_SESSION['created_time'] = $now;
    }
}

if (!function_exists('getCsrfToken')) {
    function getCsrfToken() {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
}

if (!function_exists('validateCsrfToken')) {
    function validateCsrfToken($token) {
        if (!isset($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
            return false;
        }
        if (!is_string($token) || empty($token)) {
            return false;
        }
        return hash_equals($_SESSION['csrf_token'], $token);
    }
}

if (!function_exists('requireCsrf')) {
    function requireCsrf() {
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        if (!in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
            return;
        }
        $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? null;
        if (!$token && isset($_POST['csrf_token'])) {
            $token = $_POST['csrf_token'];
        }
        if (!$token) {
            $raw = file_get_contents('php://input');
            if ($raw) {
                $decoded = json_decode($raw, true);
                if (is_array($decoded) && isset($decoded['csrf_token'])) {
                    $token = $decoded['csrf_token'];
                }
            }
        }
        if (!$token || !validateCsrfToken($token)) {
            http_response_code(403);
            header("Content-Type: application/json; charset=UTF-8");
            echo json_encode(["status" => "error", "success" => false, "message" => "Invalid or missing CSRF token."]);
            exit();
        }
    }
}

if (!function_exists('validateStrongPassword')) {
    function validateStrongPassword($password) {
        if (!is_string($password) || strlen($password) < 8) {
            return false;
        }
        if (!preg_match('/[A-Z]/', $password)) {
            return false;
        }
        if (!preg_match('/[a-z]/', $password)) {
            return false;
        }
        if (!preg_match('/[0-9]/', $password)) {
            return false;
        }
        if (!preg_match('/[\W_]/', $password)) {
            return false;
        }
        return true;
    }
}
