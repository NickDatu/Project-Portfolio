CREATE TABLE species (
    Species_ID INT PRIMARY KEY,
    Species_Name VARCHAR(50) NOT NULL,
    Status ENUM('active','inactive') NOT NULL DEFAULT 'active'
);

CREATE TABLE owners (
    Owner_ID INT PRIMARY KEY,
    Status ENUM('active','inactive') NOT NULL DEFAULT 'active'
);

CREATE TABLE pets (
    Pet_ID INT PRIMARY KEY,
    Owner_ID INT NOT NULL,
    Species_ID INT NOT NULL,
    Name VARCHAR(50) NOT NULL,
    Status ENUM('active','deceased','transferred','archived') NOT NULL DEFAULT 'active'
);

CREATE TABLE services (
    Service_ID INT PRIMARY KEY,
    Service_Name VARCHAR(100) NOT NULL
);

CREATE TABLE calendar_events (
    Event_ID INT PRIMARY KEY,
    Title VARCHAR(150) NOT NULL,
    Event_Type ENUM('SpayNeuter','General','Holiday') NOT NULL
);

CREATE TABLE appointments (
    Appointment_ID INT PRIMARY KEY,
    Owner_ID INT NOT NULL,
    Pet_ID INT NOT NULL,
    Service_ID INT NULL,
    Appointment_Date DATETIME NOT NULL,
    Status ENUM('Pending','Confirmed','Checked In','In Consultation','Completed','No Show','Cancelled') NOT NULL,
    Event_ID INT NULL
);

CREATE TABLE vaccinations (
    Vaccination_ID INT PRIMARY KEY,
    Pet_ID INT NOT NULL,
    Vaccine_Name VARCHAR(100) NOT NULL,
    Date_Administered DATE NOT NULL
);

INSERT INTO species VALUES
    (1, 'Dog', 'active'), (2, 'Cat', 'active');

INSERT INTO owners VALUES
    (1, 'active'), (2, 'active'), (3, 'inactive');

INSERT INTO pets VALUES
    (1, 1, 1, 'Alpha', 'active'),
    (2, 1, 2, 'Beta', 'active'),
    (3, 2, 1, 'Gamma', 'active'),
    (4, 2, 1, 'Deleted Pet', 'archived');

INSERT INTO services VALUES
    (1, 'Spay & Neuter'), (2, 'Anti-Rabies Vaccination'), (3, 'General Checkup');

INSERT INTO calendar_events VALUES
    (1, 'Free Spay & Neuter', 'SpayNeuter');

INSERT INTO appointments (Appointment_ID, Owner_ID, Pet_ID, Service_ID, Appointment_Date, Status) VALUES
    (1, 1, 1, 1, '2026-10-03 00:00:00', 'Completed'),
    (2, 1, 1, 1, '2026-10-03 09:00:00', 'Confirmed'),
    (3, 1, 1, 1, '2026-10-04 10:00:00', 'No Show'),
    (4, 1, 1, 1, '2026-10-04 11:00:00', 'Cancelled'),
    (5, 1, 1, 1, '2026-10-05 10:00:00', 'Pending'),
    (6, 1, 1, 1, '2026-10-06 10:00:00', 'Checked In'),
    (7, 1, 1, 1, '2026-10-07 10:00:00', 'In Consultation'),
    (8, 1, 1, 1, '2026-10-08 10:00:00', 'Completed'),
    (9, 1, 1, 1, '2026-10-09 23:59:00', 'Confirmed'),
    (10, 2, 3, 2, '2026-10-03 12:00:00', 'Completed'),
    (11, 2, 3, 2, '2026-10-04 12:00:00', 'Confirmed'),
    (12, 2, 3, 2, '2026-10-05 12:00:00', 'No Show'),
    (13, 2, 3, 2, '2026-10-06 12:00:00', 'Cancelled'),
    (14, 2, 3, 2, '2026-10-07 12:00:00', 'Pending'),
    (15, 2, 3, 2, '2026-10-08 12:00:00', 'Completed'),
    (16, 1, 2, 3, '2026-10-03 13:00:00', 'Completed'),
    (17, 1, 2, 3, '2026-10-05 13:00:00', 'Confirmed'),
    (18, 1, 2, 3, '2026-10-09 09:00:00', 'No Show'),
    (19, 1, 2, 3, '2026-10-09 10:00:00', 'Pending'),
    (20, 2, 4, 1, '2026-10-09 11:00:00', 'Completed');

INSERT INTO vaccinations VALUES
    (1, 1, 'Anti-Rabies Vaccination', '2026-10-03'),
    (2, 3, 'Anti-Rabies Vaccination', '2026-10-09'),
    (3, 4, 'Anti-Rabies Vaccination', '2026-10-09'),
    (4, 1, '5-in-1 Vaccine', '2026-10-09');
