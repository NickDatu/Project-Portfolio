<?php
declare(strict_types=1);

date_default_timezone_set('Asia/Manila');
ini_set('session.save_path', sys_get_temp_dir());
define('CITY_VET_REPORTS_TEST', true);
require_once __DIR__ . '/../api/reports/get_stats.php';

$host = getenv('DB_HOST') ?: '127.0.0.1';
$user = getenv('DB_USER') ?: 'root';
$pass = getenv('DB_PASS') !== false ? (string)getenv('DB_PASS') : '';
$database = 'city_vet_reports_test_' . getmypid();
$admin = new mysqli($host, $user, $pass);
$admin->set_charset('utf8mb4');
$admin->query("CREATE DATABASE IF NOT EXISTS {$database}");
$conn = new mysqli($host, $user, $pass, $database);
$conn->set_charset('utf8mb4');
$fixture = file_get_contents(__DIR__ . '/reports_fixture.sql');
if ($fixture === false || !$conn->multi_query($fixture)) throw new RuntimeException('Unable to load the reports fixture.');
while ($conn->more_results() && $conn->next_result()) {}

$fixedNow = new DateTimeImmutable('2026-10-09 12:00:00', new DateTimeZone('Asia/Manila'));
$failures = [];

function checkValue(string $name, $actual, $expected): void
{
    global $failures;
    if ($actual !== $expected) $failures[] = $name . ' expected ' . var_export($expected, true) . ', got ' . var_export($actual, true);
}

function checkReport(string $name, array $input, array $expected): void
{
    global $conn, $fixedNow;
    $report = cityVetBuildReport($conn, $input, $fixedNow);
    checkValue($name . ' appointments', $report['kpis']['appointments'], $expected['appointments']);
    checkValue($name . ' clients', $report['kpis']['clients'], $expected['clients']);
    checkValue($name . ' rate', $report['kpis']['no_show_rate'], $expected['rate']);
    checkValue($name . ' rabies doses', $report['rabies_doses']['total'], $expected['rabies']);
    checkValue($name . ' range start', $report['active_filters']['start_date'], $expected['start']);
    checkValue($name . ' range end', $report['active_filters']['end_date'], $expected['end']);
    checkValue($name . ' status reconciliation', $report['reconciliation']['status_counts_ok'], true);
    checkValue($name . ' trend reconciliation', $report['reconciliation']['trend_ok'], true);
    checkValue($name . ' heatmap reconciliation', $report['reconciliation']['heatmap_ok'], true);
    checkValue($name . ' all reconciliation', $report['reconciliation']['all_ok'], true);
}

try {
    // Expected values are hand-counted from reports_fixture.sql.
    checkReport('today', ['range' => 'today'], ['appointments' => 3, 'clients' => 1, 'rate' => 100.0, 'rabies' => 1, 'start' => '2026-10-09', 'end' => '2026-10-09']);
    checkReport('last 7 days', ['range' => 'last_7_days'], ['appointments' => 19, 'clients' => 2, 'rate' => 50.0, 'rabies' => 2, 'start' => '2026-10-03', 'end' => '2026-10-09']);
    checkReport('this month', ['range' => 'this_month'], ['appointments' => 19, 'clients' => 2, 'rate' => 50.0, 'rabies' => 2, 'start' => '2026-10-01', 'end' => '2026-10-31']);
    checkReport('overall', ['range' => 'overall'], ['appointments' => 19, 'clients' => 2, 'rate' => 50.0, 'rabies' => 2, 'start' => '2026-10-03', 'end' => '2026-10-09']);
    checkReport('custom boundary', ['range' => 'custom', 'start_date' => '2026-10-03', 'end_date' => '2026-10-09'], ['appointments' => 19, 'clients' => 2, 'rate' => 50.0, 'rabies' => 2, 'start' => '2026-10-03', 'end' => '2026-10-09']);
    checkReport('zero records', ['range' => 'custom', 'start_date' => '2025-01-01', 'end_date' => '2025-01-07'], ['appointments' => 0, 'clients' => 0, 'rate' => 0, 'rabies' => 0, 'start' => '2025-01-01', 'end' => '2025-01-07']);

    $lastSeven = cityVetBuildReport($conn, ['range' => 'last_7_days'], $fixedNow);
    checkValue('spay registered', $lastSeven['programs']['spay_neuter']['registered'], 9);
    checkValue('spay outcomes', [$lastSeven['programs']['spay_neuter']['served'], $lastSeven['programs']['spay_neuter']['scheduled'], $lastSeven['programs']['spay_neuter']['non_appearance'], $lastSeven['programs']['spay_neuter']['cancelled']], [2, 5, 1, 1]);
    checkValue('rabies registered', $lastSeven['programs']['rabies']['registered'], 6);
    checkValue('rabies outcomes', [$lastSeven['programs']['rabies']['served'], $lastSeven['programs']['rabies']['scheduled'], $lastSeven['programs']['rabies']['non_appearance'], $lastSeven['programs']['rabies']['cancelled']], [2, 2, 1, 1]);
    checkValue('trend sum', array_sum(array_column($lastSeven['trend']['points'], 'total')), 19);
    checkValue('heatmap sum', $lastSeven['heatmap']['total_non_cancelled'], 17);
    $reportsPage = file_get_contents(__DIR__ . '/../views/admin/reports.html');
    checkValue('CSV uses shared response fields', str_contains($reportsPage, 'data.kpis.appointments') && str_contains($reportsPage, 'data.programs') && str_contains($reportsPage, 'function csvCell'), true);

    if ($failures) {
        echo "FAIL\n" . implode("\n", $failures) . "\n";
        exit(1);
    }
    echo "PASS: today, last 7 days, this month, overall, custom boundary, zero-record range\n";
    echo "PASS: program outcomes, trend sum, heatmap sum, reconciliation blocks, shared CSV fields\n";
} finally {
    $conn->close();
    $admin->query("DROP DATABASE IF EXISTS {$database}");
    $admin->close();
}
