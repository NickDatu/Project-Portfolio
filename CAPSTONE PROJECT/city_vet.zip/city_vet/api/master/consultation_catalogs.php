<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';
require_once '../system/audit_helper.php';

header('Content-Type: application/json; charset=UTF-8');

set_exception_handler(function (Throwable $e) {
    error_log('consultation_catalogs.php unhandled: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'The consultation catalog service is temporarily unavailable.']);
    exit();
});

cityVetEnsureConsultationCatalogSchema($conn);

function consultationCatalogDefinition($type): ?array {
    $catalogs = [
        'treatment' => ['table' => 'treatment_catalog', 'id' => 'Treatment_ID', 'name' => 'Treatment_Name'],
        'medicine' => ['table' => 'medicine_catalog', 'id' => 'Medicine_ID', 'name' => 'Medicine_Name']
    ];
    return is_string($type) ? ($catalogs[$type] ?? null) : null;
}

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Access denied.']);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'GET') {
    $definition = consultationCatalogDefinition($_GET['type'] ?? '');
    if (!$definition) {
        http_response_code(422);
        echo json_encode(['status' => 'error', 'message' => 'Invalid catalog type.']);
        exit();
    }

    $includeInactive = isset($_GET['all']) && $_GET['all'] === '1' && (int)$_SESSION['role_id'] === 1;
    $where = $includeInactive ? '' : "WHERE Status = 'active'";
    $result = $conn->query("SELECT {$definition['id']} AS Item_ID, {$definition['name']} AS Item_Name, Status FROM {$definition['table']} {$where} ORDER BY {$definition['name']} ASC");
    $items = [];
    while ($row = $result->fetch_assoc()) {
        $items[] = $row;
    }
    echo json_encode(['status' => 'success', 'items' => $items]);
    exit();
}

if ($method !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
    exit();
}

if ((int)$_SESSION['role_id'] !== 1) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Administrators only.']);
    exit();
}

requireCsrf();
$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid request data.']);
    exit();
}

$definition = consultationCatalogDefinition($input['type'] ?? '');
$action = $input['action'] ?? '';
if (!$definition || !in_array($action, ['create', 'rename', 'disable'], true)) {
    http_response_code(422);
    echo json_encode(['status' => 'error', 'message' => 'Invalid catalog action.']);
    exit();
}

$itemId = (int)($input['item_id'] ?? 0);
if ($action === 'disable') {
    if ($itemId <= 0) {
        http_response_code(422);
        echo json_encode(['status' => 'error', 'message' => 'Catalog item is required.']);
        exit();
    }

    $stmt = $conn->prepare("UPDATE {$definition['table']} SET Status = 'inactive' WHERE {$definition['id']} = ? AND Status = 'active'");
    $stmt->bind_param('i', $itemId);
    $ok = $stmt->execute() && $stmt->affected_rows === 1;
    $stmt->close();
    if (!$ok) {
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => 'Active catalog item not found.']);
        exit();
    }
    auditLog($conn, (int)$_SESSION['user_id'], 'Disable Consultation Catalog Item', $definition['table'], $itemId);
    echo json_encode(['status' => 'success', 'message' => 'Catalog item disabled.']);
    exit();
}

$name = trim(strip_tags((string)($input['name'] ?? '')));
$name = preg_replace('/[\x00-\x1F\x7F]/u', '', $name);
if ($name === '' || mb_strlen($name) > 120) {
    http_response_code(422);
    echo json_encode(['status' => 'error', 'message' => 'Name must be between 1 and 120 characters.']);
    exit();
}

$duplicate = $conn->prepare("SELECT {$definition['id']} FROM {$definition['table']} WHERE {$definition['name']} = ? AND (? = 0 OR {$definition['id']} != ?) LIMIT 1");
$duplicate->bind_param('sii', $name, $itemId, $itemId);
$duplicate->execute();
$isDuplicate = (bool)$duplicate->get_result()->fetch_assoc();
$duplicate->close();
if ($isDuplicate) {
    http_response_code(409);
    echo json_encode(['status' => 'error', 'message' => 'A catalog item with this name already exists.']);
    exit();
}

if ($action === 'create') {
    $stmt = $conn->prepare("INSERT INTO {$definition['table']} ({$definition['name']}) VALUES (?)");
    $stmt->bind_param('s', $name);
    if (!$stmt->execute()) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Unable to create catalog item.']);
        exit();
    }
    $itemId = (int)$conn->insert_id;
    $stmt->close();
    auditLog($conn, (int)$_SESSION['user_id'], 'Create Consultation Catalog Item', $definition['table'], $itemId, ['metadata' => ['name' => $name]]);
    echo json_encode(['status' => 'success', 'message' => 'Catalog item created.']);
    exit();
}

if ($itemId <= 0) {
    http_response_code(422);
    echo json_encode(['status' => 'error', 'message' => 'Catalog item is required.']);
    exit();
}

$stmt = $conn->prepare("UPDATE {$definition['table']} SET {$definition['name']} = ? WHERE {$definition['id']} = ? AND Status = 'active'");
$stmt->bind_param('si', $name, $itemId);
if (!$stmt->execute() || $stmt->affected_rows < 0) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Unable to rename catalog item.']);
    exit();
}
$exists = $stmt->affected_rows === 1;
$stmt->close();
if (!$exists) {
    $check = $conn->prepare("SELECT 1 FROM {$definition['table']} WHERE {$definition['id']} = ? AND Status = 'active'");
    $check->bind_param('i', $itemId);
    $check->execute();
    $exists = (bool)$check->get_result()->fetch_row();
    $check->close();
}
if (!$exists) {
    http_response_code(404);
    echo json_encode(['status' => 'error', 'message' => 'Active catalog item not found.']);
    exit();
}

auditLog($conn, (int)$_SESSION['user_id'], 'Rename Consultation Catalog Item', $definition['table'], $itemId, ['metadata' => ['name' => $name]]);
echo json_encode(['status' => 'success', 'message' => 'Catalog item renamed.']);
