<?php
require_once '../../config/session.php';
require_once '../../config/consultation_template.php';
header('Content-Type: application/json; charset=UTF-8');
if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) { http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access denied.']); exit; }
echo json_encode(['status' => 'success', 'template' => cityVetConsultationTemplateDefinition()]);
