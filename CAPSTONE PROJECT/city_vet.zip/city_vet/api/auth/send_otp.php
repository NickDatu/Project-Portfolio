<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../notifications/notify.php';

header("Content-Type: application/json; charset=UTF-8");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Referrer-Policy: strict-origin-when-cross-origin");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Method not allowed."]);
    exit();
}

requireCsrf();

$input = json_decode(file_get_contents("php://input"), true);
if (!is_array($input)) {
    $input = $_POST;
}

$email = trim((string)($input['email'] ?? ''));
$purpose = trim((string)($input['purpose'] ?? ''));

$allowedPurposes = ['password_reset', 'register'];
if (!in_array($purpose, $allowedPurposes, true)) {
    http_response_code(422);
    echo json_encode(["status" => "error", "message" => "Invalid OTP purpose specified."]);
    exit();
}

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(422);
    echo json_encode(["status" => "error", "message" => "Please enter a valid email address."]);
    exit();
}

$emailLower = strtolower($email);


if ($purpose === 'password_reset') {
    $userStmt = $conn->prepare("SELECT User_ID, Status FROM users WHERE LOWER(Email) = ? LIMIT 1");
    $userStmt->bind_param("s", $emailLower);
    $userStmt->execute();
    $userRow = $userStmt->get_result()->fetch_assoc();
    $userStmt->close();

    if (!$userRow) {
        http_response_code(404);
        echo json_encode(["status" => "error", "message" => "No account found with this email address."]);
        exit();
    }

    if (in_array(strtolower($userRow['Status'] ?? ''), ['inactive', 'banned'], true)) {
        http_response_code(403);
        echo json_encode(["status" => "error", "message" => "Warning: Your account is deactivated. Please visit the City Vet office."]);
        exit();
    }
} elseif ($purpose === 'register') {
    $regStmt = $conn->prepare("SELECT User_ID FROM users WHERE LOWER(Email) = ? LIMIT 1");
    $regStmt->bind_param("s", $emailLower);
    $regStmt->execute();
    $exists = $regStmt->get_result()->num_rows > 0;
    $regStmt->close();

    if ($exists) {
        http_response_code(422);
        echo json_encode(["status" => "error", "message" => "This email address is already registered."]);
        exit();
    }
}


$cdStmt = $conn->prepare("SELECT UNIX_TIMESTAMP(Created_At) AS created_ts FROM otp_codes WHERE LOWER(Email) = ? AND Purpose = ? AND Created_At > DATE_SUB(NOW(), INTERVAL 60 SECOND) ORDER BY OTP_ID DESC LIMIT 1");
$cdStmt->bind_param("ss", $emailLower, $purpose);
$cdStmt->execute();
$cdRow = $cdStmt->get_result()->fetch_assoc();
$cdStmt->close();

if ($cdRow) {
    $elapsed = time() - (int)$cdRow['created_ts'];
    $remaining = max(1, 60 - $elapsed);
    http_response_code(429);
    echo json_encode([
        "status" => "error",
        "message" => "Please wait {$remaining} seconds before requesting a new code.",
        "cooldown_remaining" => $remaining
    ]);
    exit();
}


$plainOtp = sprintf("%06d", random_int(0, 999999));
$codeHash = password_hash($plainOtp, PASSWORD_DEFAULT);
$expiresAt = date('Y-m-d H:i:s', time() + 300); 


$invalidateStmt = $conn->prepare("UPDATE otp_codes SET Used_At = NOW() WHERE LOWER(Email) = ? AND Purpose = ? AND Used_At IS NULL");
$invalidateStmt->bind_param("ss", $emailLower, $purpose);
$invalidateStmt->execute();
$invalidateStmt->close();


$insStmt = $conn->prepare("INSERT INTO otp_codes (Purpose, Email, Code_Hash, Expires_At, Attempts, Created_At) VALUES (?, ?, ?, ?, 0, NOW())");
$insStmt->bind_param("ssss", $purpose, $emailLower, $codeHash, $expiresAt);

if (!$insStmt->execute()) {
    $insStmt->close();
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Unable to generate verification code. Please try again."]);
    exit();
}
$insStmt->close();


$purposeLabel = $purpose === 'password_reset' ? 'password reset' : 'account registration';
$emailResult = sendResendEmail(
    $emailLower,
    'Your City Vet verification code',
    "Your City Vet {$purposeLabel} verification code is {$plainOtp}. This code expires in 5 minutes.",
    '<p>Your City Vet verification code is:</p><p style="font-size:28px;font-weight:700;letter-spacing:6px">' . htmlspecialchars($plainOtp, ENT_QUOTES, 'UTF-8') . '</p><p>This code expires in 5 minutes.</p>'
);

if (!$emailResult['sent']) {
    $failStmt = $conn->prepare("UPDATE otp_codes SET Used_At = NOW() WHERE LOWER(Email) = ? AND Purpose = ? AND Used_At IS NULL");
    $failStmt->bind_param("ss", $emailLower, $purpose);
    $failStmt->execute();
    $failStmt->close();
    http_response_code(502);
    echo json_encode(["status" => "error", "message" => "Unable to send the verification email. Please configure the email account and try again."]);
    exit();
}


echo json_encode([
    "status" => "success",
    "message" => "A 6-digit verification code has been sent. Please check your inbox.",
    "cooldown" => 60
]);
