<?php
header("Content-Type: application/json; charset=UTF-8");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Referrer-Policy: strict-origin-when-cross-origin");

require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';
require_once '../notifications/notify.php';
require_once '../system/audit_helper.php';

cityVetEnsureEventBarangaySchema($conn);
cityVetEnsurePanelRevisionSchema($conn);

requireCsrf();

$data = json_decode(file_get_contents("php://input"), true);
if (is_null($data)) { $data = $_POST; }

if (empty($data['email']) || empty($data['password']) || empty($data['fname']) || empty($data['lname'])) {
    echo json_encode(["status" => "error", "message" => "Please fill in all required fields."]);
    exit();
}

if (($data['password'] ?? '') !== ($data['confirm_password'] ?? '')) {
    echo json_encode(["status" => "error", "message" => "Password confirmation does not match."]);
    exit();
}

// Staff and Administrators may register an owner on the client's behalf from
// their protected walk-in/owner-management screens. Public registration must
// still include the privacy consent.
$isStaffOrAdminWalkInRegistration = in_array((int)($_SESSION['role_id'] ?? 0), [1, 4], true) && !empty($data['walk_in']);
if (!$isStaffOrAdminWalkInRegistration) {
    $registrationEmail = strtolower(trim((string)$data['email']));
    $verifiedEmail = strtolower(trim((string)($_SESSION['register_verified_email'] ?? '')));
    $verifiedExpires = (int)($_SESSION['register_verified_expires'] ?? 0);
    if ($verifiedEmail === '' || $verifiedEmail !== $registrationEmail || $verifiedExpires < time()) {
        echo json_encode(["status" => "error", "message" => "Please verify your email address with the OTP before registering."]);
        exit();
    }
}
if (empty($data['privacy_consent']) && !$isStaffOrAdminWalkInRegistration) {
    echo json_encode(["status" => "error", "message" => "Please agree to the Data Privacy Consent before registering."]);
    exit();
}

$password = (string)($data['password'] ?? '');
if (!validateStrongPassword($password)) {
    echo json_encode([
        "status" => "error",
        "message" => "Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character."
    ]);
    exit();
}

$check = $conn->prepare("SELECT User_ID FROM users WHERE Email = ?");
$check->bind_param("s", $data['email']); 
$check->execute();
if ($check->get_result()->num_rows > 0) {
    echo json_encode(["status" => "error", "message" => "This Email is already registered."]);
    $check->close();
    $conn->close();
    exit();
}
$check->close();

$conn->begin_transaction();
try {
    $hashed_pass = password_hash($password, PASSWORD_BCRYPT);
    $role_id = 3;
    
    $stmt1 = $conn->prepare("INSERT INTO users (Role_ID, Username, Password_Hash, Email, Phone_number) VALUES (?, ?, ?, ?, ?)");
    $stmt1->bind_param("issss", $role_id, $data['email'], $hashed_pass, $data['email'], $data['phone']);
    if (!$stmt1->execute()) {
        throw new Exception("Failed to create user account.");
    }
    $new_user_id = $conn->insert_id;
    $stmt1->close();

    $barangay = trim($data['barangay'] ?? '');
    $full_address = ($data['address'] ?? '') . ", " . $barangay;
    $stmt2 = $conn->prepare("INSERT INTO owners (User_ID, First_name, Last_name, Contact_Number, Address, Barangay) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt2->bind_param("isssss", $new_user_id, $data['fname'], $data['lname'], $data['phone'], $full_address, $barangay);
    if (!$stmt2->execute()) {
        throw new Exception("Failed to create owner record.");
    }
    $ownerId = $conn->insert_id;
    $ownerCodeStmt = $conn->prepare("UPDATE owners SET Owner_Code = CONCAT('OWN-', YEAR(COALESCE(Registration_Date, NOW())), '-', LPAD(Owner_ID, 6, '0')) WHERE Owner_ID = ? AND (Owner_Code IS NULL OR Owner_Code = '')");
    $ownerCodeStmt->bind_param('i', $ownerId); $ownerCodeStmt->execute(); $ownerCodeStmt->close();
    $stmt2->close();

    $conn->commit();
    unset($_SESSION['register_verified_email'], $_SESSION['register_verified_expires']);

    auditLog($conn, $new_user_id, 'Register Account', 'users', $new_user_id);

    $welcomeMessage = "Welcome to City Vet, {$data['fname']}! Your account has been registered. You may now log in and manage your pets and appointments.";
    $safeFirstName = htmlspecialchars((string)$data['fname'], ENT_QUOTES, 'UTF-8');
    $welcomeHtml = '<!doctype html><html><body style="margin:0;background:#f1f5f9;font-family:Arial,Helvetica,sans-serif;color:#1f2937;line-height:1.6">'
        . '<div style="max-width:620px;margin:0 auto;padding:28px 14px">'
        . '<div style="background:#004d40;border-radius:18px 18px 0 0;padding:28px 30px;text-align:center;color:#ffffff">'
        . '<div style="display:inline-block;border:2px solid rgba(255,255,255,.35);border-radius:999px;padding:7px 15px;font-size:12px;letter-spacing:2px;font-weight:bold">CITY VET CDO</div>'
        . '<h1 style="margin:18px 0 4px;font-size:28px;line-height:1.2">Welcome to City Vet!</h1>'
        . '<p style="margin:0;color:#b2dfdb;font-size:14px">Your pet care journey starts here.</p></div>'
        . '<div style="background:#ffffff;border:1px solid #e2e8f0;border-top:0;border-radius:0 0 18px 18px;padding:30px">'
        . '<p style="font-size:18px;margin:0 0 14px">Hello, <strong>' . $safeFirstName . '</strong>!</p>'
        . '<p>We are happy to let you know that your City Vet account has been created successfully.</p>'
        . '<div style="background:#e0f2f1;border-left:4px solid #00796b;border-radius:10px;padding:16px 18px;margin:22px 0">'
        . '<strong style="color:#004d40">You are all set.</strong><br><span style="font-size:14px;color:#334155">You can now log in, register your pets, view upcoming schedules, and manage your appointments.</span></div>'
        . '<p style="margin-bottom:24px">Thank you for choosing City Vet CDO. We look forward to helping you keep your pets healthy, safe, and well cared for.</p>'
        . '<div style="text-align:center;margin:26px 0 8px"><a href="' . htmlspecialchars((defined('BASE_URL') ? BASE_URL : ''), ENT_QUOTES, 'UTF-8') . '/login.html" style="display:inline-block;background:#00796b;color:#ffffff;text-decoration:none;font-weight:bold;padding:12px 24px;border-radius:10px">Log in to City Vet</a></div>'
        . '<p style="font-size:12px;color:#64748b;text-align:center;margin:24px 0 0">This is an automated message from the City Veterinary Office. Please do not reply to this email.</p>'
        . '</div></div></body></html>';
    $emailResult = sendResendEmail($data['email'], "Welcome to City Vet, {$data['fname']}!", $welcomeMessage, $welcomeHtml);
    $smsResult = sendIprogSms($data['phone'], $welcomeMessage);

    echo json_encode([
        "status" => "success",
        "message" => "Registration Successful! Please Login.",
        "email_sent" => $emailResult["sent"] ?? false,
        "email_message" => $emailResult["message"] ?? "",
        "sms_sent" => $smsResult["sent"] ?? false,
        "sms_message" => $smsResult["message"] ?? ""
    ]);

} catch (Throwable $e) {
    try {
        $conn->rollback();
    } catch (Throwable $rbErr) {}
    error_log("Registration error: " . $e->getMessage());
    echo json_encode(["status" => "error", "message" => "Registration failed due to a server error. Please try again later."]);
}

$conn->close();
