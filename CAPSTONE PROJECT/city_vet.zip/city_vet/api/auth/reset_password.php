<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../system/audit_helper.php';

header("Content-Type: application/json; charset=UTF-8");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Referrer-Policy: strict-origin-when-cross-origin");

function writeAuditLog($conn, $userId, $action, $tableAffected, $recordId = 0) {
    return auditLog($conn, $userId, $action, $tableAffected, $recordId);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Method not allowed."]);
    exit();
}

requireCsrf();

$input = json_decode(file_get_contents("php://input"), true);
if (!is_array($input)) {
    $input = $_POST;
}

$email = trim((string)($input['email'] ?? ''));
$resetToken = trim((string)($input['reset_token'] ?? ''));
$newPassword = (string)($input['new_password'] ?? ($input['password'] ?? ''));
$confirmPassword = (string)($input['confirm_password'] ?? '');

$emailLower = strtolower($email);


$sessionAuthorized = !empty($_SESSION['password_reset_authorized']);
$sessionEmail = strtolower((string)($_SESSION['password_reset_email'] ?? ''));
$sessionToken = (string)($_SESSION['password_reset_token'] ?? '');
$sessionExpires = (int)($_SESSION['password_reset_expires'] ?? 0);

if (!$sessionAuthorized || $sessionEmail === '' || $sessionToken === '' || time() > $sessionExpires) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Your password reset session has expired or is unauthorized. Please verify your OTP again."]);
    exit();
}

if (!hash_equals($sessionToken, $resetToken) || $sessionEmail !== $emailLower) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Invalid reset authorization token."]);
    exit();
}

if ($newPassword === '') {
    http_response_code(422);
    echo json_encode(["status" => "error", "message" => "Please enter a new password."]);
    exit();
}

if ($newPassword !== $confirmPassword) {
    http_response_code(422);
    echo json_encode(["status" => "error", "message" => "Password confirmation does not match."]);
    exit();
}


if (!validateStrongPassword($newPassword)) {
    http_response_code(422);
    echo json_encode([
        "status" => "error",
        "message" => "Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character."
    ]);
    exit();
}


$userStmt = $conn->prepare("SELECT User_ID FROM users WHERE LOWER(Email) = ? LIMIT 1");
$userStmt->bind_param("s", $emailLower);
$userStmt->execute();
$userRow = $userStmt->get_result()->fetch_assoc();
$userStmt->close();

if (!$userRow) {
    http_response_code(404);
    echo json_encode(["status" => "error", "message" => "Account not found."]);
    exit();
}

$userId = (int)$userRow['User_ID'];
$newHash = password_hash($newPassword, PASSWORD_BCRYPT);

$upStmt = $conn->prepare("UPDATE users SET Password_Hash = ? WHERE User_ID = ?");
$upStmt->bind_param("si", $newHash, $userId);

if (!$upStmt->execute()) {
    $upStmt->close();
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Failed to update password. Please try again."]);
    exit();
}
$upStmt->close();

writeAuditLog($conn, $userId, 'Reset Password (OTP)', 'users', $userId);


unset(
    $_SESSION['password_reset_authorized'],
    $_SESSION['password_reset_email'],
    $_SESSION['password_reset_token'],
    $_SESSION['password_reset_expires']
);

echo json_encode([
    "status" => "success",
    "message" => "Password has been reset successfully. You can now log in with your new password."
]);

