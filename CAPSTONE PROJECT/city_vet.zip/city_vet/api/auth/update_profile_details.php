<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../system/audit_helper.php';

header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
    exit();
}
requireCsrf();

if (!isset($_SESSION['user_id'], $_SESSION['role_id'])) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Please log in again.']);
    exit();
}

$userId = (int)$_SESSION['user_id'];
$roleId = (int)$_SESSION['role_id'];
$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid profile data.']);
    exit();
}

$firstName = trim((string)($input['first_name'] ?? ''));
$lastName = trim((string)($input['last_name'] ?? ''));
$contact = preg_replace('/[\s\-()]/', '', trim((string)($input['contact_number'] ?? '')));
$address = trim((string)($input['address'] ?? ''));

if ($firstName === '' || $lastName === '' || strlen($firstName) > 100 || strlen($lastName) > 100) {
    http_response_code(422);
    echo json_encode(['status' => 'error', 'message' => 'First and last name are required and must be 100 characters or fewer.']);
    exit();
}
if ($roleId === 3 && ($contact === '' || strlen($contact) > 15 || !preg_match('/^\+?[0-9]{7,14}$/', $contact))) {
    http_response_code(422);
    echo json_encode(['status' => 'error', 'message' => 'Please provide a valid contact number (7-15 digits).']);
    exit();
}
if ($roleId === 3 && strlen($address) > 5000) {
    http_response_code(422);
    echo json_encode(['status' => 'error', 'message' => 'Address must be 5000 characters or fewer.']);
    exit();
}
if (!in_array($roleId, [1, 2, 3, 4], true)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'This account cannot edit profile details.']);
    exit();
}

$conn->begin_transaction();
try {
    if ($roleId === 3) {
        $check = $conn->prepare('SELECT Owner_ID FROM owners WHERE User_ID = ?');
        $check->bind_param('i', $userId);
        $check->execute();
        $ownerExists = $check->get_result()->num_rows > 0;
        $check->close();
        if (!$ownerExists) {
            throw new RuntimeException('Owner profile not found.');
        }
        $stmt = $conn->prepare('UPDATE owners SET First_name = ?, Last_name = ?, Contact_number = ?, Address = ? WHERE User_ID = ?');
        $stmt->bind_param('ssssi', $firstName, $lastName, $contact, $address, $userId);
        $stmt->execute();
        if ($stmt->affected_rows < 0) {
            throw new RuntimeException('Owner profile update failed.');
        }
        $stmt->close();

        $phoneStmt = $conn->prepare('UPDATE users SET Phone_number = ? WHERE User_ID = ?');
        $phoneStmt->bind_param('si', $contact, $userId);
        $phoneStmt->execute();
        $phoneStmt->close();
        $table = 'owners';
    } else {
        $stmt = $conn->prepare('UPDATE staff SET First_name = ?, Last_name = ? WHERE User_ID = ?');
        $stmt->bind_param('ssi', $firstName, $lastName, $userId);
        $stmt->execute();
        $updated = $stmt->affected_rows;
        $stmt->close();
        if ($updated === 0) {
            $check = $conn->prepare('SELECT Staff_ID FROM staff WHERE User_ID = ?');
            $check->bind_param('i', $userId);
            $check->execute();
            $exists = $check->get_result()->num_rows > 0;
            $check->close();
            if (!$exists) {
                $position = $roleId === 1 ? 'Administrator' : ($roleId === 2 ? 'Veterinarian' : 'Office Staff');
                $insert = $conn->prepare("INSERT INTO staff (User_ID, First_name, Last_name, Position, Status) VALUES (?, ?, ?, ?, 'active')");
                $insert->bind_param('isss', $userId, $firstName, $lastName, $position);
                $insert->execute();
                $insert->close();
            }
        }
        $table = 'staff';
    }

    if (!auditLog($conn, $userId, 'Update Profile Details', $table, $userId, [
        'event_type' => 'data_change',
        'outcome' => 'success',
        'metadata' => ['updated_fields' => $roleId === 3
            ? ['first_name', 'last_name', 'contact_number', 'address']
            : ['first_name', 'last_name']]
    ])) {
        throw new RuntimeException('Profile audit log could not be written.');
    }
    $conn->commit();
    echo json_encode(['status' => 'success', 'message' => 'Profile details updated.']);
} catch (Throwable $e) {
    $conn->rollback();
    error_log('update_profile_details.php: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Unable to save profile details.']);
}
