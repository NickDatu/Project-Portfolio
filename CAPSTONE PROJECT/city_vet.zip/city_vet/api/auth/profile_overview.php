<?php




require_once '../../config/session.php';
require_once '../../config/db_connection.php';
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');

if (!isset($_SESSION['user_id'], $_SESSION['role_id'])) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Please log in again.']);
    exit();
}
$userId = (int)$_SESSION['user_id'];
$roleId = (int)$_SESSION['role_id'];
$roleNames = [1 => 'Administrator', 2 => 'Veterinarian', 3 => 'Pet Owner', 4 => 'Office Staff'];

function pvOne(mysqli $conn, string $sql, string $types, array $params): array {
    $stmt = $conn->prepare($sql);
    if ($types !== '') $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ?: [];
}

try {
    $u = pvOne($conn, "SELECT Username, Email, Phone_number, Status, Created_At, Last_Activity FROM users WHERE User_ID = ?", 'i', [$userId]);
    $out = [
        'role_id'       => $roleId,
        'role_name'     => $roleNames[$roleId] ?? 'User',
        'username'      => $u['Username'] ?? '',
        'email'         => $u['Email'] ?? '',
        'phone'         => $u['Phone_number'] ?? '',
        'account_status'=> $u['Status'] ?? '',
        'member_since'  => $u['Created_At'] ?? null,
        'last_activity' => $u['Last_Activity'] ?? null,
        'details'       => [],
        'stats'         => [],
    ];

    if ($roleId === 3) {
        $o = pvOne($conn, "SELECT Owner_ID, First_name, Last_name, Contact_number, Address, Registration_Date FROM owners WHERE User_ID = ?", 'i', [$userId]);
        $ownerId = (int)($o['Owner_ID'] ?? 0);
        $out['full_name'] = trim(($o['First_name'] ?? '') . ' ' . ($o['Last_name'] ?? ''));
        $out['profile_fields'] = [
            'first_name' => $o['First_name'] ?? '',
            'last_name' => $o['Last_name'] ?? '',
            'contact_number' => $o['Contact_number'] ?? '',
            'address' => $o['Address'] ?? '',
        ];
        $out['details'] = [
            'Owner ID'      => $ownerId ? '#' . $ownerId : '',
            'Contact Number'=> $o['Contact_number'] ?? '',
            'Address'       => $o['Address'] ?? '',
        ];
        if (!empty($o['Registration_Date'])) $out['member_since'] = $o['Registration_Date'];

        $pets = pvOne($conn, "SELECT COUNT(*) c FROM pets WHERE Owner_ID = ? AND Status = 'active'", 'i', [$ownerId]);
        $a = pvOne($conn, "SELECT COUNT(*) total,
                SUM(Status='Pending') pending, SUM(Status='Confirmed') confirmed,
                SUM(Status='Checked In') checked_in, SUM(Status='In Consultation') in_consultation,
                SUM(Status='Completed') completed, SUM(Status='No Show') no_show,
                SUM(Status='Cancelled') cancelled
            FROM appointments WHERE Owner_ID = ?", 'i', [$ownerId]);
        $out['stats'] = [
            'Pets'        => (int)($pets['c'] ?? 0),
            'Appointments'=> (int)($a['total'] ?? 0),
            'Pending'     => (int)($a['pending'] ?? 0),
            'Confirmed'   => (int)($a['confirmed'] ?? 0),
            'Checked In'  => (int)($a['checked_in'] ?? 0),
            'In Consultation' => (int)($a['in_consultation'] ?? 0),
            'Completed'   => (int)($a['completed'] ?? 0),
            'Cancelled'   => (int)($a['cancelled'] ?? 0),
            'No Show'     => (int)($a['no_show'] ?? 0),
        ];
    } else {
        $s = pvOne($conn, "SELECT First_name, Last_name, Position, Status FROM staff WHERE User_ID = ?", 'i', [$userId]);
        $out['full_name'] = trim(($s['First_name'] ?? '') . ' ' . ($s['Last_name'] ?? ''));
        $out['profile_fields'] = [
            'first_name' => $s['First_name'] ?? '',
            'last_name' => $s['Last_name'] ?? '',
        ];
        $out['details'] = [
            'Position'     => $s['Position'] ?? ($roleNames[$roleId] ?? ''),
            'Staff Status' => $s['Status'] ?? '',
        ];
        $log = pvOne($conn, "SELECT COUNT(*) total,
                SUM(Timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)) last30,
                SUM(DATE(Timestamp) = CURDATE()) today
            FROM audit_logs WHERE User_ID = ? AND Outcome = 'success'", 'i', [$userId]);
        $out['stats'] = [
            'Actions Today'   => (int)($log['today'] ?? 0),
            'Actions (30 days)' => (int)($log['last30'] ?? 0),
            'Actions (All time)' => (int)($log['total'] ?? 0),
        ];
    }
    echo json_encode(['status' => 'success', 'data' => $out]);
} catch (Throwable $e) {
    error_log('profile_overview.php: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Unable to load profile details.']);
}
