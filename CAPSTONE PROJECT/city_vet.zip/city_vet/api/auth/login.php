<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../system/audit_helper.php';

header("Content-Type: application/json; charset=UTF-8");
requireCsrf();

function writeAuditLog($conn, $userId, $action, $tableAffected, $recordId = 0) {
    return auditLog($conn, $userId, $action, $tableAffected, $recordId, ['event_type' => 'security']);
}

function recordFailedLogin($conn, $ip, $email, $maxAttempts, $windowSeconds, $lockoutSeconds) {
    $now = time();
    $stmt = $conn->prepare("SELECT id, failed_attempts, last_attempt FROM login_rate_limits WHERE ip_address = ? AND email = ? LIMIT 1");
    $stmt->bind_param("ss", $ip, $email);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($row) {
        $attempts = (int)$row['failed_attempts'];
        $last = (int)$row['last_attempt'];
        if (($now - $last) > $windowSeconds) {
            $attempts = 1;
        } else {
            $attempts++;
        }
        $lockedUntil = ($attempts >= $maxAttempts) ? ($now + $lockoutSeconds) : 0;
        $upd = $conn->prepare("UPDATE login_rate_limits SET failed_attempts = ?, last_attempt = ?, locked_until = ? WHERE id = ?");
        $rid = (int)$row['id'];
        $upd->bind_param("iiii", $attempts, $now, $lockedUntil, $rid);
        $upd->execute();
        $upd->close();
    } else {
        $attempts = 1;
        $lockedUntil = 0;
        $ins = $conn->prepare("INSERT INTO login_rate_limits (ip_address, email, failed_attempts, last_attempt, locked_until) VALUES (?, ?, ?, ?, ?)");
        $ins->bind_param("ssiii", $ip, $email, $attempts, $now, $lockedUntil);
        $ins->execute();
        $ins->close();
    }
}

$conn->query("CREATE TABLE IF NOT EXISTS login_rate_limits (id INT AUTO_INCREMENT PRIMARY KEY, ip_address VARCHAR(45) NOT NULL, email VARCHAR(255) NOT NULL, failed_attempts INT NOT NULL DEFAULT 1, last_attempt INT NOT NULL, locked_until INT NOT NULL DEFAULT 0, UNIQUE KEY idx_ip_email (ip_address, email), INDEX idx_last_attempt (last_attempt)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

if (mt_rand(1, 20) === 1) {
    $prune = $conn->prepare("DELETE FROM login_rate_limits WHERE last_attempt < ?");
    if ($prune) {
        $pruneThreshold = time() - 3600;
        $prune->bind_param("i", $pruneThreshold);
        $prune->execute();
        $prune->close();
    }
}

$clientIp = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

$data = json_decode(file_get_contents("php://input"), true);
if (is_null($data)) { $data = $_POST; }

$email = strtolower(trim((string)($data['email'] ?? '')));
$password = (string)($data['password'] ?? '');

$emptyEmail = '';
$checkIp = $conn->prepare("SELECT locked_until FROM login_rate_limits WHERE ip_address = ? AND email = '' LIMIT 1");
$checkIp->bind_param("s", $clientIp);
$checkIp->execute();
$ipRow = $checkIp->get_result()->fetch_assoc();
$checkIp->close();

if ($ipRow && (int)$ipRow['locked_until'] > time()) {
    $remainingSeconds = (int)$ipRow['locked_until'] - time();
    auditLog($conn, null, 'Login Rate Limited (IP)', 'sessions', 0, ['event_type' => 'security', 'outcome' => 'blocked']);
    echo json_encode(["status" => "error", "message" => "Too many failed login attempts from this network. Please wait " . $remainingSeconds . " seconds before trying again."]);
    exit();
}

if (!empty($email)) {
    $checkAcc = $conn->prepare("SELECT locked_until FROM login_rate_limits WHERE ip_address = ? AND email = ? LIMIT 1");
    $checkAcc->bind_param("ss", $clientIp, $email);
    $checkAcc->execute();
    $accRow = $checkAcc->get_result()->fetch_assoc();
    $checkAcc->close();

    if ($accRow && (int)$accRow['locked_until'] > time()) {
        $remainingSeconds = (int)$accRow['locked_until'] - time();
        auditLog($conn, null, 'Login Rate Limited (Account)', 'sessions', 0, ['event_type' => 'security', 'outcome' => 'blocked']);
        echo json_encode(["status" => "error", "message" => "Too many failed login attempts. Please wait " . $remainingSeconds . " seconds before trying again."]);
        exit();
    }
}

if (empty($email) || empty($password)) {
    auditLog($conn, null, 'Login Failed', 'sessions', 0, ['event_type' => 'security', 'outcome' => 'failure', 'metadata' => ['reason' => 'missing_credentials']]);
    echo json_encode(["status" => "error", "message" => "Please provide both email and password."]);
    exit();
}

$stmt = $conn->prepare("SELECT User_ID, Username, Password_Hash, Role_ID, Status FROM users WHERE LOWER(Email) = ? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
    
    if (password_verify($password, $user['Password_Hash'])) {
        if ($user['Status'] === 'inactive' || $user['Status'] === 'banned') {
            http_response_code(403);
            auditLog($conn, (int)$user['User_ID'], 'Login Rejected (Deactivated)', 'sessions', 0, [
                'event_type' => 'security',
                'outcome' => 'denied',
                'metadata' => ['reason' => 'account_deactivated', 'status' => $user['Status']]
            ]);
            echo json_encode([
                "status" => "error",
                "message" => "Warning: Your account is deactivated. Please visit the City Vet office."
            ]);
            $stmt->close();
            $conn->close();
            exit();
        }

        $clearAcc = $conn->prepare("DELETE FROM login_rate_limits WHERE ip_address = ? AND email = ?");
        $clearAcc->bind_param("ss", $clientIp, $email);
        $clearAcc->execute();
        $clearAcc->close();

        session_regenerate_id(true);

        $_SESSION['user_id'] = (int)$user['User_ID'];
        $_SESSION['role_id'] = (int)$user['Role_ID'];
        $_SESSION['username'] = $user['Username'];
        $_SESSION['logged_in'] = true;
        $_SESSION['last_activity'] = time();
        $_SESSION['created_time'] = time();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

        $presence = $conn->prepare("UPDATE users SET Is_Online = 1, Last_Activity = NOW() WHERE User_ID = ?");
        $presence->bind_param("i", $user['User_ID']);
        $presence->execute();
        $presence->close();

        writeAuditLog($conn, (int)$user['User_ID'], "Login", "sessions", 0);

        $redirect = 'index.html'; 
        if ($user['Role_ID'] == 1) { $redirect = 'views/admin/dashboard.html'; }
        if ($user['Role_ID'] == 2) { $redirect = 'views/vet/dashboard.html'; }
        if ($user['Role_ID'] == 3) { $redirect = ($data['next'] ?? '') === 'appointments' ? 'views/owner/appointments.html' : 'views/owner/dashboard.html'; }
        if ($user['Role_ID'] == 4) { $redirect = 'views/staff/dashboard.html'; }

        echo json_encode([
            "status" => "success", 
            "message" => "Welcome back!", 
            "redirect" => $redirect,
            "role" => (int)$user['Role_ID'],
            "csrf_token" => $_SESSION['csrf_token']
        ]);
        $stmt->close();
        $conn->close();
        exit();
    }
}

recordFailedLogin($conn, $clientIp, $email, 5, 300, 60);
recordFailedLogin($conn, $clientIp, '', 15, 300, 60);

auditLog($conn, null, 'Login Failed', 'sessions', 0, ['event_type' => 'security', 'outcome' => 'failure', 'metadata' => ['reason' => 'invalid_credentials']]);
echo json_encode(["status" => "error", "message" => "Invalid email or password."]);

$stmt->close();
$conn->close();
