<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';

header("Content-Type: application/json; charset=UTF-8");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Referrer-Policy: strict-origin-when-cross-origin");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Method not allowed."]);
    exit();
}

requireCsrf();

$input = json_decode(file_get_contents("php://input"), true);
if (!is_array($input)) {
    $input = $_POST;
}

$email = trim((string)($input['email'] ?? ''));
$otpCode = trim((string)($input['otp_code'] ?? ($input['code'] ?? '')));
$purpose = trim((string)($input['purpose'] ?? ''));

$allowedPurposes = ['password_reset', 'register'];
if (!in_array($purpose, $allowedPurposes, true)) {
    http_response_code(422);
    echo json_encode(["status" => "error", "message" => "Invalid OTP purpose specified."]);
    exit();
}

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(422);
    echo json_encode(["status" => "error", "message" => "Please provide a valid email address."]);
    exit();
}

if ($otpCode === '' || !preg_match('/^\d{6}$/', $otpCode)) {
    http_response_code(422);
    echo json_encode(["status" => "error", "message" => "Please enter the 6-digit verification code."]);
    exit();
}

$emailLower = strtolower($email);


$stmt = $conn->prepare("SELECT OTP_ID, Code_Hash, Expires_At, Attempts, Used_At FROM otp_codes WHERE LOWER(Email) = ? AND Purpose = ? AND Used_At IS NULL ORDER BY OTP_ID DESC LIMIT 1");
$stmt->bind_param("ss", $emailLower, $purpose);
$stmt->execute();
$otpRow = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$otpRow) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "No active verification code found. Please request a new code."]);
    exit();
}

$otpId = (int)$otpRow['OTP_ID'];
$attempts = (int)$otpRow['Attempts'];
$expiresAt = strtotime($otpRow['Expires_At']);
$now = time();


if ($now > $expiresAt) {
    $invStmt = $conn->prepare("UPDATE otp_codes SET Used_At = NOW() WHERE OTP_ID = ?");
    $invStmt->bind_param("i", $otpId);
    $invStmt->execute();
    $invStmt->close();

    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "The verification code has expired. Please request a new code."]);
    exit();
}


if ($attempts >= 5) {
    $invStmt = $conn->prepare("UPDATE otp_codes SET Used_At = NOW() WHERE OTP_ID = ?");
    $invStmt->bind_param("i", $otpId);
    $invStmt->execute();
    $invStmt->close();

    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Maximum verification attempts exceeded. Please request a new code."]);
    exit();
}


if (!password_verify($otpCode, $otpRow['Code_Hash'])) {
    $newAttempts = $attempts + 1;
    $remainingAttempts = max(0, 5 - $newAttempts);

    if ($remainingAttempts === 0) {
        $upStmt = $conn->prepare("UPDATE otp_codes SET Attempts = ?, Used_At = NOW() WHERE OTP_ID = ?");
        $upStmt->bind_param("ii", $newAttempts, $otpId);
        $upStmt->execute();
        $upStmt->close();

        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Invalid verification code. Maximum attempts reached. Please request a new code."]);
        exit();
    } else {
        $upStmt = $conn->prepare("UPDATE otp_codes SET Attempts = ? WHERE OTP_ID = ?");
        $upStmt->bind_param("ii", $newAttempts, $otpId);
        $upStmt->execute();
        $upStmt->close();

        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Invalid verification code. {$remainingAttempts} attempt(s) remaining."]);
        exit();
    }
}


$usedStmt = $conn->prepare("UPDATE otp_codes SET Used_At = NOW() WHERE OTP_ID = ?");
$usedStmt->bind_param("i", $otpId);
$usedStmt->execute();
$usedStmt->close();


if ($purpose === 'register') {
    $_SESSION['register_verified_email'] = $emailLower;
    $_SESSION['register_verified_expires'] = time() + 900;
}


if ($purpose === 'password_reset') {
    $resetToken = bin2hex(random_bytes(32));
    $_SESSION['password_reset_authorized'] = true;
    $_SESSION['password_reset_email'] = $emailLower;
    $_SESSION['password_reset_token'] = $resetToken;
    $_SESSION['password_reset_expires'] = time() + 600; 

    echo json_encode([
        "status" => "success",
        "message" => "Verification code confirmed. You may now reset your password.",
        "reset_token" => $resetToken
    ]);
    exit();
}


echo json_encode([
    "status" => "success",
    "message" => "Email verified successfully."
]);
