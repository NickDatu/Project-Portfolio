<?php
require_once '../../config/session.php';

header("Content-Type: application/json; charset=UTF-8");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Referrer-Policy: strict-origin-when-cross-origin");

echo json_encode([
    "status" => "success",
    "csrf_token" => getCsrfToken()
]);

