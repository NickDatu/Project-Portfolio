<?php
require_once '../../config/session.php';

ini_set('display_errors', 0);
error_reporting(E_ALL);
header("Content-Type: application/json; charset=UTF-8");

try {
    require_once '../../config/db_connection.php';
    require_once dirname(__DIR__) . '/system/audit_helper.php';
    require_once __DIR__ . '/no_show_helper.php';
    if (isset($conn) && $conn instanceof mysqli) $conn->set_charset("utf8mb4");

    function writeAuditLog($conn, $userId, $action, $tableAffected, $recordId = 0) {
        return auditLog($conn, $userId, $action, $tableAffected, $recordId);
    }

    require_once dirname(__DIR__, 2) . '/config/vet_duty.php';

    
    function getScheduledVetForDateTime($conn, $dateValue, $timeValue = null) {
        return cityVetGetDutyVetId($conn, $dateValue);
    }

    function isVetScheduledForDateTime($conn, $vetId, $dateValue, $timeValue = null): bool {
        return cityVetIsVetOnDuty($conn, (int)$vetId, $dateValue);
    }

    if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
        http_response_code(403);
        auditLog($conn, null, 'Unauthorized Appointment Access', 'appointments', 0, ['event_type' => 'security', 'outcome' => 'denied']);
        echo json_encode(["status" => "error", "message" => "Access denied."]);
        exit();
    }

    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        if (isset($_GET['type']) && $_GET['type'] === 'form_data') {
            $response = ['owners' => [], 'services' => []];
            
            $o_res = $conn->query("SELECT Owner_ID, First_name, Last_name FROM owners WHERE Status = 'active' ORDER BY Last_name ASC");
            if($o_res) while($row = $o_res->fetch_assoc()) { $response['owners'][] = $row; }

            $s_res = $conn->query("SELECT Service_ID, Service_Name FROM services WHERE Status = 'active' ORDER BY Service_Name ASC");
            if($s_res) while($row = $s_res->fetch_assoc()) { $response['services'][] = $row; }

            echo json_encode($response);
            exit();
        }

        if (isset($_GET['owner_id'])) {
            $oid = intval($_GET['owner_id']);
            $stmt = $conn->prepare("SELECT Pet_ID, Name FROM pets WHERE Owner_ID = ? AND Status = 'active'");
            $stmt->bind_param("i", $oid);
            $stmt->execute();
            $res = $stmt->get_result();
            $pets = [];
            if($res) while($row = $res->fetch_assoc()) { $pets[] = $row; }
            $stmt->close();
            echo json_encode($pets);
            exit();
        }

        $sql = "SELECT a.Appointment_ID, a.Pet_ID, a.Appointment_Date, a.Status, a.Notes,
                       o.First_name AS Owner_First, o.Last_name AS Owner_Last,
                       p.Name AS Pet_Name, sp.Species_Name,
                       sv.Service_Name,
                       st.First_name AS Vet_First, st.Last_name AS Vet_Last,
                       COALESCE(
                           CONCAT('Dr. ', st.First_name, ' ', st.Last_name),
                           (
                               SELECT CONCAT('Dr. ', cs.First_name, ' ', cs.Last_name)
                               FROM medical_records mr
                               JOIN staff cs ON cs.User_ID = mr.Vet_ID
                               WHERE mr.Appointment_ID = a.Appointment_ID
                                 AND (mr.is_deleted = 0 OR mr.is_deleted IS NULL)
                               ORDER BY mr.Record_ID DESC
                               LIMIT 1
                           )
                       ) AS Assigned_Vet_Name
                FROM appointments a
                JOIN pets p ON a.Pet_ID = p.Pet_ID AND p.Status != 'archived'
                LEFT JOIN owners o ON a.Owner_ID = o.Owner_ID
                LEFT JOIN species sp ON p.Species_ID = sp.Species_ID
                LEFT JOIN services sv ON a.Service_ID = sv.Service_ID
                LEFT JOIN staff st ON a.Vet_ID = st.User_ID
                ORDER BY a.Appointment_Date DESC";

        $result = $conn->query($sql);
        if (!$result) {
            error_log("SQL Error in appointments.php: " . $conn->error);
            throw new Exception("Unable to load appointments.");
        }

        $appointments = [];
        while ($row = $result->fetch_assoc()) {
            $phpdate = strtotime($row['Appointment_Date']);
            $row['Formatted_Date'] = date('M j, Y', $phpdate);
            $row['Formatted_Time'] = date('g:i A', $phpdate);
            if (empty($row['Service_Name']) && !empty($row['Appointment_ID'])) {
                $row['Service_Name'] = 'General Consultation';
            }
            $appointments[] = $row;
        }

        echo json_encode($appointments);
        exit();
    }

    if ($method === 'POST') {
        requireCsrf();

        if ((int)$_SESSION['role_id'] === 1) {
            http_response_code(403);
            echo json_encode(["status" => "error", "message" => "Appointments are view-only for administrators."]);
            exit();
        }

        if (!in_array((int)$_SESSION['role_id'], [1, 4], true)) {
            http_response_code(403);
            auditLog($conn, (int)$_SESSION['user_id'], 'Denied Appointment Change', 'appointments', 0, ['event_type' => 'security', 'outcome' => 'denied']);
            echo json_encode(["status" => "error", "message" => "Access denied."]);
            exit();
        }
        $input = json_decode(file_get_contents("php://input"), true);
        $action = $input['action'] ?? '';

        if ($action === 'create') {
            $owner_id = (int)($input['owner_id'] ?? 0);
            $pet_id = (int)($input['pet_id'] ?? 0);
            $service_id = (int)($input['service_id'] ?? 0);
            $appointmentDate = trim((string)($input['date'] ?? ''));
            $appointmentTime = trim((string)($input['time'] ?? ''));
            $datetime = trim($appointmentDate . ' ' . $appointmentTime);

            if (!$owner_id || !$pet_id || !$service_id || empty($appointmentDate)) {
                echo json_encode(["status" => "error", "message" => "All appointment fields are required."]);
                exit();
            }

            $petDate = date('Y-m-d', strtotime($appointmentDate));
            
            $selectedVetId = getScheduledVetForDateTime($conn, $petDate, $appointmentTime);
            if ($selectedVetId === null || (int)$selectedVetId <= 0) {
                echo json_encode(["status" => "error", "message" => "No veterinarian is scheduled for the selected date."]);
                exit();
            }

            if (!isVetScheduledForDateTime($conn, $selectedVetId, $petDate, $appointmentTime)) {
                echo json_encode(["status" => "error", "message" => "The selected veterinarian is not scheduled for this appointment date/time."]);
                exit();
            }

            $conn->begin_transaction();
            try {
                $checkRel = $conn->prepare("SELECT p.Pet_ID FROM pets p JOIN owners o ON p.Owner_ID = o.Owner_ID WHERE p.Pet_ID = ? AND p.Owner_ID = ? AND p.Status != 'archived' AND o.Status = 'active' LIMIT 1 FOR UPDATE");
                $checkRel->bind_param("ii", $pet_id, $owner_id);
                $checkRel->execute();
                if ($checkRel->get_result()->num_rows === 0) {
                    $checkRel->close();
                    $conn->rollback();
                    echo json_encode(["status" => "error", "message" => "Selected pet does not belong to this active owner or is archived."]);
                    exit();
                }
                $checkRel->close();

                $stmt = $conn->prepare("
                    INSERT INTO appointments (Owner_ID, Pet_ID, Service_ID, Vet_ID, Appointment_Date, Status, Notes)
                    VALUES (?, ?, ?, ?, ?, 'Confirmed', 'Walk-in Booking')
                ");
                $stmt->bind_param("iiiss", $owner_id, $pet_id, $service_id, $selectedVetId, $datetime);
                $stmt->execute();
                if ($stmt->affected_rows !== 1) {
                    $stmt->close();
                    throw new Exception("Unable to create appointment: pet is not active.");
                }
                $appointment_id = $conn->insert_id;
                $stmt->close();

                $apStmt = $conn->prepare("INSERT INTO appointment_pets (Appointment_ID, Pet_ID) VALUES (?, ?)");
                $apStmt->bind_param("ii", $appointment_id, $pet_id);
                $apStmt->execute();
                $apStmt->close();

                $actorId = (int)$_SESSION['user_id'];
                writeAuditLog($conn, $actorId, "Create Appointment", "appointments", $appointment_id);
                $conn->commit();
                echo json_encode(["status" => "success", "message" => "Booked successfully"]);
            } catch (Throwable $e) {
                $conn->rollback();
                error_log("DB Error in appointments.php create: " . $e->getMessage());
                echo json_encode(["status" => "error", "message" => "Unable to create appointment."]);
            }
            exit();
        }

        if ($action === 'update_status') {
            $id = (int)($input['appointment_id'] ?? 0);
            $status = trim((string)($input['status'] ?? ''));
            $vet_id = NULL; 

            $allowedStatuses = ['Pending', 'Confirmed', 'Checked In', 'In Consultation', 'Completed', 'Cancelled', 'No Show'];
            if (!$id || empty($status) || !in_array($status, $allowedStatuses, true)) {
                echo json_encode(["status" => "error", "message" => "Valid appointment ID and status are required."]);
                exit();
            }

            $checkTarget = $conn->prepare("SELECT a.Status, a.Vet_ID, a.Appointment_Date, p.Status AS Pet_Status FROM appointments a JOIN pets p ON a.Pet_ID = p.Pet_ID WHERE a.Appointment_ID = ?");
            $checkTarget->bind_param("i", $id);
            $checkTarget->execute();
            $target = $checkTarget->get_result()->fetch_assoc();
            $checkTarget->close();

            if (!$target) {
                echo json_encode(["status" => "error", "message" => "Appointment not found."]);
                exit();
            }

            if ($target['Pet_Status'] === 'archived') {
                echo json_encode(["status" => "error", "message" => "Target pet is archived."]);
                exit();
            }

            if ($status === 'Confirmed') {
                $vet_id = getScheduledVetForDateTime($conn, date('Y-m-d', strtotime($target['Appointment_Date'] ?? date('Y-m-d'))));
                if ($vet_id !== null && (int)$vet_id <= 0) $vet_id = NULL;
            }

            $curStatus = $target['Status'];
            $isNoOp = ($curStatus === $status && ((is_null($vet_id) && is_null($target['Vet_ID'])) || ((int)$target['Vet_ID'] === (int)$vet_id)));
            if ($isNoOp) {
                echo json_encode(["status" => "success", "message" => "Status unchanged."]);
                exit();
            }

            $validTransitions = [
                'Pending' => ['Confirmed', 'Cancelled'],
                'Confirmed' => ['Checked In', 'Cancelled', 'No Show'],
                'Checked In' => ['In Consultation', 'Completed', 'Cancelled'],
                'In Consultation' => ['Completed', 'Checked In', 'Cancelled'],
                'No Show' => [],
                'Completed' => [],
                'Cancelled' => []
            ];

            if (!isset($validTransitions[$curStatus]) || !in_array($status, $validTransitions[$curStatus], true)) {
                echo json_encode(["status" => "error", "message" => "Invalid status transition from {$curStatus} to {$status}."]);
                exit();
            }

            if ($vet_id) {
                $stmt = $conn->prepare("UPDATE appointments a JOIN pets p ON a.Pet_ID = p.Pet_ID SET a.Status = ?, a.Vet_ID = ? WHERE a.Appointment_ID = ? AND a.Status = ? AND p.Status != 'archived'");
                $stmt->bind_param("siis", $status, $vet_id, $id, $curStatus);
            } else {
                $stmt = $conn->prepare("UPDATE appointments a JOIN pets p ON a.Pet_ID = p.Pet_ID SET a.Status = ? WHERE a.Appointment_ID = ? AND a.Status = ? AND p.Status != 'archived'");
                $stmt->bind_param("sis", $status, $id, $curStatus);
            }
            
            if ($stmt->execute() && $stmt->affected_rows === 1) {
                $actorId = (int)$_SESSION['user_id'];
                writeAuditLog($conn, $actorId, "Update Appointment Status", "appointments", $id);
                $resp = ["status" => "success"];
                if ($status === 'No Show') {
                    $noShowInfo = handleAppointmentNoShow($conn, $id, $actorId);
                    $resp['no_show_info'] = $noShowInfo;
                }
                echo json_encode($resp);
            } else {
                error_log("DB Error in appointments.php update_status: " . $conn->error);
                echo json_encode(["status" => "error", "message" => "Unable to update status."]);
            }
            $stmt->close();
            exit();
        }
        exit();
    }

} catch (Throwable $e) {
    http_response_code(500);
    error_log("Exception in appointments.php: " . $e->getMessage());
    echo json_encode(["status" => "error", "message" => "An error occurred while processing appointment data."]);
    exit();
}
