<?php
require_once dirname(__DIR__, 2) . '/config/db_connection.php';
require_once dirname(__DIR__) . '/system/audit_helper.php';
require_once dirname(__DIR__) . '/notifications/notify.php';

function handleAppointmentNoShow($conn, $appointmentId, $actorId = null) {
    if (!($conn instanceof mysqli) || !$appointmentId) {
        return ['no_show_count' => 0, 'deactivated' => false];
    }

    $stmt = $conn->prepare("
        SELECT a.Owner_ID, o.User_ID, o.First_name, o.Last_name, o.Contact_number, u.Email, u.Status AS User_Status
        FROM appointments a
        JOIN owners o ON a.Owner_ID = o.Owner_ID
        JOIN users u ON o.User_ID = u.User_ID
        WHERE a.Appointment_ID = ?
        LIMIT 1
    ");
    $stmt->bind_param("i", $appointmentId);
    $stmt->execute();
    $owner = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$owner) {
        return ['no_show_count' => 0, 'deactivated' => false];
    }

    $ownerId = (int)$owner['Owner_ID'];
    $userId = (int)$owner['User_ID'];

    $cntStmt = $conn->prepare("SELECT COUNT(*) AS no_show_count FROM appointments WHERE Owner_ID = ? AND Status = 'No Show'");
    $cntStmt->bind_param("i", $ownerId);
    $cntStmt->execute();
    $cntRes = $cntStmt->get_result()->fetch_assoc();
    $cntStmt->close();

    $noShowCount = (int)($cntRes['no_show_count'] ?? 0);
    $threshold = defined('NO_SHOW_DEACTIVATE_THRESHOLD') ? (int)NO_SHOW_DEACTIVATE_THRESHOLD : 3;
    $deactivated = false;

    if ($noShowCount >= $threshold && $owner['User_Status'] === 'active') {
        $updUser = $conn->prepare("UPDATE users SET Status = 'inactive' WHERE User_ID = ?");
        $updUser->bind_param("i", $userId);
        $updUser->execute();
        $updUser->close();

        $updOwner = $conn->prepare("UPDATE owners SET Status = 'inactive' WHERE Owner_ID = ?");
        $updOwner->bind_param("i", $ownerId);
        $updOwner->execute();
        $updOwner->close();

        $deactivated = true;

        auditLog($conn, $actorId ?: $userId, 'Deactivate User (No-Show Threshold)', 'users', $userId, [
            'event_type' => 'security',
            'outcome' => 'success',
            'metadata' => [
                'reason' => 'no_show_threshold_reached',
                'no_show_count' => $noShowCount,
                'threshold' => $threshold,
                'owner_id' => $ownerId
            ]
        ]);

        $noticeTitle = 'Account Deactivated';
        $noticeMsg = "Your account has been deactivated due to reaching {$noShowCount} recorded appointment no-shows. Please visit the City Vet office.";
        $insNotice = $conn->prepare("INSERT INTO notifications (User_ID, Title, Message, Type) VALUES (?, ?, ?, 'System')");
        if ($insNotice) {
            $insNotice->bind_param("iss", $userId, $noticeTitle, $noticeMsg);
            $insNotice->execute();
            $insNotice->close();
        }

        if (!empty($owner['Email'])) {
            sendResendEmail($owner['Email'], "City Vet Account Deactivated", $noticeMsg);
        }
        if (!empty($owner['Contact_number'])) {
            sendIprogSms($owner['Contact_number'], $noticeMsg);
        }
    }

    return [
        'owner_id' => $ownerId,
        'user_id' => $userId,
        'no_show_count' => $noShowCount,
        'deactivated' => $deactivated,
        'threshold' => $threshold
    ];
}
