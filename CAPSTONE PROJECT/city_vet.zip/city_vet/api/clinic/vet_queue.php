<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once __DIR__ . '/no_show_helper.php';
require_once __DIR__ . '/consultation_catalog_helper.php';
require_once dirname(__DIR__, 2) . '/config/schema_ensure.php';
require_once dirname(__DIR__, 2) . '/config/vet_duty.php';
require_once dirname(__DIR__, 2) . '/config/consultation_template.php';
require_once dirname(__DIR__, 2) . '/config/vaccination_rules.php';
header("Content-Type: application/json; charset=UTF-8");




set_exception_handler(function ($e) {
    error_log('vet_queue.php unhandled: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
        header("Content-Type: application/json; charset=UTF-8");
    }
    echo json_encode(["status" => "error", "success" => false, "message" => "The queue service hit an unexpected error. Please try again."]);
    exit();
});

if ($conn instanceof mysqli) {
    $conn->set_charset("utf8mb4");
    
    cityVetEnsureMedicalSchema($conn);
    cityVetEnsurePanelRevisionSchema($conn);
    cityVetEnsureConsultationCatalogSchema($conn);
    cityVetEnsureConsultationTemplateSchema($conn);
}

function respond($payload, $code = 200) {
    http_response_code($code);
    if (is_array($payload) && !array_key_exists('success', $payload) && isset($payload['status'])) {
        $payload['success'] = ($payload['status'] === 'success');
    }
    echo json_encode($payload);
    exit();
}

function requireRole($roles) {
    if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], $roles, true)) {
        respond(["status" => "error", "message" => "Access denied."], 403);
    }
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $mode = $_GET['mode'] ?? 'queue';

    if ($mode === 'roster') {
        requireRole([1, 2, 4]);
        $eventId = (int)($_GET['event_id'] ?? 0);
        if (!$eventId) respond(["status" => "error", "message" => "Missing event ID."], 422);

        $stmt = $conn->prepare("
            SELECT ce.Title, ce.Event_Date, ce.Max_Slots,
                   a.Appointment_ID, a.Status,
                   o.First_name, o.Last_name, o.Contact_number,
                   GROUP_CONCAT(CONCAT(p.Name, ' (', COALESCE(sp.Species_Name, 'Pet'), ')') ORDER BY p.Name SEPARATOR ', ') AS Pets,
                   COUNT(ap.Pet_ID) AS Pet_Count
            FROM calendar_events ce
            LEFT JOIN appointments a ON a.Event_ID = ce.Event_ID AND a.Status != 'Cancelled'
            LEFT JOIN owners o ON o.Owner_ID = a.Owner_ID
            LEFT JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID
            LEFT JOIN pets p ON p.Pet_ID = ap.Pet_ID AND p.Status != 'archived'
            LEFT JOIN species sp ON sp.Species_ID = p.Species_ID
            WHERE ce.Event_ID = ?
            GROUP BY a.Appointment_ID, ce.Event_ID
            ORDER BY o.Last_name ASC, o.First_name ASC
        ");
        $stmt->bind_param("i", $eventId);
        $stmt->execute();
        $result = $stmt->get_result();
        $rows = [];
        $event = null;
        while ($row = $result->fetch_assoc()) {
            if (!$event) {
                $event = [
                    "Title" => $row["Title"],
                    "Event_Date" => $row["Event_Date"],
                    "Max_Slots" => $row["Max_Slots"]
                ];
            }
            if ($row['Appointment_ID']) $rows[] = $row;
        }
        respond(["status" => "success", "event" => $event, "roster" => $rows]);
    }

    requireRole([1, 2]);
    $sql = "
        SELECT a.Appointment_ID, a.Pet_ID, a.Owner_ID, a.Service_ID, a.Event_ID, a.Appointment_Date, a.Status, a.Notes,
               p.Name AS Pet_Name, p.Gender, p.Weight, p.Birthdate,
               o.First_name AS Owner_First, o.Last_name AS Owner_Last, o.Contact_number, o.Address,
               sp.Species_Name, b.Breed_Name, s.Service_Name, ce.Event_Type
        FROM appointments a
        JOIN pets p ON p.Pet_ID = a.Pet_ID AND p.Status != 'archived'
        JOIN owners o ON o.Owner_ID = a.Owner_ID
        LEFT JOIN species sp ON sp.Species_ID = p.Species_ID
        LEFT JOIN breeds b ON b.Breed_ID = p.Breed_ID
        LEFT JOIN services s ON s.Service_ID = a.Service_ID
        LEFT JOIN calendar_events ce ON ce.Event_ID = a.Event_ID
        WHERE DATE(a.Appointment_Date) = CURDATE()
          AND a.Status = 'In Consultation'
            ORDER BY a.Appointment_Date DESC
    ";
    $result = $conn->query($sql);
    $queue = [];
    while ($row = $result->fetch_assoc()) {
        $row['Time'] = date('h:i A', strtotime($row['Appointment_Date']));
        $queue[] = $row;
    }
    respond(["status" => "success", "queue" => $queue]);
}

if ($method !== 'POST') respond(["status" => "error", "message" => "Invalid request method."], 405);

requireCsrf();

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) $input = $_POST;
$action = $input['action'] ?? '';

if ($action === 'create_walkin_queue') {
    requireRole([1, 4]);
    $ownerId = (int)($input['owner_id'] ?? 0);
    $petId = (int)($input['pet_id'] ?? 0);
    $serviceId = (int)($input['service_id'] ?? 0);
    $notes = trim($input['notes'] ?? 'Walk-in consultation');

    if (!$ownerId || !$petId || !$serviceId) {
        respond(["status" => "error", "message" => "Owner, pet, and service are required."], 422);
    }

    $check = $conn->prepare("SELECT p.Pet_ID, s.Species_Name, DATEDIFF(CURDATE(), p.Birthdate) AS Age_Days FROM pets p LEFT JOIN species s ON s.Species_ID = p.Species_ID WHERE p.Pet_ID = ? AND p.Owner_ID = ? AND p.Status = 'active'");
    $check->bind_param("ii", $petId, $ownerId);
    $check->execute();
    $petRow = $check->get_result()->fetch_assoc();
    if (!$petRow) {
        respond(["status" => "error", "message" => "Selected pet does not belong to this owner."], 422);
    }
    $speciesName = strtolower((string)($petRow['Species_Name'] ?? ''));
    $ageDays = (int)($petRow['Age_Days'] ?? 0);
    if (($speciesName === 'dog' && $ageDays < 14) || ($speciesName === 'cat' && $ageDays < 28)) {
        respond(["status" => "error", "message" => "Dogs must be at least 2 weeks old and cats must be at least 4 weeks old for the Walk-In Registry."], 422);
    }

    $svcCheck = $conn->prepare("SELECT Service_Name FROM services WHERE Service_ID = ? AND Status = 'active' LIMIT 1");
    $svcCheck->bind_param("i", $serviceId);
    $svcCheck->execute();
    $svcRow = $svcCheck->get_result()->fetch_assoc();
    if (!$svcRow || stripos($svcRow['Service_Name'], 'spay') !== false || stripos($svcRow['Service_Name'], 'neuter') !== false) {
        respond(["status" => "error", "message" => "Spay and neuter services cannot be booked via walk-in."], 422);
    }
    if (stripos($svcRow['Service_Name'], 'online consultation') !== false) {
        respond(["status" => "error", "message" => "Online Consultation cannot be registered through the Walk-In Registry."], 422);
    }

    $appointmentDate = date('Y-m-d H:i:s');
    $stmt = $conn->prepare("
        INSERT INTO appointments (Owner_ID, Pet_ID, Service_ID, Appointment_Date, Status, Notes)
        VALUES (?, ?, ?, ?, 'Checked In', ?)
    ");
    $stmt->bind_param("iiiss", $ownerId, $petId, $serviceId, $appointmentDate, $notes);
    if ($stmt->execute()) {
        $appointmentId = $conn->insert_id;
        $apStmt = $conn->prepare("INSERT INTO appointment_pets (Appointment_ID, Pet_ID) VALUES (?, ?)");
        $apStmt->bind_param("ii", $appointmentId, $petId);
        $apStmt->execute();
        $apStmt->close();
        auditLog($conn, (int)($_SESSION['user_id'] ?? 0), "Create Walk-in Queue Item", "appointments", $appointmentId);
        respond(["status" => "success", "appointment_id" => $appointmentId]);
    }

    respond(["status" => "error", "message" => "Unable to add walk-in to queue."], 500);
}

if ($action === 'update_status') {
    requireRole([1, 4]);
    $appointmentId = (int)($input['appointment_id'] ?? 0);
    $status = $input['status'] ?? '';
    $allowed = ['Checked In', 'In Consultation', 'No Show', 'Completed', 'Cancelled'];
    if (!$appointmentId || !in_array($status, $allowed, true)) {
        respond(["status" => "error", "message" => "Invalid status update."], 422);
    }

    $check = $conn->prepare("SELECT a.Status, p.Status AS Pet_Status FROM appointments a JOIN pets p ON a.Pet_ID = p.Pet_ID WHERE a.Appointment_ID = ?");
    $check->bind_param("i", $appointmentId);
    $check->execute();
    $current = $check->get_result()->fetch_assoc();
    $check->close();

    if (!$current) {
        respond(["status" => "error", "message" => "Appointment not found."], 404);
    }
    if ($current['Pet_Status'] === 'archived') {
        respond(["status" => "error", "message" => "Pet is archived."], 422);
    }

    $curStatus = $current['Status'];
    if ($curStatus === $status) {
        respond(["status" => "success", "message" => "Status unchanged."]);
    }

    $validTransitions = [
        'Pending' => ['Confirmed', 'Cancelled'],
        'Confirmed' => ['Checked In', 'Cancelled', 'No Show'],
        'Checked In' => ['In Consultation', 'Completed', 'Cancelled'],
        'In Consultation' => ['Completed', 'Checked In', 'Cancelled'],
        'No Show' => [],
        'Completed' => [],
        'Cancelled' => []
    ];

    if (!isset($validTransitions[$curStatus]) || !in_array($status, $validTransitions[$curStatus], true)) {
        respond(["status" => "error", "message" => "Invalid status transition from {$curStatus} to {$status}."], 422);
    }

    $stmt = $conn->prepare("UPDATE appointments SET Status = ? WHERE Appointment_ID = ? AND Status = ?");
    $stmt->bind_param("sis", $status, $appointmentId, $curStatus);
    if ($stmt->execute() && $stmt->affected_rows === 1) {
        auditLog($conn, (int)($_SESSION['user_id'] ?? 0), "Update Queue Status to {$status}", "appointments", $appointmentId);
        $resp = ["status" => "success"];
        if ($status === 'No Show') {
            $noShowInfo = handleAppointmentNoShow($conn, $appointmentId, (int)($_SESSION['user_id'] ?? 0));
            $resp['no_show_info'] = $noShowInfo;
        }
        respond($resp);
    }
    respond(["status" => "error", "message" => "Unable to update queue status."], 500);
}

if ($action === 'save_consultation') {
    requireRole([1, 2, 4]);
    $appointmentId = (int)($input['appointment_id'] ?? 0);
    $petId = (int)($input['pet_id'] ?? 0);
    $treatmentSelection = !empty($input['service_id'])
        ? cityVetResolveServiceSelection($conn, $input)
        : cityVetResolveTreatmentSelection($conn, $input);
    $medicineSelection = cityVetResolveMedicineSelection($conn, $input);
    $treatment = $treatmentSelection['value'];
    $medicineUsed = $medicineSelection['value'];
    $medicineDosage = trim((string)($input['medicine_dosage'] ?? ''));
    $medicineDetails = trim((string)($input['medicine_details'] ?? ''));
    $lotNumber = trim((string)($input['lot_number'] ?? ''));
    $medicineMeta = [];
    if ($medicineDosage !== '') $medicineMeta[] = 'Dosage: ' . $medicineDosage;
    if ($medicineDetails !== '') $medicineMeta[] = 'Details: ' . $medicineDetails;
    if ($medicineMeta) $medicineUsed = trim($medicineUsed . ($medicineUsed !== '' ? ' | ' : '') . implode(' | ', $medicineMeta));
    $notes = trim((string)($input['notes'] ?? ''));
    $followUpDate = trim((string)($input['follow_up_date'] ?? ''));
    $findingsResult = cityVetValidateConsultationFindings($input['findings'] ?? null);
    $roleId = (int)$_SESSION['role_id'];
    $sessionUserId = (int)$_SESSION['user_id'];

    // A manually entered follow-up date takes priority. An empty date may still
    // fall back to the age/procedure schedule below.

    if ($treatmentSelection['error']) {
        respond(["status" => "error", "message" => $treatmentSelection['error'] ?: "Appointment, pet, and treatment are required."], 422);
    }
    if ($roleId === 4 && stripos($treatment, 'online consultation') !== false) {
        respond(["status" => "error", "message" => "Online Consultation cannot be used in Staff Bypass."], 422);
    }
    if ($medicineSelection['error']) {
        respond(["status" => "error", "message" => $medicineSelection['error']], 422);
    }
    if ($findingsResult['error']) {
        respond(["status" => "error", "message" => $findingsResult['error']], 422);
    }
    if (!$appointmentId || !$petId) {
        respond(["status" => "error", "message" => "Appointment, pet, and treatment are required."], 422);
    }

    if ($followUpDate !== '') {
        $followUpDateObject = DateTime::createFromFormat('!Y-m-d', $followUpDate);
        if (!$followUpDateObject || $followUpDateObject->format('Y-m-d') !== $followUpDate || (int)$followUpDateObject->format('N') >= 6) {
            respond(["status" => "error", "message" => "Follow-up appointments may only be scheduled on weekdays."], 422);
        }
    }

    
    
    $maxNoteWords = 300;
    if ($roleId === 4) {
        $wordCount = cityVetCountWords($notes);
        if ($wordCount > $maxNoteWords) {
            respond(["status" => "error", "message" => "Notes must not exceed {$maxNoteWords} words. Current count: {$wordCount} words."], 422);
        }
    }
    if (mb_strlen($notes) > 10000) {
        respond(["status" => "error", "message" => "Notes are too long. Please shorten them."], 422);
    }

    
    
    if ($roleId === 2) {
        $vetId = $sessionUserId;
    } elseif ($roleId === 4) {
        $vetId = (int)($input['vet_id'] ?? 0);
        if ($vetId <= 0 || !cityVetIsVetOnDuty($conn, $vetId, date('Y-m-d'))) {
            respond(["status" => "error", "message" => "Select one veterinarian who is on duty today."], 422);
        }
    } else {
        $vetId = (int)cityVetGetDutyVetId($conn, date('Y-m-d'));
        if ($vetId <= 0) {
            respond(["status" => "error", "message" => "No veterinarian is scheduled as officer of the day for today. Ask the office to update the Veterinarian Schedule."], 422);
        }
    }

    $medicinePicture = trim((string)($input['medicine_picture'] ?? ''));

    if ($medicinePicture !== '') {
        $validPath = preg_match('/^uploads\/medicine\/[a-f0-9]{32}\.(jpg|png|webp|gif)$/', $medicinePicture) === 1;
        if (!$validPath || !is_file(dirname(__DIR__, 2) . '/' . $medicinePicture)) {
            respond(["status" => "error", "message" => "Invalid medicine picture."], 422);
        }
    }

    $conn->begin_transaction();
    try {
        $checkRel = $conn->prepare("
            SELECT a.Appointment_ID, a.Status, p.Status AS Pet_Status
            FROM appointments a
            JOIN pets p ON a.Pet_ID = p.Pet_ID
            WHERE a.Appointment_ID = ? AND a.Pet_ID = ?
            LIMIT 1
            FOR UPDATE
        ");
        $checkRel->bind_param("ii", $appointmentId, $petId);
        $checkRel->execute();
        $rel = $checkRel->get_result()->fetch_assoc();
        $checkRel->close();

        if (!$rel) {
            $conn->rollback();
            respond(["status" => "error", "message" => "Appointment does not match the specified pet or does not exist."], 422);
        }
        if ($rel['Pet_Status'] === 'archived') {
            $conn->rollback();
            respond(["status" => "error", "message" => "Pet is archived."], 422);
        }
        if (!in_array($rel['Status'], ['Checked In', 'In Consultation'], true)) {
            $conn->rollback();
            respond(["status" => "error", "message" => "Cannot add consultation to an appointment with status " . $rel['Status'] . "."], 422);
        }

        $stmt = $conn->prepare("
            INSERT INTO medical_records (Appointment_ID, Pet_ID, Vet_ID, Treatment, Visit_Date, Notes, Medicine_Used, Medicine_Picture, Lot_Number)
            VALUES (?, ?, ?, ?, NOW(), ?, NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''))
        ");
        $stmt->bind_param("iiisssss", $appointmentId, $petId, $vetId, $treatment, $notes, $medicineUsed, $medicinePicture, $lotNumber);
        $stmt->execute();
        $recordId = $conn->insert_id;

        if ($findingsResult['value'] !== null) {
            $finding = $findingsResult['value'];
            $purposeJson = json_encode($finding['purpose'], JSON_UNESCAPED_UNICODE);
            $findingsJson = json_encode($finding['findings'], JSON_UNESCAPED_UNICODE);
            $findingStmt = $conn->prepare("INSERT INTO consultation_findings (Record_ID, Pet_ID, Weight_Status, Body_Condition_Score, Purpose, Findings, Diagnosis_Text, Recommendations) VALUES (?, ?, NULLIF(?, ''), ?, ?, ?, NULLIF(?, ''), NULLIF(?, ''))");
            $weightStatus = (string)($finding['weight_status'] ?? '');
            $bcs = $finding['body_condition_score'];
            $diagnosis = $finding['diagnosis'];
            $recommendations = $finding['recommendations'];
            $findingStmt->bind_param('iisissss', $recordId, $petId, $weightStatus, $bcs, $purposeJson, $findingsJson, $diagnosis, $recommendations);
            $findingStmt->execute();
            $findingStmt->close();
        }

        $update = $conn->prepare("UPDATE appointments SET Status = 'Completed', Vet_ID = ? WHERE Appointment_ID = ? AND Status IN ('Checked In', 'In Consultation')");
        $update->bind_param("ii", $vetId, $appointmentId);
        $update->execute();
        if ($update->affected_rows !== 1) {
            throw new Exception("Unable to transition appointment to Completed.");
        }

        $appt = $conn->prepare("
            SELECT a.Owner_ID, a.Service_ID, a.Event_ID, s.Service_Name, sc.Category_Name,
                   ce.Event_Type, ce.Title AS Event_Title
            FROM appointments a
            LEFT JOIN services s ON a.Service_ID = s.Service_ID
            LEFT JOIN service_categories sc ON s.Category_ID = sc.Category_ID
            LEFT JOIN calendar_events ce ON ce.Event_ID = a.Event_ID
            WHERE a.Appointment_ID = ?
        ");
        $appt->bind_param("i", $appointmentId);
        $appt->execute();
        $apptRow = $appt->get_result()->fetch_assoc();
        $appt->close();

        $serviceName = $apptRow['Service_Name'] ?? '';
        $categoryName = $apptRow['Category_Name'] ?? '';
        $isSpayNeuter = ($apptRow['Event_Type'] ?? '') === 'SpayNeuter'
            || stripos($serviceName, 'spay') !== false
            || stripos($serviceName, 'neuter') !== false
            || stripos((string)($apptRow['Event_Title'] ?? ''), 'spay') !== false
            || stripos((string)($apptRow['Event_Title'] ?? ''), 'neuter') !== false;
        // Spay/Neuter event appointments do not receive follow-up appointments.
        if ($isSpayNeuter) $followUpDate = '';

        $isParvo = (stripos($serviceName, 'parvo') !== false || stripos($treatment, 'parvo') !== false);
        $isDeworming = (stripos($serviceName, 'deworm') !== false);
        $isVaccination = !$isDeworming && ($isParvo || stripos($categoryName, 'vaccin') !== false || stripos($serviceName, 'vaccin') !== false || stripos($treatment, 'vaccin') !== false);

        if ($followUpDate === '' && !$isSpayNeuter) {
            $petRuleStmt = $conn->prepare('SELECT Species_ID, Birthdate FROM pets WHERE Pet_ID = ? LIMIT 1');
            $petRuleStmt->bind_param('i', $petId); $petRuleStmt->execute(); $petRule = $petRuleStmt->get_result()->fetch_assoc(); $petRuleStmt->close();
            $ageWeeks = $petRule ? petAgeInWeeks($petRule['Birthdate']) : null;
            $matchedRule = null;
            if ($ageWeeks !== null && $petRule) {
                $petRules = cityVetRulesForPet($conn, (int)$petRule['Species_ID']);
                usort($petRules, static fn($a, $b) => (int)$b['Age_Weeks'] <=> (int)$a['Age_Weeks']);
                foreach ($petRules as $rule) {
                    if ((int)$rule['Age_Weeks'] > $ageWeeks) continue;
                    $ruleKeywords = preg_split('/\s+or\s+|\s*\/\s*/i', $rule['Procedure_Name']);
                    foreach ($ruleKeywords as $keyword) if ($keyword !== '' && stripos($treatment . ' ' . $serviceName, trim($keyword)) !== false) { $matchedRule = $rule; break 2; }
                }
            }
            if ($matchedRule) {
                // Visit_Date is written with NOW() below; use today's procedure date for the due date.
                $procedureDate = date('Y-m-d');
                $followUpDate = cityVetNextDueDate($procedureDate, (int)$matchedRule['Repeat_Value'], $matchedRule['Repeat_Unit']);
            } elseif ($isParvo && !$petRule) {
                $followUpDate = cityVetDefaultFollowUp(1, 0);
            } elseif ($isVaccination && (!$petRule || $ageWeeks === null)) {
                $followUpDate = cityVetDefaultFollowUp(0, 1);
            }
        if ($isVaccination && $followUpDate === '') {
            $followUpDate = cityVetDefaultFollowUp(0, 1);
        }

        if ($followUpDate !== '') {
            $holidayStmt = $conn->prepare("SELECT 1 FROM calendar_events WHERE Event_Date = ? AND Event_Type = 'Holiday' LIMIT 1");
            for ($attempt = 0; $attempt < 370; $attempt++) {
                $followUpDateObject = DateTime::createFromFormat('!Y-m-d', $followUpDate);
                $isWeekend = !$followUpDateObject || (int)$followUpDateObject->format('N') >= 6;
                $isHoliday = false;
                if (!$isWeekend && $holidayStmt) {
                    $holidayStmt->bind_param('s', $followUpDate);
                    $holidayStmt->execute();
                    $isHoliday = $holidayStmt->get_result()->num_rows > 0;
                }
                if (!$isWeekend && !$isHoliday) break;
                $followUpDateObject->modify('+1 day');
                $followUpDate = $followUpDateObject->format('Y-m-d');
            }
            if ($holidayStmt) $holidayStmt->close();
        }
    }

        if ($isVaccination) {
            $treatmentIsVaccine = stripos($treatment, 'vaccin') !== false || stripos($treatment, 'parvo') !== false;
            $vaccineName = $treatmentIsVaccine ? $treatment : (!empty($serviceName) ? $serviceName : (!empty($treatment) ? $treatment : ($isParvo ? 'Parvo Vaccine' : 'Vaccine')));
            $nextDue = !empty($followUpDate) ? $followUpDate : ($isParvo ? cityVetDefaultFollowUp(1, 0) : cityVetDefaultFollowUp(0, 1));
            $vStmt = $conn->prepare("INSERT INTO vaccinations (Pet_ID, Vaccine_Name, Date_Administered, Next_Due_Date, Vet_ID) VALUES (?, ?, CURDATE(), ?, ?)");
            if ($vStmt) {
                $vStmt->bind_param("issi", $petId, $vaccineName, $nextDue, $vetId);
                $vStmt->execute();
                $vStmt->close();
            }
        }

        $followUpId = null;
        if ($followUpDate !== '') {
            if ($apptRow) {
                $followUpDateTime = $followUpDate . ' 08:00:00';
                $followNotes = "Follow-up appointment from consultation #{$recordId}.";
                $serviceId = $apptRow['Service_ID'] ? (int)$apptRow['Service_ID'] : null;
                $ownerId = (int)$apptRow['Owner_ID'];
                $insertFollow = $conn->prepare("
                    INSERT INTO appointments (Owner_ID, Pet_ID, Service_ID, Vet_ID, Appointment_Date, Status, Notes)
                    SELECT ?, p.Pet_ID, ?, ?, ?, 'Confirmed', ?
                    FROM pets p
                    WHERE p.Pet_ID = ? AND p.Status != 'archived'
                ");
                $insertFollow->bind_param("iiissi", $ownerId, $serviceId, $vetId, $followUpDateTime, $followNotes, $petId);
                $insertFollow->execute();
                if ($insertFollow->affected_rows !== 1) {
                    throw new Exception("Unable to create follow-up appointment: pet is archived or inactive.");
                }
                $followUpId = $conn->insert_id;
                $insertFollow->close();

                $apStmt = $conn->prepare("INSERT INTO appointment_pets (Appointment_ID, Pet_ID) VALUES (?, ?)");
                $apStmt->bind_param("ii", $followUpId, $petId);
                $apStmt->execute();
                $apStmt->close();

                $notice = $conn->prepare("
                    INSERT INTO notifications (User_ID, Title, Message, Type)
                    SELECT o.User_ID, 'Follow-up Appointment Scheduled',
                           CONCAT('A follow-up appointment has been scheduled on ', DATE_FORMAT(?, '%M %d, %Y'), '.'),
                           'Appointment'
                    FROM owners o WHERE o.Owner_ID = ?
                ");
                $notice->bind_param("si", $followUpDateTime, $ownerId);
                $notice->execute();
                $notice->close();
            }
        }

        auditLog($conn, $sessionUserId, "Save Vet Consultation", "medical_records", $recordId, ['metadata' => ['vet_id' => $vetId, 'recorded_by_role' => $roleId]]);
        $conn->commit();
        respond(["status" => "success", "record_id" => $recordId, "follow_up_id" => $followUpId]);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log("Error in vet_queue.php save_consultation: " . $e->getMessage());
        respond(["status" => "error", "message" => "Unable to save consultation."], 500);
    }
}

respond(["status" => "error", "message" => "Unknown action."], 400);
