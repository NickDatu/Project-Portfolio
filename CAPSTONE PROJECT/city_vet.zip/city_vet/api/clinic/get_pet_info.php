<?php
require_once '../../config/session.php';
header('Content-Type: application/json; charset=UTF-8');

require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';
require_once '../../config/consultation_template.php';

if (!isset($_SESSION['user_id'], $_SESSION['role_id'])) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit;
}

$roleId = (int)$_SESSION['role_id'];
$userId = (int)$_SESSION['user_id'];
$pet_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($pet_id <= 0) {
    echo json_encode(["status" => "error", "message" => "Invalid Pet ID"]);
    exit;
}

if (!in_array($roleId, [1, 2, 3, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied."]);
    exit;
}

try {
    cityVetEnsureMedicalSchema($conn);
    cityVetEnsureConsultationTemplateSchema($conn);
    cityVetEnsurePanelRevisionSchema($conn);

    if ($roleId === 3) {
        $owner_stmt = $conn->prepare("SELECT Owner_ID FROM owners WHERE User_ID = ? LIMIT 1");
        $owner_stmt->bind_param("i", $userId);
        $owner_stmt->execute();
        $owner_res = $owner_stmt->get_result()->fetch_assoc();
        if (!$owner_res) {
            http_response_code(403);
            echo json_encode(["status" => "error", "message" => "Owner profile not found"]);
            exit;
        }
        $owner_id = (int)$owner_res['Owner_ID'];

        $pet_sql = "SELECT p.*, o.First_name, o.Last_name, o.Contact_number, o.Address, 
                           s.Species_Name, b.Breed_Name
                    FROM pets p
                    JOIN owners o ON p.Owner_ID = o.Owner_ID
                    LEFT JOIN species s ON p.Species_ID = s.Species_ID
                    LEFT JOIN breeds b ON p.Breed_ID = b.Breed_ID
                    WHERE p.Pet_ID = ? AND p.Owner_ID = ? AND p.Status = 'active'";
        $stmt = $conn->prepare($pet_sql);
        $stmt->bind_param("ii", $pet_id, $owner_id);
    } else {
        $pet_sql = "SELECT p.*, o.First_name, o.Last_name, o.Contact_number, o.Address, 
                           s.Species_Name, b.Breed_Name
                    FROM pets p
                    JOIN owners o ON p.Owner_ID = o.Owner_ID
                    LEFT JOIN species s ON p.Species_ID = s.Species_ID
                    LEFT JOIN breeds b ON p.Breed_ID = b.Breed_ID
                    WHERE p.Pet_ID = ? AND p.Status = 'active'";
        $stmt = $conn->prepare($pet_sql);
        $stmt->bind_param("i", $pet_id);
    }

    $stmt->execute();
    $pet_details = $stmt->get_result()->fetch_assoc();

    if (!$pet_details) {
        echo json_encode(["status" => "error", "message" => "Pet not found"]);
        exit;
    }

    $pet_details['Age_Display'] = 'Unknown';
    if (!empty($pet_details['Birthdate'])) {
        $dob = new DateTime($pet_details['Birthdate']);
        $today = new DateTime('today');
        $weeks = max(0, (int)floor(($today->getTimestamp() - $dob->getTimestamp()) / 604800));
        $pet_details['Age_Display'] = $weeks . ($weeks === 1 ? ' week old' : ' weeks old');
    }

    $vetNameSql = "CASE WHEN %s.User_ID IS NULL THEN NULL
                        ELSE COALESCE(NULLIF(CONCAT('Dr. ', TRIM(CONCAT(COALESCE(%s.First_name, ''), ' ', COALESCE(%s.Last_name, '')))), 'Dr. '), %s.Username) END";
    $history_sql = "
        (SELECT m.Visit_Date AS Date, m.Treatment, m.Notes, 'Medical Record' AS Type,
                " . sprintf($vetNameSql, 'vu', 'st', 'st', 'vu') . " AS Vet_Name,
                m.Medicine_Used AS Medicine_Used, m.Medicine_Picture AS Medicine_Picture
         FROM medical_records m
         LEFT JOIN users vu ON vu.User_ID = m.Vet_ID AND vu.Role_ID = 2
         LEFT JOIN staff st ON st.User_ID = m.Vet_ID
         WHERE m.Pet_ID = ? AND (m.is_deleted = 0 OR m.is_deleted IS NULL))
        UNION ALL
        (SELECT c.Consultation_Date AS Date, c.Subject AS Treatment, c.Concern_Description AS Notes, 'Consultation' AS Type,
                " . sprintf($vetNameSql, 'vu2', 'st2', 'st2', 'vu2') . " AS Vet_Name,
                NULL AS Medicine_Used, NULL AS Medicine_Picture
         FROM consultations c
         LEFT JOIN users vu2 ON vu2.User_ID = c.Vet_ID AND vu2.Role_ID = 2
         LEFT JOIN staff st2 ON st2.User_ID = c.Vet_ID
         WHERE c.Pet_ID = ? AND c.Status = 'Completed')
        UNION ALL
        (SELECT DISTINCT COALESCE(ce.Event_Date, DATE(a.Appointment_Date)) AS Date,
                COALESCE(ce.Title, 'Spay/Neuter Event') AS Treatment,
                COALESCE(a.Notes, 'Spay/Neuter completed.') AS Notes,
                'Spay/Neuter' AS Type,
                " . sprintf($vetNameSql, 'vu3', 'st3', 'st3', 'vu3') . " AS Vet_Name,
                NULL AS Medicine_Used, NULL AS Medicine_Picture
         FROM appointments a
         JOIN calendar_events ce ON ce.Event_ID = a.Event_ID
         LEFT JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID
         LEFT JOIN users vu3 ON vu3.User_ID = a.Vet_ID AND vu3.Role_ID = 2
         LEFT JOIN staff st3 ON st3.User_ID = a.Vet_ID
         WHERE (a.Pet_ID = ? OR ap.Pet_ID = ?)
           AND a.Status = 'Completed'
           AND (ce.Event_Type = 'SpayNeuter' OR LOWER(ce.Title) LIKE '%spay%' OR LOWER(ce.Title) LIKE '%neuter%')
           AND NOT EXISTS (
               SELECT 1 FROM medical_records mr WHERE mr.Appointment_ID = a.Appointment_ID AND (mr.is_deleted = 0 OR mr.is_deleted IS NULL)
           ))
        ORDER BY Date DESC";

    $hist_stmt = $conn->prepare($history_sql);
    $hist_stmt->bind_param("iiii", $pet_id, $pet_id, $pet_id, $pet_id);
    $hist_stmt->execute();
    $raw_history = $hist_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $history = [];
    $seen = [];
    foreach ($raw_history as $row) {
        $key = substr((string)$row['Date'], 0, 10) . '|' . strtolower(trim((string)$row['Treatment']));
        if (!isset($seen[$key])) {
            $seen[$key] = true;
            $history[] = $row;
        }
    }
    $findingStmt = $conn->prepare('SELECT m.Visit_Date, m.Treatment, f.Weight_Status, f.Body_Condition_Score, f.Purpose, f.Findings, f.Diagnosis_Text, f.Recommendations FROM medical_records m JOIN consultation_findings f ON f.Record_ID=m.Record_ID WHERE m.Pet_ID=? AND (m.is_deleted=0 OR m.is_deleted IS NULL)');
    $findingStmt->bind_param('i', $pet_id); $findingStmt->execute(); $findingResult=$findingStmt->get_result(); $findingMap=[];
    while($finding=$findingResult->fetch_assoc()) $findingMap[substr((string)$finding['Visit_Date'],0,10).'|'.strtolower(trim((string)$finding['Treatment']))]=['weight_status'=>$finding['Weight_Status'],'body_condition_score'=>$finding['Body_Condition_Score'],'purpose'=>json_decode($finding['Purpose']?:'[]',true),'findings'=>json_decode($finding['Findings']?:'{}',true),'diagnosis'=>$finding['Diagnosis_Text']??'','recommendations'=>$finding['Recommendations']??''];
    $findingStmt->close(); foreach($history as &$historyRow){$key=substr((string)$historyRow['Date'],0,10).'|'.strtolower(trim((string)$historyRow['Treatment']));if(isset($findingMap[$key]))$historyRow['findings']=$findingMap[$key];} unset($historyRow);

    $notes_sql = "SELECT Note_Text, Created_At FROM pet_notes WHERE Pet_ID = ? ORDER BY Created_At DESC";
    $notes_stmt = $conn->prepare($notes_sql);
    $notes_stmt->bind_param("i", $pet_id);
    $notes_stmt->execute();
    $notes_res = $notes_stmt->get_result();
    $notes = [];
    while ($nrow = $notes_res->fetch_assoc()) {
        $nrow['Date_Formatted'] = date("M j, Y", strtotime($nrow['Created_At']));
        $notes[] = $nrow;
    }
    $externalStmt = $conn->prepare("SELECT External_Record_ID, Source_Clinic, Record_Type, Record_Date, Name, Medicine, Dosage, Lot_Number, Provider, Notes, Attachment_Path, Verified_At, Created_At FROM pet_external_records WHERE Pet_ID=? AND Is_Deleted=0 ORDER BY Record_Date DESC, External_Record_ID DESC");
    $externalStmt->bind_param('i', $pet_id);
    $externalStmt->execute();
    $external_records = $externalStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $externalStmt->close();

    echo json_encode([
        "status" => "success",
        "details" => $pet_details,
        "history" => $history,
        "notes" => $notes,
        "external_records" => $external_records
    ]);

} catch (Throwable $e) {
    error_log("Error in get_pet_info.php: " . $e->getMessage());
    echo json_encode(["status" => "error", "message" => "Unable to load pet details."]);
}
