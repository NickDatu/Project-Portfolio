<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../../config/vet_duty.php';
header('Content-Type: application/json; charset=UTF-8');

if (!isset($_SESSION['user_id'], $_SESSION['role_id'])) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized.']);
    exit;
}
if (!in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Access denied.']);
    exit;
}



try {
    $targetDate = cityVetNormalizeDate($_GET['date'] ?? '') ?? date('Y-m-d');
    $vets = [];
    foreach (cityVetGetDutyVets($conn, $targetDate) as $v) {
        $vets[] = ['Vet_ID' => $v['Vet_ID'], 'Vet_Name' => 'Dr. ' . $v['Full_Name']];
    }
    echo json_encode(['status' => 'success', 'date' => $targetDate, 'weekday' => date('l', strtotime($targetDate)), 'vets' => $vets]);
} catch (Throwable $e) {
    error_log('vet_schedule.php: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Unable to load vet schedule.']);
}
