<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';
require_once '../../config/vaccination_rules.php';
header('Content-Type: application/json; charset=UTF-8');

if (!isset($_SESSION['user_id'], $_SESSION['role_id'])) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized.']);
    exit;
}

$allowedRoles = [1, 2, 3, 4];
if (!in_array((int)$_SESSION['role_id'], $allowedRoles, true)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Access denied.']);
    exit;
}

$petId = isset($_GET['pet_id']) ? (int)$_GET['pet_id'] : 0;
if ($petId <= 0) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Pet ID is required.']);
    exit;
}

try {
    cityVetEnsureConsultationTemplateSchema($conn);
    cityVetEnsurePanelRevisionSchema($conn);
    $ownerId = null;
    if ((int)$_SESSION['role_id'] === 3) {
        $ownerStmt = $conn->prepare("SELECT Owner_ID FROM owners WHERE User_ID = ? LIMIT 1");
        $ownerStmt->bind_param('i', $_SESSION['user_id']);
        $ownerStmt->execute();
        $ownerResult = $ownerStmt->get_result();
        if ($ownerResult->num_rows === 0) {
            http_response_code(403);
            echo json_encode(['status' => 'error', 'message' => 'Pet owner record not found.']);
            exit;
        }
        $ownerRow = $ownerResult->fetch_assoc();
        $ownerId = (int)$ownerRow['Owner_ID'];
    }

    $petSql = "SELECT p.Pet_ID, p.Pet_Code, p.Name AS Pet_Name, p.Gender, p.Birthdate, p.Color_Markings, p.Weight, p.Profile_Pic,
                      o.Owner_ID, o.Owner_Code, o.First_name AS Owner_First, o.Last_name AS Owner_Last,
                      o.Address, o.Barangay, o.Contact_number,
                      s.Species_Name, b.Breed_Name
                FROM pets p
                LEFT JOIN owners o ON o.Owner_ID = p.Owner_ID
                LEFT JOIN species s ON s.Species_ID = p.Species_ID
                LEFT JOIN breeds b ON b.Breed_ID = p.Breed_ID
                WHERE p.Pet_ID = ?";
    if ($ownerId !== null) {
        $petSql .= " AND p.Owner_ID = ?";
    }

    $petStmt = $conn->prepare($petSql);
    if ($ownerId !== null) {
        $petStmt->bind_param('ii', $petId, $ownerId);
    } else {
        $petStmt->bind_param('i', $petId);
    }
    $petStmt->execute();
    $petResult = $petStmt->get_result();
    $pet = $petResult->fetch_assoc();

    if (!$pet) {
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => 'Pet not found.']);
        exit;
    }

    $vaccinationSql = "SELECT v.Vaccination_ID, v.Vaccine_Name, v.Date_Administered, v.Next_Due_Date,
                             COALESCE(NULLIF(TRIM(CONCAT(COALESCE(st.First_name, ''), ' ', COALESCE(st.Last_name, ''))), ''), u.Username) AS Vet_Name
                      FROM vaccinations v
                      LEFT JOIN users u ON u.User_ID = v.Vet_ID
                      LEFT JOIN staff st ON st.User_ID = v.Vet_ID
                      WHERE v.Pet_ID = ?
                      ORDER BY v.Date_Administered DESC, v.Vaccination_ID DESC";
    $vaccinationStmt = $conn->prepare($vaccinationSql);
    $vaccinationStmt->bind_param('i', $petId);
    $vaccinationStmt->execute();
    $vaccinationResult = $vaccinationStmt->get_result();
    $vaccinations = [];
    $seen = [];
    $vetLabel = function ($name) {
        $name = trim((string)$name);
        if ($name === '') return 'City Vet Office';
        return stripos($name, 'Dr.') === 0 ? $name : 'Dr. ' . $name;
    };
    $parseMedicine = function ($raw) {
        $medicine = [];
        $dosage = null;
        foreach (array_map('trim', explode('|', (string)$raw)) as $part) {
            if ($part === '') continue;
            if (stripos($part, 'Dosage:') === 0) {
                $value = trim(substr($part, 7));
                if ($value !== '') $dosage = $value;
            } elseif (stripos($part, 'Details:') !== 0) {
                $medicine[] = $part;
            }
        }
        return ['Medicine' => $medicine ? implode(' | ', $medicine) : null, 'Dosage' => $dosage];
    };
    $exactMrStmt = $conn->prepare("SELECT Medicine_Used, Lot_Number FROM medical_records WHERE Pet_ID=? AND (is_deleted=0 OR is_deleted IS NULL) AND DATE(Visit_Date)=? AND LOWER(TRIM(Treatment))=LOWER(TRIM(?)) ORDER BY Record_ID DESC LIMIT 1");
    $sameDayMrStmt = $conn->prepare("SELECT Medicine_Used, Lot_Number FROM medical_records WHERE Pet_ID=? AND (is_deleted=0 OR is_deleted IS NULL) AND DATE(Visit_Date)=? ORDER BY Record_ID DESC LIMIT 1");
    while ($row = $vaccinationResult->fetch_assoc()) {
        $visitDate = substr((string)$row['Date_Administered'], 0, 10);
        $exactMrStmt->bind_param('iss', $petId, $visitDate, $row['Vaccine_Name']);
        $exactMrStmt->execute();
        $match = $exactMrStmt->get_result()->fetch_assoc();
        if (!$match) {
            $sameDayMrStmt->bind_param('is', $petId, $visitDate);
            $sameDayMrStmt->execute();
            $match = $sameDayMrStmt->get_result()->fetch_assoc();
        }
        $parsed = $parseMedicine($match['Medicine_Used'] ?? null);
        $key = strtolower(trim($row['Vaccine_Name'])) . '|' . $row['Date_Administered'];
        $seen[$key] = true;
        $vaccinations[] = [
            'Vaccine_Name' => $row['Vaccine_Name'],
            'Date_Administered' => $row['Date_Administered'],
            'Next_Due_Date' => $row['Next_Due_Date'],
            'Medicine' => $parsed['Medicine'],
            'Dosage' => $parsed['Dosage'],
            'Lot_Number' => $match['Lot_Number'] ?? null,
            'Vet_Name' => $vetLabel($row['Vet_Name'])
        ];
    }
    $vaccinationStmt->close();

        $mrStmt = $conn->prepare("SELECT m.Treatment, DATE(m.Visit_Date) AS Visit_Date, m.Medicine_Used, m.Lot_Number,
                                     COALESCE(NULLIF(TRIM(CONCAT(COALESCE(st.First_name, ''), ' ', COALESCE(st.Last_name, ''))), ''), u.Username) AS Vet_Name
                              FROM medical_records m
                              LEFT JOIN users u ON u.User_ID = m.Vet_ID
                              LEFT JOIN staff st ON st.User_ID = m.Vet_ID
                              WHERE m.Pet_ID = ? AND (m.is_deleted = 0 OR m.is_deleted IS NULL)
                              ORDER BY m.Visit_Date DESC");
    $mrStmt->bind_param('i', $petId);
    $mrStmt->execute();
    $mrResult = $mrStmt->get_result();
    while ($row = $mrResult->fetch_assoc()) {
        $treatment = trim((string)$row['Treatment']);
        if ($treatment === '' || stripos($treatment, 'deworm') !== false) continue;
        if (!preg_match('/vaccin|parvo|rabies|5-in-1|distemper/i', $treatment)) continue;
        $name = preg_replace('/^Other:\s*/i', '', $treatment);
        $key = strtolower($name) . '|' . $row['Visit_Date'];
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $parsed = $parseMedicine($row['Medicine_Used'] ?? null);
        $months = stripos($name, 'parvo') !== false ? 1 : 12;
        $ruleDate = null;
        $petRuleStmt = $conn->prepare('SELECT Species_ID, Birthdate FROM pets WHERE Pet_ID = ? LIMIT 1');
        $petRuleStmt->bind_param('i', $petId); $petRuleStmt->execute(); $petRule = $petRuleStmt->get_result()->fetch_assoc(); $petRuleStmt->close();
        if ($petRule && $petRule['Birthdate']) { $ageWeeks = petAgeInWeeks($petRule['Birthdate'], $row['Visit_Date']); foreach (cityVetRulesForPet($conn, (int)$petRule['Species_ID']) as $rule) { if ((int)$rule['Age_Weeks'] <= (int)$ageWeeks && stripos($rule['Procedure_Name'], 'deworm') === false && stripos($name, explode(' ', $rule['Procedure_Name'])[0]) !== false) { $ruleDate = cityVetNextDueDate($row['Visit_Date'], (int)$rule['Repeat_Value'], $rule['Repeat_Unit']); break; } } }
        $vaccinations[] = [
            'Vaccine_Name' => $name,
            'Date_Administered' => $row['Visit_Date'],
            'Next_Due_Date' => $ruleDate ?: date('Y-m-d', strtotime($row['Visit_Date'] . " +{$months} months")),
            'Medicine' => $parsed['Medicine'],
            'Dosage' => $parsed['Dosage'],
            'Lot_Number' => $row['Lot_Number'] ?? null,
            'Vet_Name' => $vetLabel($row['Vet_Name'])
        ];
    }
    $exactMrStmt->close();
    $sameDayMrStmt->close();
    $mrStmt->close();
    $externalRecords = [];
    $externalStmt = $conn->prepare("SELECT External_Record_ID, Source_Clinic, Record_Type, Record_Date, Name, Medicine, Dosage, Lot_Number, Provider, Notes FROM pet_external_records WHERE Pet_ID=? AND Is_Deleted=0 ORDER BY Record_Date DESC, External_Record_ID DESC");
    $externalStmt->bind_param('i', $petId); $externalStmt->execute(); $externalRecords = $externalStmt->get_result()->fetch_all(MYSQLI_ASSOC); $externalStmt->close();
    usort($vaccinations, function ($a, $b) { return strcmp($b['Date_Administered'], $a['Date_Administered']); });

    $latest = [];
    foreach ($vaccinations as $v) {
        $k = strtolower($v['Vaccine_Name']);
        if (!isset($latest[$k]) && !empty($v['Next_Due_Date'])) $latest[$k] = $v['Next_Due_Date'];
    }
    $validUntil = $latest ? min($latest) : null;
    $lastVet = $vaccinations ? $vaccinations[0]['Vet_Name'] : null;

    $ownerName = trim((string)($pet['Owner_First'] ?? '')) . ' ' . trim((string)($pet['Owner_Last'] ?? ''));
    $ownerName = trim($ownerName) !== '' ? $ownerName : 'Owner';
    $birthDate = $pet['Birthdate'] ? date('Y-m-d', strtotime($pet['Birthdate'])) : null;
    $age = 'Unknown';
    if ($birthDate) {
        $today = new DateTime('today');
        $dob = new DateTime($birthDate);
        $weeks = max(0, (int)floor(($today->getTimestamp() - $dob->getTimestamp()) / 604800));
        $age = $weeks . ' ' . ($weeks === 1 ? 'week' : 'weeks') . ' old';
    }

    echo json_encode([
        'status' => 'success',
        'pet' => [
            'Pet_ID' => (int)$pet['Pet_ID'],
            'Pet_Code' => $pet['Pet_Code'] ?? null,
            'Name' => $pet['Pet_Name'],
            'Species' => $pet['Species_Name'] ?? 'N/A',
            'Breed' => $pet['Breed_Name'] ?? 'N/A',
            'Gender' => $pet['Gender'] ?? 'N/A',
            'Age' => $age,
            'Birthdate' => $birthDate,
            'Color' => $pet['Color_Markings'] ?? 'N/A',
            'Weight' => $pet['Weight'] !== null ? $pet['Weight'] . ' kg' : 'N/A',
            'Owner_Code' => $pet['Owner_Code'] ?? null,
            'Profile_Pic' => $pet['Profile_Pic'] ?? null
        ],
        'owner' => [
            'Name' => $ownerName,
            'Address' => $pet['Address'] ?? 'N/A',
            'Contact_Number' => $pet['Contact_number'] ?? 'N/A',
            'Barangay' => $pet['Barangay'] ?? 'N/A',
        ],
        'vaccinations' => $vaccinations,
        'external_records' => $externalRecords,
        'generated_at' => date('Y-m-d H:i:s'),
        'vet_name' => $lastVet ?? 'City Vet Office',
        'valid_until' => $validUntil
        , 'next_recommended' => cityVetDueProcedures($conn, $petId, date('Y-m-d'))
    ]);
} catch (Throwable $e) {
    error_log('vaccination_record.php: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Unable to load vaccination record.']);
}
