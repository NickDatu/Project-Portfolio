<?php
require_once '../../config/session.php';
header('Content-Type: application/json; charset=UTF-8');

require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';
cityVetEnsurePanelRevisionSchema($conn);

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied."]);
    exit;
}

$query = isset($_GET['query']) ? trim($_GET['query']) : '';
$search = "%" . $query . "%";

$sqlPets = "SELECT p.Pet_ID, p.Pet_Code, p.Name as Pet_Name, p.Owner_ID, p.Birthdate, o.Owner_Code, o.First_name, o.Last_name, s.Species_Name, b.Breed_Name 
            FROM pets p
            JOIN owners o ON p.Owner_ID = o.Owner_ID
            LEFT JOIN species s ON p.Species_ID = s.Species_ID
            LEFT JOIN breeds b ON p.Breed_ID = b.Breed_ID
            WHERE (o.First_name LIKE ? OR o.Last_name LIKE ? OR o.Owner_Code LIKE ? OR CONCAT(o.First_name, ' ', o.Last_name) LIKE ? OR p.Name LIKE ? OR p.Pet_Code LIKE ?)
              AND p.Status = 'active'
            LIMIT 10";

$stmtPets = $conn->prepare($sqlPets);
$stmtPets->bind_param("ssssss", $search, $search, $search, $search, $search, $search);
$stmtPets->execute();
$pets = $stmtPets->get_result()->fetch_all(MYSQLI_ASSOC);

if (!empty($_GET['include_owners'])) {
    $sqlOwners = "SELECT o.Owner_ID, o.Owner_Code, o.First_name, o.Last_name, o.Contact_Number, u.Email, u.Username, o.Status,
                         (SELECT COUNT(*) FROM pets p2 WHERE p2.Owner_ID = o.Owner_ID AND p2.Status = 'active') as Pet_Count
                  FROM owners o
                  JOIN users u ON o.User_ID = u.User_ID
                  WHERE o.First_name LIKE ? OR o.Last_name LIKE ? OR o.Owner_Code LIKE ? OR CONCAT(o.First_name, ' ', o.Last_name) LIKE ? OR u.Email LIKE ? OR u.Username LIKE ? OR o.Contact_Number LIKE ?
                  LIMIT 10";
    $stmtOwners = $conn->prepare($sqlOwners);
    $stmtOwners->bind_param("sssssss", $search, $search, $search, $search, $search, $search, $search);
    $stmtOwners->execute();
    $owners = $stmtOwners->get_result()->fetch_all(MYSQLI_ASSOC);

    echo json_encode([
        "status" => "success",
        "pets" => $pets,
        "owners" => $owners
    ]);
    exit;
}

echo json_encode($pets);
