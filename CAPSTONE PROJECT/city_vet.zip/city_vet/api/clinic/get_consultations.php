<?php
require_once '../../config/session.php';
header('Content-Type: application/json; charset=UTF-8');

require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';
require_once '../../config/consultation_template.php';

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied."]);
    exit;
}

try {
    
    cityVetEnsureMedicalSchema($conn);
    cityVetEnsureConsultationTemplateSchema($conn);

    $vetId = (int)($_GET['vet_id'] ?? 0);
    $petId = (int)($_GET['pet_id'] ?? 0);
    $dateFrom = trim($_GET['date_from'] ?? '');
    $dateTo = trim($_GET['date_to'] ?? '');

    foreach ([$dateFrom, $dateTo] as $date) {
        if ($date !== '' && (!DateTime::createFromFormat('Y-m-d', $date) || DateTime::createFromFormat('Y-m-d', $date)->format('Y-m-d') !== $date)) {
            http_response_code(422);
            echo json_encode(["status" => "error", "message" => "Dates must use YYYY-MM-DD format."]);
            exit;
        }
    }

    $sql = "SELECT m.Record_ID AS Consultation_ID, m.Visit_Date, m.Treatment, m.Notes AS Symptoms,
                   m.Medicine_Used, m.Medicine_Picture, m.Vet_ID, p.Pet_ID, p.Name AS Pet_Name,
                   f.Weight_Status, f.Body_Condition_Score, f.Purpose AS Findings_Purpose, f.Findings AS Findings_Data, f.Diagnosis_Text, f.Recommendations,
                   CONCAT(o.First_name, ' ', o.Last_name) AS Owner_Name,
                   CASE WHEN vu.User_ID IS NULL OR vu.Role_ID <> 2 THEN 'Staff (no vet assigned)'
                        ELSE COALESCE(NULLIF(CONCAT('Dr. ', TRIM(CONCAT(COALESCE(st.First_name, ''), ' ', COALESCE(st.Last_name, '')))), 'Dr. '), vu.Username, 'Unknown veterinarian')
                   END AS Vet_Name
            FROM medical_records m
            JOIN pets p ON m.Pet_ID = p.Pet_ID AND p.Status != 'archived'
            JOIN owners o ON p.Owner_ID = o.Owner_ID
            LEFT JOIN users vu ON m.Vet_ID = vu.User_ID
            LEFT JOIN staff st ON st.User_ID = m.Vet_ID
            LEFT JOIN consultation_findings f ON f.Record_ID = m.Record_ID
            WHERE (m.is_deleted = 0 OR m.is_deleted IS NULL)
              AND (? = 0 OR m.Vet_ID = ?)
              AND (? = '' OR DATE(m.Visit_Date) >= ?)
              AND (? = '' OR DATE(m.Visit_Date) <= ?)
              AND (? = 0 OR m.Pet_ID = ?)
            UNION ALL
            (SELECT a.Appointment_ID AS Consultation_ID,
                    COALESCE(ce.Event_Date, DATE(a.Appointment_Date)) AS Visit_Date,
                    COALESCE(ce.Title, 'Spay/Neuter Event') AS Treatment,
                    COALESCE(a.Notes, 'Spay/Neuter completed.') AS Symptoms,
                    NULL AS Medicine_Used,
                    NULL AS Medicine_Picture,
                    a.Vet_ID,
                    p.Pet_ID,
                    p.Name AS Pet_Name,
                    NULL AS Weight_Status,
                    NULL AS Body_Condition_Score,
                    NULL AS Findings_Purpose,
                    NULL AS Findings_Data,
                    NULL AS Diagnosis_Text,
                    NULL AS Recommendations,
                    CONCAT(o.First_name, ' ', o.Last_name) AS Owner_Name,
                    CASE WHEN vu2.User_ID IS NULL OR vu2.Role_ID <> 2 THEN 'Staff (no vet assigned)'
                         ELSE COALESCE(NULLIF(CONCAT('Dr. ', TRIM(CONCAT(COALESCE(st2.First_name, ''), ' ', COALESCE(st2.Last_name, '')))), 'Dr. '), vu2.Username, 'Unknown veterinarian')
                    END AS Vet_Name
             FROM appointments a
             JOIN calendar_events ce ON ce.Event_ID = a.Event_ID
             LEFT JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID
             JOIN pets p ON p.Pet_ID = COALESCE(ap.Pet_ID, a.Pet_ID) AND p.Status != 'archived'
             JOIN owners o ON p.Owner_ID = o.Owner_ID
             LEFT JOIN users vu2 ON a.Vet_ID = vu2.User_ID
             LEFT JOIN staff st2 ON st2.User_ID = a.Vet_ID
             WHERE a.Status = 'Completed'
               AND (ce.Event_Type = 'SpayNeuter' OR LOWER(ce.Title) LIKE '%spay%' OR LOWER(ce.Title) LIKE '%neuter%')
               AND (? = 0 OR a.Vet_ID = ?)
               AND (? = '' OR DATE(COALESCE(ce.Event_Date, a.Appointment_Date)) >= ?)
               AND (? = '' OR DATE(COALESCE(ce.Event_Date, a.Appointment_Date)) <= ?)
               AND NOT EXISTS (
                   SELECT 1 FROM medical_records mr
                   WHERE mr.Appointment_ID = a.Appointment_ID
                     AND mr.Pet_ID = p.Pet_ID
                     AND (mr.is_deleted = 0 OR mr.is_deleted IS NULL)
               ))
            ORDER BY Visit_Date DESC";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iissssiiiissss", $vetId, $vetId, $dateFrom, $dateFrom, $dateTo, $dateTo, $petId, $petId, $vetId, $vetId, $dateFrom, $dateFrom, $dateTo, $dateTo);
    $stmt->execute();
    $result = $stmt->get_result();
    $records = [];

    while($row = $result->fetch_assoc()) {
        $row['findings'] = $row['Findings_Data'] ? ['weight_status' => $row['Weight_Status'], 'body_condition_score' => $row['Body_Condition_Score'] !== null ? (int)$row['Body_Condition_Score'] : null, 'purpose' => json_decode($row['Findings_Purpose'] ?: '[]', true), 'findings' => json_decode($row['Findings_Data'] ?: '{}', true), 'diagnosis' => $row['Diagnosis_Text'] ?? '', 'recommendations' => $row['Recommendations'] ?? ''] : null;
        $records[] = $row;
    }

    $todayRes = $conn->query("SELECT COUNT(*) as count FROM medical_records WHERE DATE(Visit_Date) = CURDATE() AND (is_deleted = 0 OR is_deleted IS NULL)");
    $today = $todayRes ? $todayRes->fetch_assoc() : ['count' => 0];
    
    $totalRes = $conn->query("SELECT COUNT(*) as count FROM medical_records WHERE is_deleted = 0 OR is_deleted IS NULL");
    $total = $totalRes ? $totalRes->fetch_assoc() : ['count' => 0];

    $vetsRes = $conn->query("SELECT u.User_ID AS Vet_ID, CONCAT('Dr. ', s.First_name, ' ', s.Last_name) AS Vet_Name FROM users u JOIN staff s ON s.User_ID = u.User_ID WHERE u.Role_ID = 2 AND u.Status = 'active' AND s.Status = 'active' ORDER BY s.First_name, s.Last_name");
    $vets = [];
    while ($vet = $vetsRes->fetch_assoc()) {
        $vets[] = $vet;
    }

    echo json_encode([
        "status" => "success",
        "today" => (int)$today['count'],
        "total" => (int)$total['count'],
        "records" => $records,
        "vets" => $vets
    ]);

} catch (Throwable $e) {
    error_log("Error in get_consultations.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(["status" => "error", "success" => false, "message" => "Unable to load consultations. Please contact the administrator if this keeps happening."]);
}
