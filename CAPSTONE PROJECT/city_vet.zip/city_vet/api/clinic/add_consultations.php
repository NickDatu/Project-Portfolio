<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../system/audit_helper.php';
require_once __DIR__ . '/consultation_catalog_helper.php';

header('Content-Type: application/json; charset=UTF-8');

require_once dirname(__DIR__, 2) . '/config/vet_duty.php';


function getScheduledVetForDateTime($conn, $dateValue, $timeValue = null) {
    return cityVetGetDutyVetId($conn, $dateValue);
}

function isVetScheduledForDateTime($conn, $vetId, $dateValue, $timeValue = null): bool {
    return cityVetIsVetOnDuty($conn, (int)$vetId, $dateValue);
}

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied."]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();

    $rawInput = file_get_contents("php://input");
    $jsonData = (!empty($rawInput)) ? json_decode($rawInput, true) : null;

    $owner_id = (int)($_POST['owner_id'] ?? ($jsonData['owner_id'] ?? 0));
    $pet_id = (int)($_POST['pet_id'] ?? ($jsonData['pet_id'] ?? 0));
    $treatmentSelection = cityVetResolveTreatmentSelection($conn, is_array($jsonData) ? $jsonData : $_POST);
    $subject = $treatmentSelection['value'];
    $description = trim($_POST['symptoms'] ?? ($jsonData['symptoms'] ?? ($_POST['notes'] ?? ($jsonData['notes'] ?? ($_POST['description'] ?? ($jsonData['description'] ?? ''))))));
    $medicineSelection = cityVetResolveMedicineSelection($conn, is_array($jsonData) ? $jsonData : $_POST);
    $medicineUsed = $medicineSelection['value'];
    $medicinePicture = trim($_POST['medicine_picture'] ?? ($jsonData['medicine_picture'] ?? ''));
    $visitDate = trim($_POST['visit_date'] ?? ($jsonData['visit_date'] ?? ($_POST['date'] ?? ($jsonData['date'] ?? date('Y-m-d')))));
    $visitTime = trim($_POST['visit_time'] ?? ($jsonData['visit_time'] ?? ($_POST['time'] ?? ($jsonData['time'] ?? ''))));

    
    
    $vet_id = 0;
    if ((int)$_SESSION['role_id'] === 2) {
        $vet_id = (int)$_SESSION['user_id'];
    } else {
        $vet_id = (int)getScheduledVetForDateTime($conn, $visitDate, $visitTime);
    }

    if (!$owner_id || !$pet_id || $treatmentSelection['error']) {
        http_response_code(422);
        echo json_encode(["status" => "error", "message" => $treatmentSelection['error'] ?: "Owner, pet, and treatment subject are required."]);
        exit();
    }
    if ($medicineSelection['error']) {
        http_response_code(422);
        echo json_encode(["status" => "error", "message" => $medicineSelection['error']]);
        exit();
    }

    if ($vet_id <= 0) {
        echo json_encode(["status" => "error", "message" => "No veterinarian is scheduled for the selected date."]);
        exit();
    }


    if (strlen($medicinePicture) > 255) {
        http_response_code(422);
        echo json_encode(["status" => "error", "message" => "Medicine picture must be 255 characters or fewer."]);
        exit();
    }

    $checkPet = $conn->prepare("SELECT Pet_ID FROM pets WHERE Pet_ID = ? AND Owner_ID = ? AND Status != 'archived' LIMIT 1");
    $checkPet->bind_param("ii", $pet_id, $owner_id);
    $checkPet->execute();
    if ($checkPet->get_result()->num_rows === 0) {
        $checkPet->close();
        echo json_encode(["status" => "error", "message" => "Pet does not belong to owner or is archived."]);
        exit();
    }
    $checkPet->close();

    $sql = "INSERT INTO medical_records (Pet_ID, Vet_ID, Treatment, Notes, Visit_Date, Medicine_Used, Medicine_Picture)
            VALUES (?, ?, ?, ?, NOW(), NULLIF(?, ''), NULLIF(?, ''))";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iissss", $pet_id, $vet_id, $subject, $description, $medicineUsed, $medicinePicture);

    if ($stmt->execute()) {
        $conId = (int)$conn->insert_id;
        auditLog($conn, (int)$_SESSION['user_id'], 'Create Medical Record', 'medical_records', $conId, [
            'metadata' => ['owner_id' => (int)$owner_id, 'pet_id' => (int)$pet_id, 'vet_id' => $vet_id]
        ]);
        echo json_encode(["status" => "success", "message" => "Consultation recorded!"]);
    } else {
        error_log("Error in add_consultations.php: " . $stmt->error);
        echo json_encode(["status" => "error", "message" => "Unable to record consultation."]);
    }
    $stmt->close();
}
