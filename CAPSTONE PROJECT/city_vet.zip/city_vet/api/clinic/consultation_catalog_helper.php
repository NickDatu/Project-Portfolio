<?php

function cityVetCleanConsultationOther($value, string $label): array {
    if (!is_string($value)) {
        return ['value' => '', 'error' => "{$label} must be text."];
    }

    $value = trim(strip_tags($value));
    $value = preg_replace('/[\x00-\x1F\x7F]/u', '', $value);
    if ($value === '' || mb_strlen($value) > 120) {
        return ['value' => '', 'error' => "{$label} must be between 1 and 120 characters."];
    }

    return ['value' => $value, 'error' => null];
}

function cityVetResolveTreatmentSelection(mysqli $conn, array $input): array {
    $selection = $input['treatment_id'] ?? '';
    if ($selection === 'other') {
        $other = cityVetCleanConsultationOther($input['treatment_other'] ?? '', 'Other treatment');
        return ['value' => $other['error'] ? '' : 'Other: ' . $other['value'], 'error' => $other['error']];
    }

    if (!is_scalar($selection) || !preg_match('/^[1-9][0-9]*$/', (string)$selection)) {
        return ['value' => '', 'error' => 'Select a valid treatment.'];
    }

    $treatmentId = (int)$selection;
    $stmt = $conn->prepare("SELECT Treatment_Name FROM treatment_catalog WHERE Treatment_ID = ? AND Status = 'active' LIMIT 1");
    $stmt->bind_param('i', $treatmentId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row) {
        return ['value' => '', 'error' => 'The selected treatment is invalid or inactive.'];
    }

    return ['value' => $row['Treatment_Name'], 'error' => null];
}

function cityVetResolveServiceSelection(mysqli $conn, array $input): array {
    $selection = $input['service_id'] ?? '';
    if (!is_scalar($selection) || !preg_match('/^[1-9][0-9]*$/', (string)$selection)) {
        return ['value' => '', 'error' => 'Select a valid service.'];
    }

    $serviceId = (int)$selection;
    $stmt = $conn->prepare("SELECT Service_Name FROM services WHERE Service_ID = ? AND Status = 'active' AND LOWER(Service_Name) NOT LIKE '%spay%' AND LOWER(Service_Name) NOT LIKE '%neuter%' LIMIT 1");
    $stmt->bind_param('i', $serviceId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row) {
        return ['value' => '', 'error' => 'The selected service is invalid or inactive.'];
    }

    return ['value' => $row['Service_Name'], 'error' => null];
}

function cityVetResolveMedicineSelection(mysqli $conn, array $input): array {
    $selections = $input['medicine_ids'] ?? [];
    if (!is_array($selections) || count($selections) > 20) {
        return ['value' => '', 'error' => 'Select valid medicines.'];
    }

    $labels = [];
    $seen = [];
    $includeOther = false;
    $stmt = $conn->prepare("SELECT Medicine_Name FROM medicine_catalog WHERE Medicine_ID = ? AND Status = 'active' LIMIT 1");

    foreach ($selections as $selection) {
        if ($selection === 'other') {
            if ($includeOther) {
                $stmt->close();
                return ['value' => '', 'error' => 'The Other medicine option can only be selected once.'];
            }
            $includeOther = true;
            continue;
        }

        if (!is_scalar($selection) || !preg_match('/^[1-9][0-9]*$/', (string)$selection)) {
            $stmt->close();
            return ['value' => '', 'error' => 'Select valid medicines.'];
        }

        $medicineId = (int)$selection;
        if (isset($seen[$medicineId])) {
            $stmt->close();
            return ['value' => '', 'error' => 'Duplicate medicines are not allowed.'];
        }
        $seen[$medicineId] = true;

        $stmt->bind_param('i', $medicineId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        if (!$row) {
            $stmt->close();
            return ['value' => '', 'error' => 'A selected medicine is invalid or inactive.'];
        }
        $labels[] = $row['Medicine_Name'];
    }
    $stmt->close();

    $otherValue = $input['medicine_other'] ?? '';
    if ($includeOther) {
        $other = cityVetCleanConsultationOther($otherValue, 'Other medicine');
        if ($other['error']) {
            return ['value' => '', 'error' => $other['error']];
        }
        $labels[] = 'Other: ' . $other['value'];
    } elseif (is_string($otherValue) && trim($otherValue) !== '') {
        return ['value' => '', 'error' => 'Select Other to enter a custom medicine.'];
    }

    $value = implode('; ', $labels);
    if (mb_strlen($value) > 1000) {
        return ['value' => '', 'error' => 'Selected medicines must not exceed 1000 characters.'];
    }

    return ['value' => $value, 'error' => null];
}
