<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../../config/vet_duty.php';
header('Content-Type: application/json; charset=UTF-8');


if (!isset($_SESSION['user_id'], $_SESSION['role_id'])) {
    http_response_code(401);
    echo json_encode(["status" => "error", "success" => false, "message" => "Unauthorized."]);
    exit;
}
if (!in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "success" => false, "message" => "Access denied."]);
    exit;
}



try {
    $vets = [];
    // Veterinarian assignment lists all active registered veterinarians.
    // Duty schedules are not used to filter this dropdown.
    foreach (cityVetListActiveVets($conn) as $v) {
        $vets[] = ["Vet_ID" => $v['Vet_ID'], "Vet_Name" => 'Dr. ' . $v['Full_Name']];
    }
    echo json_encode(["status" => "success", "success" => true, "vets" => $vets, "data" => ["vets" => $vets]]);
} catch (Throwable $e) {
    error_log('get_vets.php: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(["status" => "error", "success" => false, "message" => "Unable to load veterinarians."]);
}
