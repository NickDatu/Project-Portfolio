<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../../config/vet_duty.php';
require_once '../../config/schema_ensure.php';
require_once '../system/audit_helper.php';
header('Content-Type: application/json; charset=UTF-8');

function dutyRespond(array $payload, int $code = 200): void {
    http_response_code($code);
    $payload['success'] = ($payload['status'] ?? '') === 'success';
    echo json_encode($payload);
    exit;
}

if (!isset($_SESSION['user_id'], $_SESSION['role_id'])) {
    dutyRespond(['status' => 'error', 'message' => 'Unauthorized.'], 401);
}
$roleId = (int)$_SESSION['role_id'];
$userId = (int)$_SESSION['user_id'];

if (!in_array($roleId, [1, 2, 4], true)) {
    dutyRespond(['status' => 'error', 'message' => 'Access denied.'], 403);
}

$conn->set_charset('utf8mb4');
cityVetEnsureDutySchema($conn);
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

try {
    if ($method === 'GET') {
        $month = trim((string)($_GET['month'] ?? date('Y-m')));
        if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $month)) {
            dutyRespond(['status' => 'error', 'message' => 'Invalid month.'], 422);
        }
        $start = $month . '-01';
        $end = date('Y-m-t', strtotime($start));

        $stmt = $conn->prepare(
            "SELECT d.Duty_Date, u.User_ID AS Vet_ID,
                    COALESCE(NULLIF(TRIM(CONCAT(COALESCE(s.First_name, ''), ' ', COALESCE(s.Last_name, ''))), ''), u.Username) AS Full_Name,
                    u.Status AS User_Status
             FROM vet_duty_schedule d
             JOIN users u ON u.User_ID = d.Vet_User_ID
             LEFT JOIN staff s ON s.User_ID = u.User_ID
             WHERE d.Duty_Date BETWEEN ? AND ?
             ORDER BY d.Duty_Date ASC, Full_Name ASC"
        );
        $stmt->bind_param('ss', $start, $end);
        $stmt->execute();
        $res = $stmt->get_result();
        $byDate = [];
        while ($row = $res->fetch_assoc()) {
            $byDate[$row['Duty_Date']][] = ['Vet_ID' => (int)$row['Vet_ID'], 'Vet_Name' => 'Dr. ' . trim($row['Full_Name']), 'Active' => $row['User_Status'] === 'active'];
        }
        $stmt->close();

        $days = [];
        $daysInMonth = (int)date('t', strtotime($start));
        for ($d = 1; $d <= $daysInMonth; $d++) {
            $date = sprintf('%s-%02d', $month, $d);
            $days[] = [
                'date' => $date,
                'weekday' => date('D', strtotime($date)),
                'is_weekend' => in_array(date('N', strtotime($date)), ['6', '7'], true),
                'vets' => $byDate[$date] ?? [],
            ];
        }

        $vets = [];
        if ($roleId !== 2) {
            foreach (cityVetListActiveVets($conn) as $v) {
                $vets[] = ['Vet_ID' => $v['Vet_ID'], 'Vet_Name' => 'Dr. ' . trim($v['Full_Name'])];
            }
        }
        dutyRespond([
            'status' => 'success',
            'month' => $month,
            'has_schedule' => !empty($byDate),
            'days' => $days,
            'vets' => $vets,
            'can_edit' => in_array($roleId, [1, 4], true),
            'today' => date('Y-m-d'),
        ]);
    }

    if ($method !== 'POST') {
        dutyRespond(['status' => 'error', 'message' => 'Method not allowed.'], 405);
    }
    if (!in_array($roleId, [1, 4], true)) {
        dutyRespond(['status' => 'error', 'message' => 'Only staff or admin can change the schedule.'], 403);
    }
    requireCsrf();

    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $action = (string)($input['action'] ?? '');

    
    if ($action === 'import' || $action === 'preview') {
        $month = trim((string)($input['month'] ?? ''));
        if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $month)) {
            dutyRespond(['status' => 'error', 'message' => 'Choose the month this schedule is for.'], 422);
        }
        $text = (string)($input['text'] ?? '');
        if (trim($text) === '' || strlen($text) > 200000) {
            dutyRespond(['status' => 'error', 'message' => 'Paste the schedule text first.'], 422);
        }

        $parsed = cityVetParseDutyText($text, $month);
        $vets = cityVetListActiveVets($conn);
        $rows = [];        
        $preview = [];
        $problems = [];
        foreach ($parsed as $date => $names) {
            if (substr($date, 0, 7) !== $month) {
                $problems[] = "$date is outside $month and was skipped.";
                continue;
            }
            $entry = ['date' => $date, 'weekday' => date('D', strtotime($date)), 'vets' => [], 'unmatched' => []];
            foreach ($names as $printed) {
                $vet = cityVetMatchVetByName($vets, $printed);
                if ($vet) {
                    $entry['vets'][] = ['Vet_ID' => $vet['Vet_ID'], 'Vet_Name' => 'Dr. ' . trim($vet['Full_Name']), 'printed' => $printed];
                    $rows[$date . '|' . $vet['Vet_ID']] = [$date, $vet['Vet_ID']];
                } else {
                    $entry['unmatched'][] = $printed;
                }
            }
            $preview[] = $entry;
        }
        $unmatchedNames = [];
        foreach ($preview as $e) foreach ($e['unmatched'] as $n) $unmatchedNames[$n] = true;

        if (!$preview) {
            dutyRespond(['status' => 'error', 'message' => 'No schedule lines were recognised. Use one line per day, e.g. "2026-10-01, Dr. Xandrah Mae J. Brua".'], 422);
        }

        if ($action === 'preview') {
            dutyRespond([
                'status' => 'success',
                'preview' => $preview,
                'matched_rows' => count($rows),
                'unmatched_names' => array_keys($unmatchedNames),
                'problems' => $problems,
            ]);
        }

        
        if ($unmatchedNames) {
            dutyRespond([
                'status' => 'error',
                'message' => 'Some names do not match a veterinarian account: ' . implode('; ', array_keys($unmatchedNames)) . '. Create or correct those accounts, then import again.',
                'unmatched_names' => array_keys($unmatchedNames),
            ], 422);
        }

        $conn->begin_transaction();
        try {
            $start = $month . '-01';
            $end = date('Y-m-t', strtotime($start));
            $del = $conn->prepare("DELETE FROM vet_duty_schedule WHERE Duty_Date BETWEEN ? AND ?");
            $del->bind_param('ss', $start, $end);
            $del->execute();
            $del->close();

            $ins = $conn->prepare("INSERT INTO vet_duty_schedule (Duty_Date, Vet_User_ID, Created_By) VALUES (?, ?, ?)");
            foreach ($rows as [$date, $vetId]) {
                $ins->bind_param('sii', $date, $vetId, $userId);
                $ins->execute();
            }
            $ins->close();
            $conn->commit();
        } catch (Throwable $e) {
            $conn->rollback();
            error_log('vet_duty_schedule import: ' . $e->getMessage());
            dutyRespond(['status' => 'error', 'message' => 'Unable to save the schedule.'], 500);
        }
        auditLog($conn, $userId, 'Import Vet Duty Schedule', 'vet_duty_schedule', 0, ['metadata' => ['month' => $month, 'entries' => count($rows)]]);
        dutyRespond(['status' => 'success', 'message' => 'Schedule for ' . date('F Y', strtotime($month . '-01')) . ' saved (' . count($rows) . ' duty assignments).', 'entries' => count($rows)]);
    }

    
    if ($action === 'set_day') {
        $date = cityVetNormalizeDate($input['date'] ?? '');
        if ($date === null) dutyRespond(['status' => 'error', 'message' => 'Invalid date.'], 422);
        $vetIds = array_values(array_unique(array_filter(array_map('intval', (array)($input['vet_ids'] ?? [])), fn($v) => $v > 0)));
        foreach ($vetIds as $vid) {
            if (!cityVetGetActiveVet($conn, $vid)) {
                dutyRespond(['status' => 'error', 'message' => 'One of the selected veterinarians is invalid or inactive.'], 422);
            }
        }
        $conn->begin_transaction();
        try {
            $del = $conn->prepare("DELETE FROM vet_duty_schedule WHERE Duty_Date = ?");
            $del->bind_param('s', $date);
            $del->execute();
            $del->close();
            $ins = $conn->prepare("INSERT INTO vet_duty_schedule (Duty_Date, Vet_User_ID, Created_By) VALUES (?, ?, ?)");
            foreach ($vetIds as $vid) {
                $ins->bind_param('sii', $date, $vid, $userId);
                $ins->execute();
            }
            $ins->close();
            $conn->commit();
        } catch (Throwable $e) {
            $conn->rollback();
            error_log('vet_duty_schedule set_day: ' . $e->getMessage());
            dutyRespond(['status' => 'error', 'message' => 'Unable to update that day.'], 500);
        }
        auditLog($conn, $userId, 'Update Vet Duty Day', 'vet_duty_schedule', 0, ['metadata' => ['date' => $date, 'vet_ids' => $vetIds]]);
        dutyRespond(['status' => 'success', 'message' => 'Day updated.']);
    }

    dutyRespond(['status' => 'error', 'message' => 'Unknown action.'], 422);
} catch (Throwable $e) {
    error_log('vet_duty_schedule.php: ' . $e->getMessage());
    dutyRespond(['status' => 'error', 'message' => 'Unable to process the schedule request.'], 500);
}
