<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../system/audit_helper.php';

header('Content-Type: application/json; charset=UTF-8');

function respond($payload, $code = 200) {
    http_response_code($code);
    echo json_encode($payload);
    exit();
}

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    respond(["status" => "error", "message" => "Access denied."], 403);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(["status" => "error", "message" => "Method not allowed."], 405);
}

requireCsrf();

$file = $_FILES['medicine_picture'] ?? null;
if (!$file || $file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) {
    respond(["status" => "error", "message" => "No valid image was uploaded."], 422);
}

if ($file['size'] > 5 * 1024 * 1024) {
    respond(["status" => "error", "message" => "Image file size must not exceed 5MB."], 422);
}

$info = @getimagesize($file['tmp_name']);
$extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
$mime = is_array($info) ? ($info['mime'] ?? '') : '';
if (!isset($extensions[$mime])) {
    respond(["status" => "error", "message" => "Invalid image type. Only JPG, PNG, WEBP, and GIF are allowed."], 422);
}

$dir = dirname(__DIR__, 2) . '/uploads/medicine';
if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
    respond(["status" => "error", "message" => "Unable to store image."], 500);
}

$name = bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) {
    respond(["status" => "error", "message" => "Unable to store image."], 500);
}

auditLog($conn, (int)$_SESSION['user_id'], 'Upload Medicine Picture', 'medical_records', 0);
respond(["status" => "success", "path" => 'uploads/medicine/' . $name]);
