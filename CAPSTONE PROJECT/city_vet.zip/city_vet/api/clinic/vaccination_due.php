<?php
require_once '../../config/session.php'; require_once '../../config/db_connection.php'; require_once '../../config/schema_ensure.php'; require_once '../../config/vaccination_rules.php';
header('Content-Type: application/json; charset=UTF-8');
if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1,2,4], true)) { http_response_code(403); echo json_encode(['status'=>'error','message'=>'Access denied.']); exit; }
cityVetEnsureConsultationTemplateSchema($conn); $petId=(int)($_GET['pet_id']??0); if($petId<=0){http_response_code(422);echo json_encode(['status'=>'error','message'=>'Pet ID is required.']);exit;}
echo json_encode(['status'=>'success','due'=>cityVetDueProcedures($conn,$petId,date('Y-m-d'))]);
