<?php
require_once '../../config/session.php';
ini_set('display_errors', 0);
header("Content-Type: application/json; charset=UTF-8");

require_once '../../config/db_connection.php';

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied"]);
    exit();
}

$sql = "SELECT 
            a.Appointment_ID, 
            a.Appointment_Date, 
            a.Status,
            a.Notes,
            p.Pet_ID,
            p.Name AS Pet_Name,
            p.Gender,
            p.Weight,
            o.First_name AS Owner_First,
            o.Last_name AS Owner_Last,
            o.Contact_number,
            o.Address,
            s.Species_Name,
            b.Breed_Name,
            srv.Service_Name
        FROM appointments a
        INNER JOIN pets p ON a.Pet_ID = p.Pet_ID AND p.Status != 'archived'
        INNER JOIN owners o ON a.Owner_ID = o.Owner_ID
        LEFT JOIN species s ON p.Species_ID = s.Species_ID
        LEFT JOIN breeds b ON p.Breed_ID = b.Breed_ID
        LEFT JOIN services srv ON a.Service_ID = srv.Service_ID
        WHERE a.Status = 'Pending' 
        ORDER BY a.Appointment_Date DESC";

$result = $conn->query($sql);

$appointments = [];
if ($result) {
    while($row = $result->fetch_assoc()) {
        if (!empty($row['Appointment_Date'])) {
            $phpdate = strtotime($row['Appointment_Date']);
            $row['Appointment_Date'] = date('M j, Y - g:i A', $phpdate);
        }
        if (empty($row['Service_Name'])) {
            $row['Service_Name'] = 'Spay/Neuter';
        }
        $appointments[] = $row;
    }
    echo json_encode($appointments);
} else {
    error_log("Error in vet_get_pending.php: " . $conn->error);
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Unable to load pending appointments."]);
}
