<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../system/audit_helper.php';
header('Content-Type: application/json; charset=UTF-8');

$method = $_SERVER['REQUEST_METHOD'];
$action = $_POST['action'] ?? ($_GET['action'] ?? '');
$readOnlyActions = ['get_species', 'get_breeds'];

if (!in_array($action, $readOnlyActions, true) && $method !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Method not allowed. POST required."]);
    exit();
}

if (!in_array($action, $readOnlyActions, true)) {
    requireCsrf();
    if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 1) {
        http_response_code(403);
        echo json_encode(["status" => "error", "message" => "Access denied. Administrators only."]);
        exit();
    }
}

try {
    if (!$conn) {
        throw new Exception("Database connection failed.");
    }

    if ($action == 'get_species') {
        $where = isset($_GET['all']) ? "WHERE Species_Name IN ('Dog', 'Cat')" : "WHERE Status = 'active' AND Species_Name IN ('Dog', 'Cat')";
        $result = $conn->query("SELECT * FROM species $where ORDER BY Species_Name ASC");
        echo json_encode($result->fetch_all(MYSQLI_ASSOC));
        exit();
    } 

    if ($action == 'get_breeds') {
        $where = isset($_GET['all']) ? "WHERE s.Species_Name IN ('Dog', 'Cat')" : "WHERE b.Status = 'active' AND s.Species_Name IN ('Dog', 'Cat')";
        $sql = "SELECT b.Breed_ID, b.Breed_Name, b.Status, s.Species_Name, b.Species_ID 
                FROM breeds b 
                INNER JOIN species s ON b.Species_ID = s.Species_ID 
                $where
                ORDER BY b.Breed_Name ASC";
        $result = $conn->query($sql);
        echo json_encode($result->fetch_all(MYSQLI_ASSOC));
        exit();
    }

    if ($action == 'save_species') {
        $name = trim($_POST['item_name'] ?? '');
        if (!in_array($name, ['Dog', 'Cat'], true)) {
            http_response_code(422);
            echo json_encode(["status" => "error", "message" => "Only Dog and Cat species are supported."]);
            exit();
        }
        $stmt = $conn->prepare("INSERT INTO species (Species_Name, Status) VALUES (?, 'active')");
        $stmt->bind_param("s", $name);
        if ($stmt->execute()) {
            auditLog($conn, (int)$_SESSION['user_id'], 'Create Species', 'species', (int)$conn->insert_id, ['metadata' => ['name' => $name]]);
            echo json_encode(["status" => "success"]);
        } else {
            error_log("Error in save_species: " . $stmt->error);
            echo json_encode(["status" => "error", "message" => "Unable to save species."]);
        }
        exit();
    }

    if ($action == 'save_breed') {
        $name = trim($_POST['item_name'] ?? '');
        $s_id = (int)($_POST['Species_ID'] ?? 0);
        if ($name === '' || !$s_id) {
            echo json_encode(["status" => "error", "message" => "Breed name and species are required."]);
            exit();
        }
        $spChk = $conn->prepare("SELECT Species_ID FROM species WHERE Species_ID = ? AND Species_Name IN ('Dog', 'Cat') AND Status = 'active'");
        $spChk->bind_param("i", $s_id);
        $spChk->execute();
        if ($spChk->get_result()->num_rows === 0) {
            http_response_code(422);
            echo json_encode(["status" => "error", "message" => "Breeds can only be added for Dog or Cat."]);
            exit();
        }
        $spChk->close();
        $stmt = $conn->prepare("INSERT INTO breeds (Breed_Name, Species_ID, Status) VALUES (?, ?, 'active')");
        $stmt->bind_param("si", $name, $s_id);
        if ($stmt->execute()) {
            auditLog($conn, (int)$_SESSION['user_id'], 'Create Breed', 'breeds', (int)$conn->insert_id, ['metadata' => ['name' => $name, 'species_id' => $s_id]]);
            echo json_encode(["status" => "success"]);
        } else {
            error_log("Error in save_breed: " . $stmt->error);
            echo json_encode(["status" => "error", "message" => "Unable to save breed."]);
        }
        exit();
    }

    if ($action === 'delete_species') {
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) {
            echo json_encode(["status" => "error", "message" => "Species ID is required."]);
            exit();
        }
        $stmt = $conn->prepare("UPDATE species SET Status = 'inactive' WHERE Species_ID = ? AND Status = 'active'");
        $stmt->bind_param("i", $id);
        if ($stmt->execute() && $stmt->affected_rows === 1) {
            auditLog($conn, (int)$_SESSION['user_id'], 'Archive Species', 'species', $id);
            echo json_encode(["status" => "success"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Species not found or already inactive."]);
        }
        $stmt->close();
        exit();
    }

    if ($action === 'delete_breed') {
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) {
            echo json_encode(["status" => "error", "message" => "Breed ID is required."]);
            exit();
        }
        $stmt = $conn->prepare("UPDATE breeds SET Status = 'inactive' WHERE Breed_ID = ? AND Status = 'active'");
        $stmt->bind_param("i", $id);
        if ($stmt->execute() && $stmt->affected_rows === 1) {
            auditLog($conn, (int)$_SESSION['user_id'], 'Archive Breed', 'breeds', $id);
            echo json_encode(["status" => "success"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Breed not found or already inactive."]);
        }
        $stmt->close();
        exit();
    }

    if ($action === 'restore_species') {
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) {
            echo json_encode(["status" => "error", "message" => "Species ID is required."]);
            exit();
        }
        $stmt = $conn->prepare("UPDATE species SET Status = 'active' WHERE Species_ID = ? AND Status = 'inactive' AND Species_Name IN ('Dog', 'Cat')");
        $stmt->bind_param("i", $id);
        if ($stmt->execute() && $stmt->affected_rows === 1) {
            auditLog($conn, (int)$_SESSION['user_id'], 'Restore Species', 'species', $id);
            echo json_encode(["status" => "success"]);
        } else {
            http_response_code(422);
            echo json_encode(["status" => "error", "message" => "Only Dog and Cat species can be restored."]);
        }
        $stmt->close();
        exit();
    }

    if ($action === 'restore_breed') {
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) {
            echo json_encode(["status" => "error", "message" => "Breed ID is required."]);
            exit();
        }
        $stmt = $conn->prepare("UPDATE breeds SET Status = 'active' WHERE Breed_ID = ? AND Status = 'inactive'");
        $stmt->bind_param("i", $id);
        if ($stmt->execute() && $stmt->affected_rows === 1) {
            auditLog($conn, (int)$_SESSION['user_id'], 'Restore Breed', 'breeds', $id);
            echo json_encode(["status" => "success"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Breed not found or already active."]);
        }
        $stmt->close();
        exit();
    }

} catch (Throwable $e) {
    error_log("Exception in manage_species_breeds.php: " . $e->getMessage());
    echo json_encode(["status" => "error", "message" => "An error occurred while managing species or breeds."]);
}
