<?php












require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../system/audit_helper.php';
require_once '../../config/schema_ensure.php';
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');

function lqRespond(bool $success, string $message, $data = null, int $code = 200): void {
    http_response_code($code);
    $payload = [
        'success' => $success,
        'status'  => $success ? 'success' : 'error',
        'message' => $message,
    ];
    if ($data !== null) {
        $payload['data'] = $data;
    }
    echo json_encode($payload);
    exit();
}

set_exception_handler(function ($e) {
    error_log('live_queue.php unhandled: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    lqRespond(false, 'Unable to process the live queue request.', null, 500);
});


if (!isset($_SESSION['user_id'], $_SESSION['role_id'])) {
    lqRespond(false, 'Please log in again.', null, 401);
}
$userId = (int)$_SESSION['user_id'];
$roleId = (int)$_SESSION['role_id'];
if (!in_array($roleId, [1, 4], true)) {
    auditLog($conn, $userId, 'Unauthorized Live Queue Access', 'live_queue_tickets', 0, [
        'event_type' => 'security',
        'outcome' => 'denied'
    ]);
    lqRespond(false, 'Access denied. Only staff can manage the live queue.', null, 403);
}

$conn->set_charset('utf8mb4');
cityVetEnsureLiveQueueSchema($conn);

$SESSION_DATE = date('Y-m-d');


function lqTicketLabel(array $t): string {
    return sprintf('%s #%03d', $t['Service_Name'], (int)$t['Ticket_Number']);
}

function lqFormat(array $t): array {
    $owner = trim(($t['First_name'] ?? '') . ' ' . ($t['Last_name'] ?? ''));
    return [
        'Ticket_ID'        => (int)$t['Ticket_ID'],
        'Ticket_Number'    => (int)$t['Ticket_Number'],
        'Ticket_Label'     => lqTicketLabel($t),
        'Service_Code'     => $t['Service_Code'],
        'Service_Name'     => $t['Service_Name'],
        'Owner_ID'         => $t['Owner_ID'] !== null ? (int)$t['Owner_ID'] : null,
        'Owner_Label'      => $t['Owner_ID'] !== null ? 'Pet Owner #' . (int)$t['Owner_ID'] : 'Walk-in',
        'Owner_Name'       => $owner !== '' ? $owner : trim((string)($t['Note'] ?? '')),
        'Note'             => $t['Note'] ?? null,
        'Contact_number'   => $t['Contact_number'] ?? null,
        'Pet_ID'           => $t['Pet_ID'] !== null ? (int)$t['Pet_ID'] : null,
        'Pet_Name'         => $t['Pet_Name'] ?? null,
        'Status'           => $t['Status'],
        'Recall_Count'     => (int)$t['Recall_Count'],
        'Created_At'       => $t['Created_At'],
        'Called_At'        => $t['Called_At'],
        'Serving_At'       => $t['Serving_At'],
        'Completed_At'     => $t['Completed_At'],
        'Last_Recalled_At' => $t['Last_Recalled_At'],
    ];
}

const LQ_SELECT = "SELECT t.*, s.Service_Name, o.First_name, o.Last_name, o.Contact_number, p.Name AS Pet_Name
                   FROM live_queue_tickets t
                   JOIN live_queue_services s ON s.Service_Code = t.Service_Code
                   LEFT JOIN owners o ON o.Owner_ID = t.Owner_ID
                   LEFT JOIN pets p ON p.Pet_ID = t.Pet_ID";

function lqFetchTicket(mysqli $conn, int $ticketId, bool $forUpdate = false): ?array {
    $sql = LQ_SELECT . " WHERE t.Ticket_ID = ? LIMIT 1" . ($forUpdate ? " FOR UPDATE" : "");
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $ticketId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}

function lqState(mysqli $conn, string $sessionDate): array {
    $stmt = $conn->prepare(LQ_SELECT . " WHERE t.Session_Date = ? ORDER BY t.Ticket_ID DESC");
    $stmt->bind_param('s', $sessionDate);
    $stmt->execute();
    $res = $stmt->get_result();

    $current = null;
    $waiting = [];
    $completed = [];
    $skipped = [];
    $counts = ['Waiting' => 0, 'Called' => 0, 'Serving' => 0, 'Completed' => 0, 'Skipped' => 0, 'Cancelled' => 0];

    while ($row = $res->fetch_assoc()) {
        $counts[$row['Status']] = ($counts[$row['Status']] ?? 0) + 1;
        $t = lqFormat($row);
        switch ($row['Status']) {
            case 'Called':
            case 'Serving':
                $current = $t;
                break;
            case 'Waiting':
                $waiting[] = $t;
                break;
            case 'Completed':
                $completed[] = $t;
                break;
            case 'Skipped':
                $skipped[] = $t;
                break;
        }
    }
    $stmt->close();

    usort($completed, function ($a, $b) {
        return strcmp((string)$b['Completed_At'], (string)$a['Completed_At']);
    });

    $services = [];
    $sRes = $conn->query("SELECT Service_Code, Service_Name FROM live_queue_services WHERE Status = 'active' ORDER BY Sort_Order ASC, Service_Name ASC");
    while ($s = $sRes->fetch_assoc()) {
        $services[] = $s;
    }

    $allServices = [];
    $aRes = $conn->query("SELECT s.Service_Code, s.Service_Name, s.Sort_Order, s.Status,
                                  (SELECT COUNT(*) FROM live_queue_tickets t WHERE t.Service_Code = s.Service_Code) AS Ticket_Count
                           FROM live_queue_services s ORDER BY s.Sort_Order ASC, s.Service_Name ASC");
    while ($s = $aRes->fetch_assoc()) {
        $allServices[] = $s;
    }

    return [
        'all_services' => $allServices,
        'session_date' => $sessionDate,
        'current'      => $current,
        'waiting'      => $waiting,
        'completed'    => $completed,
        'skipped'      => $skipped,
        'counts'       => $counts,
        'services'     => $services,
    ];
}

function lqLockOrFail(mysqli $conn): void {
    $res = $conn->query("SELECT GET_LOCK('city_vet_live_queue', 5) AS got");
    $row = $res ? $res->fetch_assoc() : null;
    if (!$row || (int)$row['got'] !== 1) {
        lqRespond(false, 'The queue is busy. Please try again.', null, 409);
    }
}

function lqUnlock(mysqli $conn): void {
    $conn->query("SELECT RELEASE_LOCK('city_vet_live_queue')");
}


if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $mode = $_GET['mode'] ?? 'state';

    if ($mode === 'state') {
        lqRespond(true, 'Queue loaded.', lqState($conn, $SESSION_DATE));
    }

    if ($mode === 'owners') {
        $q = trim((string)($_GET['q'] ?? ''));
        if (mb_strlen($q) > 100) $q = mb_substr($q, 0, 100);
        $like = '%' . $q . '%';
        $idQ = ctype_digit($q) ? (int)$q : 0;
        $stmt = $conn->prepare(
            "SELECT Owner_ID, First_name, Last_name, Contact_number
             FROM owners
             WHERE Status = 'active'
               AND (? = '' OR CONCAT(First_name, ' ', Last_name) LIKE ? OR Contact_number LIKE ? OR (? > 0 AND Owner_ID = ?))
             ORDER BY Last_name ASC, First_name ASC
             LIMIT 15"
        );
        $stmt->bind_param('sssii', $q, $like, $like, $idQ, $idQ);
        $stmt->execute();
        $owners = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        lqRespond(true, 'Owners loaded.', ['owners' => $owners]);
    }

    if ($mode === 'pets') {
        $ownerId = (int)($_GET['owner_id'] ?? 0);
        if ($ownerId <= 0) lqRespond(false, 'Owner is required.', null, 422);
        $stmt = $conn->prepare(
            "SELECT p.Pet_ID, p.Name, sp.Species_Name
             FROM pets p LEFT JOIN species sp ON sp.Species_ID = p.Species_ID
             WHERE p.Owner_ID = ? AND p.Status = 'active'
             ORDER BY p.Name ASC"
        );
        $stmt->bind_param('i', $ownerId);
        $stmt->execute();
        $pets = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        lqRespond(true, 'Pets loaded.', ['pets' => $pets]);
    }

    lqRespond(false, 'Unknown mode.', null, 400);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    lqRespond(false, 'Invalid request method.', null, 405);
}

requireCsrf();

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) $input = $_POST;
$action = (string)($input['action'] ?? '');


if ($action === 'create_ticket') {
    
    $ownerId = (int)($input['owner_id'] ?? 0);
    $petId = (int)($input['pet_id'] ?? 0);
    $serviceCode = strtoupper(trim((string)($input['service_code'] ?? '')));
    $note = trim((string)($input['note'] ?? ''));
    if (mb_strlen($note) > 100) $note = mb_substr($note, 0, 100);
    $noteParam = $note !== '' ? $note : null;

    if ($serviceCode === '') {
        lqRespond(false, 'Please select a service.', null, 422);
    }

    $ownerParam = null;
    if ($ownerId > 0) {
        $stmt = $conn->prepare("SELECT Owner_ID FROM owners WHERE Owner_ID = ? AND Status = 'active' LIMIT 1");
        $stmt->bind_param('i', $ownerId);
        $stmt->execute();
        $ownerOk = (bool)$stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$ownerOk) lqRespond(false, 'Pet owner not found or inactive.', null, 422);
        $ownerParam = $ownerId;
    }

    $stmt = $conn->prepare("SELECT Service_Code FROM live_queue_services WHERE Service_Code = ? AND Status = 'active' LIMIT 1");
    $stmt->bind_param('s', $serviceCode);
    $stmt->execute();
    $serviceOk = (bool)$stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$serviceOk) lqRespond(false, 'Selected service is not available.', null, 422);

    $petParam = null;
    if ($petId > 0 && $ownerParam !== null) {
        $stmt = $conn->prepare("SELECT Pet_ID FROM pets WHERE Pet_ID = ? AND Owner_ID = ? AND Status = 'active' LIMIT 1");
        $stmt->bind_param('ii', $petId, $ownerId);
        $stmt->execute();
        $petOk = (bool)$stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$petOk) lqRespond(false, 'Selected pet does not belong to this owner.', null, 422);
        $petParam = $petId;
    }

    $conn->begin_transaction();
    try {
        
        
        $ins = $conn->prepare("INSERT IGNORE INTO live_queue_counters (Session_Date, Service_Code, Last_Number) VALUES (?, ?, 0)");
        $ins->bind_param('ss', $SESSION_DATE, $serviceCode);
        $ins->execute();
        $ins->close();

        $sel = $conn->prepare("SELECT Last_Number FROM live_queue_counters WHERE Session_Date = ? AND Service_Code = ? FOR UPDATE");
        $sel->bind_param('ss', $SESSION_DATE, $serviceCode);
        $sel->execute();
        $counter = $sel->get_result()->fetch_assoc();
        $sel->close();
        $next = (int)($counter['Last_Number'] ?? 0) + 1;

        $upd = $conn->prepare("UPDATE live_queue_counters SET Last_Number = ? WHERE Session_Date = ? AND Service_Code = ?");
        $upd->bind_param('iss', $next, $SESSION_DATE, $serviceCode);
        $upd->execute();
        $upd->close();

        $tk = $conn->prepare(
            "INSERT INTO live_queue_tickets (Session_Date, Service_Code, Ticket_Number, Owner_ID, Pet_ID, Note, Status, Created_By)
             VALUES (?, ?, ?, ?, ?, ?, 'Waiting', ?)"
        );
        $tk->bind_param('ssiiisi', $SESSION_DATE, $serviceCode, $next, $ownerParam, $petParam, $noteParam, $userId);
        $tk->execute();
        $ticketId = (int)$conn->insert_id;
        $tk->close();

        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('live_queue create_ticket: ' . $e->getMessage());
        lqRespond(false, 'Unable to create queue ticket.', null, 500);
    }

    auditLog($conn, $userId, 'Create Live Queue Ticket', 'live_queue_tickets', $ticketId, ['metadata' => ['service' => $serviceCode, 'ticket_number' => $next, 'owner_id' => $ownerParam]]);
    $ticket = lqFormat(lqFetchTicket($conn, $ticketId));
    lqRespond(true, 'Ticket created successfully', ['ticket' => $ticket], 201);
}


if (in_array($action, ['add_service', 'rename_service', 'toggle_service', 'delete_service'], true)) {
    if ($action === 'add_service') {
        $name = trim(preg_replace('/\s+/', ' ', (string)($input['service_name'] ?? '')));
        if ($name === '' || mb_strlen($name) > 60) {
            lqRespond(false, 'Enter a service name (up to 60 characters).', null, 422);
        }
        $name = mb_convert_case($name, MB_CASE_TITLE, 'UTF-8');
        $dup = $conn->prepare("SELECT Service_Code FROM live_queue_services WHERE LOWER(Service_Name) = LOWER(?) LIMIT 1");
        $dup->bind_param('s', $name);
        $dup->execute();
        $exists = (bool)$dup->get_result()->fetch_assoc();
        $dup->close();
        if ($exists) lqRespond(false, 'That service already exists.', null, 409);

        $base = strtoupper(preg_replace('/[^A-Za-z0-9]+/', '_', $name));
        $base = trim($base, '_');
        $base = substr($base !== '' ? $base : 'SERVICE', 0, 16);
        $code = $base;
        $i = 1;
        $chk = $conn->prepare("SELECT 1 FROM live_queue_services WHERE Service_Code = ? LIMIT 1");
        while (true) {
            $chk->bind_param('s', $code);
            $chk->execute();
            if (!$chk->get_result()->fetch_assoc()) break;
            $i++;
            $code = substr($base, 0, 16) . '_' . $i;
        }
        $chk->close();

        $mx = $conn->query("SELECT COALESCE(MAX(Sort_Order), 0) AS m FROM live_queue_services WHERE Sort_Order < 99")->fetch_assoc();
        $sort = (int)($mx['m'] ?? 0) + 1;
        $ins = $conn->prepare("INSERT INTO live_queue_services (Service_Code, Service_Name, Sort_Order, Status) VALUES (?, ?, ?, 'active')");
        $ins->bind_param('ssi', $code, $name, $sort);
        $ins->execute();
        $ins->close();
        auditLog($conn, $userId, 'Add Live Queue Service', 'live_queue_services', 0, ['metadata' => ['code' => $code, 'name' => $name]]);
        lqRespond(true, 'Service added.', ['services' => lqState($conn, $SESSION_DATE)['all_services']], 201);
    }

    $code = strtoupper(trim((string)($input['service_code'] ?? '')));
    $stmt = $conn->prepare("SELECT Service_Code, Service_Name, Status FROM live_queue_services WHERE Service_Code = ? LIMIT 1");
    $stmt->bind_param('s', $code);
    $stmt->execute();
    $svc = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$svc) lqRespond(false, 'Service not found.', null, 404);

    if ($action === 'rename_service') {
        $name = trim(preg_replace('/\s+/', ' ', (string)($input['service_name'] ?? '')));
        if ($name === '' || mb_strlen($name) > 60) lqRespond(false, 'Enter a service name (up to 60 characters).', null, 422);
        $name = mb_convert_case($name, MB_CASE_TITLE, 'UTF-8');
        $dup = $conn->prepare("SELECT 1 FROM live_queue_services WHERE LOWER(Service_Name) = LOWER(?) AND Service_Code <> ? LIMIT 1");
        $dup->bind_param('ss', $name, $code);
        $dup->execute();
        $exists = (bool)$dup->get_result()->fetch_assoc();
        $dup->close();
        if ($exists) lqRespond(false, 'Another service already uses that name.', null, 409);
        $u = $conn->prepare("UPDATE live_queue_services SET Service_Name = ? WHERE Service_Code = ?");
        $u->bind_param('ss', $name, $code);
        $u->execute();
        $u->close();
        auditLog($conn, $userId, 'Rename Live Queue Service', 'live_queue_services', 0, ['metadata' => ['code' => $code, 'name' => $name]]);
        lqRespond(true, 'Service renamed.', ['services' => lqState($conn, $SESSION_DATE)['all_services']]);
    }

    if ($action === 'toggle_service') {
        $new = $svc['Status'] === 'active' ? 'inactive' : 'active';
        $u = $conn->prepare("UPDATE live_queue_services SET Status = ? WHERE Service_Code = ?");
        $u->bind_param('ss', $new, $code);
        $u->execute();
        $u->close();
        auditLog($conn, $userId, ($new === 'active' ? 'Enable' : 'Disable') . ' Live Queue Service', 'live_queue_services', 0, ['metadata' => ['code' => $code]]);
        lqRespond(true, 'Service ' . ($new === 'active' ? 'enabled.' : 'disabled.'), ['services' => lqState($conn, $SESSION_DATE)['all_services']]);
    }

    
    $c = $conn->prepare("SELECT COUNT(*) AS c FROM live_queue_tickets WHERE Service_Code = ?");
    $c->bind_param('s', $code);
    $c->execute();
    $used = (int)($c->get_result()->fetch_assoc()['c'] ?? 0);
    $c->close();
    if ($used > 0) lqRespond(false, 'This service already has tickets. Disable it instead of deleting.', null, 409);
    $d = $conn->prepare("DELETE FROM live_queue_services WHERE Service_Code = ?");
    $d->bind_param('s', $code);
    $d->execute();
    $d->close();
    auditLog($conn, $userId, 'Delete Live Queue Service', 'live_queue_services', 0, ['metadata' => ['code' => $code]]);
    lqRespond(true, 'Service deleted.', ['services' => lqState($conn, $SESSION_DATE)['all_services']]);
}


if ($action === 'call_next') {
    $serviceCode = strtoupper(trim((string)($input['service_code'] ?? '')));

    lqLockOrFail($conn);
    try {
        $stmt = $conn->prepare("SELECT t.Ticket_ID, s.Service_Name, t.Ticket_Number FROM live_queue_tickets t JOIN live_queue_services s ON s.Service_Code = t.Service_Code WHERE t.Session_Date = ? AND t.Status IN ('Called','Serving') LIMIT 1");
        $stmt->bind_param('s', $SESSION_DATE);
        $stmt->execute();
        $active = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($active) {
            lqUnlock($conn);
            lqRespond(false, 'Finish or skip ' . lqTicketLabel($active) . ' before calling the next ticket.', null, 409);
        }

        if ($serviceCode !== '') {
            $stmt = $conn->prepare("SELECT Ticket_ID FROM live_queue_tickets WHERE Session_Date = ? AND Status = 'Waiting' AND Service_Code = ? ORDER BY Ticket_ID DESC LIMIT 1");
            $stmt->bind_param('ss', $SESSION_DATE, $serviceCode);
        } else {
            $stmt = $conn->prepare("SELECT Ticket_ID FROM live_queue_tickets WHERE Session_Date = ? AND Status = 'Waiting' ORDER BY Ticket_ID DESC LIMIT 1");
            $stmt->bind_param('s', $SESSION_DATE);
        }
        $stmt->execute();
        $next = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$next) {
            lqUnlock($conn);
            lqRespond(false, 'No tickets are waiting.', null, 404);
        }

        $ticketId = (int)$next['Ticket_ID'];
        $upd = $conn->prepare("UPDATE live_queue_tickets SET Status = 'Called', Called_At = NOW(), Handled_By = ? WHERE Ticket_ID = ? AND Status = 'Waiting'");
        $upd->bind_param('ii', $userId, $ticketId);
        $upd->execute();
        $changed = $upd->affected_rows === 1;
        $upd->close();
        lqUnlock($conn);
    } catch (Throwable $e) {
        lqUnlock($conn);
        error_log('live_queue call_next: ' . $e->getMessage());
        lqRespond(false, 'Unable to call the next ticket.', null, 500);
    }

    if (!$changed) lqRespond(false, 'Ticket was already called. Please refresh.', null, 409);
    auditLog($conn, $userId, 'Call Next Live Queue Ticket', 'live_queue_tickets', $ticketId);
    lqRespond(true, 'Now calling next ticket.', ['ticket' => lqFormat(lqFetchTicket($conn, $ticketId))]);
}


$ticketActions = ['call_ticket', 'mark_serving', 'complete', 'skip', 'recall', 'requeue', 'cancel'];
if (in_array($action, $ticketActions, true)) {
    $ticketId = (int)($input['ticket_id'] ?? 0);
    if ($ticketId <= 0) lqRespond(false, 'Ticket is required.', null, 422);

    lqLockOrFail($conn);
    try {
        $conn->begin_transaction();
        $ticket = lqFetchTicket($conn, $ticketId, true);
        if (!$ticket) {
            $conn->rollback();
            lqUnlock($conn);
            lqRespond(false, 'Ticket not found.', null, 404);
        }
        if ($ticket['Session_Date'] !== $SESSION_DATE) {
            $conn->rollback();
            lqUnlock($conn);
            lqRespond(false, 'This ticket belongs to a previous queue session.', null, 422);
        }

        $status = $ticket['Status'];
        $sql = null;
        $message = '';
        $auditName = '';

        switch ($action) {
            case 'call_ticket':
                if ($status !== 'Waiting') { $sql = false; $message = 'Only waiting tickets can be called.'; break; }
                $chk = $conn->prepare("SELECT COUNT(*) AS c FROM live_queue_tickets WHERE Session_Date = ? AND Status IN ('Called','Serving')");
                $chk->bind_param('s', $SESSION_DATE);
                $chk->execute();
                $busy = (int)($chk->get_result()->fetch_assoc()['c'] ?? 0);
                $chk->close();
                if ($busy > 0) { $sql = false; $message = 'Finish or skip the current ticket first.'; break; }
                $sql = "UPDATE live_queue_tickets SET Status = 'Called', Called_At = NOW(), Handled_By = ? WHERE Ticket_ID = ? AND Status = 'Waiting'";
                $message = 'Ticket called.'; $auditName = 'Call Live Queue Ticket';
                break;
            case 'mark_serving':
                if ($status !== 'Called') { $sql = false; $message = 'Only a called ticket can be marked as serving.'; break; }
                $sql = "UPDATE live_queue_tickets SET Status = 'Serving', Serving_At = NOW(), Handled_By = ? WHERE Ticket_ID = ? AND Status = 'Called'";
                $message = 'Ticket is now being served.'; $auditName = 'Serve Live Queue Ticket';
                break;
            case 'complete':
                if (!in_array($status, ['Called', 'Serving'], true)) { $sql = false; $message = 'Only the current ticket can be completed.'; break; }
                $sql = "UPDATE live_queue_tickets SET Status = 'Completed', Completed_At = NOW(), Handled_By = ? WHERE Ticket_ID = ? AND Status IN ('Called','Serving')";
                $message = 'Ticket completed.'; $auditName = 'Complete Live Queue Ticket';
                break;
            case 'skip':
                if (!in_array($status, ['Waiting', 'Called', 'Serving'], true)) { $sql = false; $message = 'This ticket cannot be skipped.'; break; }
                $sql = "UPDATE live_queue_tickets SET Status = 'Skipped', Handled_By = ? WHERE Ticket_ID = ? AND Status IN ('Waiting','Called','Serving')";
                $message = 'Ticket skipped.'; $auditName = 'Skip Live Queue Ticket';
                break;
            case 'recall':
                if (!in_array($status, ['Called', 'Serving'], true)) { $sql = false; $message = 'Only the current ticket can be recalled.'; break; }
                $sql = "UPDATE live_queue_tickets SET Recall_Count = Recall_Count + 1, Last_Recalled_At = NOW(), Handled_By = ? WHERE Ticket_ID = ? AND Status IN ('Called','Serving')";
                $message = 'Ticket recalled.'; $auditName = 'Recall Live Queue Ticket';
                break;
            case 'requeue':
                if ($status !== 'Skipped') { $sql = false; $message = 'Only skipped tickets can be put back in the queue.'; break; }
                $sql = "UPDATE live_queue_tickets SET Status = 'Waiting', Handled_By = ? WHERE Ticket_ID = ? AND Status = 'Skipped'";
                $message = 'Ticket returned to the waiting list.'; $auditName = 'Requeue Live Queue Ticket';
                break;
            case 'cancel':
                if (!in_array($status, ['Waiting', 'Skipped'], true)) { $sql = false; $message = 'Only waiting or skipped tickets can be cancelled.'; break; }
                $sql = "UPDATE live_queue_tickets SET Status = 'Cancelled', Handled_By = ? WHERE Ticket_ID = ? AND Status IN ('Waiting','Skipped')";
                $message = 'Ticket cancelled.'; $auditName = 'Cancel Live Queue Ticket';
                break;
        }

        if ($sql === false) {
            $conn->rollback();
            lqUnlock($conn);
            lqRespond(false, $message, null, 422);
        }

        $upd = $conn->prepare($sql);
        $upd->bind_param('ii', $userId, $ticketId);
        $upd->execute();
        $changed = $upd->affected_rows === 1;
        $upd->close();
        if (!$changed) {
            $conn->rollback();
            lqUnlock($conn);
            lqRespond(false, 'Ticket changed while you were working. Please refresh.', null, 409);
        }
        $conn->commit();
        lqUnlock($conn);
    } catch (Throwable $e) {
        $conn->rollback();
        lqUnlock($conn);
        error_log('live_queue ' . $action . ': ' . $e->getMessage());
        lqRespond(false, 'Unable to update the ticket.', null, 500);
    }

    auditLog($conn, $userId, $auditName, 'live_queue_tickets', $ticketId);
    lqRespond(true, $message, ['ticket' => lqFormat(lqFetchTicket($conn, $ticketId))]);
}

lqRespond(false, 'Unknown action.', null, 400);
