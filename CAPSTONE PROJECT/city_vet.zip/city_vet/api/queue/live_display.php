<?php






require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';
date_default_timezone_set('Asia/Manila');
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, max-age=0');

function lqDisplayRespond(bool $success, string $message, $data = null, int $code = 200): void {
    http_response_code($code);
    $payload = ['success' => $success, 'status' => $success ? 'success' : 'error', 'message' => $message];
    if ($data !== null) $payload['data'] = $data;
    echo json_encode($payload);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    lqDisplayRespond(false, 'Read-only endpoint.', null, 405);
}

try {
    $conn->set_charset('utf8mb4');
    cityVetEnsureLiveQueueSchema($conn);
    $today = date('Y-m-d');

    $stmt = $conn->prepare(
        "SELECT t.Ticket_ID, t.Ticket_Number, t.Owner_ID, t.Status, t.Recall_Count, t.Called_At, t.Last_Recalled_At, s.Service_Name
         FROM live_queue_tickets t
         JOIN live_queue_services s ON s.Service_Code = t.Service_Code
         WHERE t.Session_Date = ? AND t.Status IN ('Waiting','Called','Serving','Completed')
         ORDER BY t.Ticket_ID DESC"
    );
    $stmt->bind_param('s', $today);
    $stmt->execute();
    $res = $stmt->get_result();

    $fmt = function ($r) {
        return [
            'ticket_number' => (int)$r['Ticket_Number'],
            'ticket_label'  => sprintf('#%03d', (int)$r['Ticket_Number']),
            'service'       => $r['Service_Name'],
            'owner_label'   => $r['Owner_ID'] !== null ? 'Pet Owner #' . (int)$r['Owner_ID'] : '',
            'status'        => $r['Status'],
        ];
    };

    $now = null;
    $nowKey = '';
    $waiting = [];
    $recent = [];
    $waitingTotal = 0;
    while ($r = $res->fetch_assoc()) {
        if ($r['Status'] === 'Called' || $r['Status'] === 'Serving') {
            $now = $fmt($r);
            
            $nowKey = $r['Ticket_ID'] . ':' . $r['Status'] . ':' . $r['Recall_Count'];
        } elseif ($r['Status'] === 'Waiting') {
            $waitingTotal++;
            if (count($waiting) < 12) $waiting[] = $fmt($r);
        } else {
            $recent[] = $fmt($r);
        }
    }
    $stmt->close();
    $recent = array_slice(array_reverse($recent), 0, 5);

    lqDisplayRespond(true, 'OK', [
        'now_serving'   => $now,
        'announce_key'  => $nowKey,
        'waiting'       => $waiting,
        'waiting_total' => $waitingTotal,
        'recently_done' => $recent,
        'server_time'   => date('c'),
    ]);
} catch (Throwable $e) {
    error_log('live_display.php: ' . $e->getMessage());
    lqDisplayRespond(false, 'Display feed unavailable.', null, 500);
}
