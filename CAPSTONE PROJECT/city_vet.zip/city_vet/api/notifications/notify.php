<?php
require_once dirname(__DIR__, 2) . '/config/notification_config.php';

function smtpConfigReady() {
    return defined('SMTP_USERNAME') && defined('SMTP_PASSWORD') && SMTP_USERNAME !== '' && SMTP_PASSWORD !== '' && SMTP_PASSWORD !== 'PASTE_YOUR_GMAIL_APP_PASSWORD_HERE';
}

function notificationConfigReady($value, $placeholder) {
    return !empty($value) && $value !== $placeholder;
}

function postJson($url, $headers, $payload) {
    if (!function_exists('curl_init')) {
        return ["sent" => false, "message" => "PHP cURL extension is not enabled."];
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_TIMEOUT => 20
    ]);

    $body = curl_exec($ch);
    $error = curl_error($ch);
    $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($body === false || $error) {
        return ["sent" => false, "message" => $error ?: "Connection failed."];
    }

    return [
        "sent" => $statusCode >= 200 && $statusCode < 300,
        "message" => $body,
        "status_code" => $statusCode
    ];
}

function postForm($url, $payload) {
    if (!function_exists('curl_init')) {
        return ["sent" => false, "message" => "PHP cURL extension is not enabled."];
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($payload),
        CURLOPT_TIMEOUT => 20
    ]);

    $body = curl_exec($ch);
    $error = curl_error($ch);
    $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($body === false || $error) {
        return ["sent" => false, "message" => $error ?: "Connection failed."];
    }

    return [
        "sent" => $statusCode >= 200 && $statusCode < 300,
        "message" => $body,
        "status_code" => $statusCode
    ];
}

function sendResendEmail($to, $subject, $plainMessage, $htmlMessage = null) {
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return ["sent" => false, "message" => "Invalid recipient email."];
    }

    if (smtpConfigReady()) {
        $autoload = dirname(__DIR__, 2) . '/vendor/autoload.php';
        if (file_exists($autoload)) {
            require_once $autoload;
            try {
                $mailer = new \PHPMailer\PHPMailer\PHPMailer(true);
                $mailer->isSMTP();
                $mailer->Host = SMTP_HOST;
                $mailer->SMTPAuth = true;
                $mailer->Username = SMTP_USERNAME;
                $mailer->Password = SMTP_PASSWORD;
                $mailer->Port = (int)SMTP_PORT;
                if (strtolower((string)SMTP_ENCRYPTION) === 'ssl') {
                    $mailer->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
                } else {
                    $mailer->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                }
                $mailer->setFrom(SMTP_FROM_EMAIL ?: SMTP_USERNAME, SMTP_FROM_NAME);
                $mailer->addAddress($to);
                $mailer->Subject = $subject;
                $mailer->Body = $htmlMessage ?: nl2br(htmlspecialchars($plainMessage, ENT_QUOTES, 'UTF-8'));
                $mailer->AltBody = $plainMessage;
                $mailer->isHTML((bool)$htmlMessage);
                $mailer->send();
                return ["sent" => true, "message" => "Email sent via SMTP."];
            } catch (Throwable $e) {
                error_log('SMTP email failed: ' . $e->getMessage());
                return ["sent" => false, "message" => "SMTP email could not be sent."];
            }
        }
    }

    if (!notificationConfigReady(RESEND_API_KEY, 'PASTE_RESEND_API_KEY_HERE')) {
        return ["sent" => false, "message" => "No email provider is configured."];
    }

    $payload = [
        "from" => RESEND_FROM_EMAIL,
        "to" => [$to],
        "subject" => $subject,
        "text" => $plainMessage
    ];

    if ($htmlMessage) {
        $payload["html"] = $htmlMessage;
    }

    return postJson(
        'https://api.resend.com/emails',
        [
            'Authorization: Bearer ' . RESEND_API_KEY,
            'Content-Type: application/json'
        ],
        $payload
    );
}

function normalizePhilippineMobile($phone) {
    $digits = preg_replace('/\D+/', '', $phone ?? '');
    if (strlen($digits) === 11 && substr($digits, 0, 2) === '09') {
        return '63' . substr($digits, 1);
    }
    if (strlen($digits) === 12 && substr($digits, 0, 2) === '63') {
        return $digits;
    }
    return $digits;
}

function sendIprogSms($phone, $message) {
    if (defined('IPROG_SMS_ENABLED') && !IPROG_SMS_ENABLED) {
        return ["sent" => false, "message" => "IPROG SMS is temporarily disabled."];
    }

    $number = normalizePhilippineMobile($phone);
    if (!$number || strlen($number) < 10) {
        return ["sent" => false, "message" => "Invalid mobile number."];
    }

    if (!notificationConfigReady(IPROG_API_TOKEN, 'PASTE_YOUR_IPROG_API_TOKEN_HERE')) {
        return ["sent" => false, "message" => "IPROG API token is not configured."];
    }

    $payload = [
        "api_token" => IPROG_API_TOKEN,
        "phone_number" => $number,
        "message" => $message
    ];

    return postJson('https://www.iprogsms.com/api/v1/sms_messages', [
        'Content-Type: application/json',
        'Accept: application/json'
    ], $payload);
}
