<?php
require_once dirname(__DIR__, 2) . '/config/schema_ensure.php';
require_once __DIR__ . '/notify.php';

function cityVetRunReminderBatch(mysqli $conn, string $targetDate, int $batchSize = 100): array {
    $batchSize = max(1, min(100, $batchSize));
    $query = "SELECT a.Appointment_ID, a.Owner_ID, o.User_ID, o.First_name, u.Email, a.Event_ID,
                     TIME(a.Appointment_Date) AS Appt_Time, ce.Title AS Event_Title, s.Service_Name,
                     GROUP_CONCAT(DISTINCT p.Name ORDER BY p.Name SEPARATOR ', ') AS Pet_Names
              FROM appointments a JOIN owners o ON o.Owner_ID = a.Owner_ID JOIN users u ON u.User_ID = o.User_ID
              LEFT JOIN calendar_events ce ON ce.Event_ID = a.Event_ID LEFT JOIN services s ON s.Service_ID = a.Service_ID
              LEFT JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID
              LEFT JOIN pets p ON p.Pet_ID = COALESCE(ap.Pet_ID, a.Pet_ID)
              WHERE a.Status = 'Confirmed' AND DATE(COALESCE(ce.Event_Date, a.Appointment_Date)) = ?
                AND NOT EXISTS (
                    SELECT 1 FROM notifications reminder_notice
                    WHERE reminder_notice.User_ID = o.User_ID
                      AND reminder_notice.Title = 'Upcoming Appointment Reminder'
                      AND reminder_notice.Message LIKE CONCAT('%Appointment #', a.Appointment_ID, '%')
                )
              GROUP BY a.Appointment_ID LIMIT {$batchSize}";
    $stmt = $conn->prepare($query); $stmt->bind_param('s', $targetDate); $stmt->execute(); $result = $stmt->get_result();
    $processed = 0; $created = 0; $skipped = 0;
    $checkStmt = $conn->prepare("SELECT Notification_ID FROM notifications WHERE User_ID = ? AND Title = 'Upcoming Appointment Reminder' AND Message LIKE ? LIMIT 1");
    $insertStmt = $conn->prepare("INSERT INTO notifications (User_ID, Title, Message, Type, Is_Read, Sent_At) VALUES (?, ?, ?, ?, 0, NOW())");
    while ($row = $result->fetch_assoc()) {
        $processed++; $userId = (int)$row['User_ID']; $apptId = (int)$row['Appointment_ID'];
        $serviceOrEvent = $row['Event_Title'] ?: ($row['Service_Name'] ?: 'General Consultation');
        $petNames = $row['Pet_Names'] ?: 'your pet';
        $timeStr = !empty($row['Appt_Time']) ? ' at ' . date('g:i A', strtotime($row['Appt_Time'])) : '';
        $type = !empty($row['Event_ID']) ? 'SpayNeuter' : 'Appointment';
        $likePattern = "%Appointment #{$apptId}%"; $checkStmt->bind_param('is', $userId, $likePattern); $checkStmt->execute();
        if ($checkStmt->get_result()->num_rows > 0) { $skipped++; continue; }
        $title = 'Upcoming Appointment Reminder';
        $message = "Reminder: You have a scheduled appointment (Appointment #{$apptId}) tomorrow on {$targetDate}{$timeStr} for {$petNames}: {$serviceOrEvent}.";
        $insertStmt->bind_param('isss', $userId, $title, $message, $type);
        if ($insertStmt->execute()) {
            $created++;
            if (!empty($row['Email'])) try { sendResendEmail($row['Email'], 'City Vet appointment reminder', $message, '<p>Hello ' . htmlspecialchars((string)$row['First_name'], ENT_QUOTES, 'UTF-8') . ',</p><p>' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</p><p>Please contact the City Veterinary Office if you need assistance.</p>'); } catch (Throwable $e) { error_log('Reminder email failed: ' . $e->getMessage()); }
        }
    }
    $stmt->close(); $checkStmt->close(); $insertStmt->close();
    return ['processed' => $processed, 'created' => $created, 'skipped' => $skipped];
}

function cityVetRunDailyReminderTrigger(mysqli $conn): void {
    try {
        cityVetEnsureReminderRunSchema($conn); $today = date('Y-m-d');
        $insert = $conn->prepare("INSERT IGNORE INTO cityvet_reminder_runs (Reminder_Key, Last_Run_Date) VALUES ('appointment_reminders', NULL)"); $insert->execute(); $insert->close();
        $claim = $conn->prepare("UPDATE cityvet_reminder_runs SET Last_Run_Date = ? WHERE Reminder_Key = 'appointment_reminders' AND (Last_Run_Date IS NULL OR Last_Run_Date < ?)");
        $claim->bind_param('ss', $today, $today); $claim->execute(); $claimed = $claim->affected_rows === 1; $claim->close();
        if ($claimed) cityVetRunReminderBatch($conn, date('Y-m-d', strtotime('+1 day')), 100);
    } catch (Throwable $e) { error_log('Daily reminder trigger failed: ' . $e->getMessage()); }
}
