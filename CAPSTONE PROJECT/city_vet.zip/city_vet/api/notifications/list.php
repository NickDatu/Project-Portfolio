<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';
require_once __DIR__ . '/reminder_runner.php';
header('Content-Type: application/json; charset=UTF-8');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit;
}

$userId = (int)$_SESSION['user_id'];
cityVetEnsureNotificationSchema($conn);
register_shutdown_function(function () use ($conn) {
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    } else {
        ignore_user_abort(true);
        set_time_limit(60);
        while (ob_get_level() > 0) ob_end_flush();
        flush();
    }
    cityVetRunDailyReminderTrigger($conn);
});

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $conn->prepare("
        SELECT n.Notification_ID, n.Title, n.Message, n.Type, n.Event_ID, n.Is_Read, n.Sent_At,
               ce.Title AS Event_Title, ce.Event_Date, ce.Event_Type
        FROM notifications
        n LEFT JOIN calendar_events ce ON ce.Event_ID = n.Event_ID
        WHERE User_ID = ?
        ORDER BY Sent_At DESC, Notification_ID DESC
        LIMIT 50
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $notifications = [];
    while ($row = $result->fetch_assoc()) {
        $row['Notification_ID'] = (int)$row['Notification_ID'];
        $row['Is_Read'] = (int)$row['Is_Read'];
        $row['Event_ID'] = $row['Event_ID'] !== null ? (int)$row['Event_ID'] : null;
        $notifications[] = $row;
    }
    $stmt->close();

    $cntStmt = $conn->prepare("SELECT COUNT(*) AS unread FROM notifications WHERE User_ID = ? AND Is_Read = 0");
    $cntStmt->bind_param("i", $userId);
    $cntStmt->execute();
    $totalUnread = (int)($cntStmt->get_result()->fetch_assoc()['unread'] ?? 0);
    $cntStmt->close();

    echo json_encode([
        "status" => "success",
        "notifications" => $notifications,
        "unread_count" => $totalUnread
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) $input = $_POST;

    $action = $input['action'] ?? '';

    if ($action === 'mark_read') {
        $notificationId = (int)($input['notification_id'] ?? 0);
        if (!$notificationId) {
            http_response_code(422);
            echo json_encode(["status" => "error", "message" => "Missing notification ID."]);
            exit;
        }

        $stmt = $conn->prepare("UPDATE notifications SET Is_Read = 1 WHERE Notification_ID = ? AND User_ID = ?");
        $stmt->bind_param("ii", $notificationId, $userId);
        $stmt->execute();
        $stmt->close();

        $cntStmt = $conn->prepare("SELECT COUNT(*) AS unread FROM notifications WHERE User_ID = ? AND Is_Read = 0");
        $cntStmt->bind_param("i", $userId);
        $cntStmt->execute();
        $unread = (int)($cntStmt->get_result()->fetch_assoc()['unread'] ?? 0);
        $cntStmt->close();

        echo json_encode([
            "status" => "success",
            "message" => "Notification marked as read.",
            "unread_count" => $unread
        ]);
        exit;
    }

    if ($action === 'mark_all_read') {
        $stmt = $conn->prepare("UPDATE notifications SET Is_Read = 1 WHERE User_ID = ? AND Is_Read = 0");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $stmt->close();

        echo json_encode([
            "status" => "success",
            "message" => "All notifications marked as read.",
            "unread_count" => 0
        ]);
        exit;
    }

    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Invalid action."]);
    exit;
}

http_response_code(405);
echo json_encode(["status" => "error", "message" => "Method not allowed."]);
