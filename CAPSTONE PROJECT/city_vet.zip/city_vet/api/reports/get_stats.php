<?php
declare(strict_types=1);

require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db_connection.php';

header('Content-Type: application/json; charset=UTF-8');
date_default_timezone_set('Asia/Manila');

if (!defined('CITY_VET_REPORTS_TEST')) {
    if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || (int)$_SESSION['role_id'] !== 1) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'Access denied. Administrators only.']);
        exit;
    }
}

try {
    if (!$conn->query("SET SESSION time_zone = '+08:00'")) throw new RuntimeException('Unable to configure report timezone.');
    echo json_encode(cityVetReportBuild($conn, $_GET, new DateTimeImmutable('now', new DateTimeZone('Asia/Manila'))));
} catch (InvalidArgumentException $e) {
    http_response_code(422);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
} catch (Throwable $e) {
    error_log('reports/get_stats.php: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Unable to load reports right now.']);
}

function cityVetReportBuild(mysqli $conn, array $input, DateTimeImmutable $now): array
{
    $overall = ((string)($input['overall'] ?? '0')) === '1';
    $granularity = (string)($input['granularity'] ?? 'daily');
    if (!in_array($granularity, ['daily', 'weekly', 'monthly'], true)) throw new InvalidArgumentException('Invalid report granularity.');

    if ($overall) {
        [$start, $end] = cityVetReportOverallRange($conn);
        if ($start === null || $end === null) return cityVetReportEmpty($granularity);
    } else {
        $start = cityVetReportDate((string)($input['start'] ?? ''));
        $end = cityVetReportDate((string)($input['end'] ?? ''));
        if ($start === null || $end === null || $start > $end) throw new InvalidArgumentException('Enter a valid start and end date.');
        if ((new DateTimeImmutable($start))->diff(new DateTimeImmutable($end))->days > 1095) throw new InvalidArgumentException('Reports may cover at most three years.');
    }

    // Future-dated appointments or vaccination records must not be treated as
    // completed report activity. This also keeps the current month from showing
    // outcomes for dates that have not happened yet.
    $requestedEnd = $end;
    $today = (new DateTimeImmutable('now', new DateTimeZone('Asia/Manila')))->format('Y-m-d');
    if ($end > $today) $end = $today;
    if ($start > $end) return cityVetReportEmpty($granularity);

    $rows = cityVetReportAppointmentRows($conn, $start, $end);
    $current = cityVetReportAggregate($rows);
    $prior = null;
    if (!$overall) {
        $currentStart = new DateTimeImmutable($start, new DateTimeZone('Asia/Manila'));
        $currentEnd = new DateTimeImmutable($end, new DateTimeZone('Asia/Manila'));
        $days = $currentStart->diff($currentEnd)->days + 1;
        $priorEnd = $currentStart->modify('-1 day');
        $priorStart = $priorEnd->modify('-' . ($days - 1) . ' days');
        $priorRows = cityVetReportAppointmentRows($conn, $priorStart->format('Y-m-d'), $priorEnd->format('Y-m-d'));
        if ($priorRows) $prior = cityVetReportAggregate($priorRows);
    }

    $programs = cityVetReportPrograms($rows);
    $trend = cityVetReportTrend($rows, $start, $end, $granularity);
    $rabiesTrend = cityVetReportRabiesTrend($conn, $start, $end, $granularity);
    $peak = cityVetReportPeak($rows, $start, $requestedEnd);
    $reconciliation = cityVetReportReconciliation($current, $programs, $trend, $peak);

    return [
        'status' => 'success',
        'range' => ['start' => $start, 'end' => $end, 'granularity' => $granularity, 'overall' => $overall ? 1 : 0],
        'kpis' => [
            'appointments' => $current['total'], 'clients' => $current['clients'], 'no_show_rate' => $current['no_show_rate'],
            'deltas' => ['appointments' => cityVetReportDelta($current['total'], $prior['total'] ?? null), 'clients' => cityVetReportDelta($current['clients'], $prior['clients'] ?? null), 'no_show_rate' => cityVetReportDelta($current['no_show_rate'], $prior['no_show_rate'] ?? null)]
        ],
        'programs' => array_values($programs), 'rabies_trend' => $rabiesTrend, 'trend' => $trend, 'peak' => $peak, 'reconciliation' => $reconciliation
    ];
}

function cityVetReportDate(string $value): ?string
{
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value, new DateTimeZone('Asia/Manila'));
    $errors = DateTimeImmutable::getLastErrors();
    if (!$date || ($errors !== false && ($errors['warning_count'] || $errors['error_count'])) || $date->format('Y-m-d') !== $value) return null;
    return $value;
}

function cityVetReportOverallRange(mysqli $conn): array
{
    $sql = "SELECT MIN(DATE(COALESCE(ce.Event_Date, a.Appointment_Date))) AS first_date, MAX(DATE(COALESCE(ce.Event_Date, a.Appointment_Date))) AS last_date
            FROM appointments a INNER JOIN owners o ON o.Owner_ID = a.Owner_ID AND o.Status = 'active'
            LEFT JOIN calendar_events ce ON ce.Event_ID = a.Event_ID LEFT JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID
            INNER JOIN pets p ON p.Pet_ID = COALESCE(ap.Pet_ID, a.Pet_ID) AND p.Status <> 'archived'
            WHERE (ap.Appointment_Pet_ID IS NOT NULL OR NOT EXISTS (SELECT 1 FROM appointment_pets ap2 WHERE ap2.Appointment_ID = a.Appointment_ID))";
    $stmt = $conn->prepare($sql);
    if (!$stmt || !$stmt->execute()) throw new RuntimeException('Unable to determine the report range.');
    $row = $stmt->get_result()->fetch_assoc() ?: [];
    $stmt->close();
    return [$row['first_date'] ?? null, $row['last_date'] ?? null];
}

function cityVetReportAppointmentRows(mysqli $conn, string $start, string $end): array
{
    $sql = "SELECT a.Appointment_ID, a.Owner_ID, a.Status, a.Appointment_Date, DATE(COALESCE(ce.Event_Date, a.Appointment_Date)) AS Report_Date,
                   ce.Event_Type, ce.Title AS Event_Title, COALESCE(s.Service_Name, '') AS Service_Name, COALESCE(ap.Pet_ID, a.Pet_ID) AS Slot_Pet_ID
            FROM appointments a INNER JOIN owners o ON o.Owner_ID = a.Owner_ID AND o.Status = 'active'
            LEFT JOIN calendar_events ce ON ce.Event_ID = a.Event_ID LEFT JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID
            INNER JOIN pets p ON p.Pet_ID = COALESCE(ap.Pet_ID, a.Pet_ID) AND p.Status <> 'archived'
            LEFT JOIN services s ON s.Service_ID = a.Service_ID
            WHERE DATE(COALESCE(ce.Event_Date, a.Appointment_Date)) BETWEEN ? AND ?
              AND (ap.Appointment_Pet_ID IS NOT NULL OR NOT EXISTS (SELECT 1 FROM appointment_pets ap2 WHERE ap2.Appointment_ID = a.Appointment_ID))
            ORDER BY Report_Date, a.Appointment_Date, a.Appointment_ID, Slot_Pet_ID";
    $stmt = $conn->prepare($sql);
    if (!$stmt) throw new RuntimeException('Unable to prepare the appointment report query.');
    $stmt->bind_param('ss', $start, $end);
    if (!$stmt->execute()) throw new RuntimeException('Unable to load appointment report data.');
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

function cityVetReportAggregate(array $rows): array
{
    $statuses = ['Pending', 'Confirmed', 'Checked In', 'In Consultation', 'Completed', 'No Show', 'Cancelled'];
    $counts = array_fill_keys($statuses, 0); $owners = [];
    foreach ($rows as $row) { if (isset($counts[$row['Status']])) $counts[$row['Status']]++; $owners[(int)$row['Owner_ID']] = true; }
    $resolved = $counts['Completed'] + $counts['No Show'] + $counts['Cancelled'];
    return ['total' => count($rows), 'clients' => count($owners), 'statuses' => $counts, 'no_show_rate' => $resolved ? round((($counts['No Show'] + $counts['Cancelled']) / $resolved) * 100, 1) : 0.0];
}

function cityVetReportPrograms(array $rows): array
{
    $make = static fn(string $key, string $label): array => ['key' => $key, 'label' => $label, 'registered' => 0, 'served' => 0, 'scheduled' => 0, 'nonappearance' => 0, 'cancelled' => 0, 'outcomes' => ['Completed' => 0, 'Scheduled' => 0, 'No Show' => 0, 'Cancelled' => 0]];
    $programs = ['spay_neuter' => $make('spay_neuter', 'Spay & Neuter'), 'rabies' => $make('rabies', 'Rabies Vaccination')];
    foreach ($rows as $row) {
        $text = strtolower((string)$row['Service_Name'] . ' ' . (string)$row['Event_Title']);
        $key = $row['Event_Type'] === 'SpayNeuter' || str_contains($text, 'spay') || str_contains($text, 'neuter') ? 'spay_neuter' : (str_contains($text, 'rabies') ? 'rabies' : null);
        if ($key === null) continue;
        $programs[$key]['registered']++; $status = (string)$row['Status'];
        if ($status === 'Completed') { $programs[$key]['served']++; $programs[$key]['outcomes']['Completed']++; }
        elseif (in_array($status, ['Pending', 'Confirmed', 'Checked In', 'In Consultation'], true)) { $programs[$key]['scheduled']++; $programs[$key]['outcomes']['Scheduled']++; }
        elseif ($status === 'No Show') { $programs[$key]['nonappearance']++; $programs[$key]['outcomes']['No Show']++; }
        elseif ($status === 'Cancelled') { $programs[$key]['cancelled']++; $programs[$key]['outcomes']['Cancelled']++; }
    }
    return $programs;
}

function cityVetReportBucketStart(string $date, string $granularity): DateTimeImmutable
{
    $value = new DateTimeImmutable($date, new DateTimeZone('Asia/Manila'));
    return $granularity === 'weekly' ? $value->modify('monday this week') : ($granularity === 'monthly' ? $value->modify('first day of this month') : $value);
}

function cityVetReportTrend(array $rows, string $start, string $end, string $granularity): array
{
    $to = new DateTimeImmutable($end, new DateTimeZone('Asia/Manila')); $buckets = [];
    for ($cursor = cityVetReportBucketStart($start, $granularity); $cursor <= $to; $cursor = $granularity === 'daily' ? $cursor->modify('+1 day') : ($granularity === 'weekly' ? $cursor->modify('+7 days') : $cursor->modify('+1 month'))) {
        $key = $granularity === 'monthly' ? $cursor->format('Y-m') : $cursor->format('Y-m-d');
        $label = $granularity === 'daily' ? $cursor->format('M d, Y') : ($granularity === 'weekly' ? $cursor->format('M d, Y') . ' - ' . $cursor->modify('+6 days')->format('M d, Y') : $cursor->format('F Y'));
        $buckets[$key] = ['label' => $label, 'appointments' => 0, 'missed' => 0];
    }
    foreach ($rows as $row) { $bucket = cityVetReportBucketStart($row['Report_Date'], $granularity); $key = $granularity === 'monthly' ? $bucket->format('Y-m') : $bucket->format('Y-m-d'); if (isset($buckets[$key])) { $buckets[$key]['appointments']++; if (in_array($row['Status'], ['No Show', 'Cancelled'], true)) $buckets[$key]['missed']++; } }
    return array_values($buckets);
}

function cityVetReportRabiesTrend(mysqli $conn, string $start, string $end, string $granularity): array
{
    $sql = "SELECT v.Date_Administered FROM vaccinations v INNER JOIN pets p ON p.Pet_ID = v.Pet_ID AND p.Status <> 'archived' INNER JOIN owners o ON o.Owner_ID = p.Owner_ID AND o.Status = 'active' WHERE v.Date_Administered BETWEEN ? AND ? AND LOWER(v.Vaccine_Name) LIKE '%rabies%' ORDER BY v.Date_Administered";
    $stmt = $conn->prepare($sql); if (!$stmt) throw new RuntimeException('Unable to prepare the vaccination report query.'); $stmt->bind_param('ss', $start, $end); if (!$stmt->execute()) throw new RuntimeException('Unable to load vaccination report data.'); $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    $to = new DateTimeImmutable($end, new DateTimeZone('Asia/Manila')); $buckets = [];
    for ($cursor = cityVetReportBucketStart($start, $granularity); $cursor <= $to; $cursor = $granularity === 'daily' ? $cursor->modify('+1 day') : ($granularity === 'weekly' ? $cursor->modify('+7 days') : $cursor->modify('+1 month'))) {
        $key = $granularity === 'monthly' ? $cursor->format('Y-m') : $cursor->format('Y-m-d'); $label = $granularity === 'daily' ? $cursor->format('M d, Y') : ($granularity === 'weekly' ? $cursor->format('M d, Y') . ' - ' . $cursor->modify('+6 days')->format('M d, Y') : $cursor->format('F Y')); $buckets[$key] = ['label' => $label, 'doses' => 0];
    }
    foreach ($rows as $row) { $bucket = cityVetReportBucketStart($row['Date_Administered'], $granularity); $key = $granularity === 'monthly' ? $bucket->format('Y-m') : $bucket->format('Y-m-d'); if (isset($buckets[$key])) $buckets[$key]['doses']++; }
    return array_values($buckets);
}

function cityVetReportPeak(array $rows, string $start, string $end): array
{
    $timezone = new DateTimeZone('Asia/Manila');
    $counts = [];
    foreach ($rows as $row) {
        if ($row['Status'] === 'Cancelled') continue;
        $date = (string)$row['Report_Date'];
        $counts[$date] = ($counts[$date] ?? 0) + 1;
    }

    $points = [];
    $from = new DateTimeImmutable($start, $timezone);
    $to = new DateTimeImmutable($end, $timezone);
    for ($cursor = $from; $cursor <= $to; $cursor = $cursor->modify('+1 day')) {
        $date = $cursor->format('Y-m-d');
        $points[] = ['date' => $date, 'label' => $cursor->format('M j, Y'), 'total' => $counts[$date] ?? 0];
    }
    return $points;
}

function cityVetReportDelta(float|int $current, float|int|null $prior): ?float { return $prior === null ? null : round((float)$current - (float)$prior, 1); }

function cityVetReportReconciliation(array $current, array $programs, array $trend, array $peak): array
{
    $checks = [array_sum($current['statuses']) === $current['total']];
    foreach ($programs as $program) $checks[] = $program['registered'] === ($program['served'] + $program['scheduled'] + $program['nonappearance'] + $program['cancelled']);
    $checks[] = array_sum(array_column($trend, 'appointments')) === $current['total']; $checks[] = array_sum(array_column($peak, 'total')) === ($current['total'] - $current['statuses']['Cancelled']);
    $ok = !in_array(false, $checks, true); return ['ok' => $ok, 'message' => $ok ? 'All report totals reconcile.' : 'Report totals do not reconcile. Please verify the underlying records.'];
}

function cityVetReportEmpty(string $granularity): array
{
    return ['status' => 'success', 'range' => ['start' => null, 'end' => null, 'granularity' => $granularity, 'overall' => 1], 'kpis' => ['appointments' => 0, 'clients' => 0, 'no_show_rate' => 0, 'deltas' => ['appointments' => null, 'clients' => null, 'no_show_rate' => null]], 'programs' => array_values(cityVetReportPrograms([])), 'rabies_trend' => [], 'trend' => [], 'peak' => [], 'reconciliation' => ['ok' => true, 'message' => 'No records are available for this range.']];
}
