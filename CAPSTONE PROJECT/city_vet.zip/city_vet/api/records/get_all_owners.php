<?php
require_once '../../config/session.php';
header('Content-Type: application/json; charset=UTF-8');

require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';
cityVetEnsurePanelRevisionSchema($conn);

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied."]);
    exit();
}

$sql = "SELECT Owner_ID, Owner_Code, First_name, Last_name, Contact_number FROM owners WHERE Status = 'active' ORDER BY Owner_ID DESC";
$result = $conn->query($sql);

$owners = [];
if ($result) {
    while($row = $result->fetch_assoc()) {
        $owners[] = $row;
    }
    echo json_encode($owners);
} else {
    error_log("Error in get_all_owners.php: " . $conn->error);
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Unable to load owners."]);
}
