<?php
require_once '../../config/session.php';
header('Content-Type: application/json; charset=UTF-8');

require_once '../../config/db_connection.php';
require_once dirname(__DIR__) . '/owner/spay_neuter_eligibility.php';
require_once dirname(__DIR__, 2) . '/config/schema_ensure.php';

if (!isset($_SESSION['user_id'], $_SESSION['role_id'])) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit();
}

$roleId = (int)$_SESSION['role_id'];
$userId = (int)$_SESSION['user_id'];
cityVetEnsurePanelRevisionSchema($conn);
$owner_id = isset($_GET['owner_id']) ? intval($_GET['owner_id']) : 0;

if ($owner_id <= 0) {
    echo json_encode([]);
    exit();
}

if ($roleId === 3) {
    $verify_stmt = $conn->prepare("SELECT Owner_ID FROM owners WHERE Owner_ID = ? AND User_ID = ?");
    $verify_stmt->bind_param("ii", $owner_id, $userId);
    $verify_stmt->execute();
    if ($verify_stmt->get_result()->num_rows === 0) {
        http_response_code(403);
        echo json_encode(["status" => "error", "message" => "Access denied"]);
        exit();
    }
} elseif (!in_array($roleId, [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied"]);
    exit();
}

$sql = "SELECT p.Pet_ID, p.Pet_Code, p.Name, p.Birthdate, s.Species_Name AS Species, b.Breed_Name,
               DATEDIFF(CURDATE(), p.Birthdate) AS Age_Days
        FROM pets p 
        LEFT JOIN species s ON p.Species_ID = s.Species_ID
        LEFT JOIN breeds b ON p.Breed_ID = b.Breed_ID 
        WHERE p.Owner_ID = ? AND p.Status = 'active'";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $owner_id);
$stmt->execute();
$result = $stmt->get_result();

$pets = [];
while($row = $result->fetch_assoc()) {
    $row['Spay_Neuter_Ineligible'] = cityVetIsSpayNeuterIneligible($conn, (int)$row['Pet_ID']) ? 1 : 0;
    $pets[] = $row;
}
echo json_encode($pets);
