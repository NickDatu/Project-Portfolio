<?php
require_once '../../config/session.php';
header("Content-Type: application/json; charset=UTF-8");

require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access Denied"]);
    exit();
}
cityVetEnsurePanelRevisionSchema($conn);

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    if ($search !== '') {
        $searchParam = "%{$search}%";
        $sql = "SELECT 
                    o.Owner_ID, o.Owner_Code,
                    o.First_name, 
                    o.Last_name, 
                    o.Contact_Number, 
                    o.Address, 
                    u.Email,
                    u.Username,
                    o.Status,
                    COUNT(DISTINCT p.Pet_ID) as Pet_Count,
                    (SELECT COUNT(*) FROM appointments a_ns WHERE a_ns.Owner_ID = o.Owner_ID AND a_ns.Status = 'No Show') AS No_Show_Count
                FROM owners o
                JOIN users u ON o.User_ID = u.User_ID
                LEFT JOIN pets p ON o.Owner_ID = p.Owner_ID AND p.Status = 'active'
                WHERE o.First_name LIKE ? OR o.Last_name LIKE ? OR o.Owner_Code LIKE ? OR u.Email LIKE ? OR u.Username LIKE ? OR o.Contact_Number LIKE ? OR p.Name LIKE ?
                GROUP BY o.Owner_ID
                ORDER BY o.Owner_ID DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssss", $searchParam, $searchParam, $searchParam, $searchParam, $searchParam, $searchParam, $searchParam);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $sql = "SELECT 
                    o.Owner_ID, o.Owner_Code,
                    o.First_name, 
                    o.Last_name, 
                    o.Contact_Number, 
                    o.Address, 
                    u.Email,
                    u.Username,
                    o.Status,
                    COUNT(DISTINCT p.Pet_ID) as Pet_Count,
                    (SELECT COUNT(*) FROM appointments a_ns WHERE a_ns.Owner_ID = o.Owner_ID AND a_ns.Status = 'No Show') AS No_Show_Count
                FROM owners o
                JOIN users u ON o.User_ID = u.User_ID
                LEFT JOIN pets p ON o.Owner_ID = p.Owner_ID AND p.Status = 'active'
                GROUP BY o.Owner_ID
                ORDER BY o.Owner_ID DESC";
        $result = $conn->query($sql);
    }

    $owners = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $owners[] = $row;
        }
    }

    echo json_encode($owners);
    exit();
}
