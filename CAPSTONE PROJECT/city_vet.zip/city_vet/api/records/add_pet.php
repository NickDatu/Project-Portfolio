<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../system/audit_helper.php';
header('Content-Type: application/json; charset=UTF-8');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $species_id = (int)($_POST['species_id'] ?? 0);
    $species_check = $conn->prepare("SELECT Species_ID FROM species WHERE Species_ID = ? AND Status = 'active' AND Species_Name IN ('Dog', 'Cat')");
    $species_check->bind_param("i", $species_id);
    $species_check->execute();
    if ($species_check->get_result()->num_rows === 0) {
        http_response_code(422);
        echo json_encode(["status" => "error", "message" => "Selected species is not available. Only Dog and Cat are allowed."]);
        exit;
    }
    $species_check->close();

    require_once '../owner/add_pet.php';
    exit;
}

http_response_code(405);
echo json_encode(["status" => "error", "message" => "Invalid Request Method"]);
