<?php
require_once '../../config/session.php';
header('Content-Type: application/json; charset=UTF-8');

require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';
cityVetEnsurePanelRevisionSchema($conn);

if (!isset($_SESSION['user_id'], $_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied."]);
    exit();
}

$sql = "SELECT p.Pet_ID, p.Pet_Code, p.Name, p.Birthdate, CONCAT(o.First_name, ' ', o.Last_name) as Owner_Name, o.Owner_Code 
        FROM pets p 
        JOIN owners o ON p.Owner_ID = o.Owner_ID 
        WHERE p.Status = 'active'
        ORDER BY p.Pet_ID DESC";

$result = $conn->query($sql);
$pets = [];

if ($result) {
    while($row = $result->fetch_assoc()) {
        $pets[] = $row;
    }
    echo json_encode($pets);
} else {
    error_log("Error in get_all_pets.php: " . $conn->error);
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Unable to load pets."]);
}
