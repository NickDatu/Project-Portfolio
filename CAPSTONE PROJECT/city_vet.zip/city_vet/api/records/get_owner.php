<?php
require_once '../../config/session.php';
header("Content-Type: application/json; charset=UTF-8");

require_once '../../config/db_connection.php';

if (!isset($_SESSION['user_id']) || !in_array((int)($_SESSION['role_id'] ?? 0), [1, 2, 4], true)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied"]);
    exit();
}

if (!isset($_GET['id'])) {
    echo json_encode(["status" => "error", "message" => "No ID provided"]);
    exit();
}

$owner_id = intval($_GET['id']);

$sql_owner = "SELECT o.*, u.Email, u.Username 
              FROM owners o 
              JOIN users u ON o.User_ID = u.User_ID 
              WHERE o.Owner_ID = ?";
$stmt = $conn->prepare($sql_owner);
$stmt->bind_param("i", $owner_id);
$stmt->execute();
$owner_result = $stmt->get_result();

if ($owner_result->num_rows === 0) {
    echo json_encode(["status" => "error", "message" => "Owner not found"]);
    exit();
}

$owner_data = $owner_result->fetch_assoc();

$sql_pets = "SELECT p.*, s.Species_Name, b.Breed_Name 
             FROM pets p
             LEFT JOIN species s ON p.Species_ID = s.Species_ID
             LEFT JOIN breeds b ON p.Breed_ID = b.Breed_ID
             WHERE p.Owner_ID = ? AND p.Status != 'archived'";
$stmt_pets = $conn->prepare($sql_pets);
$stmt_pets->bind_param("i", $owner_id);
$stmt_pets->execute();
$pets_result = $stmt_pets->get_result();

$pets_data = [];
while ($pet = $pets_result->fetch_assoc()) {
    $pets_data[] = $pet;
}

$archived_stmt = $conn->prepare("SELECT p.*, s.Species_Name, b.Breed_Name
    FROM pets p
    LEFT JOIN species s ON p.Species_ID = s.Species_ID
    LEFT JOIN breeds b ON p.Breed_ID = b.Breed_ID
    WHERE p.Owner_ID = ? AND p.Status = 'archived'
    ORDER BY p.Pet_ID DESC");
$archived_stmt->bind_param("i", $owner_id);
$archived_stmt->execute();
$archived_result = $archived_stmt->get_result();
$archived_pets = [];
while ($pet = $archived_result->fetch_assoc()) {
    $archived_pets[] = $pet;
}


$appt_stmt = $conn->prepare("SELECT a.Appointment_ID, a.Status, a.Appointment_Date, a.Notes,
        ce.Title AS Event_Title, ce.Event_Date, p.Name AS Pet_Name, sv.Service_Name
    FROM appointments a
    LEFT JOIN calendar_events ce ON ce.Event_ID = a.Event_ID
    LEFT JOIN pets p ON p.Pet_ID = a.Pet_ID
    LEFT JOIN services sv ON sv.Service_ID = a.Service_ID
    WHERE a.Owner_ID = ?
    ORDER BY COALESCE(ce.Event_Date, DATE(a.Appointment_Date)) DESC, a.Appointment_ID DESC");
$appt_stmt->bind_param("i", $owner_id);
$appt_stmt->execute();
$appointments = [];
$stats = ["total" => 0, "pending" => 0, "confirmed" => 0, "completed" => 0, "cancelled" => 0, "no_show" => 0];
$ares = $appt_stmt->get_result();
while ($a = $ares->fetch_assoc()) {
    $a['Date'] = $a['Event_Date'] ?: substr((string)$a['Appointment_Date'], 0, 10);
    $appointments[] = $a;
    $stats["total"]++;
    switch ($a['Status']) {
        case 'Pending': $stats["pending"]++; break;
        case 'Confirmed': $stats["confirmed"]++; break;
        case 'Completed': $stats["completed"]++; break;
        case 'Cancelled': $stats["cancelled"]++; break;
        case 'No Show': $stats["no_show"]++; break;
    }
}
$appt_stmt->close();

echo json_encode([
    "status" => "success",
    "appointments" => $appointments,
    "appointment_stats" => $stats,
    "owner" => $owner_data,
    "pets" => $pets_data,
    "archived_pets" => $archived_pets
]);
