<?php
header("Content-Type: application/json; charset=UTF-8");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Referrer-Policy: strict-origin-when-cross-origin");

require_once '../../config/db_connection.php';

try {
    $sql = "SELECT Service_ID, Service_Name, Price 
            FROM services 
            WHERE Status = 'active'
              AND LOWER(Service_Name) NOT LIKE '%spay%'
              AND LOWER(Service_Name) NOT LIKE '%neuter%'";
    
    $result = $conn->query($sql);

    if (!$result) {
        error_log("Error in get_services.php: " . $conn->error);
        throw new Exception("Unable to load services.");
    }

    $services = [];
    while($row = $result->fetch_assoc()) {
        $services[] = $row;
    }

    echo json_encode($services);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Unable to load services."]);
}

$conn->close();
