<?php

if (!function_exists('cityVetIsSpayNeuterIneligible')) {
    function cityVetIsSpayNeuterIneligible(mysqli $conn, int $petId): bool {
        $stmt = $conn->prepare("SELECT 1 FROM appointments a LEFT JOIN calendar_events ce ON ce.Event_ID = a.Event_ID LEFT JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID WHERE (a.Pet_ID = ? OR ap.Pet_ID = ?) AND a.Status IN ('Pending','Confirmed','Checked In','In Consultation','Completed') AND (ce.Event_Type = 'SpayNeuter' OR LOWER(COALESCE(ce.Title, '')) LIKE '%spay%' OR LOWER(COALESCE(ce.Title, '')) LIKE '%neuter%') LIMIT 1");
        $stmt->bind_param('ii', $petId, $petId);
        $stmt->execute();
        $hasBooking = (bool)$stmt->get_result()->fetch_row();
        $stmt->close();
        if ($hasBooking) return true;

        $stmt = $conn->prepare("SELECT 1 FROM medical_records WHERE Pet_ID = ? AND (is_deleted = 0 OR is_deleted IS NULL) AND (LOWER(COALESCE(Treatment, '')) LIKE '%spay%' OR LOWER(COALESCE(Treatment, '')) LIKE '%neuter%') LIMIT 1");
        $stmt->bind_param('i', $petId);
        $stmt->execute();
        $hasMedicalRecord = (bool)$stmt->get_result()->fetch_row();
        $stmt->close();
        return $hasMedicalRecord;
    }
}
