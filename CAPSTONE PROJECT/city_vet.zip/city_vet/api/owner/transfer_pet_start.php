<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';
require_once '../system/audit_helper.php';
require_once '../notifications/notify.php';

header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed. POST required.']);
    exit();
}
requireCsrf();
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 3) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Owner access required.']);
    exit();
}

cityVetEnsurePetTransferSchema($conn);
$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) $input = $_POST;

$petId = (int)($input['pet_id'] ?? 0);
$targetEmail = strtolower(trim((string)($input['target_email'] ?? $input['email'] ?? '')));
$userId = (int)$_SESSION['user_id'];
$genericMessage = 'If the account is eligible, a transfer verification code has been sent to the current owner.';

if ($petId <= 0 || !filter_var($targetEmail, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['status' => 'success', 'message' => $genericMessage]);
    exit();
}

$ownerStmt = $conn->prepare('SELECT Owner_ID, First_name, Last_name, Email FROM owners o JOIN users u ON u.User_ID = o.User_ID WHERE o.User_ID = ? AND o.Status = \'active\' AND u.Status = \'active\' LIMIT 1');
$ownerStmt->bind_param('i', $userId);
$ownerStmt->execute();
$sourceOwner = $ownerStmt->get_result()->fetch_assoc();
$ownerStmt->close();
if (!$sourceOwner) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Owner profile not found.']);
    exit();
}
$sourceOwnerId = (int)$sourceOwner['Owner_ID'];

$petStmt = $conn->prepare('SELECT Pet_ID, Name, Status FROM pets WHERE Pet_ID = ? AND Owner_ID = ? LIMIT 1');
$petStmt->bind_param('ii', $petId, $sourceOwnerId);
$petStmt->execute();
$pet = $petStmt->get_result()->fetch_assoc();
$petStmt->close();
if (!$pet) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Pet not found or access denied.']);
    exit();
}
if ($pet['Status'] !== 'active') {
    http_response_code(422);
    echo json_encode(['status' => 'error', 'message' => 'Only active pets can be transferred.']);
    exit();
}

$targetStmt = $conn->prepare("SELECT o.Owner_ID, o.User_ID, o.First_name, o.Last_name, u.Email FROM users u JOIN owners o ON o.User_ID = u.User_ID WHERE LOWER(u.Email) = ? AND u.Role_ID = 3 AND u.Status = 'active' AND o.Status = 'active' LIMIT 1");
$targetStmt->bind_param('s', $targetEmail);
$targetStmt->execute();
$target = $targetStmt->get_result()->fetch_assoc();
$targetStmt->close();
if (!$target || (int)$target['Owner_ID'] === $sourceOwnerId) {
    echo json_encode(['status' => 'success', 'message' => $genericMessage]);
    exit();
}
$targetOwnerId = (int)$target['Owner_ID'];

$activeAppointmentStmt = $conn->prepare("SELECT 1 FROM appointments a LEFT JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID WHERE (a.Pet_ID = ? OR ap.Pet_ID = ?) AND a.Status IN ('Pending','Confirmed','Checked In','In Consultation') LIMIT 1");
$activeAppointmentStmt->bind_param('ii', $petId, $petId);
$activeAppointmentStmt->execute();
$hasActiveAppointment = (bool)$activeAppointmentStmt->get_result()->fetch_row();
$activeAppointmentStmt->close();

$activeConsultationStmt = $conn->prepare("SELECT 1 FROM consultations WHERE Pet_ID = ? AND Status IN ('Pending','Ongoing') LIMIT 1");
$activeConsultationStmt->bind_param('i', $petId);
$activeConsultationStmt->execute();
$hasActiveConsultation = (bool)$activeConsultationStmt->get_result()->fetch_row();
$activeConsultationStmt->close();

$hasActiveQueue = false;
if (cityVetTableExists($conn, 'live_queue_tickets')) {
    $queueStmt = $conn->prepare("SELECT 1 FROM live_queue_tickets WHERE Pet_ID = ? AND Status IN ('Waiting','Called','Serving') LIMIT 1");
    $queueStmt->bind_param('i', $petId);
    $queueStmt->execute();
    $hasActiveQueue = (bool)$queueStmt->get_result()->fetch_row();
    $queueStmt->close();
}
if ($hasActiveAppointment || $hasActiveConsultation || $hasActiveQueue) {
    http_response_code(409);
    echo json_encode(['status' => 'error', 'message' => 'This pet has an active appointment, consultation, or queue ticket. Cancel or complete it before transferring the pet.']);
    exit();
}

$otp = sprintf('%06d', random_int(0, 999999));
$otpHash = password_hash($otp, PASSWORD_DEFAULT);
$expiresAt = date('Y-m-d H:i:s', time() + 600);
$conn->begin_transaction();
try {
    $lockPetStmt = $conn->prepare("SELECT Pet_ID, Name, Status FROM pets WHERE Pet_ID = ? AND Owner_ID = ? FOR UPDATE");
    $lockPetStmt->bind_param('ii', $petId, $sourceOwnerId);
    $lockPetStmt->execute();
    $lockedPet = $lockPetStmt->get_result()->fetch_assoc();
    $lockPetStmt->close();
    if (!$lockedPet || $lockedPet['Status'] !== 'active') throw new Exception('Pet is no longer eligible for transfer.');

    $expireStmt = $conn->prepare("UPDATE pet_transfer_requests SET Status = 'expired' WHERE Pet_ID = ? AND Status = 'pending'");
    $expireStmt->bind_param('i', $petId);
    $expireStmt->execute();
    $expireStmt->close();

    $insertStmt = $conn->prepare("INSERT INTO pet_transfer_requests (Pet_ID, From_Owner_ID, To_Owner_ID, OTP_Hash, Expires_At) VALUES (?, ?, ?, ?, ?)");
    $insertStmt->bind_param('iiiss', $petId, $sourceOwnerId, $targetOwnerId, $otpHash, $expiresAt);
    if (!$insertStmt->execute()) throw new Exception('Unable to create transfer request.');
    $transferId = (int)$conn->insert_id;
    $insertStmt->close();

    $safeName = htmlspecialchars((string)$pet['Name'], ENT_QUOTES, 'UTF-8');
    $emailResult = sendResendEmail(
        (string)$sourceOwner['Email'],
        'City Vet pet transfer verification code',
        "Your City Vet transfer code for {$pet['Name']} is {$otp}. It expires in 10 minutes. Share this code only with the intended new owner.",
        '<p>Your City Vet transfer verification code for <strong>' . $safeName . '</strong> is:</p><p style="font-size:28px;font-weight:700;letter-spacing:6px">' . $otp . '</p><p>This code expires in 10 minutes. Share it only with the intended new owner.</p>'
    );
    if (!($emailResult['sent'] ?? false)) throw new Exception('Unable to send the verification email.');
    $conn->commit();
} catch (Throwable $e) {
    $conn->rollback();
    error_log('Pet transfer start failed: ' . $e->getMessage());
    http_response_code(502);
    echo json_encode(['status' => 'error', 'message' => 'Unable to send the transfer verification code. Please try again later.']);
    exit();
}

auditLog($conn, $userId, 'Start Pet Transfer', 'pet_transfer_requests', $transferId, ['metadata' => ['pet_id' => $petId, 'from_owner_id' => $sourceOwnerId, 'to_owner_id' => $targetOwnerId]]);
$noticeStmt = $conn->prepare("INSERT INTO notifications (User_ID, Title, Message, Type) VALUES (?, ?, ?, 'System')");
if ($noticeStmt) {
    $noticeTitle = 'Pet transfer request';
    $noticeMessage = $pet['Name'] . ' is waiting for your transfer code. Enter the code given by the current owner to accept the pet.';
    $targetUserId = (int)$target['User_ID'];
    $noticeStmt->bind_param('iss', $targetUserId, $noticeTitle, $noticeMessage);
    $noticeStmt->execute();
    $noticeStmt->close();
}
echo json_encode(['status' => 'success', 'message' => 'A transfer verification code was sent to your account email. Give the code to the intended new owner.', 'transfer_id' => $transferId, 'expires_in' => 600]);
