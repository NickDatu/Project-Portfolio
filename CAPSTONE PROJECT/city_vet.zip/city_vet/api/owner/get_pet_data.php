<?php
require_once '../../config/session.php';
header("Content-Type: application/json; charset=UTF-8");

require_once '../../config/db_connection.php'; 
require_once '../../config/schema_ensure.php';
require_once '../../config/consultation_template.php';

if (!isset($_SESSION['user_id'])) { 
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Unauthorized"]); 
    exit(); 
}

$user_id = (int)$_SESSION['user_id'];
cityVetEnsureMedicalSchema($conn);
cityVetEnsurePanelRevisionSchema($conn);
cityVetEnsureConsultationTemplateSchema($conn);

$owner_stmt = $conn->prepare("SELECT Owner_ID, First_name FROM owners WHERE User_ID = ? LIMIT 1");
$owner_stmt->bind_param("i", $user_id);
$owner_stmt->execute();
$owner_res = $owner_stmt->get_result();

if ($owner_res->num_rows === 0) {
    echo json_encode(["status" => "error", "message" => "Owner profile not found"]);
    exit();
}

$owner = $owner_res->fetch_assoc();
$owner_id = (int)$owner['Owner_ID'];

$breeds = [];
$breed_q = $conn->query("SELECT Breed_ID, Species_ID, Breed_Name FROM breeds WHERE Status = 'active'");
if ($breed_q) {
    while($b = $breed_q->fetch_assoc()) {
        $breeds[] = $b; 
    }
}

if (isset($_GET['id'])) {
    $pet_id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT p.*, b.Breed_Name, s.Species_Name FROM pets p 
            LEFT JOIN breeds b ON p.Breed_ID = b.Breed_ID
            LEFT JOIN species s ON p.Species_ID = s.Species_ID
            WHERE p.Pet_ID = ? AND p.Owner_ID = ? AND (p.Status != 'archived' OR ? = 1)");
    $includeArchived = !empty($_GET['include_archived']) && $_GET['include_archived'] === '1' ? 1 : 0;
    $stmt->bind_param("iii", $pet_id, $owner_id, $includeArchived);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $pet = $result->fetch_assoc();
        
        $age_display = "Unknown";
        if ($pet['Birthdate']) {
            $dob = new DateTime($pet['Birthdate']);
            $now = new DateTime();
            $weeks = max(0, (int)floor(($now->getTimestamp() - $dob->getTimestamp()) / 604800));
            $age_display = $weeks . ($weeks === 1 ? " week old" : " weeks old");
        }
        $pet['Age_Display'] = $age_display;
        $pet['Birthdate_Formatted'] = date("F j, Y", strtotime($pet['Birthdate']));

        $notes = [];
        $notes_stmt = $conn->prepare("SELECT * FROM pet_notes WHERE Pet_ID = ? ORDER BY Created_At DESC");
        $notes_stmt->bind_param("i", $pet_id);
        $notes_stmt->execute();
        $notes_res = $notes_stmt->get_result();
        while ($n = $notes_res->fetch_assoc()) {
            $n['Date_Formatted'] = date("M j, Y", strtotime($n['Created_At']));
            $notes[] = $n;
        }
        $external_records = [];
        $externalStmt = $conn->prepare("SELECT External_Record_ID, Source_Clinic, Record_Type, Record_Date, Name, Medicine, Dosage, Lot_Number, Provider, Notes, Attachment_Path, Verified_At FROM pet_external_records WHERE Pet_ID = ? AND Is_Deleted = 0 ORDER BY Record_Date DESC, External_Record_ID DESC");
        $externalStmt->bind_param('i', $pet_id); $externalStmt->execute();
        $externalResult = $externalStmt->get_result();
        while ($externalRow = $externalResult->fetch_assoc()) $external_records[] = $externalRow;
        $externalStmt->close();

        $history_sql = "
            (SELECT m.Visit_Date as Date, COALESCE(m.Treatment, 'General Checkup') as Treatment, m.Notes, 'Medical Record' as Type,
                    CASE WHEN vu.User_ID IS NULL THEN NULL
                         ELSE COALESCE(NULLIF(CONCAT('Dr. ', TRIM(CONCAT(COALESCE(st.First_name, ''), ' ', COALESCE(st.Last_name, '')))), 'Dr. '), vu.Username) END AS Vet_Name,
                    m.Medicine_Used AS Medicine_Used, m.Medicine_Picture AS Medicine_Picture
             FROM medical_records m
             LEFT JOIN users vu ON vu.User_ID = m.Vet_ID AND vu.Role_ID = 2
             LEFT JOIN staff st ON st.User_ID = m.Vet_ID
             WHERE m.Pet_ID = ? AND (m.is_deleted = 0 OR m.is_deleted IS NULL))
            UNION ALL
            (SELECT c.Consultation_Date AS Date, c.Subject AS Treatment, c.Concern_Description AS Notes, 'Consultation' AS Type,
                    CASE WHEN vu2.User_ID IS NULL THEN NULL
                         ELSE COALESCE(NULLIF(CONCAT('Dr. ', TRIM(CONCAT(COALESCE(st2.First_name, ''), ' ', COALESCE(st2.Last_name, '')))), 'Dr. '), vu2.Username) END AS Vet_Name,
                    NULL AS Medicine_Used, NULL AS Medicine_Picture
             FROM consultations c
             LEFT JOIN users vu2 ON vu2.User_ID = c.Vet_ID AND vu2.Role_ID = 2
             LEFT JOIN staff st2 ON st2.User_ID = c.Vet_ID
             WHERE c.Pet_ID = ? AND c.Status = 'Completed')
            UNION ALL
            (SELECT DISTINCT COALESCE(ce.Event_Date, DATE(a.Appointment_Date)) as Date,
                    COALESCE(ce.Title, 'Spay/Neuter Event') as Treatment,
                    COALESCE(a.Notes, 'Spay/Neuter completed.') as Notes,
                    'Spay/Neuter' as Type,
                    CASE WHEN vu3.User_ID IS NULL THEN NULL
                         ELSE COALESCE(NULLIF(CONCAT('Dr. ', TRIM(CONCAT(COALESCE(st3.First_name, ''), ' ', COALESCE(st3.Last_name, '')))), 'Dr. '), vu3.Username) END AS Vet_Name,
                    NULL AS Medicine_Used, NULL AS Medicine_Picture
             FROM appointments a
             JOIN calendar_events ce ON ce.Event_ID = a.Event_ID
             LEFT JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID
             LEFT JOIN users vu3 ON vu3.User_ID = a.Vet_ID AND vu3.Role_ID = 2
             LEFT JOIN staff st3 ON st3.User_ID = a.Vet_ID
             WHERE (a.Pet_ID = ? OR ap.Pet_ID = ?)
               AND a.Status = 'Completed'
               AND (ce.Event_Type = 'SpayNeuter' OR LOWER(ce.Title) LIKE '%spay%' OR LOWER(ce.Title) LIKE '%neuter%')
               AND NOT EXISTS (
                   SELECT 1 FROM medical_records mr WHERE mr.Appointment_ID = a.Appointment_ID AND (mr.is_deleted = 0 OR mr.is_deleted IS NULL)
               ))
            ORDER BY Date DESC";

        $hist_stmt = $conn->prepare($history_sql);
        $hist_stmt->bind_param("iiii", $pet_id, $pet_id, $pet_id, $pet_id);
        $hist_stmt->execute();
        $history_res = $hist_stmt->get_result();
        $history = [];
        $seen = [];
        if ($history_res) {
            while ($h = $history_res->fetch_assoc()) {
                $key = substr((string)$h['Date'], 0, 10) . '|' . strtolower(trim((string)$h['Treatment']));
                if (!isset($seen[$key])) {
                    $seen[$key] = true;
                    $history[] = $h;
                }
            }
        }

        $findingStmt = $conn->prepare('SELECT m.Visit_Date, m.Treatment, f.Weight_Status, f.Body_Condition_Score, f.Purpose, f.Findings, f.Diagnosis_Text, f.Recommendations FROM medical_records m JOIN consultation_findings f ON f.Record_ID=m.Record_ID WHERE m.Pet_ID=? AND (m.is_deleted=0 OR m.is_deleted IS NULL)');
        $findingStmt->bind_param('i', $pet_id); $findingStmt->execute(); $findingResult=$findingStmt->get_result(); $findingMap=[];
        while($finding=$findingResult->fetch_assoc()) $findingMap[substr((string)$finding['Visit_Date'],0,10).'|'.strtolower(trim((string)$finding['Treatment']))]=['weight_status'=>$finding['Weight_Status'],'body_condition_score'=>$finding['Body_Condition_Score'],'purpose'=>json_decode($finding['Purpose']?:'[]',true),'findings'=>json_decode($finding['Findings']?:'{}',true),'diagnosis'=>$finding['Diagnosis_Text']??'','recommendations'=>$finding['Recommendations']??''];
        $findingStmt->close(); foreach($history as &$historyRow){$key=substr((string)$historyRow['Date'],0,10).'|'.strtolower(trim((string)$historyRow['Treatment']));if(isset($findingMap[$key]))$historyRow['findings']=$findingMap[$key];} unset($historyRow);

        $upcomingStmt = $conn->prepare("SELECT DATE_FORMAT(COALESCE(ce.Event_Date, DATE(a.Appointment_Date)), '%M %d, %Y') AS Date,
                CASE WHEN ce.Event_Type = 'SpayNeuter' THEN 'Time to be announced' ELSE DATE_FORMAT(a.Appointment_Date, '%l:%i %p') END AS Time
            FROM appointments a LEFT JOIN calendar_events ce ON ce.Event_ID = a.Event_ID
            LEFT JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID
            WHERE a.Owner_ID = ? AND (a.Pet_ID = ? OR ap.Pet_ID = ?)
              AND COALESCE(ce.Event_Date, DATE(a.Appointment_Date)) >= CURDATE()
              AND a.Status IN ('Pending', 'Confirmed')
            GROUP BY a.Appointment_ID ORDER BY COALESCE(ce.Event_Date, DATE(a.Appointment_Date)), a.Appointment_Date LIMIT 1");
        $upcomingStmt->bind_param("iii", $owner_id, $pet_id, $pet_id);
        $upcomingStmt->execute();
        $upcoming_appointments = $upcomingStmt->get_result()->fetch_all(MYSQLI_ASSOC);

        echo json_encode([
            "status" => "success", 
            "mode" => "detail", 
            "owner_name" => $owner['First_name'], 
            "pet" => $pet, 
            "notes" => $notes,
            "external_records" => $external_records,
            "history" => $history,
            "upcoming_appointments" => $upcoming_appointments,
            "all_breeds" => $breeds 
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Pet not found"]);
    }

} else {
    $pets = [];
    $includeArchived = !empty($_GET['include_archived']) && $_GET['include_archived'] === '1' ? 1 : 0;
    $stmt = $conn->prepare("SELECT p.Pet_ID, p.Pet_Code, p.Name, p.Status, p.Gender, p.Weight, p.Profile_Pic, b.Breed_Name, s.Species_Name FROM pets p 
            LEFT JOIN breeds b ON p.Breed_ID = b.Breed_ID 
            LEFT JOIN species s ON p.Species_ID = s.Species_ID
            WHERE p.Owner_ID = ? AND (p.Status != 'archived' OR ? = 1)");
    $stmt->bind_param("ii", $owner_id, $includeArchived);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) { $pets[] = $row; }

    echo json_encode([
        "status" => "success", 
        "mode" => "list", 
        "owner_name" => $owner['First_name'], 
        "pets" => $pets,
        "all_breeds" => $breeds 
    ]);
}
