<?php
require_once '../../config/session.php';
header("Content-Type: application/json; charset=UTF-8");

require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';
require_once __DIR__ . '/spay_neuter_eligibility.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["status" => "error", "error" => "Not logged in"]);
    exit();
}

$user_id = (int)$_SESSION['user_id'];
cityVetEnsurePanelRevisionSchema($conn);

$owner_stmt = $conn->prepare("
    SELECT o.Owner_ID, o.Owner_Code, o.First_name, o.Last_name, o.Contact_number, o.Address, o.Barangay, u.Email, u.Username, u.Phone_number 
    FROM owners o
    JOIN users u ON o.User_ID = u.User_ID
    WHERE o.User_ID = ?
");
$owner_stmt->bind_param("i", $user_id);
$owner_stmt->execute();
$owner_result = $owner_stmt->get_result();

if ($owner_result->num_rows === 0) {
    echo json_encode(["status" => "error", "error" => "Owner profile not found"]);
    exit();
}

$owner = $owner_result->fetch_assoc();
$owner_id = (int)$owner['Owner_ID'];
$email = $owner['Email'];

$includeArchived = !empty($_GET['include_archived']) && $_GET['include_archived'] === '1';
$petSql = "SELECT Pet_ID, Pet_Code, Name, Status FROM pets WHERE Owner_ID = ?" . ($includeArchived ? " AND Status IN ('active','archived')" : " AND Status = 'active'");
$pets_stmt = $conn->prepare($petSql);
$pets_stmt->bind_param("i", $owner_id);
$pets_stmt->execute();
$pets_result = $pets_stmt->get_result();
$pets = [];

while ($row = $pets_result->fetch_assoc()) {
    $row['Spay_Neuter_Ineligible'] = cityVetIsSpayNeuterIneligible($conn, (int)$row['Pet_ID']) ? 1 : 0;
    $pets[] = $row;
}

$phone = !empty($owner['Contact_number']) ? $owner['Contact_number'] : ($owner['Phone_number'] ?? '');

echo json_encode([
    "owner_name" => $owner['First_name'],
    "username" => $owner['Username'] ?? $owner['First_name'],
    "first_name" => $owner['First_name'],
    "last_name" => $owner['Last_name'] ?? '',
    "email" => $email,
    "phone" => $phone,
    "phone_number" => $phone,
    "contact_number" => $owner['Contact_number'] ?? '',
    "pets" => $pets
]);
