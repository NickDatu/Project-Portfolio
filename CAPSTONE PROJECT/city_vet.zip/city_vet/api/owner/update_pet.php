<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../system/audit_helper.php';
header('Content-Type: application/json; charset=UTF-8');

function writeAuditLog($conn, $userId, $action, $tableAffected, $recordId = 0) {
    return auditLog($conn, $userId, $action, $tableAffected, $recordId);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(["status" => "error", "message" => "Unauthorized"]);
        exit();
    }

    $actorId = (int)$_SESSION['user_id'];
    $roleId = isset($_SESSION['role_id']) ? (int)$_SESSION['role_id'] : 0;
    $pet_id = (int)($_POST['pet_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $species_id = (int)($_POST['species_id'] ?? 0);
    $breed_id = !empty($_POST['breed_id']) ? (int)$_POST['breed_id'] : null;
    $gender = $_POST['gender'] ?? 'Unknown';
    $birthdate = $_POST['birthdate'] ?? '';
    $color = trim($_POST['color'] ?? '');
    $weight = $_POST['weight'] ?? 0;

    if (!$pet_id || $name === '' || !$species_id || empty($birthdate)) {
        echo json_encode(["status" => "error", "message" => "Pet name, species, and birthdate are required."]);
        exit();
    }

    if (strtotime($birthdate) > time()) {
        echo json_encode(["status" => "error", "message" => "Birthdate cannot be in the future."]);
        exit();
    }

    if (!in_array($gender, ['Male', 'Female', 'Unknown'])) {
        echo json_encode(["status" => "error", "message" => "Invalid pet gender."]);
        exit();
    }

    if (!is_numeric($weight) || $weight < 0) {
        echo json_encode(["status" => "error", "message" => "Weight must be a valid number."]);
        exit();
    }

    $species_check = $conn->prepare("SELECT Species_ID FROM species WHERE Species_ID = ? AND Status = 'active' AND Species_Name IN ('Dog', 'Cat')");
    $species_check->bind_param("i", $species_id);
    $species_check->execute();
    if ($species_check->get_result()->num_rows === 0) {
        http_response_code(422);
        echo json_encode(["status" => "error", "message" => "Selected species is not available. Only Dog and Cat are allowed."]);
        exit();
    }
    $species_check->close();

    if ($roleId === 1 || $roleId === 4) {
        $access_stmt = $conn->prepare("SELECT Pet_ID FROM pets WHERE Pet_ID = ? AND Status != 'archived'");
        $access_stmt->bind_param("i", $pet_id);
    } else {
        $access_stmt = $conn->prepare("
            SELECT p.Pet_ID
            FROM pets p
            JOIN owners o ON p.Owner_ID = o.Owner_ID
            WHERE p.Pet_ID = ? AND o.User_ID = ? AND p.Status != 'archived'
        ");
        $access_stmt->bind_param("ii", $pet_id, $actorId);
    }
    $access_stmt->execute();
    if ($access_stmt->get_result()->num_rows === 0) {
        http_response_code(403);
        echo json_encode(["status" => "error", "message" => "Pet not found or access denied."]);
        exit();
    }

    $profile_pic = null;
    if (isset($_FILES['pet_image']) && $_FILES['pet_image']['name'] != "") {
        if ($_FILES['pet_image']['error'] !== 0) {
            echo json_encode(["status" => "error", "message" => "Image upload error."]);
            exit();
        }
        if (!is_uploaded_file($_FILES['pet_image']['tmp_name'])) {
            echo json_encode(["status" => "error", "message" => "Invalid image upload."]);
            exit();
        }

        if ($_FILES['pet_image']['size'] > 5 * 1024 * 1024) {
            echo json_encode(["status" => "error", "message" => "Image file size must not exceed 5MB."]);
            exit();
        }

        $allowed_extensions = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
        $file_extension = strtolower(pathinfo($_FILES["pet_image"]["name"], PATHINFO_EXTENSION));

        if (!in_array($file_extension, $allowed_extensions, true)) {
            echo json_encode(["status" => "error", "message" => "Invalid image type. Only JPG, PNG, WEBP, and GIF are allowed."]);
            exit();
        }

        $image_info = @getimagesize($_FILES["pet_image"]["tmp_name"]);
        $allowed_mimes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
        if ($image_info === false || !in_array($image_info['mime'] ?? '', $allowed_mimes, true)) {
            echo json_encode(["status" => "error", "message" => "Invalid image type. Only JPG, PNG, WEBP, and GIF are allowed."]);
            exit();
        }

        $target_dir = "../../uploads/pets/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0755, true);
        }
        
        $file_name = 'pet_' . bin2hex(random_bytes(16)) . "." . $file_extension;
        $target_file = $target_dir . $file_name;
        
        if (move_uploaded_file($_FILES["pet_image"]["tmp_name"], $target_file)) {
            $profile_pic = $file_name;
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to save uploaded file."]);
            exit();
        }
    }

    if ($profile_pic) {
        $sql = "UPDATE pets SET Name=?, Species_ID=?, Breed_ID=?, Gender=?, Birthdate=?, Color_Markings=?, Weight=?, Profile_Pic=? WHERE Pet_ID=? AND Status != 'archived'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("siisssdsi", $name, $species_id, $breed_id, $gender, $birthdate, $color, $weight, $profile_pic, $pet_id);
    } else {
        $sql = "UPDATE pets SET Name=?, Species_ID=?, Breed_ID=?, Gender=?, Birthdate=?, Color_Markings=?, Weight=? WHERE Pet_ID=? AND Status != 'archived'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("siisssdi", $name, $species_id, $breed_id, $gender, $birthdate, $color, $weight, $pet_id);
    }

    if ($stmt->execute()) {
        writeAuditLog($conn, $actorId, "Update Pet Record", "pets", $pet_id);
        echo json_encode(["status" => "success", "message" => "Pet updated successfully"]);
    } else {
        error_log("Error in update_pet.php: " . $conn->error);
        echo json_encode(["status" => "error", "message" => "Unable to update pet details."]);
    }
} else {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Invalid Request Method"]);
}
