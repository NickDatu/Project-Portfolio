<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';
require_once '../system/audit_helper.php';
header('Content-Type: application/json; charset=UTF-8');
cityVetEnsurePanelRevisionSchema($conn);

function writeAuditLog($conn, $userId, $action, $tableAffected, $recordId = 0) {
    return auditLog($conn, $userId, $action, $tableAffected, $recordId);
}

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit;
}

$user_id = (int)$_SESSION['user_id'];
$role_id = isset($_SESSION['role_id']) ? (int)$_SESSION['role_id'] : 0;

$owner_id = 0;
if (($role_id === 1 || $role_id === 4) && !empty($_POST['owner_id'])) {
    $requested_owner_id = (int)$_POST['owner_id'];
    $owner_check = $conn->prepare("SELECT Owner_ID FROM owners WHERE Owner_ID = ? AND Status = 'active' LIMIT 1");
    $owner_check->bind_param("i", $requested_owner_id);
    $owner_check->execute();
    $owner_res = $owner_check->get_result();
    if ($owner_res->num_rows > 0) {
        $owner_id = $requested_owner_id;
    } else {
        echo json_encode(["status" => "error", "message" => "Specified owner profile not found."]);
        exit;
    }
    $owner_check->close();
}

if (!$owner_id) {
    $owner_query = $conn->prepare("SELECT Owner_ID FROM owners WHERE User_ID = ? LIMIT 1");
    $owner_query->bind_param("i", $user_id);
    $owner_query->execute();
    $owner_result = $owner_query->get_result();

    if ($owner_result->num_rows === 0) {
        echo json_encode(["status" => "error", "message" => "Owner profile not found."]);
        exit;
    }

    $owner_data = $owner_result->fetch_assoc();
    $owner_id = (int)$owner_data['Owner_ID'];
    $owner_query->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $name = trim($_POST['name'] ?? '');
    $species_id = (int)($_POST['species_id'] ?? 0);
    $breed_id = !empty($_POST['breed_id']) ? (int)$_POST['breed_id'] : null;
    $gender = $_POST['gender'] ?? '';
    $birthdate = $_POST['birthdate'] ?? '';
    $color = trim($_POST['color'] ?? '');
    $weight = $_POST['weight'] ?? 0;

    if ($name === '' || !$species_id || empty($birthdate)) {
        echo json_encode(["status" => "error", "message" => "Pet name, species, and birthdate are required."]);
        exit;
    }

    if (strtotime($birthdate) > time()) {
        echo json_encode(["status" => "error", "message" => "Birthdate cannot be in the future."]);
        exit;
    }

    if (!in_array($gender, ['Male', 'Female'], true)) {
        echo json_encode(["status" => "error", "message" => "Invalid pet gender."]);
        exit;
    }

    if (!is_numeric($weight) || $weight < 0) {
        echo json_encode(["status" => "error", "message" => "Weight must be a valid number."]);
        exit;
    }

    $species_check = $conn->prepare("SELECT Species_ID FROM species WHERE Species_ID = ? AND Status = 'active' AND Species_Name IN ('Dog', 'Cat')");
    $species_check->bind_param("i", $species_id);
    $species_check->execute();
    if ($species_check->get_result()->num_rows === 0) {
        http_response_code(422);
        echo json_encode(["status" => "error", "message" => "Selected species is not available. Only Dog and Cat are allowed."]);
        exit;
    }

    if ($breed_id) {
        $breed_check = $conn->prepare("SELECT Breed_ID FROM breeds WHERE Breed_ID = ? AND Species_ID = ? AND Status = 'active'");
        $breed_check->bind_param("ii", $breed_id, $species_id);
        $breed_check->execute();
        if ($breed_check->get_result()->num_rows === 0) {
            echo json_encode(["status" => "error", "message" => "Selected breed is not available for this species."]);
            exit;
        }
    }

    $profile_pic = null;
    if (isset($_FILES['pet_image']) && $_FILES['pet_image']['error'] === 0) {
        if (!is_uploaded_file($_FILES['pet_image']['tmp_name'])) {
            echo json_encode(["status" => "error", "message" => "Invalid image upload."]);
            exit;
        }
        if ($_FILES['pet_image']['size'] > 5 * 1024 * 1024) {
            echo json_encode(["status" => "error", "message" => "Image file size must not exceed 5MB."]);
            exit;
        }

        $allowed_extensions = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
        $file_extension = strtolower(pathinfo($_FILES["pet_image"]["name"], PATHINFO_EXTENSION));
        
        if (!in_array($file_extension, $allowed_extensions, true)) {
            echo json_encode(["status" => "error", "message" => "Invalid image type. Only JPG, PNG, WEBP, and GIF are allowed."]);
            exit;
        }

        $image_info = @getimagesize($_FILES["pet_image"]["tmp_name"]);
        $allowed_mimes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
        if ($image_info === false || !in_array($image_info['mime'] ?? '', $allowed_mimes, true)) {
            echo json_encode(["status" => "error", "message" => "Invalid image type. Only JPG, PNG, WEBP, and GIF are allowed."]);
            exit;
        }

        $target_dir = "../../uploads/pets/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0755, true); 
        
        $file_name = 'pet_' . bin2hex(random_bytes(16)) . "." . $file_extension;
        
        if (move_uploaded_file($_FILES["pet_image"]["tmp_name"], $target_dir . $file_name)) {
            $profile_pic = $file_name;
        }
    }

    $sql = "INSERT INTO pets (Owner_ID, Name, Species_ID, Breed_ID, Gender, Birthdate, Color_Markings, Weight, Profile_Pic, Status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isiisssds", $owner_id, $name, $species_id, $breed_id, $gender, $birthdate, $color, $weight, $profile_pic);

    if ($stmt->execute()) {
        $pet_id = $conn->insert_id;
        $codeStmt = $conn->prepare("UPDATE pets p JOIN owners o ON o.Owner_ID = p.Owner_ID SET p.Pet_Code = CONCAT('PET-', YEAR(COALESCE(o.Registration_Date, NOW())), '-', LPAD(p.Pet_ID, 6, '0')) WHERE p.Pet_ID = ? AND (p.Pet_Code IS NULL OR p.Pet_Code = '')");
        $codeStmt->bind_param('i', $pet_id); $codeStmt->execute(); $codeStmt->close();
        writeAuditLog($conn, $user_id, "Add Pet Record", "pets", $pet_id);
        echo json_encode(["status" => "success", "message" => "Pet registered successfully!", "pet_id" => $pet_id]);
    } else {
        error_log("Error in add_pet.php: " . $stmt->error);
        echo json_encode(["status" => "error", "message" => "Unable to register pet."]);
    }
}
