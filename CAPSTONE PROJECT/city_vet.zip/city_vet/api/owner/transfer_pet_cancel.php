<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';
require_once '../system/audit_helper.php';

header('Content-Type: application/json; charset=UTF-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['status'=>'error','message'=>'Method not allowed. POST required.']); exit(); }
requireCsrf();
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 3) { http_response_code(403); echo json_encode(['status'=>'error','message'=>'Owner access required.']); exit(); }
cityVetEnsurePetTransferSchema($conn);
$input = json_decode(file_get_contents('php://input'), true); if (!is_array($input)) $input = $_POST;
$transferId = (int)($input['transfer_id'] ?? 0); $userId = (int)$_SESSION['user_id'];
if ($transferId <= 0) { http_response_code(422); echo json_encode(['status'=>'error','message'=>'Transfer request is required.']); exit(); }
$detailStmt = $conn->prepare("SELECT p.Name AS Pet_Name, u.User_ID AS Target_User_ID FROM pet_transfer_requests r JOIN pets p ON p.Pet_ID = r.Pet_ID JOIN owners fo ON fo.Owner_ID = r.From_Owner_ID JOIN owners towner ON towner.Owner_ID = r.To_Owner_ID JOIN users u ON u.User_ID = towner.User_ID WHERE r.Transfer_ID = ? AND fo.User_ID = ? AND r.Status = 'pending' LIMIT 1");
$detailStmt->bind_param('ii', $transferId, $userId); $detailStmt->execute(); $detail = $detailStmt->get_result()->fetch_assoc(); $detailStmt->close();
$stmt = $conn->prepare("UPDATE pet_transfer_requests r JOIN owners o ON o.Owner_ID = r.From_Owner_ID SET r.Status = 'cancelled' WHERE r.Transfer_ID = ? AND o.User_ID = ? AND r.Status = 'pending'");
$stmt->bind_param('ii', $transferId, $userId); $stmt->execute(); $changed = $stmt->affected_rows === 1; $stmt->close();
if (!$changed) { http_response_code(404); echo json_encode(['status'=>'error','message'=>'Pending transfer request not found.']); exit(); }
auditLog($conn, $userId, 'Cancel Pet Transfer', 'pet_transfer_requests', $transferId);
if ($detail) {
    $noticeStmt = $conn->prepare("INSERT INTO notifications (User_ID, Title, Message, Type) VALUES (?, 'Pet transfer cancelled', ?, 'System')");
    if ($noticeStmt) { $cancelMessage = $detail['Pet_Name'] . ' transfer was cancelled by the current owner.'; $targetUserId = (int)$detail['Target_User_ID']; $noticeStmt->bind_param('is', $targetUserId, $cancelMessage); $noticeStmt->execute(); $noticeStmt->close(); }
}
echo json_encode(['status'=>'success','message'=>'Pet transfer request cancelled.']);
