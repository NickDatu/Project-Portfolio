<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';

header('Content-Type: application/json; charset=UTF-8');
if ($_SERVER['REQUEST_METHOD'] !== 'GET') { http_response_code(405); echo json_encode(['status'=>'error','message'=>'Method not allowed.']); exit(); }
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 3) { http_response_code(403); echo json_encode(['status'=>'error','message'=>'Owner access required.']); exit(); }
cityVetEnsurePetTransferSchema($conn);
$userId = (int)$_SESSION['user_id'];
$expireStmt = $conn->prepare("UPDATE pet_transfer_requests r JOIN owners o ON (o.Owner_ID = r.From_Owner_ID OR o.Owner_ID = r.To_Owner_ID) SET r.Status = 'expired' WHERE o.User_ID = ? AND r.Status = 'pending' AND r.Expires_At < NOW()");
$expireStmt->bind_param('i', $userId); $expireStmt->execute(); $expireStmt->close();
$stmt = $conn->prepare("SELECT r.Transfer_ID, r.Pet_ID, r.Expires_At, r.Created_At, r.From_Owner_ID, r.To_Owner_ID, p.Name AS Pet_Name, fo.First_name AS From_First_Name, fo.Last_name AS From_Last_Name, t.First_name AS To_First_Name, t.Last_name AS To_Last_Name, CASE WHEN fo.User_ID = ? THEN 'outgoing' ELSE 'incoming' END AS Direction FROM pet_transfer_requests r JOIN pets p ON p.Pet_ID = r.Pet_ID JOIN owners fo ON fo.Owner_ID = r.From_Owner_ID JOIN owners t ON t.Owner_ID = r.To_Owner_ID WHERE (fo.User_ID = ? OR t.User_ID = ?) AND r.Status = 'pending' ORDER BY r.Created_At DESC");
$stmt->bind_param('iii', $userId, $userId, $userId); $stmt->execute(); $result = $stmt->get_result(); $requests = [];
while ($row = $result->fetch_assoc()) { $requests[] = $row; }
$stmt->close();
echo json_encode(['status'=>'success','requests'=>$requests]);
