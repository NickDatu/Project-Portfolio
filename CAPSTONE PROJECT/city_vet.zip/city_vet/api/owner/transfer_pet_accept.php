<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';
require_once '../system/audit_helper.php';

header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed. POST required.']);
    exit();
}
requireCsrf();
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 3) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Owner access required.']);
    exit();
}

cityVetEnsurePetTransferSchema($conn);
$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) $input = $_POST;
$transferId = (int)($input['transfer_id'] ?? 0);
$otp = trim((string)($input['otp'] ?? $input['otp_code'] ?? ''));
$userId = (int)$_SESSION['user_id'];
if (!preg_match('/^\d{6}$/', $otp)) {
    http_response_code(422);
    echo json_encode(['status' => 'error', 'message' => 'A valid transfer request and 6-digit code are required.']);
    exit();
}

$ownerStmt = $conn->prepare("SELECT Owner_ID, First_name, Last_name FROM owners WHERE User_ID = ? AND Status = 'active' LIMIT 1");
$ownerStmt->bind_param('i', $userId);
$ownerStmt->execute();
$targetOwner = $ownerStmt->get_result()->fetch_assoc();
$ownerStmt->close();
if (!$targetOwner) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Owner profile not found.']);
    exit();
}
$targetOwnerId = (int)$targetOwner['Owner_ID'];

$conn->begin_transaction();
try {
    if ($transferId <= 0) {
        $latestStmt = $conn->prepare("SELECT Transfer_ID FROM pet_transfer_requests WHERE To_Owner_ID = ? AND Status = 'pending' AND Expires_At >= NOW() ORDER BY Created_At DESC, Transfer_ID DESC LIMIT 1");
        $latestStmt->bind_param('i', $targetOwnerId);
        $latestStmt->execute();
        $latest = $latestStmt->get_result()->fetch_assoc();
        $latestStmt->close();
        if (!$latest) throw new Exception('Transfer request is unavailable.');
        $transferId = (int)$latest['Transfer_ID'];
    }
    $requestStmt = $conn->prepare("SELECT r.Transfer_ID, r.Pet_ID, r.From_Owner_ID, r.To_Owner_ID, r.OTP_Hash, r.Expires_At, r.Attempts, r.Status, p.Name AS Pet_Name, fo.First_name AS From_First_Name, fo.Last_name AS From_Last_Name FROM pet_transfer_requests r JOIN pets p ON p.Pet_ID = r.Pet_ID JOIN owners fo ON fo.Owner_ID = r.From_Owner_ID WHERE r.Transfer_ID = ? AND r.To_Owner_ID = ? FOR UPDATE");
    $requestStmt->bind_param('ii', $transferId, $targetOwnerId);
    $requestStmt->execute();
    $request = $requestStmt->get_result()->fetch_assoc();
    $requestStmt->close();
    if (!$request || $request['Status'] !== 'pending') throw new Exception('Transfer request is unavailable.');
    if (strtotime($request['Expires_At']) < time()) {
        $expireStmt = $conn->prepare("UPDATE pet_transfer_requests SET Status = 'expired' WHERE Transfer_ID = ? AND Status = 'pending'");
        $expireStmt->bind_param('i', $transferId);
        $expireStmt->execute();
        $expireStmt->close();
        throw new Exception('Transfer request expired.');
    }
    if ((int)$request['Attempts'] >= 5) throw new Exception('Maximum verification attempts exceeded.');

    if (!password_verify($otp, $request['OTP_Hash'])) {
        $attempts = (int)$request['Attempts'] + 1;
        $newStatus = $attempts >= 5 ? 'cancelled' : 'pending';
        $attemptStmt = $conn->prepare('UPDATE pet_transfer_requests SET Attempts = ?, Status = ? WHERE Transfer_ID = ? AND Status = \'pending\'');
        $attemptStmt->bind_param('isi', $attempts, $newStatus, $transferId);
        $attemptStmt->execute();
        $attemptStmt->close();
        $conn->commit();
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => $attempts >= 5 ? 'Invalid code. The transfer request has been cancelled.' : 'Invalid code. Please try again.']);
        exit();
    }

    $petStmt = $conn->prepare("SELECT Pet_ID, Owner_ID, Status FROM pets WHERE Pet_ID = ? FOR UPDATE");
    $petStmt->bind_param('i', $request['Pet_ID']);
    $petStmt->execute();
    $pet = $petStmt->get_result()->fetch_assoc();
    $petStmt->close();
    if (!$pet || (int)$pet['Owner_ID'] !== (int)$request['From_Owner_ID'] || $pet['Status'] !== 'active') throw new Exception('The pet is no longer eligible for transfer.');

    $activeAppointmentStmt = $conn->prepare("SELECT 1 FROM appointments a LEFT JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID WHERE (a.Pet_ID = ? OR ap.Pet_ID = ?) AND a.Status IN ('Pending','Confirmed','Checked In','In Consultation') LIMIT 1");
    $activeAppointmentStmt->bind_param('ii', $request['Pet_ID'], $request['Pet_ID']);
    $activeAppointmentStmt->execute();
    $hasActiveAppointment = (bool)$activeAppointmentStmt->get_result()->fetch_row();
    $activeAppointmentStmt->close();
    $activeConsultationStmt = $conn->prepare("SELECT 1 FROM consultations WHERE Pet_ID = ? AND Status IN ('Pending','Ongoing') LIMIT 1");
    $activeConsultationStmt->bind_param('i', $request['Pet_ID']);
    $activeConsultationStmt->execute();
    $hasActiveConsultation = (bool)$activeConsultationStmt->get_result()->fetch_row();
    $activeConsultationStmt->close();
    $hasActiveQueue = false;
    if (cityVetTableExists($conn, 'live_queue_tickets')) {
        $queueStmt = $conn->prepare("SELECT 1 FROM live_queue_tickets WHERE Pet_ID = ? AND Status IN ('Waiting','Called','Serving') LIMIT 1");
        $queueStmt->bind_param('i', $request['Pet_ID']);
        $queueStmt->execute();
        $hasActiveQueue = (bool)$queueStmt->get_result()->fetch_row();
        $queueStmt->close();
    }
    if ($hasActiveAppointment || $hasActiveConsultation || $hasActiveQueue) throw new Exception('This pet has an active appointment, consultation, or queue ticket.');

    $updatePet = $conn->prepare('UPDATE pets SET Owner_ID = ? WHERE Pet_ID = ? AND Owner_ID = ? AND Status = \'active\'');
    $updatePet->bind_param('iii', $targetOwnerId, $request['Pet_ID'], $request['From_Owner_ID']);
    if (!$updatePet->execute() || $updatePet->affected_rows !== 1) throw new Exception('Unable to complete pet transfer.');
    $updatePet->close();
    $completeStmt = $conn->prepare("UPDATE pet_transfer_requests SET Status = 'completed', Completed_At = NOW() WHERE Transfer_ID = ? AND Status = 'pending'");
    $completeStmt->bind_param('i', $transferId);
    if (!$completeStmt->execute() || $completeStmt->affected_rows !== 1) throw new Exception('Unable to complete transfer request.');
    $completeStmt->close();
    $conn->commit();
} catch (Throwable $e) {
    $conn->rollback();
    auditLog($conn, $userId, 'Accept Pet Transfer', 'pet_transfer_requests', $transferId, ['outcome' => 'denied', 'metadata' => ['reason' => $e->getMessage()]]);
    http_response_code(409);
    $errorMessage = match ($e->getMessage()) {
        'Transfer request expired.' => 'This transfer code has expired. Ask the current owner to start a new transfer request.',
        'Transfer request is unavailable.' => 'No active transfer request was found. Ask the current owner to start a new transfer request.',
        default => 'Transfer request is invalid, expired, or no longer available.'
    };
    echo json_encode(['status' => 'error', 'message' => $errorMessage]);
    exit();
}

$petId = (int)$request['Pet_ID'];
$fromOwnerId = (int)$request['From_Owner_ID'];
$title = 'Pet transfer completed';
$newMessage = "{$request['Pet_Name']} has been transferred to your account.";
$oldMessage = "{$request['Pet_Name']} has been transferred to the new owner.";
$noticeStmt = $conn->prepare("INSERT INTO notifications (User_ID, Title, Message, Type) VALUES (?, ?, ?, 'System')");
if ($noticeStmt) {
    $noticeStmt->bind_param('iss', $userId, $title, $newMessage); $noticeStmt->execute();
    $oldUserStmt = $conn->prepare('SELECT User_ID FROM owners WHERE Owner_ID = ? LIMIT 1');
    $oldUserStmt->bind_param('i', $fromOwnerId); $oldUserStmt->execute(); $oldUser = $oldUserStmt->get_result()->fetch_assoc(); $oldUserStmt->close();
    if ($oldUser) { $oldUserId = (int)$oldUser['User_ID']; $noticeStmt->bind_param('iss', $oldUserId, $title, $oldMessage); $noticeStmt->execute(); }
    $noticeStmt->close();
}
auditLog($conn, $userId, 'Complete Pet Transfer', 'pet_transfer_requests', $transferId, ['metadata' => ['pet_id' => $petId, 'from_owner_id' => $fromOwnerId, 'to_owner_id' => $targetOwnerId, 'transfer_id' => $transferId]]);
echo json_encode(['status' => 'success', 'message' => 'Pet transfer completed successfully.', 'pet_id' => $petId]);
