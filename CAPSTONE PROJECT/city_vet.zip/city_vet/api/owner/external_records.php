<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../../config/schema_ensure.php';
require_once '../system/audit_helper.php';
header('Content-Type: application/json; charset=UTF-8');

if (!isset($_SESSION['user_id'], $_SESSION['role_id'])) { http_response_code(401); echo json_encode(['status'=>'error','message'=>'Unauthorized']); exit; }
cityVetEnsurePanelRevisionSchema($conn); requireCsrf();
$userId = (int)$_SESSION['user_id']; $roleId = (int)$_SESSION['role_id'];
$petId = (int)($_POST['pet_id'] ?? 0); $action = trim((string)($_POST['action'] ?? 'create'));
if (!$petId) { http_response_code(422); echo json_encode(['status'=>'error','message'=>'Pet ID is required.']); exit; }
$ownerCheck = $conn->prepare("SELECT p.Pet_ID, p.Owner_ID, p.Status, o.User_ID FROM pets p JOIN owners o ON o.Owner_ID=p.Owner_ID WHERE p.Pet_ID=? LIMIT 1");
$ownerCheck->bind_param('i',$petId); $ownerCheck->execute(); $pet = $ownerCheck->get_result()->fetch_assoc(); $ownerCheck->close();
if (!$pet || ($roleId === 3 && (int)$pet['User_ID'] !== $userId)) { http_response_code(403); echo json_encode(['status'=>'error','message'=>'Pet access denied.']); exit; }
if ($roleId === 3 && $pet['Status'] === 'archived') { http_response_code(422); echo json_encode(['status'=>'error','message'=>'Archived pets are read-only.']); exit; }
if ($action === 'verify' || $action === 'delete' || $action === 'edit') {
    if (!in_array($roleId, [1,2,4], true)) { http_response_code(403); echo json_encode(['status'=>'error','message'=>'Only City Vet staff may modify verification or existing external records.']); exit; }
    $recordId=(int)($_POST['external_record_id']??0); if(!$recordId){http_response_code(422);echo json_encode(['status'=>'error','message'=>'External record ID is required.']);exit;}
    if($action==='verify') { $s=$conn->prepare("UPDATE pet_external_records SET Verified_By=?, Verified_At=NOW() WHERE External_Record_ID=? AND Pet_ID=? AND Is_Deleted=0"); $s->bind_param('iii',$userId,$recordId,$petId); }
    elseif($action==='delete') { $s=$conn->prepare("UPDATE pet_external_records SET Is_Deleted=1 WHERE External_Record_ID=? AND Pet_ID=? AND Is_Deleted=0"); $s->bind_param('ii',$recordId,$petId); }
    else { $name=trim((string)($_POST['name']??''));$notes=trim((string)($_POST['notes']??''));$s=$conn->prepare("UPDATE pet_external_records SET Source_Clinic=?, Record_Type=?, Record_Date=?, Name=?, Medicine=?, Dosage=?, Lot_Number=?, Provider=?, Notes=? WHERE External_Record_ID=? AND Pet_ID=? AND Is_Deleted=0 AND Verified_At IS NULL");$source=trim((string)($_POST['source_clinic']??''));$type=trim((string)($_POST['record_type']??'Other'));$date=trim((string)($_POST['record_date']??''))?:null;$medicine=trim((string)($_POST['medicine']??''));$dosage=trim((string)($_POST['dosage']??''));$lot=trim((string)($_POST['lot_number']??''));$provider=trim((string)($_POST['provider']??''));$s->bind_param('sssssssssii',$source,$type,$date,$name,$medicine,$dosage,$lot,$provider,$notes,$recordId,$petId);}
    $ok=$s->execute();$s->close(); if(!$ok){http_response_code(400);echo json_encode(['status'=>'error','message'=>'Unable to update external record.']);exit;} auditLog($conn,$userId,'External Pet Record '.ucfirst($action),'pet_external_records',$recordId); echo json_encode(['status'=>'success']); exit;
}
$source=trim((string)($_POST['source_clinic']??''));$type=trim((string)($_POST['record_type']??'Other'));$date=trim((string)($_POST['record_date']??''))?:null;$name=trim((string)($_POST['name']??''));$medicine=trim((string)($_POST['medicine']??''));$dosage=trim((string)($_POST['dosage']??''));$lot=trim((string)($_POST['lot_number']??''));$provider=trim((string)($_POST['provider']??''));$notes=trim((string)($_POST['notes']??''));
if(!in_array($type,['Vaccination','Treatment','Deworming','Other'],true)||($name===''&&$medicine==='')){http_response_code(422);echo json_encode(['status'=>'error','message'=>'Record type and record name are required.']);exit;}
$attachment=null;
if(isset($_FILES['attachment'])&&$_FILES['attachment']['error']!==UPLOAD_ERR_NO_FILE){$f=$_FILES['attachment'];if($f['error']!==UPLOAD_ERR_OK||$f['size']>5*1024*1024){http_response_code(422);echo json_encode(['status'=>'error','message'=>'Attachment must not exceed 5MB.']);exit;} $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));if(!in_array($ext,['jpg','jpeg','png','webp','pdf'],true)){http_response_code(422);echo json_encode(['status'=>'error','message'=>'Invalid attachment type.']);exit;} $dir='../../uploads/external_records/';if(!is_dir($dir))mkdir($dir,0755,true);$attachment='external_'.bin2hex(random_bytes(16)).'.'.$ext;if(!move_uploaded_file($f['tmp_name'],$dir.$attachment)){http_response_code(500);echo json_encode(['status'=>'error','message'=>'Unable to save attachment.']);exit;} $attachment='uploads/external_records/'.$attachment;}
$s=$conn->prepare("INSERT INTO pet_external_records (Pet_ID,Source_Clinic,Record_Type,Record_Date,Name,Medicine,Dosage,Lot_Number,Provider,Notes,Attachment_Path,Created_By) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");$s->bind_param('issssssssssi',$petId,$source,$type,$date,$name,$medicine,$dosage,$lot,$provider,$notes,$attachment,$userId);$ok=$s->execute();$id=$conn->insert_id;$s->close();if(!$ok){http_response_code(500);echo json_encode(['status'=>'error','message'=>'Unable to save external record.']);exit;}auditLog($conn,$userId,'Add External Pet Record','pet_external_records',$id);echo json_encode(['status'=>'success','external_record_id'=>$id]);
