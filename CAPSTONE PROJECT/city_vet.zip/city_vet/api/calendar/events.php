<?php
require_once '../../config/session.php';
require_once '../../config/db_connection.php';
require_once '../notifications/notify.php';
require_once '../../config/schema_ensure.php';
require_once dirname(__DIR__) . '/owner/spay_neuter_eligibility.php';
header("Content-Type: application/json; charset=UTF-8");

if (isset($conn) && $conn instanceof mysqli) {
    $conn->set_charset("utf8mb4");
    cityVetEnsureNotificationSchema($conn);
    cityVetEnsureEventBarangaySchema($conn);
    cityVetEnsureCalendarEventTypeSchema($conn);
    cityVetEnsureSpayConfirmationSchema($conn);
    cityVetEnsurePanelRevisionSchema($conn);
}

function jsonResponse($payload, $code = 200) {
    http_response_code($code);
    echo json_encode($payload);
    exit();
}

function requireLogin() {
    if (!isset($_SESSION['user_id'], $_SESSION['role_id'])) {
        jsonResponse(["status" => "error", "message" => "Unauthorized"], 401);
    }
}

function requireRole($roles) {
    requireLogin();
    if (!in_array((int)$_SESSION['role_id'], $roles, true)) {
        jsonResponse(["status" => "error", "message" => "Access denied"], 403);
    }
}

function writeAuditLog($conn, $userId, $action, $tableAffected, $recordId = 0) {
    if (!$userId) return;

    $stmt = $conn->prepare("INSERT INTO audit_logs (User_ID, Action, Table_Affected, Record_ID) VALUES (?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("issi", $userId, $action, $tableAffected, $recordId);
        $stmt->execute();
        $stmt->close();
    }
}

function notifyUsersByRole($conn, $roleId, $title, $message, $type = 'SpayNeuter', $eventId = null, $barangay = null) {
    if ($barangay !== null && $barangay !== '') {
        $users = $conn->prepare("SELECT u.User_ID FROM users u JOIN owners o ON o.User_ID = u.User_ID WHERE u.Role_ID = ? AND u.Status = 'active' AND (o.Barangay = ? OR (o.Barangay IS NULL AND o.Address LIKE CONCAT('%, ', ?)))");
        $users->bind_param("iss", $roleId, $barangay, $barangay);
    } else {
        $users = $conn->prepare("SELECT User_ID FROM users WHERE Role_ID = ? AND Status = 'active'");
        $users->bind_param("i", $roleId);
    }
    $users->execute();
    $result = $users->get_result();

    $notice = $conn->prepare("INSERT INTO notifications (User_ID, Title, Message, Type, Event_ID) VALUES (?, ?, ?, ?, ?)");
    while ($row = $result->fetch_assoc()) {
        $uid = (int)$row['User_ID'];
        $notice->bind_param("isssi", $uid, $title, $message, $type, $eventId);
        $notice->execute();
    }
    $notice->close();
    $users->close();
}

function notifyUser($conn, $userId, $title, $message, $type = 'SpayNeuter', $eventId = null) {
    $stmt = $conn->prepare("INSERT INTO notifications (User_ID, Title, Message, Type, Event_ID) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("isssi", $userId, $title, $message, $type, $eventId);
    $stmt->execute();
    $stmt->close();
}

function emailEventAnnouncementToAllOwners($conn, $title, $eventType, $eventDate, $barangay, $content) {
    $result = $conn->query("SELECT u.Email, o.First_name FROM users u JOIN owners o ON o.User_ID = u.User_ID WHERE u.Role_ID = 3 AND u.Status = 'active' AND o.Status = 'active' AND u.Email IS NOT NULL AND u.Email <> ''");
    if (!$result) return;
    $location = $barangay !== null && trim($barangay) !== '' ? trim($barangay) : 'City Veterinary Office';
    $subject = $eventType === 'SpayNeuter' ? "New Spay/Neuter Schedule: {$title}" : "City Vet Announcement: {$title}";
    $plain = "Hello,\n\n{$title} will be held on {$eventDate} at {$location}.\n\n" . trim($content) . "\n\nThis announcement was sent to all registered City Vet pet owners.";
    while ($row = $result->fetch_assoc()) {
        $name = htmlspecialchars((string)($row['First_name'] ?? 'Pet Owner'), ENT_QUOTES, 'UTF-8');
        $safeTitle = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
        $safeContent = nl2br(htmlspecialchars($content, ENT_QUOTES, 'UTF-8'));
        $html = '<p>Hello <strong>' . $name . '</strong>,</p><p><strong>' . $safeTitle . '</strong> will be held on <strong>' . htmlspecialchars($eventDate, ENT_QUOTES, 'UTF-8') . '</strong> at <strong>' . htmlspecialchars($location, ENT_QUOTES, 'UTF-8') . '</strong>.</p><p>' . $safeContent . '</p><p>This announcement was sent to all registered City Vet pet owners.</p>';
        sendResendEmail((string)$row['Email'], $subject, $plain, $html);
    }
}

define('MAX_EVENTS_PER_DAY', 10);

function approvedPetCount($conn, $eventId) {
    $stmt = $conn->prepare("
        SELECT COUNT(ap.Appointment_Pet_ID) AS used_slots
        FROM appointments a
        JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID
        WHERE a.Event_ID = ? AND a.Status IN ('Confirmed', 'Checked In', 'In Consultation', 'Completed')
    ");
    $stmt->bind_param("i", $eventId);
    $stmt->execute();
    return (int)$stmt->get_result()->fetch_assoc()['used_slots'];
}

function eventCountSql($condition) {
    $cond = $condition === '' ? '' : " AND $condition";
    return "(SELECT COUNT(ap.Appointment_Pet_ID) FROM appointments a JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID WHERE a.Event_ID = ce.Event_ID$cond)";
}

function reopenEventIfSlotsFree($conn, $eventId) {
    $stmt = $conn->prepare("SELECT Max_Slots, Event_Date, Status FROM calendar_events WHERE Event_ID = ?");
    $stmt->bind_param("i", $eventId);
    $stmt->execute();
    $event = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($event && $event['Status'] === 'Closed' && $event['Event_Date'] >= date('Y-m-d') && approvedPetCount($conn, $eventId) < (int)$event['Max_Slots']) {
        $open = $conn->prepare("UPDATE calendar_events SET Status = 'Open' WHERE Event_ID = ? AND Status = 'Closed'");
        $open->bind_param("i", $eventId);
        $open->execute();
        $open->close();
    }
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    
    $conn->query("UPDATE calendar_events SET Status = 'Closed' WHERE Event_Date < CURDATE() AND Status = 'Open'");

    $mode = $_GET['mode'] ?? 'events';

    if ($mode === 'history' || $mode === 'past_events') {
        requireRole([1, 2, 4]);

        $where = ["(ce.Event_Date < CURDATE() OR ce.Status = 'Closed')"];
        $types = '';
        $params = [];
        $fDate = trim($_GET['date'] ?? '');
        $fMonth = trim($_GET['month'] ?? '');
        $fYear = trim($_GET['year'] ?? '');
        $fEventType = trim($_GET['event_type'] ?? '');
        $fEventTitle = trim($_GET['event_title'] ?? '');
        if (in_array($fEventType, ['SpayNeuter', 'General', 'Holiday'], true)) {
            $where[] = "ce.Event_Type = ?";
            $types .= 's';
            $params[] = $fEventType;
        }
        if ($fEventTitle !== '') {
            $where[] = "ce.Title LIKE ?";
            $types .= 's';
            $params[] = '%' . $fEventTitle . '%';
        }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $fDate)) {
            $where[] = "ce.Event_Date = ?";
            $types .= 's';
            $params[] = $fDate;
        } elseif (preg_match('/^\d{4}-\d{2}$/', $fMonth)) {
            $where[] = "DATE_FORMAT(ce.Event_Date, '%Y-%m') = ?";
            $types .= 's';
            $params[] = $fMonth;
        } elseif (preg_match('/^\d{4}$/', $fYear)) {
            $where[] = "YEAR(ce.Event_Date) = ?";
            $types .= 'i';
            $params[] = (int)$fYear;
        }

        $sql = "
            SELECT
                ce.Event_ID,
                ce.Title,
                ce.Event_Type,
                ce.Event_Date,
                ce.Max_Slots,
                ce.Status,
                ce.Correction_Reason,
                ce.Corrected_By,
                ce.Corrected_At,
                " . eventCountSql('') . " AS Total_Booked,
                " . eventCountSql("a.Status IN ('Confirmed', 'Checked In', 'In Consultation', 'Completed', 'No Show')") . " AS Confirmed_Count,
                " . eventCountSql("a.Status = 'Completed'") . " AS Catered_Count,
                " . eventCountSql("a.Status = 'Cancelled'") . " AS Cancelled_Count,
                " . eventCountSql("a.Status = 'No Show'") . " AS No_Show_Count,
                " . eventCountSql("a.Status = 'Pending'") . " AS Pending_Count
            FROM calendar_events ce
            WHERE " . implode(' AND ', $where) . "
            ORDER BY ce.Event_Date DESC, ce.Event_ID DESC
        ";
        $stmt = $conn->prepare($sql);
        if ($types !== '') {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $history = [];
        $totals = ['events' => 0, 'booked' => 0, 'confirmed' => 0, 'catered' => 0, 'cancelled' => 0, 'no_show' => 0, 'pending' => 0];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                foreach (['Total_Booked', 'Confirmed_Count', 'Catered_Count', 'Cancelled_Count', 'No_Show_Count', 'Pending_Count'] as $key) {
                    $row[$key] = (int)$row[$key];
                }
                $totals['events']++;
                $totals['booked'] += $row['Total_Booked'];
                $totals['confirmed'] += $row['Confirmed_Count'];
                $totals['catered'] += $row['Catered_Count'];
                $totals['cancelled'] += $row['Cancelled_Count'];
                $totals['no_show'] += $row['No_Show_Count'];
                $totals['pending'] += $row['Pending_Count'];
                $bookingStmt = $conn->prepare("SELECT Appointment_ID, Status, Correction_Reason, Corrected_At FROM appointments WHERE Event_ID = ? ORDER BY Appointment_ID ASC");
                $bookingEventId = (int)$row['Event_ID']; $bookingStmt->bind_param('i', $bookingEventId); $bookingStmt->execute(); $row['Bookings'] = $bookingStmt->get_result()->fetch_all(MYSQLI_ASSOC); $bookingStmt->close();
                $history[] = $row;
            }
        }
        $stmt->close();
        jsonResponse(["status" => "success", "history" => $history, "totals" => $totals]);
    }

    if ($mode === 'my_bookings') {
        requireRole([3]);

        $userId = (int)$_SESSION['user_id'];
        $stmt = $conn->prepare("
            SELECT
                a.Appointment_ID,
                a.Event_ID,
                a.Status,
                a.Confirmed_At,
                a.Owner_Confirmed_At,
                a.Notes,
                a.Appointment_Date,
                COALESCE(ce.Title, s.Service_Name, 'Appointment') AS Title,
                ce.Event_Type,
                COALESCE(ce.Event_Date, DATE(a.Appointment_Date)) AS Event_Date,
                ce.Status AS Event_Status,
                s.Service_Name,
                COUNT(DISTINCT COALESCE(ap.Pet_ID, a.Pet_ID)) AS Pet_Count,
                GROUP_CONCAT(DISTINCT p.Name ORDER BY p.Name SEPARATOR ', ') AS Pet_Names
            FROM appointments a
            LEFT JOIN calendar_events ce ON ce.Event_ID = a.Event_ID
            LEFT JOIN services s ON s.Service_ID = a.Service_ID
            JOIN owners o ON o.Owner_ID = a.Owner_ID
            LEFT JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID
            LEFT JOIN pets p ON p.Pet_ID = COALESCE(ap.Pet_ID, a.Pet_ID)
            WHERE o.User_ID = ?
            GROUP BY a.Appointment_ID
            ORDER BY COALESCE(ce.Event_Date, DATE(a.Appointment_Date)) DESC, a.Appointment_ID DESC
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $bookings = [];
        $today = date('Y-m-d');
        $now = date('Y-m-d H:i:s');
        while ($row = $result->fetch_assoc()) {
            $row['Pet_Count'] = (int)$row['Pet_Count'];
            $row['Can_Cancel'] = in_array($row['Status'], ['Pending', 'Confirmed'], true)
                && ($row['Event_ID'] !== null
                    ? $row['Event_Date'] >= $today
                    : $row['Appointment_Date'] >= $now)
                && ($row['Event_ID'] === null || empty($row['Owner_Confirmed_At']));
            $bookings[] = $row;
        }
        $stmt->close();
        jsonResponse(["status" => "success", "bookings" => $bookings]);
    }

    if ($mode === 'event_details') {
        requireRole([1, 2, 4]);
        $eventId = (int)($_GET['event_id'] ?? 0);
        if (!$eventId) {
            jsonResponse(["status" => "error", "message" => "Missing event ID"], 422);
        }

        $stmt = $conn->prepare("SELECT Event_ID, Title, Event_Type, Event_Date, Barangay, Max_Slots, Content, Status FROM calendar_events WHERE Event_ID = ?");
        $stmt->bind_param("i", $eventId);
        $stmt->execute();
        $event = $stmt->get_result()->fetch_assoc();
        if (!$event) {
            jsonResponse(["status" => "error", "message" => "Event not found"], 404);
        }

        jsonResponse(["status" => "success", "event" => $event]);
    }

    if ($mode === 'pending') {
        requireRole([1, 4]);

        $sql = "
            SELECT
                a.Appointment_ID,
                a.Event_ID,
                a.Appointment_Date,
                a.Status,
                a.Confirmation_Attempts,
                a.Last_Contacted_At,
                a.Callback_Deadline,
                a.Owner_Confirmed_At,
                ce.Title,
                ce.Event_Date,
                o.First_name,
                o.Last_name,
                o.Contact_number,
                u.Email,
                COUNT(ap.Pet_ID) AS Pet_Count,
                GROUP_CONCAT(p.Name ORDER BY p.Name SEPARATOR ', ') AS Pet_Names
            FROM appointments a
            JOIN calendar_events ce ON ce.Event_ID = a.Event_ID
            JOIN owners o ON o.Owner_ID = a.Owner_ID
            JOIN users u ON u.User_ID = o.User_ID
            JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID
            JOIN pets p ON p.Pet_ID = ap.Pet_ID AND p.Status != 'archived'
            WHERE a.Status IN ('Pending', 'Confirmed')
              AND a.Owner_Confirmed_At IS NULL
            GROUP BY a.Appointment_ID
            ORDER BY ce.Event_Date DESC, a.Appointment_ID DESC
        ";
        $result = $conn->query($sql);
        $rows = [];
        while ($row = $result->fetch_assoc()) {
            $row['Awaiting_Callback'] = (int)$row['Confirmation_Attempts'] >= 3 && empty($row['Owner_Confirmed_At']);
            $rows[] = $row;
        }
        jsonResponse(["status" => "success", "bookings" => $rows]);
    }

    $sql = "
        SELECT
            ce.Event_ID,
            ce.Title,
            ce.Event_Type,
            ce.Event_Date,
            ce.Barangay,
            ce.Max_Slots,
            ce.Content,
            ce.Status,
            " . eventCountSql("a.Status IN ('Confirmed', 'Checked In', 'In Consultation', 'Completed')") . " AS Used_Slots,
            " . eventCountSql("a.Status = 'Pending'") . " AS Pending_Count,
            " . eventCountSql("a.Status = 'Cancelled'") . " AS Cancelled_Count,
            " . eventCountSql("a.Status = 'No Show'") . " AS No_Show_Count,
            " . eventCountSql("a.Status = 'Completed'") . " AS Catered_Count
        FROM calendar_events ce
        WHERE ce.Status != 'Cancelled'
        ORDER BY ce.Event_Date DESC, ce.Event_ID DESC
    ";
    $result = $conn->query($sql);
    $events = [];
    while ($row = $result->fetch_assoc()) {
        $row['Used_Slots'] = (int)$row['Used_Slots'];
        foreach (['Pending_Count', 'Cancelled_Count', 'No_Show_Count', 'Catered_Count'] as $countKey) {
            $row[$countKey] = (int)$row[$countKey];
        }
        $row['Confirmed_Count'] = (int)$row['Used_Slots'];
        $row['Remaining_Slots'] = max(0, (int)$row['Max_Slots'] - (int)$row['Used_Slots']);
        $row['Is_Full'] = $row['Remaining_Slots'] <= 0 && (int)$row['Max_Slots'] > 0;

        
        if ($row['Status'] === 'Closed' && $row['Remaining_Slots'] > 0 && $row['Event_Date'] >= date('Y-m-d')) {
            $conn->query("UPDATE calendar_events SET Status = 'Open' WHERE Event_ID = " . (int)$row['Event_ID'] . " AND Status = 'Closed'");
            $row['Status'] = 'Open';
            $row['Is_Full'] = false;
        }

        $events[] = $row;
    }
    jsonResponse(["status" => "success", "events" => $events]);
}

if ($method !== 'POST') {
    jsonResponse(["status" => "error", "message" => "Invalid request method"], 405);
}

requireCsrf();

$input = json_decode(file_get_contents("php://input"), true);
if (!is_array($input)) {
    $input = $_POST;
}
$action = $input['action'] ?? '';

if ($action === 'create_event') {
    requireRole([1, 4]);

    $title = trim($input['title'] ?? '');
    $eventType = trim($input['event_type'] ?? 'SpayNeuter');
    $eventDate = trim($input['event_date'] ?? '');
    $maxSlots = in_array($eventType, ['General', 'Holiday'], true) ? 0 : (int)($input['max_slots'] ?? 300);
    $content = trim($input['content'] ?? '');
    $barangay = trim($input['barangay'] ?? '');
    $barangay = $barangay === '' ? null : $barangay;
    $createdBy = (int)$_SESSION['user_id'];

    if ($title === '' || $eventDate === '') {
        jsonResponse(["status" => "error", "message" => "Please provide title and date."], 422);
    }
    if (!in_array($eventType, ['SpayNeuter', 'General', 'Holiday'], true)) {
        jsonResponse(["status" => "error", "message" => "Invalid event type."], 422);
    }
    if ($eventType === 'SpayNeuter' && $maxSlots < 1) {
        jsonResponse(["status" => "error", "message" => "Please provide available slots for Spay/Neuter events."], 422);
    }

    $dateObj = DateTime::createFromFormat('Y-m-d', $eventDate);
    if (!$dateObj || $dateObj->format('Y-m-d') !== $eventDate) {
        jsonResponse(["status" => "error", "message" => "Invalid event date."], 422);
    }

    $conn->begin_transaction();
    try {
        $countStmt = $conn->prepare("SELECT Event_ID FROM calendar_events WHERE Event_Date = ? AND Status != 'Cancelled' FOR UPDATE");
        $countStmt->bind_param("s", $eventDate);
        $countStmt->execute();
        $eventCount = $countStmt->get_result()->num_rows;
        $countStmt->close();

        if ($eventCount >= MAX_EVENTS_PER_DAY) {
            $conn->rollback();
            jsonResponse(["status" => "error", "message" => "A maximum of " . MAX_EVENTS_PER_DAY . " events can be posted on the same day."], 422);
        }

        $stmt = $conn->prepare("INSERT INTO calendar_events (Title, Event_Type, Event_Date, Barangay, Max_Slots, Content, Created_By) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssisi", $title, $eventType, $eventDate, $barangay, $maxSlots, $content, $createdBy);

        if (!$stmt->execute()) {
            throw new Exception("Unable to create event.");
        }

        $eventId = $conn->insert_id;
        $stmt->close();
        $conn->commit();
    } catch (Exception $e) {
        $conn->rollback();
        jsonResponse(["status" => "error", "message" => "Unable to create event."], 400);
    }

    $auditAction = $eventType === 'Holiday' ? "Create Holiday Event" : ($eventType === 'General' ? "Create General Event" : "Create Spay/Neuter Event");
    writeAuditLog($conn, $createdBy, $auditAction, "calendar_events", $eventId);

    if ($eventType === 'SpayNeuter') {
        notifyUsersByRole(
            $conn,
            3,
            "New Spay & Neuter Schedule",
            "{$title} is available on {$eventDate}. Book your registered pets while slots are available.",
            'SpayNeuter',
            $eventId
        );
    } else {
        notifyUsersByRole(
            $conn,
            3,
            "New Event: {$title}",
            "{$title} on {$eventDate}. {$content}",
            'System',
            $eventId,
            $barangay
        );
    }

    emailEventAnnouncementToAllOwners($conn, $title, $eventType, $eventDate, $barangay, $content);

    $successMsg = $eventType === 'Holiday' ? "Holiday added to the calendar." : ($eventType === 'General' ? "General event created and pet owners were notified." : "Event created and pet owners were notified.");
    jsonResponse(["status" => "success", "message" => $successMsg, "event_id" => $eventId]);
}

if ($action === 'book_event' || $action === 'staff_book_event') {
    requireRole([1, 3, 4]);

    $roleId = (int)$_SESSION['role_id'];
    $userId = (int)$_SESSION['user_id'];
    $eventId = (int)($input['event_id'] ?? 0);
    $petIds = $input['pet_ids'] ?? [];
    if (!is_array($petIds)) $petIds = [$petIds];
    $petIds = array_values(array_unique(array_filter(array_map('intval', $petIds))));

    if (!$eventId || count($petIds) === 0) {
        jsonResponse(["status" => "error", "message" => "Select an event and at least one pet."], 422);
    }

    if ($roleId === 3 && count($petIds) > 2) {
        jsonResponse(["status" => "error", "message" => "You can book a maximum of 2 pets per Spay/Neuter event."], 422);
    }

    if ($roleId === 3) {
        $ownerStmt = $conn->prepare("SELECT Owner_ID, User_ID FROM owners WHERE User_ID = ? AND Status = 'active'");
        $ownerStmt->bind_param("i", $userId);
        $ownerStmt->execute();
        $owner = $ownerStmt->get_result()->fetch_assoc();
        if (!$owner) {
            jsonResponse(["status" => "error", "message" => "Owner profile not found."], 404);
        }
        $ownerId = (int)$owner['Owner_ID'];
        $ownerUserId = (int)$owner['User_ID'];
        $bookingStatus = 'Pending';
        $confirmedAt = null;
        $notes = "Spay/Neuter event booking for " . count($petIds) . " pet(s).";
    } else {
        $ownerId = (int)($input['owner_id'] ?? 0);
        if (!$ownerId) {
            jsonResponse(["status" => "error", "message" => "Please select a pet owner."], 422);
        }
        $ownerStmt = $conn->prepare("SELECT Owner_ID, User_ID FROM owners WHERE Owner_ID = ? AND Status = 'active'");
        $ownerStmt->bind_param("i", $ownerId);
        $ownerStmt->execute();
        $owner = $ownerStmt->get_result()->fetch_assoc();
        if (!$owner) {
            jsonResponse(["status" => "error", "message" => "Owner profile not found."], 404);
        }
        $ownerUserId = (int)$owner['User_ID'];
        $bookingStatus = 'Confirmed';
        $confirmedAt = date('Y-m-d H:i:s');
        $notes = "Spay/Neuter event booking by staff for " . count($petIds) . " pet(s).";
    }

    $conn->begin_transaction();
    try {
        $eventStmt = $conn->prepare("SELECT Event_ID, Title, Event_Date, Max_Slots, Status FROM calendar_events WHERE Event_ID = ? FOR UPDATE");
        $eventStmt->bind_param("i", $eventId);
        $eventStmt->execute();
        $event = $eventStmt->get_result()->fetch_assoc();

        if (!$event || $event['Status'] !== 'Open') {
            throw new Exception("This Spay/Neuter event is not available for booking.");
        }
        if ($event['Event_Date'] < date('Y-m-d')) {
            throw new Exception("This event date has already passed and can no longer be booked.");
        }

        if ($roleId === 3) {
            $ownerBookingStmt = $conn->prepare("SELECT a.Appointment_ID FROM appointments a WHERE a.Event_ID = ? AND a.Owner_ID = ? AND a.Status IN ('Pending', 'Confirmed', 'Checked In', 'In Consultation', 'Completed', 'No Show') LIMIT 1 FOR UPDATE");
            $ownerBookingStmt->bind_param("ii", $eventId, $ownerId);
            $ownerBookingStmt->execute();
            if ($ownerBookingStmt->get_result()->num_rows > 0) {
                throw new Exception("You already have a booking for this Spay/Neuter event.");
            }

            // An owner may book Spay/Neuter only once per event date, even when
            // staff created multiple Spay/Neuter events for that same day.
            $sameDayBookingStmt = $conn->prepare("
                SELECT a.Appointment_ID
                FROM appointments a
                JOIN calendar_events booked_event ON booked_event.Event_ID = a.Event_ID
                WHERE a.Owner_ID = ?
                  AND booked_event.Event_Type = 'SpayNeuter'
                  AND booked_event.Event_Date = ?
                  AND a.Status IN ('Pending', 'Confirmed', 'Checked In', 'In Consultation', 'Completed', 'No Show')
                LIMIT 1
                FOR UPDATE
            ");
            $sameDayBookingStmt->bind_param("is", $ownerId, $event['Event_Date']);
            $sameDayBookingStmt->execute();
            if ($sameDayBookingStmt->get_result()->num_rows > 0) {
                throw new Exception("You already have a Spay/Neuter booking on this date.");
            }
        }

        $usedSlots = approvedPetCount($conn, $eventId);
        if ($usedSlots >= (int)$event['Max_Slots']) {
            throw new Exception("This event is already fully booked.");
        }
        if ($usedSlots + count($petIds) > (int)$event['Max_Slots']) {
            throw new Exception("Only " . ((int)$event['Max_Slots'] - $usedSlots) . " slot(s) remain for this event.");
        }

        $petStmt = $conn->prepare("SELECT Pet_ID, Name FROM pets WHERE Pet_ID = ? AND Owner_ID = ? AND Status = 'active' FOR UPDATE");
        foreach ($petIds as $petId) {
            $petStmt->bind_param("ii", $petId, $ownerId);
            $petStmt->execute();
            $petRow = $petStmt->get_result()->fetch_assoc();
            if (!$petRow) {
                throw new Exception("One or more selected pets are not active under this account.");
            }
            if (cityVetIsSpayNeuterIneligible($conn, $petId)) {
                throw new Exception($petRow['Name'] . " is not eligible for Spay/Neuter because it already has a completed or active Spay/Neuter booking.");
            }
        }

        $dupStmt = $conn->prepare("
            SELECT p.Name
            FROM appointment_pets ap
            JOIN appointments a ON a.Appointment_ID = ap.Appointment_ID
            JOIN pets p ON p.Pet_ID = ap.Pet_ID
            WHERE a.Event_ID = ?
              AND ap.Pet_ID = ?
              AND a.Status IN ('Pending', 'Confirmed')
            LIMIT 1
            FOR UPDATE
        ");
        foreach ($petIds as $petId) {
            $dupStmt->bind_param("ii", $eventId, $petId);
            $dupStmt->execute();
            $duplicate = $dupStmt->get_result()->fetch_assoc();
            if ($duplicate) {
                throw new Exception($duplicate['Name'] . " already has a booking request for this event.");
            }
        }

        $appointmentDate = $event['Event_Date'] . " 08:00:00";
        $apptStmt = $conn->prepare("
            INSERT INTO appointments (Event_ID, Owner_ID, Pet_ID, Service_ID, Appointment_Date, Status, Confirmed_At, Notes)
            VALUES (?, ?, ?, NULL, ?, ?, ?, ?)
        ");
        $joinStmt = $conn->prepare("INSERT INTO appointment_pets (Appointment_ID, Pet_ID) VALUES (?, ?)");
        $appointmentIds = [];
        foreach ($petIds as $petId) {
            // Keep each pet in its own appointment so cancellation/status changes
            // affect only that pet's reserved slot.
            $petNotes = $roleId === 3
                ? "Spay/Neuter event booking for 1 pet(s)."
                : "Spay/Neuter event booking by staff for 1 pet(s).";
            $apptStmt->bind_param("iiissss", $eventId, $ownerId, $petId, $appointmentDate, $bookingStatus, $confirmedAt, $petNotes);
            $apptStmt->execute();
            $appointmentId = $conn->insert_id;
            $appointmentIds[] = $appointmentId;

            $joinStmt->bind_param("ii", $appointmentId, $petId);
            $joinStmt->execute();

            if ($roleId === 3) {
                writeAuditLog($conn, $userId, "Request Spay/Neuter Booking", "appointments", $appointmentId);
            } else {
                writeAuditLog($conn, $userId, "Staff Book Spay/Neuter", "appointments", $appointmentId);
            }
        }

        if ($roleId === 3) {
            notifyUsersByRole(
                $conn,
                4,
                "Pending Spay/Neuter Booking",
                "A pet owner submitted a booking request for {$event['Title']} on {$event['Event_Date']}.",
                'SpayNeuter',
                $eventId
            );
            $conn->commit();
            jsonResponse(["status" => "success", "message" => "Booking request submitted. Please wait for staff confirmation.", "appointment_ids" => $appointmentIds]);
        } else {
            if (approvedPetCount($conn, $eventId) >= (int)$event['Max_Slots']) {
                $close = $conn->prepare("UPDATE calendar_events SET Status = 'Closed' WHERE Event_ID = ? AND Status = 'Open'");
                $close->bind_param("i", $eventId);
                $close->execute();
                $close->close();
            }
            notifyUser(
                $conn,
                $ownerUserId,
                "Spay/Neuter Booking Confirmed",
                "Staff confirmed a booking for {$event['Title']} on {$event['Event_Date']} for your pet(s).",
                'SpayNeuter',
                $eventId
            );
            $conn->commit();
            jsonResponse(["status" => "success", "message" => "Spay/Neuter booking confirmed successfully.", "appointment_ids" => $appointmentIds]);
        }
    } catch (Exception $e) {
        $conn->rollback();
        jsonResponse(["status" => "error", "message" => $e->getMessage()], 400);
    }
}

if ($action === 'delete_event') {
    requireRole([1, 4]);

    $eventId = (int)($input['event_id'] ?? 0);
    if (!$eventId) {
        jsonResponse(["status" => "error", "message" => "Missing event ID."], 422);
    }

    $conn->begin_transaction();
    try {
        $checkStmt = $conn->prepare("SELECT Event_ID, Title, Event_Date FROM calendar_events WHERE Event_ID = ? FOR UPDATE");
        $checkStmt->bind_param("i", $eventId);
        $checkStmt->execute();
        $event = $checkStmt->get_result()->fetch_assoc();

        if (!$event) {
            throw new Exception("Event not found.");
        }
        if ($event['Event_Date'] < date('Y-m-d')) {
            throw new Exception("Past events are retained as closed records and cannot be deleted.");
        }

        $appointmentStmt = $conn->prepare("SELECT Appointment_ID FROM appointments WHERE Event_ID = ?");
        $appointmentStmt->bind_param("i", $eventId);
        $appointmentStmt->execute();
        $appointmentIds = [];
        $appResult = $appointmentStmt->get_result();
        while ($row = $appResult->fetch_assoc()) {
            $appointmentIds[] = (int)$row['Appointment_ID'];
        }

        if (!empty($appointmentIds)) {
            $placeholders = implode(',', array_fill(0, count($appointmentIds), '?'));
            $petDelete = $conn->prepare("DELETE FROM appointment_pets WHERE Appointment_ID IN ($placeholders)");
            $types = str_repeat('i', count($appointmentIds));
            $petDelete->bind_param($types, ...$appointmentIds);
            $petDelete->execute();
            $petDelete->close();

            $apptDelete = $conn->prepare("DELETE FROM appointments WHERE Appointment_ID IN ($placeholders)");
            $apptDelete->bind_param($types, ...$appointmentIds);
            $apptDelete->execute();
            $apptDelete->close();
        }

        $deleteStmt = $conn->prepare("DELETE FROM calendar_events WHERE Event_ID = ?");
        $deleteStmt->bind_param("i", $eventId);
        $deleteStmt->execute();
        $deleteStmt->close();

        writeAuditLog($conn, (int)$_SESSION['user_id'], "Delete Calendar Event", "calendar_events", $eventId);
        $conn->commit();
        jsonResponse(["status" => "success", "message" => "Event deleted successfully."]);
    } catch (Exception $e) {
        $conn->rollback();
        jsonResponse(["status" => "error", "message" => $e->getMessage()], 400);
    }
}

if ($action === 'close_event') {
    requireRole([1, 4]);

    $eventId = (int)($input['event_id'] ?? 0);
    if (!$eventId) {
        jsonResponse(["status" => "error", "message" => "Missing event ID."], 422);
    }

    $stmt = $conn->prepare("UPDATE calendar_events SET Status = 'Closed' WHERE Event_ID = ? AND Status = 'Open' AND Event_Date < CURDATE()");
    $stmt->bind_param("i", $eventId);
    $stmt->execute();
    if ($stmt->affected_rows !== 1) {
        jsonResponse(["status" => "error", "message" => "Only an open past event can be marked as closed."], 422);
    }

    writeAuditLog($conn, (int)$_SESSION['user_id'], "Close Calendar Event", "calendar_events", $eventId);
    jsonResponse(["status" => "success", "message" => "Event marked as closed."]);
}

    if ($action === 'confirm_booking') {
    requireRole([1, 4]);

    $appointmentId = (int)($input['appointment_id'] ?? 0);
    if (!$appointmentId) {
        jsonResponse(["status" => "error", "message" => "Missing appointment ID."], 422);
    }

    $conn->begin_transaction();
    try {
        $apptStmt = $conn->prepare("
            SELECT
                a.Appointment_ID,
                a.Event_ID,
                a.Status,
                a.Confirmation_Attempts,
                a.Owner_Confirmed_At,
                ce.Title,
                ce.Event_Date,
                ce.Max_Slots,
                o.User_ID,
                o.Contact_number,
                u.Email
            FROM appointments a
            JOIN calendar_events ce ON ce.Event_ID = a.Event_ID
            JOIN owners o ON o.Owner_ID = a.Owner_ID
            JOIN users u ON u.User_ID = o.User_ID
            WHERE a.Appointment_ID = ?
            FOR UPDATE
        ");
        $apptStmt->bind_param("i", $appointmentId);
        $apptStmt->execute();
        $appt = $apptStmt->get_result()->fetch_assoc();

        if (!$appt || $appt['Status'] !== 'Pending') {
            throw new Exception("This booking is no longer pending.");
        }
        $eventLock = $conn->prepare("SELECT Event_ID FROM calendar_events WHERE Event_ID = ? FOR UPDATE");
        $eventId = (int)$appt['Event_ID'];
        $eventLock->bind_param("i", $eventId);
        $eventLock->execute();
        $eventLockResult = $eventLock->get_result();
        if ($eventLockResult) {
            $eventLockResult->free();
        }
        $eventLock->close();

        $countStmt = $conn->prepare("SELECT COUNT(*) AS Pet_Count FROM appointment_pets WHERE Appointment_ID = ?");
        $countStmt->bind_param("i", $appointmentId);
        $countStmt->execute();
        $petCount = (int)$countStmt->get_result()->fetch_assoc()['Pet_Count'];

        $usedSlots = approvedPetCount($conn, $eventId);
        if ($usedSlots + $petCount > (int)$appt['Max_Slots']) {
            throw new Exception("Not enough slots remain for this booking.");
        }

        $archivedPetStmt = $conn->prepare("
            SELECT p.Name
            FROM appointment_pets ap
            JOIN pets p ON ap.Pet_ID = p.Pet_ID
            WHERE ap.Appointment_ID = ? AND p.Status = 'archived'
            LIMIT 1
            FOR UPDATE
        ");
        $archivedPetStmt->bind_param("i", $appointmentId);
        $archivedPetStmt->execute();
        $archivedRow = $archivedPetStmt->get_result()->fetch_assoc();
        $archivedPetStmt->close();
        if ($archivedRow) {
            throw new Exception("Cannot confirm booking: pet " . $archivedRow['Name'] . " is archived.");
        }

        $update = $conn->prepare("UPDATE appointments SET Status = 'Confirmed', Confirmed_At = NOW() WHERE Appointment_ID = ? AND Status = 'Pending'");
        $update->bind_param("i", $appointmentId);
        $update->execute();
        if ($update->affected_rows !== 1) {
            throw new Exception("This booking was already processed or is no longer pending.");
        }

        $remaining = (int)$appt['Max_Slots'] - ($usedSlots + $petCount);
        if ($remaining <= 0) {
            $close = $conn->prepare("UPDATE calendar_events SET Status = 'Closed' WHERE Event_ID = ?");
            $close->bind_param("i", $eventId);
            $close->execute();
        }

        $message = "THINGS TO DO / IMPORTANT REMINDERS\n\n"
            . "To ensure a safe and organized Spay and Neuter Activity, please observe the following:\n\n"
            . "1. FAST YOUR PET FOR 8 HOURS BEFORE THE OPERATION. No food or water for 8 hours before surgery.\n"
            . "2. Bring your own pet carrier or crate, especially for cats.\n"
            . "3. First come, first served.\n"
            . "4. Pregnant, nursing, or sick dogs and cats are not allowed to undergo the procedure.\n"
            . "5. Bring your own bedding (sack or used tarp) for post-operative recovery.\n"
            . "6. Cut-off time is 1:00 PM only. Latecomers will not be accepted.\n"
            . "7. Maximum of 2 pets per owner is allowed.\n"
            . "8. Only pet owners who confirmed their participation will be accepted.\n"
            . "9. Bring your own ballpen for registration and documentation.\n"
            . "10. Only 1 pet owner and 1 assistant may stay with the pet. Please avoid bringing children when possible.\n\n"
            . "Thank you for your cooperation and understanding. Your participation helps promote responsible pet ownership, animal welfare, and a rabies-free community.";
        notifyUser($conn, (int)$appt['User_ID'], "Spay/Neuter Slot Confirmed", $message, 'SpayNeuter', (int)$appt['Event_ID']);
        $emailResult = sendResendEmail($appt['Email'], "City Vet Spay/Neuter Slot Confirmed", $message);
        $smsResult = sendIprogSms($appt['Contact_number'], $message);
        $smsSent = $smsResult['sent'];
        if ($smsSent) {
            $sent = $conn->prepare("UPDATE appointments SET Reminder_SMS_Sent_At = NOW() WHERE Appointment_ID = ?");
            $sent->bind_param("i", $appointmentId);
            $sent->execute();
            $sent->close();
        }
        writeAuditLog($conn, (int)$_SESSION['user_id'], "Confirm Spay/Neuter Booking", "appointments", $appointmentId);

        $conn->commit();
        jsonResponse([
            "status" => "success",
            "message" => "Booking confirmed. The full spay/neuter reminder was sent or queued as one SMS request.",
            "remaining_slots" => $remaining,
            "email_sent" => $emailResult["sent"],
            "email_message" => $emailResult["message"],
            "sms_sent" => $smsSent,
            "sms_message" => $smsResult["message"]
        ]);
    } catch (Exception $e) {
        $conn->rollback();
        jsonResponse(["status" => "error", "message" => $e->getMessage()], 400);
    }
}

if ($action === 'confirm_attendance') {
    requireRole([1, 4]);

    $appointmentId = (int)($input['appointment_id'] ?? 0);
    if (!$appointmentId) {
        jsonResponse(["status" => "error", "message" => "Missing appointment ID."], 422);
    }

    $stmt = $conn->prepare("SELECT a.Appointment_ID, a.Event_ID, a.Status, a.Owner_Confirmed_At, ce.Title, ce.Event_Date, o.User_ID AS Owner_User_ID FROM appointments a JOIN calendar_events ce ON ce.Event_ID = a.Event_ID JOIN owners o ON o.Owner_ID = a.Owner_ID WHERE a.Appointment_ID = ? LIMIT 1");
    $stmt->bind_param("i", $appointmentId);
    $stmt->execute();
    $booking = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$booking) {
        jsonResponse(["status" => "error", "message" => "Booking not found."], 404);
    }
    if ($booking['Status'] !== 'Confirmed') {
        jsonResponse(["status" => "error", "message" => "The slot must be confirmed before attendance can be confirmed."], 422);
    }
    if (!empty($booking['Owner_Confirmed_At'])) {
        jsonResponse(["status" => "success", "message" => "Owner attendance was already confirmed."]);
    }

    $update = $conn->prepare("UPDATE appointments SET Owner_Confirmed_At = NOW(), Owner_Confirmed_By = ? WHERE Appointment_ID = ? AND Status = 'Confirmed' AND Owner_Confirmed_At IS NULL");
    $actorId = (int)$_SESSION['user_id'];
    $update->bind_param("ii", $actorId, $appointmentId);
    if (!$update->execute() || $update->affected_rows !== 1) {
        $update->close();
        jsonResponse(["status" => "error", "message" => "This booking was already processed."], 409);
    }
    $update->close();

    notifyUser($conn, (int)$booking['Owner_User_ID'], "Spay/Neuter Attendance Confirmed", "Your attendance for {$booking['Title']} on {$booking['Event_Date']} has been confirmed by City Vet staff.", 'SpayNeuter', (int)$booking['Event_ID']);
    writeAuditLog($conn, $actorId, "Confirm Spay/Neuter Attendance", "appointments", $appointmentId);
    jsonResponse(["status" => "success", "message" => "Owner attendance confirmed and recorded."]);
}

if ($action === 'cancel_booking') {
    requireRole([1, 3, 4]);

    $appointmentId = (int)($input['appointment_id'] ?? 0);
    $reason = trim((string)($input['reason'] ?? ''));
    if (!$appointmentId) {
        jsonResponse(["status" => "error", "message" => "Missing appointment ID."], 422);
    }
    if (function_exists('mb_substr')) {
        $reason = mb_substr($reason, 0, 200);
    } else {
        $reason = substr($reason, 0, 200);
    }

    $roleId = (int)$_SESSION['role_id'];
    $actorId = (int)$_SESSION['user_id'];

    $conn->begin_transaction();
    try {
        $ownerId = null;
        if ($roleId === 3) {
            $ownerStmt = $conn->prepare("SELECT Owner_ID FROM owners WHERE User_ID = ? LIMIT 1");
            $ownerStmt->bind_param("i", $actorId);
            $ownerStmt->execute();
            $owner = $ownerStmt->get_result()->fetch_assoc();
            $ownerStmt->close();
            if (!$owner) {
                throw new Exception("Owner profile not found.");
            }
            $ownerId = (int)$owner['Owner_ID'];
        }

        $stmt = $conn->prepare("
            SELECT a.Appointment_ID, a.Event_ID, a.Appointment_Date, a.Status,
                   a.Owner_Confirmed_At,
                   ce.Title, ce.Event_Date, s.Service_Name, o.Owner_ID, o.User_ID AS Owner_User_ID
            FROM appointments a
            LEFT JOIN calendar_events ce ON ce.Event_ID = a.Event_ID
            LEFT JOIN services s ON s.Service_ID = a.Service_ID
            JOIN owners o ON o.Owner_ID = a.Owner_ID
            WHERE a.Appointment_ID = ?
            FOR UPDATE
        ");
        $stmt->bind_param("i", $appointmentId);
        $stmt->execute();
        $appt = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$appt) {
            throw new Exception("Booking not found.");
        }
        if ($roleId === 3 && (int)$appt['Owner_ID'] !== $ownerId) {
            throw new Exception("You can only cancel your own bookings.");
        }
        if (!in_array($appt['Status'], ['Pending', 'Confirmed'], true)) {
            throw new Exception("Only pending or confirmed bookings can be cancelled.");
        }
        if ($roleId === 3 && $appt['Event_ID'] !== null && !empty($appt['Owner_Confirmed_At'])) {
            throw new Exception("This booking can no longer be cancelled because attendance was already confirmed by staff.");
        }
        if ($appt['Event_ID'] !== null) {
            if ($appt['Event_Date'] < date('Y-m-d')) {
                throw new Exception("This event date has already passed.");
            }
        } elseif ($appt['Appointment_Date'] < date('Y-m-d H:i:s')) {
            throw new Exception("This appointment date and time has already passed.");
        }

        $who = $roleId === 3 ? 'pet owner' : 'staff';
        $suffix = " | Cancelled by {$who} on " . date('Y-m-d H:i') . ($reason !== '' ? ": {$reason}" : '');
        $upd = $conn->prepare("UPDATE appointments SET Status = 'Cancelled', Notes = CONCAT(COALESCE(Notes, ''), ?) WHERE Appointment_ID = ? AND Status IN ('Pending', 'Confirmed')");
        $upd->bind_param("si", $suffix, $appointmentId);
        $upd->execute();
        if ($upd->affected_rows !== 1) {
            throw new Exception("This booking was already processed.");
        }
        $upd->close();

        if ($appt['Event_ID'] !== null) {
            reopenEventIfSlotsFree($conn, (int)$appt['Event_ID']);
        }

        if ($roleId === 3) {
            if ($appt['Event_ID'] !== null) {
                notifyUsersByRole($conn, 4, "Spay/Neuter Booking Cancelled", "A pet owner cancelled a booking for {$appt['Title']} on {$appt['Event_Date']}.", 'SpayNeuter', (int)$appt['Event_ID']);
            } else {
                $serviceName = $appt['Service_Name'] ?: 'Appointment';
                notifyUsersByRole($conn, 4, "Appointment Cancelled", "A pet owner cancelled a {$serviceName} appointment scheduled for {$appt['Appointment_Date']}.", 'Appointment');
            }
        } else {
            if ($appt['Event_ID'] !== null) {
                notifyUser($conn, (int)$appt['Owner_User_ID'], "Spay/Neuter Booking Cancelled", "Your booking for {$appt['Title']} on {$appt['Event_Date']} was cancelled by the office.", 'SpayNeuter', (int)$appt['Event_ID']);
            } else {
                $serviceName = $appt['Service_Name'] ?: 'Appointment';
                notifyUser($conn, (int)$appt['Owner_User_ID'], "Appointment Cancelled", "Your {$serviceName} appointment scheduled for {$appt['Appointment_Date']} was cancelled by the office.", 'Appointment');
            }
        }
        $auditAction = $appt['Event_ID'] !== null ? "Cancel Spay/Neuter Booking" : "Cancel Appointment";
        writeAuditLog($conn, $actorId, $auditAction, "appointments", $appointmentId);

        $conn->commit();
        jsonResponse(["status" => "success", "message" => "Booking cancelled."]);
    } catch (Exception $e) {
        $conn->rollback();
        jsonResponse(["status" => "error", "message" => $e->getMessage()], 400);
    }
}

if ($action === 'mark_event_no_show') {
    requireRole([1, 4]);

    $appointmentId = (int)($input['appointment_id'] ?? 0);
    if (!$appointmentId) {
        jsonResponse(["status" => "error", "message" => "Missing appointment ID."], 422);
    }

    $chk = $conn->prepare("
        SELECT a.Appointment_ID, a.Status, ce.Event_Date
        FROM appointments a
        JOIN calendar_events ce ON a.Event_ID = ce.Event_ID
        WHERE a.Appointment_ID = ?
    ");
    $chk->bind_param("i", $appointmentId);
    $chk->execute();
    $appt = $chk->get_result()->fetch_assoc();
    $chk->close();

    if (!$appt) {
        jsonResponse(["status" => "error", "message" => "Booking not found."], 404);
    }
    if ($appt['Event_Date'] > date('Y-m-d')) {
        jsonResponse(["status" => "error", "message" => "Cannot mark No Show for future events."], 422);
    }
    if ($appt['Status'] === 'No Show') {
        jsonResponse(["status" => "success", "message" => "Already marked as No Show."]);
    }
    if ($appt['Status'] !== 'Confirmed') {
        jsonResponse(["status" => "error", "message" => "Only confirmed bookings can be marked as No Show."], 422);
    }

    $upd = $conn->prepare("UPDATE appointments SET Status = 'No Show' WHERE Appointment_ID = ? AND Status = 'Confirmed'");
    $upd->bind_param("i", $appointmentId);
    if ($upd->execute() && $upd->affected_rows === 1) {
        require_once dirname(__DIR__) . '/clinic/no_show_helper.php';
        $noShowInfo = handleAppointmentNoShow($conn, $appointmentId, (int)$_SESSION['user_id']);
        writeAuditLog($conn, (int)$_SESSION['user_id'], "Mark Event Booking No Show", "appointments", $appointmentId);
        jsonResponse(["status" => "success", "message" => "Marked as No Show.", "no_show_info" => $noShowInfo]);
    }
    jsonResponse(["status" => "error", "message" => "Unable to update status."], 500);
}

if ($action === 'mark_event_catered') {
    requireRole([1, 4]);

    $appointmentId = (int)($input['appointment_id'] ?? 0);
    if (!$appointmentId) {
        jsonResponse(["status" => "error", "message" => "Missing appointment ID."], 422);
    }

    $chk = $conn->prepare("
        SELECT a.Appointment_ID, a.Status, ce.Event_Date, ce.Title
        FROM appointments a
        JOIN calendar_events ce ON a.Event_ID = ce.Event_ID
        WHERE a.Appointment_ID = ?
    ");
    $chk->bind_param("i", $appointmentId);
    $chk->execute();
    $appt = $chk->get_result()->fetch_assoc();
    $chk->close();

    if (!$appt) {
        jsonResponse(["status" => "error", "message" => "Booking not found."], 404);
    }
    if ($appt['Status'] === 'Completed') {
        jsonResponse(["status" => "success", "message" => "Already marked as Completed."]);
    }
    if ($appt['Status'] !== 'Confirmed') {
        jsonResponse(["status" => "error", "message" => "Only confirmed bookings can be marked as Completed."], 422);
    }

    $upd = $conn->prepare("UPDATE appointments SET Status = 'Completed' WHERE Appointment_ID = ? AND Status = 'Confirmed'");
    $upd->bind_param("i", $appointmentId);
    if ($upd->execute() && $upd->affected_rows === 1) {
        writeAuditLog($conn, (int)$_SESSION['user_id'], "Mark Event Booking Catered", "appointments", $appointmentId);
        jsonResponse(["status" => "success", "message" => "Booking marked as Completed."]);
    }
    jsonResponse(["status" => "error", "message" => "Unable to update status."], 500);
}

if ($action === 'correct_past_status') {
    requireRole([1, 4]);
    $eventId = (int)($input['event_id'] ?? 0); $appointmentId = (int)($input['appointment_id'] ?? 0);
    $newStatus = trim((string)($input['status'] ?? '')); $reason = trim((string)($input['reason'] ?? ''));
    if (mb_strlen($reason) < 5) jsonResponse(["status" => "error", "message" => "Please provide a reason of at least 5 characters."], 422);
    $actor = (int)$_SESSION['user_id'];
    if ($eventId > 0) {
        jsonResponse(["status"=>"error","message"=>"Only pet booking statuses can be corrected; event status is not editable here."],422);
        $s=$conn->prepare("SELECT Event_ID,Event_Type,Event_Date,Status,Max_Slots FROM calendar_events WHERE Event_ID=? LIMIT 1");$s->bind_param('i',$eventId);$s->execute();$event=$s->get_result()->fetch_assoc();$s->close();
        if(!$event||$event['Event_Type']!=='SpayNeuter') jsonResponse(["status"=>"error","message"=>"Spay/Neuter event not found."],404);
        if($event['Event_Date']>date('Y-m-d')) jsonResponse(["status"=>"error","message"=>"Only past or today events can be corrected."],422);
        if($newStatus==='Open' && approvedPetCount($conn,$eventId)>=(int)$event['Max_Slots']) jsonResponse(["status"=>"error","message"=>"This event cannot be reopened because it has no available slots."],422);
        $s=$conn->prepare("UPDATE calendar_events SET Status=?, Correction_Reason=?, Corrected_By=?, Corrected_At=NOW() WHERE Event_ID=?");$s->bind_param('ssii',$newStatus,$reason,$actor,$eventId);$ok=$s->execute();$s->close();
        if(!$ok) jsonResponse(["status"=>"error","message"=>"Unable to correct event status."],500);
        writeAuditLog($conn,$actor,"Correct Past Spay/Neuter Event {$event['Status']} to {$newStatus}: {$reason}",'calendar_events',$eventId);jsonResponse(["status"=>"success","message"=>"Event status corrected."]); 
    }
    if ($appointmentId > 0) {
        if (!in_array($newStatus, ['Pending','Confirmed','Checked In','In Consultation','Completed','No Show','Cancelled'], true)) jsonResponse(["status"=>"error","message"=>"Invalid booking status."],422);
        $countsTowardSlots = ['Confirmed', 'Checked In', 'In Consultation', 'Completed'];
        $conn->begin_transaction();
        try {
            $s=$conn->prepare("SELECT a.Appointment_ID,a.Status,a.Pet_ID,ce.Event_ID,ce.Event_Date,ce.Max_Slots FROM appointments a JOIN calendar_events ce ON ce.Event_ID=a.Event_ID WHERE a.Appointment_ID=? AND ce.Event_Type='SpayNeuter' LIMIT 1 FOR UPDATE");$s->bind_param('i',$appointmentId);$s->execute();$appt=$s->get_result()->fetch_assoc();$s->close();
            if(!$appt) throw new RuntimeException('Spay/Neuter booking not found.');
            $lock=$conn->prepare('SELECT Event_ID, Max_Slots, Event_Date FROM calendar_events WHERE Event_ID=? FOR UPDATE');$lock->bind_param('i',$appt['Event_ID']);$lock->execute();$eventLocked=$lock->get_result()->fetch_assoc();$lock->close();
            if (!$eventLocked || $eventLocked['Event_Date'] > date('Y-m-d')) throw new RuntimeException($eventLocked ? 'Only past or today bookings can be corrected.' : 'Spay/Neuter event not found.');
            if (in_array($newStatus, $countsTowardSlots, true) && !in_array($appt['Status'], $countsTowardSlots, true)) {
                $pc=$conn->prepare('SELECT COUNT(DISTINCT Pet_ID) AS Pet_Count FROM appointment_pets WHERE Appointment_ID=?');$pc->bind_param('i',$appointmentId);$pc->execute();$petCount=(int)($pc->get_result()->fetch_assoc()['Pet_Count'] ?? 0);$pc->close();
                if ($petCount < 1 && !empty($appt['Pet_ID'])) $petCount = 1;
                if (approvedPetCount($conn, (int)$appt['Event_ID']) + $petCount > (int)$eventLocked['Max_Slots']) throw new RuntimeException('This correction would exceed the event\'s available pet slots.');
            }
            $s=$conn->prepare("UPDATE appointments SET Status=?, Correction_Reason=?, Corrected_By=?, Corrected_At=NOW() WHERE Appointment_ID=?");$s->bind_param('ssii',$newStatus,$reason,$actor,$appointmentId);$ok=$s->execute();$s->close();if(!$ok) throw new RuntimeException('Unable to correct booking status.');
            writeAuditLog($conn,$actor,"Correct Past Spay/Neuter Booking {$appt['Status']} to {$newStatus}: {$reason}",'appointments',$appointmentId);
            $conn->commit();
            jsonResponse(["status"=>"success","message"=>"Booking status corrected."]); 
        } catch (Throwable $e) {
            $conn->rollback();
            $message = $e->getMessage();
            $code = $message === 'Spay/Neuter booking not found.' ? 404 : 422;
            jsonResponse(["status"=>"error","message"=>$message],$code);
        }
    }
    jsonResponse(["status"=>"error","message"=>"Event or appointment is required."],422);
}

jsonResponse(["status" => "error", "message" => "Unknown action."], 400);
