<?php
require_once '../../config/session.php';
header("Content-Type: application/json; charset=UTF-8");
require_once '../../config/db_connection.php';

if ($conn instanceof mysqli) {
    $conn->set_charset("utf8mb4");
}

function jsonResponse($payload, $code = 200) {
    http_response_code($code);
    echo json_encode($payload);
    exit();
}

function requireRole($roles) {
    if (!isset($_SESSION['user_id'], $_SESSION['role_id'])) {
        jsonResponse(["status" => "error", "message" => "Unauthorized"], 401);
    }

    if (!in_array((int)$_SESSION['role_id'], $roles, true)) {
        jsonResponse(["status" => "error", "message" => "Access denied"], 403);
    }
}


$conn->query("UPDATE calendar_events SET Status = 'Closed' WHERE Event_Date < CURDATE() AND Status = 'Open'");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    requireRole([1, 4]);

    $input = json_decode(file_get_contents("php://input"), true);
    if (!is_array($input)) $input = $_POST;
    $appointmentId = (int)($input['appointment_id'] ?? 0);

    if (!$appointmentId) {
        jsonResponse(["status" => "error", "message" => "Missing appointment ID"], 422);
    }

    if (($input['action'] ?? '') === 'assign_veterinarian') {
        $vetId = (int)($input['vet_id'] ?? 0);
        if (!$vetId) jsonResponse(["status" => "error", "message" => "Select a veterinarian."], 422);
        $vetCheck = $conn->prepare("SELECT User_ID FROM users WHERE User_ID = ? AND Role_ID = 2 AND Status = 'active'");
        $vetCheck->bind_param("i", $vetId);
        $vetCheck->execute();
        if (!$vetCheck->get_result()->fetch_assoc()) jsonResponse(["status" => "error", "message" => "Veterinarian not found."], 422);
        $vetCheck->close();
        $updateVet = $conn->prepare("UPDATE appointments SET Vet_ID = ? WHERE Appointment_ID = ? AND Event_ID IS NOT NULL AND Status IN ('Confirmed', 'Completed')");
        $updateVet->bind_param("ii", $vetId, $appointmentId);
        $updateVet->execute();
        if ($updateVet->affected_rows < 1) jsonResponse(["status" => "error", "message" => "Only confirmed or completed event bookings can be assigned a veterinarian."], 422);
        jsonResponse(["status" => "success", "message" => "Veterinarian assignment saved."]);
    }

    $chk = $conn->prepare("
        SELECT a.Appointment_ID, a.Status, ce.Event_Date
        FROM appointments a
        JOIN calendar_events ce ON a.Event_ID = ce.Event_ID
        WHERE a.Appointment_ID = ?
    ");
    $chk->bind_param("i", $appointmentId);
    $chk->execute();
    $appt = $chk->get_result()->fetch_assoc();
    $chk->close();

    if (!$appt) {
        jsonResponse(["status" => "error", "message" => "Booking not found."], 404);
    }
    $actionType = $input['action'] ?? ($input['status'] ?? 'No Show');
    if ($actionType === 'Catered' || $actionType === 'Completed') {
        if ($appt['Status'] === 'Completed') {
            jsonResponse(["status" => "success", "message" => "Already marked as Completed."]);
        }
        if ($appt['Status'] !== 'Confirmed') {
            jsonResponse(["status" => "error", "message" => "Only confirmed bookings can be marked as Completed."], 422);
        }
        $upd = $conn->prepare("UPDATE appointments SET Status = 'Completed' WHERE Appointment_ID = ? AND Status = 'Confirmed'");
        $upd->bind_param("i", $appointmentId);
        if ($upd->execute() && $upd->affected_rows === 1) {
            jsonResponse(["status" => "success", "message" => "Marked as Completed."]);
        }
        jsonResponse(["status" => "error", "message" => "Unable to update status."], 500);
    }

    if ($appt['Event_Date'] > date('Y-m-d')) {
        jsonResponse(["status" => "error", "message" => "Cannot mark No Show for future events."], 422);
    }
    if ($appt['Status'] === 'No Show') {
        jsonResponse(["status" => "success", "message" => "Already marked as No Show."]);
    }
    if ($appt['Status'] !== 'Confirmed') {
        jsonResponse(["status" => "error", "message" => "Only confirmed bookings can be marked as No Show."], 422);
    }

    $upd = $conn->prepare("UPDATE appointments SET Status = 'No Show' WHERE Appointment_ID = ? AND Status = 'Confirmed'");
    $upd->bind_param("i", $appointmentId);
    if ($upd->execute() && $upd->affected_rows === 1) {
        require_once dirname(__DIR__) . '/clinic/no_show_helper.php';
        $noShowInfo = handleAppointmentNoShow($conn, $appointmentId, (int)$_SESSION['user_id']);
        jsonResponse(["status" => "success", "message" => "Marked as No Show.", "no_show_info" => $noShowInfo]);
    }
    jsonResponse(["status" => "error", "message" => "Unable to update status."], 500);
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonResponse(["status" => "error", "message" => "Invalid request method"], 405);
}

requireRole([1, 2, 4]);

$eventId = (int)($_GET['event_id'] ?? 0);
if (!$eventId) {
    jsonResponse(["status" => "error", "message" => "Missing event ID"], 422);
}

$evStmt = $conn->prepare("SELECT Event_ID, Title, Event_Type, Event_Date, Max_Slots, Content, Status FROM calendar_events WHERE Event_ID = ?");
$evStmt->bind_param("i", $eventId);
$evStmt->execute();
$eventRow = $evStmt->get_result()->fetch_assoc();
$evStmt->close();

if (!$eventRow) {
    jsonResponse(["status" => "error", "message" => "Event not found"], 404);
}

$event = [
    "Event_ID" => (int)$eventRow['Event_ID'],
    "Title" => $eventRow['Title'],
    "Event_Type" => $eventRow['Event_Type'],
    "Event_Date" => $eventRow['Event_Date'],
    "Max_Slots" => (int)$eventRow['Max_Slots'],
    "Content" => $eventRow['Content'],
    "Status" => $eventRow['Status']
];

$stmt = $conn->prepare("
    SELECT
        a.Appointment_ID,
        a.Status,
        a.Confirmed_At,
        a.Owner_Confirmed_At,
        a.Vet_ID,
        a.Notes,
        CONCAT(COALESCE(o.First_name, ''), ' ', COALESCE(o.Last_name, '')) AS Owner_Name,
        o.Contact_number,
        o.Address,
        u.Email,
        p.Pet_ID,
        p.Name AS Pet_Name,
        p.Gender,
        p.Weight,
        p.Status AS Pet_Status,
        sp.Species_Name,
        b.Breed_Name
    FROM appointments a
    JOIN owners o ON o.Owner_ID = a.Owner_ID
    LEFT JOIN users u ON u.User_ID = o.User_ID
    LEFT JOIN appointment_pets ap ON ap.Appointment_ID = a.Appointment_ID
    LEFT JOIN pets p ON p.Pet_ID = ap.Pet_ID
    LEFT JOIN species sp ON sp.Species_ID = p.Species_ID
    LEFT JOIN breeds b ON b.Breed_ID = p.Breed_ID
    WHERE a.Event_ID = ?
    ORDER BY FIELD(a.Status, 'Pending', 'Confirmed', 'Checked In', 'In Consultation', 'Completed', 'No Show', 'Cancelled'), o.Last_name, o.First_name, a.Appointment_ID, p.Name
");
$stmt->bind_param("i", $eventId);
$stmt->execute();
$result = $stmt->get_result();

$byAppointment = [];
$summary = ['Total' => 0, 'Pending' => 0, 'Confirmed' => 0, 'Catered' => 0, 'Cancelled' => 0, 'No_Show' => 0];

while ($row = $result->fetch_assoc()) {
    $aid = (int)$row['Appointment_ID'];
    if (!isset($byAppointment[$aid])) {
        $byAppointment[$aid] = [
            "Appointment_ID" => $aid,
            "Status" => $row['Status'],
            "Confirmed_At" => $row['Confirmed_At'],
            "Owner_Confirmed_At" => $row['Owner_Confirmed_At'],
            "Vet_ID" => $row['Vet_ID'],
            "Notes" => $row['Notes'],
            "Owner_Name" => trim($row['Owner_Name']),
            "Contact_number" => $row['Contact_number'],
            "Email" => $row['Email'],
            "Address" => $row['Address'],
            "Pet_Count" => 0,
            "Pet_Names" => '',
            "Pets" => []
        ];
    }
    if ($row['Pet_ID']) {
        $byAppointment[$aid]['Pets'][] = [
            "Pet_ID" => (int)$row['Pet_ID'],
            "Name" => $row['Pet_Name'],
            "Species" => $row['Species_Name'],
            "Breed" => $row['Breed_Name'],
            "Gender" => $row['Gender'],
            "Weight" => $row['Weight'],
            "Archived" => $row['Pet_Status'] === 'archived'
        ];
    }
}
$stmt->close();

$roster = [];
foreach ($byAppointment as $entry) {
    $entry['Pet_Count'] = count($entry['Pets']);
    $entry['Pet_Names'] = implode(', ', array_map(function ($pet) { return $pet['Name']; }, $entry['Pets']));
    $summary['Total'] += $entry['Pet_Count'];
    switch ($entry['Status']) {
        case 'Pending': $summary['Pending'] += $entry['Pet_Count']; break;
        case 'Cancelled': $summary['Cancelled'] += $entry['Pet_Count']; break;
        case 'No Show': $summary['No_Show'] += $entry['Pet_Count']; $summary['Confirmed'] += $entry['Pet_Count']; break;
        case 'Completed': $summary['Catered'] += $entry['Pet_Count']; $summary['Confirmed'] += $entry['Pet_Count']; break;
        default: $summary['Confirmed'] += $entry['Pet_Count'];
    }
    $roster[] = $entry;
}

jsonResponse([
    "status" => "success",
    "event" => $event,
    "summary" => $summary,
    "roster" => $roster
]);
