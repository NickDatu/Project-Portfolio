# City Vet - fixes + Live Ticket Queue (2026-10-05)

## Setup (do this once)
1. Replace your `htdocs/city_vet` folder with this one (keep your own `config/app_config.php` if you have one).
2. Optional but recommended: in phpMyAdmin > `city_vet_db` > Import `DATABASE/migration_live_queue_and_medical.sql`.
   (The app also applies the same changes automatically on first use, so this is a safety net.)
3. Hard-refresh the browser (Ctrl+F5) so the updated sidebar loads.

## Root causes
| Problem | Cause |
|---|---|
| `vet_queue.php` HTTP 500 (staff bypass save) | Your imported DB has no `medical_records.Booklet / Medicine_Used / Medicine_Picture` columns. The INSERT threw, and unhandled exceptions returned an HTML 500. |
| `history.html` "Unable to load consultations" | `get_consultations.php` selects those same three columns, so the query failed. |
| Bypass notes demanded 300 words | Backend and frontend both used `< 300` instead of `> 300`. |

## Files changed
- `api/clinic/vet_queue.php` - JSON-safe error handling, max-300-word rule (staff), vet validation, medicine sanitising
- `api/clinic/get_consultations.php`, `api/clinic/get_pet_info.php`, `api/owner/get_pet_data.php` - schema safety + vet name / medicine in history
- `views/staff/dashboard.html` - vet dropdown, word counter (`N / 300 words`), history columns, Live Ticket Queue button
- `views/vet/pet_details.html`, `views/owner/mypets.html`, `views/admin/consultations.html`, `views/staff/patient_records.html`, `views/vet/history.html` - Veterinarian / Medicine Used columns and clearer headers
- `js/sidebar_staff.js` - new sidebar link
- `DATABASE/deployment_clean_schema.sql` - live queue tables added

## New files
- `config/schema_ensure.php` - idempotent schema helpers + word counter + vet lookup
- `api/clinic/get_vets.php` - active veterinarians (Role 2) for the dropdown
- `api/queue/live_queue.php` - staff-only queue API (roles Admin/Staff, CSRF, prepared statements)
- `api/queue/live_display.php` - public read-only feed (no names/contacts)
- `views/staff/live_queue.html` - staff console
- `views/queue/live_display.html` - waiting-room screen
- `DATABASE/migration_live_queue_and_medical.sql`

## Live queue
- Tables: `live_queue_services` (extend by inserting rows), `live_queue_counters`, `live_queue_tickets` (FKs to owners, pets, users).
- A queue session = one calendar day. Ticket numbers are per service per day (`Vaccination #001`, `#002`...), handed out under a row lock plus a UNIQUE key, so duplicates cannot occur.
- Flow: Waiting -> Called -> Serving -> Completed. Also Skip (can be put back), Recall (re-flashes/chimes the display), Cancel.
- Only one ticket can be Called/Serving at a time; Call Next is blocked until it is completed or skipped.
- Staff page: `/city_vet/views/staff/live_queue.html`. Screen: `/city_vet/views/queue/live_display.html` (polls every 2.5 s; click "Sound off" once to enable the chime).
- "Pet Owner #N" uses the owner's `Owner_ID`.

## Update (2026-10-05, round 2)
- **500 on `vet_queue.php` when saving a vaccination/follow-up**: `bind_param("iiiissi", ...)` had 7 type letters for 6 variables. Now `"iiissi"` (`api/clinic/vet_queue.php`, follow-up insert).
- **Medical history now opens full details**: new `js/medical_record_modal.js` shows date, type, pet, veterinarian, treatment, **booklet**, **medicine used**, **medicine picture** and notes. A "View" button was added to every medical history list: staff dashboard (patient record), vet pet details, vet history log, staff patient records, admin consultations, and the owner's My Pets page.
- `api/clinic/get_pet_info.php` and `api/owner/get_pet_data.php` now also return `Booklet` and `Medicine_Picture` so every role gets the same details.
