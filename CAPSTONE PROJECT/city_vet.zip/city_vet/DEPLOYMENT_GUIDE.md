# City Vet Management System — Production Deployment Guide

This guide provides complete instructions for deploying the City Vet Management System to standard shared PHP/MySQL web hosting environments, with **InfinityFree** free hosting as the primary reference target. The instructions also apply directly to standard cPanel, DirectAdmin, Plesk, and Apache/PHP/MySQL environments.

---

## 1. System Requirements & Architecture

- **Web Server**: Apache 2.4+ with `mod_rewrite` and `.htaccess` override support.
- **PHP Version**: PHP 8.0, 8.1, or 8.2 (with `mysqli`, `session`, `json`, `mbstring`, `fileinfo`, `openssl` extensions enabled by default in standard shared hosting).
- **Database**: MySQL 5.7+ or MariaDB 10.3+.
- **SSL/TLS**: Valid SSL certificate (Let's Encrypt / InfinityFree Free SSL / Cloudflare SSL). The system automatically detects SSL behind reverse proxies via `HTTP_X_FORWARDED_PROTO`.
- **Reminder trigger**: Appointment reminders run once per day on the first authenticated activity. A daily cron job or Windows Task Scheduler task is still recommended for reliable delivery; no other scheduled jobs are required.

---

## 2. Deployment Package Preparation

The deployment package is located in `dist/city_vet_deployment.zip` (or the folder `dist/city_vet_deployment/`).

### What is included in the clean deployment package:
- All frontend assets (`index.html`, `views/`, `css/`, `js/`).
- All backend APIs (`api/auth/`, `api/clinic/`, `api/records/`, `api/reports/`, etc.).
- Configuration templates (`config/app_config.sample.php`, `config/notification_config.php`).
- Protective `.htaccess` files (`.htaccess`, `config/.htaccess`, `uploads/.htaccess`).
- Consolidated clean database schema (`DATABASE/deployment_clean_schema.sql`).
- One-time administrator setup tool (`bootstrap_admin.php`).
- Database and deployment documentation.

### What is strictly excluded:
- Real secrets (`config/app_config.php`, `notification_config.local.php`, `.env`).
- Version control (`.git/`).
- Scratch/development testing scripts (`scratch/`, `.gemini/`).
- Historical development database dumps containing local test data.
- Uploaded user test images.

---

## 3. Step-by-Step Deployment Procedure

### Step 3.1: Database Provisioning
1. Log in to your InfinityFree control panel (VistaPanel) or cPanel.
2. Open **MySQL Databases** and create a new database (e.g., `cityvet`).
3. Note your connection details:
   - **Hostname**: e.g., `sql123.infinityfree.com` (do not use `localhost` on InfinityFree)
   - **Database Name**: e.g., `if0_38400001_cityvet`
   - **Username**: e.g., `if0_38400001`
   - **Password**: Your hosting account password
4. Launch **phpMyAdmin** from the control panel.
5. Select your database and click **Import**.
6. Select `DATABASE/deployment_clean_schema.sql` and run the import.
7. Verify that 25 tables are created. For detailed troubleshooting, refer to `DATABASE/DATABASE_INSTALLATION_GUIDE.md`.

---

### Step 3.2: Upload Application Files
1. Open your FTP client (such as FileZilla) or use the hosting **Online File Manager**.
2. Connect using your FTP credentials:
   - Host: `ftpupload.net` (for InfinityFree) or your domain FTP host
   - Username: Your hosting account username
   - Port: `21`
3. Navigate into the document root directory:
   - On InfinityFree: `htdocs/`
   - On cPanel: `public_html/`
4. Upload all files and folders from the deployment package into the document root.
5. Confirm the root directory contains:
   - `index.html`
   - `bootstrap_admin.php`
   - `.htaccess`
   - `api/`, `config/`, `css/`, `js/`, `uploads/`, `views/`

---

### Step 3.3: Configure Production Credentials (`app_config.php`)
1. In the `config/` directory on your server, locate `app_config.sample.php`.
2. Make a copy of `app_config.sample.php` and name it `app_config.php`.
3. Open `config/app_config.php` in your editor or online file manager and populate your credentials:

```php
<?php
define('APP_ENV', 'production');
define('APP_URL', 'https://yourdomain.infinityfreeapp.com');

define('DB_HOST', 'sql123.infinityfree.com');
define('DB_USER', 'if0_38400001');
define('DB_PASS', 'YourRealDatabasePasswordHere');
define('DB_NAME', 'if0_38400001_cityvet');

define('RESEND_API_KEY', 're_your_api_key_here');
define('RESEND_FROM_EMAIL', 'City Vet <onboarding@resend.dev>');
define('SEMAPHORE_API_KEY', 'your_semaphore_key_here');
define('SEMAPHORE_SENDER_NAME', 'CITYVET');
```

4. Save the file.
5. **Security Check**: Verify that direct browser access to `https://yourdomain.com/config/app_config.php` returns **403 Forbidden** (enforced by `config/.htaccess`).

---

### Step 3.4: Run One-Time Administrator Bootstrap
1. In your browser, navigate to:
   `https://yourdomain.com/bootstrap_admin.php`
2. You will be greeted by the **City Vet — Initial Administrator Setup** screen.
3. Fill in the form:
   - **Administrator Username**: e.g., `admin`
   - **Administrator Email**: e.g., `admin@yourdomain.com`
   - **Phone Number**: (Optional) e.g., `09123456789`
   - **Password**: Enter a strong password (minimum 8 characters, at least one uppercase letter, one lowercase letter, one number, and one special character).
   - **Confirm Password**: Re-enter password.
4. Click **Create Primary Administrator**.
5. Once created, a green success confirmation screen will appear.
6. **CRITICAL POST-INSTALLATION SECURITY STEP**:
   Delete `bootstrap_admin.php` from your server root immediately via FTP or File Manager.
   *(Even if forgotten, any subsequent access will immediately return HTTP 403 Forbidden and refuse execution).*

---

## 4. Verification & Post-Deployment Checklist

Complete these checks immediately after deployment:

| # | Check Item | Expected Result |
| :--- | :--- | :--- |
| 1 | Navigate to `https://yourdomain.com/index.html` | Homepage loads cleanly with styling and login form |
| 2 | Attempt login with wrong password | Generic error message ("Invalid email or password"), rate-limit tracked |
| 3 | Log in with newly created Administrator account | Redirects seamlessly to `views/admin/dashboard.html` |
| 4 | Navigate to Master Files (`views/admin/master_files.html`) | Services, Species, Breeds list correctly from reference tables |
| 5 | Inspect Security Headers in DevTools Network tab | `X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`, `Referrer-Policy: strict-origin-when-cross-origin` |
| 6 | Direct access to `https://yourdomain.com/config/app_config.php` | Returns **403 Forbidden** |
| 7 | Direct access to `https://yourdomain.com/uploads/` | Returns **403 Forbidden** |
| 8 | Try accessing `https://yourdomain.com/bootstrap_admin.php` | File should be deleted (404); if still present, returns **403 Forbidden** |

---

## 5. Maintenance, Backup & Rollback

### Automated Request-Driven Maintenance
- **Login Rate Limits**: Old rate-limit tracking rows (>1 hour) are automatically pruned probabilistically (5% chance per login attempt). No cron job needed.
- **Session Lifetimes**: Inactive sessions (>30 minutes) and absolute session lifetimes (>8 hours) are enforced automatically on each authenticated request.

### Database Backups
To take regular backups from shared hosting:
1. Open phpMyAdmin from your control panel.
2. Select your database.
3. Click **Export** -> **Quick** -> **SQL** -> **Go**.
4. Store the exported SQL file securely offline.

### Rollback Procedure
If a deployment update needs to be rolled back:
1. Re-upload previous codebase files via FTP.
2. In phpMyAdmin, import the previous known-good database backup.
3. Verify `config/app_config.php` retains valid database credentials.
