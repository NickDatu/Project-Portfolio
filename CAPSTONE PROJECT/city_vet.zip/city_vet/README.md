# City Vet Management System

The City Vet Management System is a role-based clinical and administrative web application for veterinary offices, providing queue management, spay/neuter event booking, patient records, consultations, duty scheduling, notifications, and analytics.

---

## Roles and Access

1. **Administrator**: Full system oversight, appointment analytics, consultations, staff/vet management, species and breed catalogs, and audit logs.
2. **Veterinarian**: Shift schedule review, consultation queue examination, patient medical records, treatment recording, and appointment history.
3. **Staff**: Reception desk operations, live ticket queue, walk-in management, owner and pet records, event roster management, staff-assisted Spay/Neuter booking, and vet schedule assignment.
4. **Pet Owner**: Pet registration, upcoming and past appointments, Spay/Neuter event booking, notification center, and office policy review.

---

## Environment Configuration

Configure connection settings through environment variables or `config/database.php`:

| Variable | Description | Default |
| :--- | :--- | :--- |
| `DB_HOST` | Database server hostname | `localhost` |
| `DB_USER` | Database username | `root` |
| `DB_PASS` | Database password | `""` |
| `DB_NAME` | Database schema name | `city_vet_verify` |
| `APP_ENV` | Application environment | `development` / `production` |
| `APP_TIMEZONE` | Office timezone | `Asia/Manila` |

---

## Database Installation and Migration Order

Import database scripts in the exact sequence specified:

1. `DATABASE/deployment_clean_schema.sql` — Base table structures and standard system catalogs.
2. `DATABASE/migration_services_proper_names.sql` — Service display casing standardization.
3. `DATABASE/migration_add_otp_and_medical_fields.sql` — One-time password verification and medical history columns.
4. `DATABASE/migration_live_queue_and_medical.sql` — Queue and medical records integration.
5. `DATABASE/migration_live_queue_no_owner.sql` — Support for ownerless walk-in reception tickets.
6. `DATABASE/migration_add_mongrel_breed.sql` — Addition of Mongrel / Aspin breed options.
7. `DATABASE/migration_vet_duty_schedule.sql` — Duty schedule table for Officer of the Day imports.
8. `DATABASE/migration_consultation_catalogs.sql` — Master dropdowns for treatments and medicines.
9. `DATABASE/migration_walkin_services.sql` — Walk-in queue service restriction to exact 6 services.
10. `DATABASE/migration_restrict_species.sql` — Deactivation of non-Dog/Cat species and breeds.
11. `DATABASE/demo_data.sql` — (Optional) Demo data containing accounts for Brua, Baylo, Desuyo, Gonzales, and Enriquez with October 2026 duty schedule.

Refer to [DATABASE/DATABASE_INSTALLATION_GUIDE.md](DATABASE/DATABASE_INSTALLATION_GUIDE.md) for full import commands.

---

## Scheduled Reminder Automation (`scripts/generate_reminders.php`)

The migration sequence also includes `DATABASE/migration_consultation_template.sql` after the consultation catalog migration. It adds optional consultation findings and the data-driven Dog/Cat vaccination schedule.

The reminder generator notifies pet owners of appointments scheduled for the following day.

For existing installations, run `DATABASE/migration_notification_event_links.sql` after the consultation-template migration. It adds event links to notifications so event notices can open their associated event.

### Characteristics
- Evaluates appointments where date equals tomorrow (`CURDATE() + INTERVAL 1 DAY`).
- Idempotent: checks for prior reminder notification for each appointment ID; re-running produces zero duplicate notifications.
- Automatically triggered once per day on the first authenticated activity; a daily Linux cron or Windows Task Scheduler job is still recommended for reliable delivery.

### Command Line Execution
```powershell
php scripts\generate_reminders.php
```

### Linux Cron Configuration
To run every morning at 08:00 AM:
```bash
0 8 * * * /usr/bin/php /var/www/html/city_vet/scripts/generate_reminders.php >> /var/log/city_vet_reminders.log 2>&1
```

### Windows Task Scheduler Configuration
1. Open Windows Task Scheduler (`taskschd.msc`).
2. Create Basic Task named `CityVetAppointmentReminders`.
3. Set Trigger to **Daily** at **08:00 AM**.
4. Set Action to **Start a program**:
   - **Program/script**: `C:\xampp\php\php.exe`
   - **Add arguments**: `scripts\generate_reminders.php`
   - **Start in**: `C:\xampp\htdocs\city_vet`
5. Save and confirm the task.

---

## Demo Credentials

Password for all demo accounts: `DemoVet!2026`

- Administrator: `admin.demo@example.test`
- Staff: `staff.demo@example.test`
- Veterinarian: `vet.demo@example.test`
- Pet Owner: `alice.demo@example.test`

---

## Replaceable Visual Assets

Official branding artwork may be replaced in-place:
- `assets/logo.svg`
- `assets/favicon.svg`

Public hero carousel images:
- `uploads/hero_slides/1.jpg` — veterinary examination
- `uploads/hero_slides/2.jpg` — cat in a veterinary office
- `uploads/hero_slides/3.jpg` — veterinary examination

### Hero Photo Credits and Licenses
- Slide 1 & 3: “Ear examination of a white dog in Newark, New Jersey” and “Facial examination of a small dog resting in a padded bed in Newark, New Jersey,” by Veterinarian Pet Alliance, [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).
- Slide 2: “Iranian cat in clinic” by Mohsen Sajjadi, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/).
