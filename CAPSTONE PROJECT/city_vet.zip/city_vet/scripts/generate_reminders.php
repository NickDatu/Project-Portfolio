<?php
if (php_sapi_name() !== 'cli' && empty($_SERVER['REMINDER_ALLOW_HTTP'])) {
    http_response_code(403);
    echo "CLI only\n";
    exit(1);
}

require_once dirname(__DIR__) . '/config/db_connection.php';
require_once dirname(__DIR__) . '/api/notifications/reminder_runner.php';

$targetDate = $argv[1] ?? date('Y-m-d', strtotime('+1 day'));

$summary = cityVetRunReminderBatch($conn, $targetDate, 100);
$processed = $summary['processed']; $created = $summary['created']; $skipped = $summary['skipped'];
$now = date('Y-m-d H:i:s');
echo "[{$now}] Target date: {$targetDate}. Processed: {$processed}, Created: {$created}, Skipped: {$skipped}.\n";
exit(0);
